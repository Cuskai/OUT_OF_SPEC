# OUT OF SPEC — Stage 2.6 Composable Casting Model Foundation

## Scope of this increment

This increment adds a pure-Java, game-independent **data-model and registry foundation** to the Stage 3.8 Binding Contracts source project. It is deliberately not the runtime implementation of the full seal system.

It does not select V202 as a base project and does not edit any provided baseline ZIP/JAR. It also does not wire keyboard events, packets, SAO HUD, Epic Fight animation, recipe data files, progression, actual spell executors, or the unified numeric effect calculator. Those require a later explicitly scoped integration step.

## Model boundaries

- `BasicSeal`: twelve stable semantic IDs (`zi`, `chou`, `yin`, `mao`, `chen`, `si`, `wu`, `wei`, `shen`, `you`, `xu`, `hai`). Suggested keys are metadata only. Actual Minecraft key mappings must be rebindable and are not part of this model.
- `SealSequence`: immutable ordered sequence, canonicalized by semantic IDs rather than physical key names. Length is limited to 32 for input/protocol safety, not game balance.
- `SpellRecipe`: stable recipe ID, real spell ID, basic-seal sequence, inter-seal timeout, and declared mobility policy.
- `AdditionalSealDefinition`: stable ID, sequence, compatible recipe IDs, requirements, incompatibilities, occurrence limit, tier, composition mode, optional special-executor ID, and typed effect contributions.
- `EffectContribution`: source, owner, target spell scope, parameter, operation, unit, and numeric value. The unit/operation table rejects semantically mismatched combinations before the runtime calculator sees them.
- `CastingRecipeRegistry`: mutable only during bootstrap. `freeze(...)` validates references, compatible recipe scopes, duplicate sequence ambiguity, contradictory requires/conflicts rules, and whether every special executor ID is supplied by a concrete executor registration.
- `CastPlanRequest`: an untrusted selection-only request with request ID, recipe ID, and selected additional-seal IDs. It deliberately contains no caster identity, active-contract list, or effect values.
- `ServerBindingSnapshot`: an internal object that must be built from the server's active/persisted contract state. It must never be decoded from a client packet.
- `ServerCastContext`: trusted server context containing the actual packet sender's UUID, the server-derived binding snapshot, and server game tick. The network handler must create this from Minecraft's authenticated sender, not copy a submitted UUID.
- `ResolvedCastPlan`: immutable result produced after registry-level validation, with selected additions, applied effects carrying source provenance, server tick for diagnostics, and a stable SHA-256 fingerprint.

## Resolver behavior

`CastPlanResolver` currently performs *model-level* validation:

1. Requires a frozen registry and a known base recipe.
2. Rejects unknown/incompatible additions and repeats beyond the definition's declared limit.
3. Verifies required additions are present and conflicting additions are absent.
4. Builds effects from registered addition definitions; clients cannot provide those values in `CastPlanRequest`.
5. Accepts binding effects only through the separate server snapshot, rejects a non-binding source on that channel, requires the owner to exist in the server snapshot, rejects duplicate contribution IDs, and applies only global or matching-spell scopes.
6. Produces one immutable, fingerprinted plan.

The caller must still do game-state checks not represented here: player unlock state, target validity, current mana/cooldowns, active casting preparation, contract lifetime/trigger state, server transaction/idempotency ledger, and the actual Iron's Spells cast-initiation API. The model is not authority by itself; server-side integration must perform those checks before execution. The fingerprint is a deterministic plan identity, not yet an implemented transaction ledger: the same request ID with changed content must be rejected by a future server idempotency store.

## Effect value semantics

The initial typed parameter set includes damage, area radius, projectile count, flight speed, cast-window movement speed, duration, piercing, mana cost, cooldown and cast time. `MULTIPLY` stores a **factor**, not a natural-language percentage delta. For example, a factor of `4.0` means multiply the selected parameter by four; a user statement “increased by 300%” must be translated by the rule engine to that factor, whereas “increased to 300% of base” means a factor of `3.0`. That language conversion is not performed by this model package.

Zero multipliers are representable when a real effect's semantics allow full suppression (for example, a movement multiplier of zero); negative multipliers are rejected. A future unified effect calculator must enforce parameter-specific safe ranges, total damage/coverage budgets, and server-performance budgets. Those checks are not claimed implemented by this model increment.

## Resolution and ambiguity rules

- Exact duplicate base sequences are rejected during registration. Prefix overlaps are allowed and are reported as `EXACT_AND_PREFIX` so UI/input code can ask the player to confirm or continue.
- Additional sequences can be reused in different recipe contexts, but the same exact sequence cannot identify two additions for the same recipe.
- Additional-seal IDs are stable and independent from their current key sequence, so changing key mappings/sequences does not inherently mutate saved contract references.
- `INDEPENDENT_EFFECTS` is metadata for commutative parameter contributions; `SPECIAL_EXECUTOR` must reference an executor that the bootstrap actually registers. A string alone is not treated as an implementation.

## Follow-up increment

Stage 2.7 now adds a pure-Java `SealInputSession` state machine; see `STAGE_2_7_SEAL_INPUT_STATE_MACHINE.md`. Stage 2.8 now supplies rebindable Minecraft key mappings and key-down/key-up forwarding for a diagnostic-only input HUD. It intentionally does not send real cast packets or dispatch real effects. Remaining work includes integration with actual registered spell recipes, server-side player unlock/target/mana/cooldown checks, real `AdditionalSealExecutor` registrations, the unified final effect calculator and a durable anti-duplication transaction ledger. This isolated branch still needs a successful Forge build and Minecraft test before its client adapter can be considered runtime-verified.

## Validation boundary

- Pure Java model assertions and source audits are part of this increment.
- The existing Stage 3.8 contract judge remains separate and is tested for regression.
- Full ForgeGradle build, Mixin transformation, Ollama runtime, multiplayer, keyboard input, actual additional-seal effects, Epic Fight animation and in-game behavior are **not** verified by this increment.

The routine test command performs baseline SHA-256 and archive CRC checks. The project-merger test that rewrites and reads back the entire bundled Stage 1.1 JAR is available as an opt-in deep check because it can be slow on CPU-limited environments: set `OUT_OF_SPEC_DEEP_PACKAGE_TEST=1` before running the validator. The same merger fixture was successfully exercised for this Stage 3.8 branch before the model-only files were added; those files do not alter merger code or baseline contents.
