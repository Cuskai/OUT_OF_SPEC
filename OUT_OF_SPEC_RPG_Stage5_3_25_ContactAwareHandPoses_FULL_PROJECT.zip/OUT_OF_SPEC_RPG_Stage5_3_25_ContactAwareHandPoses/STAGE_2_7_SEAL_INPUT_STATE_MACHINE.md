# OUT OF SPEC — Stage 2.7 Seal Input State Machine

## Scope

Stage 2.7 adds a pure-Java input-session state machine on top of the Stage 2.6 typed model/registry. It remains the pure-Java core in the Stage 3.8 contract project. It does not select V202 or edit a baseline ZIP/JAR. Stage 2.8 supplies a client-side adapter, test-only recipe catalog and diagnostic HUD around this state machine.

## State machine

`SealInputSession` moves through `IDLE → BASE_INPUT → ADDITIONAL_INPUT → VALIDATING → CASTING → IDLE`. It only accepts physical key-down edge callbacks supplied by a future platform adapter; a duplicate key-down while the same seal is still held is ignored until a matching key-up arrives.

- The default inter-seal timeout is 800 ms and is configurable within the already defined 100–5000 ms safe range. For an active prefix, the shortest timeout among all still-possible recipes governs the next input.
- Exact/prefix ambiguity requires explicit confirmation. Confirming an exact match selects it even if a longer recipe shares its prefix; continuing input can select the longer recipe.
- Timeouts clear only the unconfirmed sequence and never auto-cast. Pressing a new seal after a gap over the timeout starts a new sequence.
- Backspace removes the last unconfirmed seal, preserving the true timestamp of the new final seal; with an empty sequence in the additional phase it removes the last selected addition.
- Additional-seal confirmation checks recipe scope, occurrence limits, and declared conflicts. The draft cannot be submitted while its current sequence is unconfirmed or required additions are missing. The server resolver must still repeat all checks.
- `submitCast` creates a selection-only `CastPlanRequest`; it contains no caster UUID, binding list or effect values. A future network adapter must derive actual sender identity and contract state from server context.
- Only a validation response for the exact pending request ID can change the pending session to accepted/recoverable-rejected/terminal-rejected. A local cancel cannot undo a submitted request or active cast, and stale cast-end events are ignored.
- The maximum sequence length remains the Stage 2.6 safety bound of 32; overflow clears the unconfirmed sequence instead of truncating it into a possible spell.

## What this increment does not do

This is not real keyboard handling. It has no Minecraft/Forge imports and does not implement keybinding reconfiguration, UI/HUD rendering, input capture priority against other mods, packets, server player-state checks, mana/cooldown consumption, the actual Iron's Spells cast API, spell executor/extra-seal effects, transaction idempotency storage, Epic Fight animation, unlock progression, or contract execution hooks. A real host-project integration is still required after explicitly choosing the base project.

## Validation

- The original 88 Stage 3.8 binding-contract assertions remain in the regression suite.
- Stage 2.6 retains 84 data-model/registry assertions.
- Stage 2.7 adds 54 pure-Java input-session assertions for edge deduplication, prefix confirmation, additional-seal composition, timeout, backspace, requirements/conflicts, submit/validation response isolation, recoverable/terminal failure, cancellation boundaries and sequence overflow.
- The model and input-session sources compile with `javac --release 17 -Xlint:all` with no warnings in this environment.
- The normal project validator checks resource JSON, expanded TOML, Java 17 build configuration, baseline SHA-256 and ZIP CRC. Its full archive-rewrite fixture is opt-in with `OUT_OF_SPEC_DEEP_PACKAGE_TEST=1`; a previous run on this branch's unchanged merger tool and baseline passed.
- Gradle/ForgeGradle are unavailable here; no full Forge compile, Minecraft launch, Mixin transformation, keyboard integration or gameplay test is claimed.
