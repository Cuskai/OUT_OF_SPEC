# Stage 2.8 — In-game Seal Input Diagnostic HUD

## Goal

Make the current Stage 2.7 input state machine observable in a real Minecraft client before wiring real spell executors. The diagnostic HUD shows what was actually recorded, which recipe matches, whether the current sequence is a full match or longer-recipe prefix, selected additional seals, and the last input/validation feedback.

## Added files

- `cn.blockforge.outofspec.spellcraft.model.SealInputTestRecipes`: explicit diagnostic-only registry with four base test recipes and five additional-seal definitions. Every spell ID uses `debug_` and must not be sent to an Iron's Spells executor.
- `cn.blockforge.outofspec.binding.client.SealInputDebugKeyMappings`: rebindable controls and twelve basic-seal key mappings registered under the OUT OF SPEC RPG Controls category.
- `cn.blockforge.outofspec.binding.client.SealInputDebugClient`: key-down/key-up adapter, client tick lifecycle, timeout feedback and top-left `RenderGuiEvent.Post` HUD. It intentionally produces only a local selection request and simulates the platform-neutral session lifecycle for diagnostics; it does not submit a Forge packet or call a spell executor.
- `cn.blockforge.outofspec.binding.mixin.client.SealInputKeyIsolationMixin`: redirects Minecraft's `KeyboardHandler` `KeyMapping.click` / `KeyMapping.set` calls, suppressing competing KeyMappings for a seal key only while the seal-input phase is active. Other key mappings resume normally once input ends.
- `tests/java/SealInputTestRecipesHarness.java` and `tests/check_seal_debug_hud.py`: additional pure-Java recipe assertions and client/source/configuration invariants.

## Controls (all are rebindable)

- `K`: begin a base-seal input session.
- `O`: confirm the exact base recipe, or confirm the current additional-seal sequence.
- `Enter`: create a local diagnostic selection request, run the local input-session lifecycle simulation, and return to idle. This is not server acceptance or a real cast.
- `Backspace`: remove the last unconfirmed seal; if the sequence is empty in the additional phase, remove the most recently selected addition.
- `P`: cancel the unsubmitted draft.
- `F8`: hide/show the HUD.
- Basic seals: `Z X C V B N F G H R T Y` → 子 丑 寅 卯 辰 巳 午 未 申 酉 戌 亥.

## Diagnostic recipes

Base sequences:

- `Z → X`: `诊断术式·青焰弹`.
- `Z → X → C`: `诊断术式·青焰爆发`. The first sequence is intentionally also the prefix of this longer recipe, so the HUD should report the full match plus the longer option.
- `C → V → B`: `诊断术式·震荡环`.
- `X → N → Y`: `诊断术式·裂光矢`.

Additional-seal sequences, after confirming a base recipe:

- `F`: `范围微调`, preview only, area factor 1.25.
- `F → G`: `范围扩展`, preview only, area factor 1.75. `F` is also an exact+prefix ambiguity here.
- `H → R`: `分裂结构`, preview only, projectile count +2. Compatible with the three projectile-oriented diagnostic recipes.
- `T → Y`: `弹道加速`, preview only, flight-speed factor 1.25.
- `R → T`: `持续时间延长`, preview only, duration factor 1.5; compatible with the ring and burst diagnostic recipes.

These numeric values are stored as typed test contributions to confirm registry/input selection only. No visual projectile, damage, range, actual duration, mana, cooldown or binding effect is applied.

## In-game test steps

1. Build the full source project with JDK 17 and Gradle 8.x with working ForgeGradle dependency access: `gradle clean build`.
2. Install only the resulting merged Stage 3.8 JAR from `build/libs`. Do not install the standalone intermediate add-on JAR alongside it or install another copy of the included Stage 1.1 baseline.
3. Enter a world. The HUD should appear at the top-left by default. Press `K`; the state should change to base input.
4. Press `Z`, then `X`, observing the entered seal sequence and the exact/longer candidate match. Press `O`: the base recipe should lock and state should change to additional input. Alternatively continue with `C` before confirming to choose the longer burst recipe.
5. Press `F`, observe the exact+prefix additional match, press `O` for small range; or press `F → G` then `O` for range extension. Other examples: `H → R`, `T → Y`, `R → T`, each followed by `O`.
6. With no unconfirmed sequence, press `Enter`. The HUD should record the selected test recipe/additions and say local input check passed. It should return to idle. No server request, real cast, mana payment or binding effect should occur.
7. Test timeout by entering one seal and waiting longer than 800 ms before the next. The partial sequence should clear and no cast should occur. Test Backspace, `P`, and `F8` as well.
8. If another mod hotkey reacts during a seal session, keep a copy of `logs/latest.log`, note the key/control binding, and report whether the key-isolation Mixin applied. The Mixin currently targets standard Minecraft KeyMapping dispatch; it does not claim to block every third-party mod that directly listens to raw keyboard events.

## Validation results in this environment

- 88 Stage 3.8 contract assertions passed in the most recent complete prior regression run; no contract classes or original binding execution code were edited for this stage.
- 84 Stage 2.6 model assertions and 54 Stage 2.7 input-session assertions pass.
- 36 new diagnostic recipe assertions pass.
- `javac --release 17 -Xlint:all` succeeded with zero warnings when compiling the pure Java model, diagnostic recipes, and client adapter/mixin against API-shaped Minecraft/Forge/Mixin stubs. This is only a syntax/API-shape check, not the real Forge compiler.
- Static source audit and JSON/TOML validation pass; the bundled Stage 1.1 baseline hash remains unchanged.
- **Not performed:** full ForgeGradle build; Mixin application; launching Minecraft; real keyboard/render validation. Gradle is not installed in this environment and downloading the Gradle distribution failed. Treat this as a complete source project requiring a real Forge build and in-game test, not a Forge-compiled artifact.
