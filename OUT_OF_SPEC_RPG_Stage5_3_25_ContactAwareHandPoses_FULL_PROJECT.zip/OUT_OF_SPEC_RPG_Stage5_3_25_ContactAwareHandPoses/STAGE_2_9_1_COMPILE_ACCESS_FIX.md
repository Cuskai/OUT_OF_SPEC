# Stage 2.9.1 Compile Access Fix

## Reported failure
Windows `gradle clean build` failed at `compileJava` because `SealCastingLifecycleEvents` (package `cn.blockforge.outofspec.binding`) called `SealCastingNetwork.forgetPlayer(UUID)`, but the method was package-private in `cn.blockforge.outofspec.binding.network`.

## Change
`SealCastingNetwork.forgetPlayer(UUID)` is now `public static synchronized`. The existing session cleanup behavior is unchanged. The HUD source-audit test now protects the cross-package API visibility and verifies that the logout handler still calls it.

## Verification
- `tests/run_judge_tests.sh`: exit code 0 after the fix.
- Four pure-Java harnesses and all default source/config audits passed.
- No full ForgeGradle build was available in this environment. Re-run `gradle clean build` on Windows to confirm the reported compile error is resolved and identify any subsequent errors.
- The two `ResourceLocation(String, String)` warnings are unrelated deprecation warnings and did not cause the reported failure.
