# Stage 2.9.1 — Real Seal-Cast Integration Compile Access Fix

## Goal

Replace Stage 2.8's live diagnostic registry with a small, explicit first set of real Iron's Spells recipes while preserving the HUD and input state machine. Only effects with a real executor are selectable in the live registry.

## Registered base recipes

- `ZX` → `irons_spellbooks:magic_arrow`
- `ZXC` → `irons_spellbooks:firebolt`
- `CVB` → `irons_spellbooks:lightning_lance`
- `XNY` → `irons_spellbooks:fireball`

`ZX` is deliberately a prefix-ambiguous sequence. A single `O` after `ZX` chooses Magic Arrow; continue with `C` and confirm to choose Firebolt.

## Registered additional seals

- `F` → ×1.20 on the value returned by Iron's Spells `AbstractSpell#getSpellPower` for the current real cast.
- `FG` → ×1.35 on that same calculation.

They are mutually incompatible, cannot repeat, and are the only additions in the live registry. They do not claim to directly multiply all final damage. Other effects (range, split projectiles, speed, duration) remain absent from the live registry until real server-side executor code is added.

## Server path

1. Client submits only a request UUID, registered recipe ID and ordered additional-seal IDs.
2. Server deduplicates request UUIDs, builds its own caster/binding context and resolves `ResolvedCastPlan`.
3. Server checks the registered spell is enabled, not permanently sealed, available and unlocked in the player's active spellbook/hand/Curios spell selection, plus existing binding preparation conditions.
4. Server installs cast-local additional-seal effect state and calls the real `AbstractSpell#attemptInitiateCast` with the selected option's actual level/source/slot. This mirrors Iron's Spells' own selected-option call path; native `canBeCastedBy`, learnability, mana/cooldown, `SpellPreCastEvent`, effective cast time and casting-state packet path remain in control.
5. Existing Stage 3.8 Mixin/event hooks retain ownership of binding effects; `SealedCastEffectState` executes only `ADDITIONAL_SEAL` `SPELL_POWER/MULTIPLY/MULTIPLIER` contributions, so binding effects aren't double-applied.
6. `AbstractSpell#getSpellPower` applies the cast-local multiplier only to the matching spell ID. State is cleared when the real `castSpell` method returns or the active cast is interrupted. Server terminal responses are queued until the end of the server tick so an immediate spell cannot send a completion packet ahead of the initial acceptance packet.
7. Client responses must match the current request ID. World unload clears client pending state and held keys; stale later responses cannot revive it.

## Added regression coverage

- 34 pure-Java assertions for the real spell registry, spell IDs, exact and prefix matches, additional-seal values/source, compatible and conflicting selections, resolver effects and unknown-recipe/addition rejection.
- Four additional input-session assertions for disconnect cleanup, clearing held keys and rejecting late validation for an unloaded world.
- Static source audit checks that the live HUD uses `RealSealCastingRecipes`, submits over the separate cast channel, server selects an actual spell option, only supported addition effects are accepted, and cast-local state gets cleaned up.

## Baseline bytecode audit

An additional opt-in check (`python tests/check_spell_power_baseline.py`) runs `javap` against the bundled Stage 1.1 baseline JAR. It confirms that Magic Arrow, Firebolt, Lightning Lance and Fireball call `AbstractSpell#getSpellPower`, and that the baseline exposes the expected selected-option initiation/execution API signatures. This is bytecode/source-API evidence only; it does not prove runtime Mixin application or successful Minecraft casting.

## Validation boundary

The pure Java recipe/model assertions and static source/configuration checks can validate registration and flow invariants only. They do not compile the Forge sources against the full ForgeGradle mappings, prove that all Mixin injections apply at runtime, test an actual networking connection, or prove the chosen four spell implementations all consume `getSpellPower` in the expected way at runtime in Minecraft. Stage 2.9 needs a Forge build and a test-world run to verify that boundary.


## Stage 2.9.1 compile-access fix

A Windows ForgeGradle `compileJava` run found that `SealCastingLifecycleEvents` called `SealCastingNetwork.forgetPlayer(UUID)` from the parent `cn.blockforge.outofspec.binding` package while the method was package-private in `cn.blockforge.outofspec.binding.network`. The method is now `public static synchronized`, and `tests/check_seal_debug_hud.py` explicitly asserts this cross-package API visibility. The cleanup operation and its session-scoped semantics are unchanged.

This fixes the reported compiler error in source, but a new Windows `gradle clean build` must still confirm whether any subsequent compiler errors remain. The two `ResourceLocation(String, String)` warnings are separate deprecation warnings and are not the cause of the previous failure.
