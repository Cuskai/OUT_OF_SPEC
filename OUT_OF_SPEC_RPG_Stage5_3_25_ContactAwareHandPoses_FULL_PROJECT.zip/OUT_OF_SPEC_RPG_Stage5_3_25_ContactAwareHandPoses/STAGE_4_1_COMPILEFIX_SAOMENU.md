# Stage 4.1 — Compile fix and SAO Menu integration

## Fix for the user's Gradle `compileJava` failure

`GrimoireCastRequest` is a private static class with `firstSpellId` and `secondSpellId` fields; it is not a Java `record` and therefore has no generated `firstSpellId()` / `secondSpellId()` accessors. The server handler now reads `packet.firstSpellId` and `packet.secondSpellId`, fixing all six reported symbol errors in `SpellGrowthNetwork.java`.

The four deprecation/removal warnings in the user's log are not fatal and are independent of these compile errors. They were not changed by this hotfix.

## SAO Menu integration

- `SAOSkillBindingMenuMixin` now adds localized entries for the Research Archive, Growth Terminal, Seal Codex and Arcane Grimoire Terminal in the same SAO Menu skills submenu used by the Binding Contract terminal.
- Each entry opens its existing `SpellGrowthScreen.Mode`; it does not create extra global `I / L / U` keybindings.
- The growth screen retains the SAO Menu instance as its parent. Closing the screen or pressing Esc returns to SAO Menu.
- Right-click use of the optional Arcane Grimoire remains a direct item route to its configuration screen.
- Existing Binding Contract menu handling is retained in the same mixin, avoiding two separate injections competing to rebuild the same menu node.

## Validation performed after this change

- Pure Java regression harnesses and source audits: PASS.
- Resource JSON / localization JSON validation and `mods.toml` parsing: PASS.
- Bundled Stage 1.1 rollback baseline SHA-256 and ZIP CRC check: PASS.
- Full ForgeGradle compilation, reobfuscation and Minecraft runtime testing: not performed in this environment because no Gradle executable or project wrapper is available here. Re-run `gradle clean build` in the user's Windows project before installing the resulting JAR. SAO Menu item labels and Mixin behavior must still be confirmed in-game.

## Local Windows use

Apply the patch to the current Stage 4 project (or use the included full-project archive), then execute `gradle clean build`. Expected output file remains:

`build\libs\OUT_OF_SPEC_RPG_IronSpell_SAO_BindingContracts_Stage4_SpellGrowth.jar`
