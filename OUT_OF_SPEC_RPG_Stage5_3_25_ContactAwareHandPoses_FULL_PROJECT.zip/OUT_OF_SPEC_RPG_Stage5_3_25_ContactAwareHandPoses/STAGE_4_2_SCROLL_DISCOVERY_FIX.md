# Stage 4.2 — Superseded by Stage 4.3

Stage 4.2 only repaired detection for OUT OF SPEC's own `SpellScrollItem` class. It did not support native Iron's Spells `io.redspace.ironsspellbooks.item.Scroll`, whose per-scroll spell ID is stored inside the `ISpellContainer` NBT. That was an incomplete fix.

Use the Stage 4.3 patch instead. It resolves native scroll embedded IDs, scans inventory at server tick/login/snapshot time, consumes the exact matching scroll, and adds `/oosgrowth diagnose` for server-side confirmation.
