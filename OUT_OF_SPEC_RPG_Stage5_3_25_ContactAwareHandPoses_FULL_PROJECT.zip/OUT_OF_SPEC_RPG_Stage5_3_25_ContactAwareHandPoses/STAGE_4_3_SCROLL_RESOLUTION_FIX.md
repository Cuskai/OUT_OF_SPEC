# Stage 4.3 — Scroll Resolution and Discovery Fix

## Root cause found

The previous Stage 4.2 fix still checked only the custom `SpellScrollItem` class and `SpellGrowthItems.scrollForSpell(...)` registry item. Iron's Spells uses one native `io.redspace.ironsspellbooks.item.Scroll` item ID for scrolls; the actual spell is embedded in `ISpellContainer` NBT. Therefore the earlier patch could not recognize normal Iron's Spells spell-scroll drops, count them in the research UI, or consume one during research.

## Changes

- Added `SpellScrollResolver` to resolve the embedded ID from native `ISpellContainer` data or the custom OOS scroll's fixed profile.
- Reworked research inventory count and consumption to match by resolved spell ID, so the study consumes one scroll for the selected spell, regardless of supported source.
- Added server-side discovery routes on item pickup, player login, one-second inventory reconciliation and research snapshot requests. The custom scroll's inventory tick remains an additional fallback.
- Added `/oosgrowth diagnose` for the executing player without OP permission in the current follow-up. It prints candidate scroll item registry IDs, item class, embedded spell ID, support decision, each supported spell's count and persisted discovered/learned flags. This also helps identify a stale JAR or a different third-party scroll item.
- Updated the research UI text so it no longer claims native Iron's Spells scrolls are unsupported. A blank generic `irons_spellbooks:scroll` stack with no spell container is correctly treated as blank, not as a spell scroll.

## In-game verification

1. Build using `gradle clean build`; only install the merged JAR at `build\libs\OUT_OF_SPEC_RPG_IronSpell_SAO_BindingContracts_Stage4_SpellGrowth.jar`. Remove old duplicate Stage 4 JARs from `mods` first.
2. Give a deterministic custom scroll: `/give @s out_of_spec_binding:scroll_firebolt 1`. It should discover Firebolt.
3. Give an actual native spell-bearing scroll using Iron's Spells' command: `/createScroll irons_spellbooks:firebolt 1`. (Do not use a plain `/give @s irons_spellbooks:scroll 1`; without embedded spell data that is just a blank scroll.) It should also discover Firebolt.
4. With either scroll in inventory, run `/oosgrowth diagnose` as the player carrying the scroll; OP permission is not required. Expected catalog line: `irons_spellbooks:firebolt | matchingScrolls=1 | discovered=true | learned=false` for a one-scroll test with no other matching scrolls. The diagnostic also identifies which item is installed and what spell ID it carries.
5. Open SAO Menu → Skills → 术式研究档案 and verify Firebolt appears with `卷轴库存：1`; study it. Exactly one matching scroll should be consumed, and a successful or failed research result should be reported.

## Validation boundary

The pure Java/source audit and existing model regression suite can check source consistency, but they cannot instantiate Minecraft ItemStacks or verify Forge event bus runtime behavior. ForgeGradle compilation and in-game validation must still be run with the supported 1.20.1 Forge setup.
