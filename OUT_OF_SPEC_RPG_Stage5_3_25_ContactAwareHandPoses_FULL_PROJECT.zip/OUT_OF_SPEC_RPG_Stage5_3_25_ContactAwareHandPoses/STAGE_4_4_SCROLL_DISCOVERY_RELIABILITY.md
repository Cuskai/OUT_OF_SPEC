# Stage 4.4 — Scroll Discovery Reliability and Runtime Diagnostics

Release marker: `OUT_OF_SPEC_STAGE_4_4_0.5.3` (metadata version `0.5.3`)

## Why the previous diagnostic was insufficient

Stage 4.3 gated `/oosgrowth diagnose` behind permission level 2. A non-operator could therefore see the command as unknown even when the class had registered. That prevented the very runtime check intended to distinguish a missed scroll from a stale or incorrectly loaded JAR.

This stage removes that gate for read-only, self-inventory diagnostics. Growth events are also registered explicitly from the main mod constructor rather than relying only on annotation scanning.

## Reliability changes

- Register the static Forge event handler class explicitly once from `BindingCastingMod`; the old `@Mod.EventBusSubscriber` annotation was removed to avoid double registration.
- Add player-accessible `/oosgrowth`, `/oosgrowth help`, `/oosgrowth version`, `/oosgrowth scan`, and `/oosgrowth diagnose` commands. They inspect only the executing player's data, and do not change gameplay state except that `scan` performs the same legitimate idempotent discovery reconciliation as the ordinary tick path.
- Print `OUT_OF_SPEC_STAGE_4_4_0.5.3` in chat at login and from the `version` command. If this marker is absent and the commands do not exist, the running game did not load this build.
- Resolve native Iron's Spells scrolls using `ISpellContainer` first, then fall back to parsing the modern `irons_spellbooks:spell_container` or legacy `ISB_Spells` CompoundTag. The fallback reads the `data` list's spell ID fields and canonicalizes unqualified IDs into the Iron's Spells namespace.
- Recognize the native item by its class *or* its exact registry key `irons_spellbooks:scroll`, so a class-identity mismatch does not instantly reject a spell-bearing scroll.
- Pickup events inspect both the event stack and the post-pickup inventory; login, server inventory scans and research-snapshot requests remain as redundant reconciliation paths.
- Diagnostics include inventory, armor and offhand candidate stacks and report item ID, item class, embedded spell ID, catalog support, matching stack count and saved discovered/learned flags.
- Metadata version is bumped from `0.5.2` to `0.5.3` to make an old build easier to distinguish.

## Test procedure after build

1. Remove every older OUT OF SPEC Stage 4 JAR from the active Minecraft instance's `mods` directory.
2. Build this full project with `gradle clean build`.
3. Install only `build/libs/OUT_OF_SPEC_RPG_IronSpell_SAO_BindingContracts_Stage4_SpellGrowth.jar`.
4. Enter a world. The login chat should contain `OUT_OF_SPEC_STAGE_4_4_0.5.3`.
5. Carry a native spell-bearing scroll or an OOS scroll in the normal inventory, then run `/oosgrowth version`, `/oosgrowth scan`, and `/oosgrowth diagnose`. No OP permission should be needed.
6. Open SAO Menu → Skills → Spell Research Archive and check for Firebolt plus its exact scroll count. Research should consume exactly one scroll whose embedded spell ID matches Firebolt, not an unrelated scroll.

## Validation boundary

Source regression/model tests and the JAR merger fixture can pass without launching Minecraft. They cannot prove Forge event execution, server/client packet timing, actual inventory stack NBT or SAO Menu mixin behavior. This package is a full source project, not an installation-ready JAR; the local Gradle build and in-game verification remain required.
