# Stage 4.5 — Native Spell Registry Adaptation and Three Iteration Passes

Version marker: `OUT_OF_SPEC_STAGE_4_5_0.5.4` / metadata version `0.5.4`.

## Goal

Replace the four-spell-only Stage 4 growth list with a live registry-backed catalog so the original Iron's Spells spells can enter scroll discovery, research, seal casting, growth, codex and Grimoire selection without per-spell hard-coded entries. Preserve the original Stage 1.1 baseline and previously implemented Binding Contract / seal input work.

## Iteration 1 — catalog and identity correctness

- Enumerate `SpellRegistry.REGISTRY.get().getValues()` at common setup and refresh on server start.
- Retain curated sequences for the four earlier real spell recipes: Magic Arrow `ZX`, Firebolt `ZXC`, Lightning Lance `CVB`, Fireball `XNY`.
- Generate deterministic, unique four-seal sequences for the other registered spells. Avoid reserved legacy sequences and prefix collisions so a generated recipe cannot intercept an existing curated short sequence.
- Encode the full namespaced spell ID into profile keys unambiguously instead of normalizing punctuation to underscores, which could collide across mod namespace/path combinations.
- Fixture result: 130 registered test profiles including utility/healing/shield examples, a disabled entry, 120 synthetic spell IDs, and deliberate namespace collision pairs. Catalog test: 421 assertions passed.

## Iteration 2 — full link and UI state consistency

- Dynamic real `SpellRecipe` construction maps each generated recipe to the original registered `irons_spellbooks:<path>` spell and executor.
- Recipe lookup is rebuilt when catalog generation changes; the key-input session reloads when the generation changes instead of retaining a static four-item table.
- Ensure research/codex/growth/grimoire lists can navigate more than a small fixed set of spells by supporting paging/scrolling and display positions.
- Treat native-disabled spells as disabled in UI/server operations; don't let them continue to a level-up/breakthrough/cast configuration path.
- Allow release-based challenge progress for utility, healing and movement spells rather than relying only on direct damage.
- Real recipe harness: every one of the 130 fixture profiles points to its matching real spell ID and exact sequence; 554 assertions passed. UI and source audit passed.

## Iteration 3 — event timing and progression correctness

- Confirmed from the bundled Iron's Spells baseline API/bytecode that `SpellOnCastEvent` is posted before the original `onCast` implementation executes. Awarding proficiency on that event would grant progress before a successful cast and could double count with the Mixin return hook.
- Changed that event to handle pre-cast adjustments only. Proficiency and successful-release challenge progress are awarded once from the actual `AbstractSpell.castSpell` return hook.
- Challenge progress tracks hit and successful release evidence without double-counting a single release. This gives non-damaging spells a path through the same growth progression.
- Sequence stress harness: 500 synthetic IDs, deterministic by sorted registry input, four-seal length, all unique, no adjacent repeat, and no prefix overlap with curated recipes; 4,502 assertions passed.

## Final verification run

Command:

```bash
OUT_OF_SPEC_DEEP_PACKAGE_TEST=1 bash tests/run_judge_tests.sh
```

Result: exit code `0`.

Key outputs:
- 421 dynamic catalog/profile assertions passed across 130 test profiles.
- 4,502 generated sequence stress assertions passed.
- 88 binding/contract assertions passed.
- 138 composable casting model/input assertions passed.
- 44 diagnostic recipe assertions passed.
- 554 real seal-casting recipe assertions passed, including complete 130-profile recipe-to-spell mapping.
- Stage 3.8 / Stage 2.6–2.9 / Stage 4.5 source audits passed.
- 12 resource JSON files and expanded `mods.toml` parsed.
- Baseline SHA-256 unchanged: `ebb72ec47f22b64fbac3ab58ff96f9d0df5fe276638bb3cb57bf3b1832fd1fda`.
- JDK-only merger fixture passed: merged registration entries survived and baseline payload entries remained byte-identical.

## Validation boundary

This was source-level and fixture validation. The environment has no Gradle executable or project wrapper, so no complete ForgeGradle `clean build`, reobfuscation, dedicated server launch, or Minecraft in-game validation has been performed. The 130/500 counts are stress fixtures, not a claim that a real running client has exactly that many spells. The live game catalog is derived from the runtime Iron's Spells registry (the bundled baseline API declares 112 registry-object handles); installed integrations can add or disable entries.

After building on Windows, install only the merged Stage 4 artifact, remove older duplicate OUT OF SPEC JARs, confirm `/oosgrowth version` prints `OUT_OF_SPEC_STAGE_4_5_0.5.4`, then use `/oosgrowth scan` and `/oosgrowth diagnose` on the native scrolls. The runtime registry count and each inventory item's embedded spell ID should be visible there. Follow up with a real test of every enabled native spell, disabled spells, research consumption, level/branch effects, SAO Menu navigation, Grimoire and old Binding Contracts.
