# Stage 4.6.1 — Compile repair and complete AI transcript

Build marker: `OUT_OF_SPEC_STAGE_4_6_1_0.5.6`; mod metadata version: `0.5.6`.

## Fixes

1. `SealInputDebugClient` now declares the `feedback` field referenced by the HUD, input-state result handling, and status coloring. The duplicate `compact(String, int)` helper was removed, leaving the single null/blank-safe implementation.
2. `BindingContractScreen` renders the complete AI analysis/alternative within a scissored viewport. Mouse-wheel scrolling moves through all wrapped lines; an engraved scrollbar appears only when more lines exist than fit.
3. AI request elapsed time is rendered while the request is pending; the completed request keeps its elapsed duration visible. Leaving the screen does not cancel a request, while editing the intent still invalidates its stale response.
4. Source audits now guard against the missing field and duplicate helper regressions. The Windows batch test runner also invokes the Stage 4.6.1 UI source audit.

## Regression results

- `bash tests/run_judge_tests.sh`: exit `0`, 315 `PASS` records, zero `FAIL`/`ERROR` records.
- `OUT_OF_SPEC_DEEP_PACKAGE_TEST=1 bash tests/run_judge_tests.sh`: exit `0`, 316 `PASS` records, zero `FAIL`/`ERROR` records.
- Full output is stored in `STAGE_4_6_1_AUTOMATED_TEST_RUN.txt` and `STAGE_4_6_1_DEEP_AUTOMATED_TEST_RUN.txt`.
- The deep package fixture compiled and exercised `Stage11JarMerger` against a disposable synthetic addon archive; the actual bundled baseline remains unchanged.

## Verification boundary

There was no `gradle` executable, project wrapper, or network access in the edit environment. Therefore the reported Windows failure is repaired in source, but ForgeGradle compilation/reobfuscation and Minecraft in-game behavior remain **unverified** until `gradle clean build` and a live test are run on the user's Windows setup.
