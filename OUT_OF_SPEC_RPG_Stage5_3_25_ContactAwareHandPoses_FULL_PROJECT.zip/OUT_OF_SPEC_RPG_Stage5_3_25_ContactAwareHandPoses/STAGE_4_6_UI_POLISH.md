# Stage 4.6 — Arcane UI, Additional Seal Mastery & Background Binding AI

Date: 2026-10-17  
Mod metadata version: `0.5.5`  
Build marker: `OUT_OF_SPEC_STAGE_4_6_0.5.5`

## User-reported problems addressed

1. The seal casting HUD showed too much persistent information and obstructed the world view.
2. Additional seals behaved like universally available inputs instead of learned advanced abilities.
3. Binding Contract AI judgments could take long enough that the user could not comfortably leave the screen; leaving risked losing the apparent in-flight session/result.
4. The existing screens looked like generic forms rather than a coherent magical interface.

## Implementation

### A. Compact active-casting HUD

- Active rail size is limited to `min(314, scaledScreenWidth - 20)` by `40` pixels, placed near the bottom center.
- Two persistent rows show only spell/phase and current base-seal sequence/addition count.
- Most status messages use a transient toast above the rail (`1150 ms` window); idle feedback disappears after `2400 ms`.
- Existing input/session operations and server-authoritative cast requests are retained. The redesign removes the old always-visible multi-line debug content from the active world HUD.

### B. Additional-seal mastery

The server stores mastery under the player's persistent growth root in `additional_seals`. The state is copied by the existing player clone persistence handler along with spell growth data.

| Ability | Sequence | Effect | Requirements |
|---|---|---|---|
| Spell Power Focus | `午` | Spell-power calculation ×1.20 | At least one learned spell; 1 Arcane Core; 2 Amethyst Shards |
| Advanced Spell Power Focus | `午 → 未` | Spell-power calculation ×1.35 | Normal focus mastered; at least one spell at Lv.3; 2 Arcane Cores; 6 Amethyst Shards |

- These two existing real effect definitions conflict and cannot be stacked in one cast.
- Learning consumes materials and updates the server-owned snapshot.
- The client builds an input recipe registry filtered to the player's mastered additions. The server independently checks `isAdditionalSealLearned` before resolving/starting a cast.
- The SAO Menu Skills submenu includes `追加印研究` / `Additional Seal Study`; the codex shows only mastered additions.
- No unsupported placeholder effects are exposed as executable. Only these two registered spell-power additions are currently learnable.

### C. Closeable Binding Contract AI session

- `BindingContractScreen.openOrResume(Screen parent)` retains a single session instance and replaces the parent reference whenever the screen is opened from the current SAO Menu.
- `onClose()` saves the current draft and returns to the parent without incrementing the AI request token or canceling the future.
- A pending `BindingAIAdvisor.request(intent)` callback is allowed to update the retained session while it is hidden. The result is available when the screen is reopened.
- Background server contract status is forwarded to the retained screen instance even while hidden.
- If the user edits the draft while a request is pending, that request is marked stale; a late response cannot overwrite or blend with the new text.
- Closing/navigating is not contract activation, and the server remains authoritative for final contract validation.

### D. Visual language

- Added a hand-drawn transparent 256×256 ritual-sigil texture (`src/main/resources/assets/out_of_spec_binding/textures/gui/ritual_seal.png`) and editable vector source (`design/ritual_seal.svg`).
- Spell research/growth/codex/grimoire screens share a dark ink-blue surface, engraved double borders, a subdued center-right sigil watermark, cyan/violet ink and antique-gold labels.
- Additional-seal detail spacing reserves separate lines for title, tier, sequence, effect, description, mastery state and requirements, with the action row at a fixed lower line so text does not overlap the learn button.
- Binding Contract text input is drawn as an inset inscription rail. Native button hitboxes/actions remain intact while their visuals are painted in an engraved metal/ink-glass style; corner brackets and a small oath sigil create visual identity without replacing the readable content.

## Source validation

Ran:

```bash
bash tests/run_judge_tests.sh
OUT_OF_SPEC_DEEP_PACKAGE_TEST=1 bash tests/run_judge_tests.sh
```

Results: the standard run exited `0` with 315 `PASS` records; the deep run exited `0` with 316 `PASS` records. Neither log contains `FAIL` or `ERROR`. The optional deep fixture validates the JDK-only merger using a disposable synthetic archive and confirms that the bundled baseline payload remains unchanged; it is not a production build.

Key suite sizes include 421 catalog assertions across 130 fixture spell profiles, 4,502 sequence assertions across 500 synthetic spell IDs, 88 binding assertions, 138 casting/input assertions, 44 diagnostic-recipe assertions, and 554 real-casting recipe assertions. Resource JSON and expanded `mods.toml` checks pass.

Baseline Stage 1.1 SHA-256 unchanged:

`ebb72ec47f22b64fbac3ab58ff96f9d0df5fe276638bb3cb57bf3b1832fd1fda`

## Not verified here

No `gradle` executable or project wrapper is available in this edit environment. ForgeGradle compilation, reobfuscation, mod launch, actual GPU/UI rendering, live key input, real network round trips, AI background behavior inside Minecraft, and gameplay balance are not claimed as verified. A Windows `gradle clean build` and in-game validation are still required.
