# OUT OF SPEC RPG — Stage 4.7 Arcane Frame & Symmetric Sigil

Build marker: `OUT_OF_SPEC_STAGE_4_7_0.5.7`; mod metadata version: `0.5.7`.

## Visual changes

- Moved the compact two-row seal-casting HUD from the bottom edge to the upper HUD area. Its transient feedback now appears below the rail rather than above it.
- Rebuilt `ritual_seal.png` and its source SVG as a transparent, concentric occult diagram: one shared center, aligned outer rings, one symmetric pentagonal rail, a centered pentagram, and five equally spaced satellite medallions. The previous dense, high-crossing-line texture has been simplified so the visual reads as one intentional diagram rather than a stack of competing shapes.
- Reworked the Binding Contract Terminal and Spell Growth Terminal outer bezels toward the supplied UI reference: dark pixel-forged metal, stepped corners, subdued antique brass, and restrained violet crystal accents. The reference's center grid layout was not copied.
- Kept all text regions, screen actions, contract judgement, AI request lifecycle, casting keybinds, and server-side validation logic intact.

## Validation boundary

- Standard suite: exit code 0; 316 `PASS` records; 0 `FAIL`/`ERROR`.
- Deep suite: exit code 0; 317 `PASS` records; 0 `FAIL`/`ERROR`.
- The deep suite also compiled and exercised the JDK-only merger using a synthetic fixture; that is not the real ForgeGradle add-on artifact.

These checks are not a substitute for a ForgeGradle build or an in-game visual test. Forge compilation, reobfuscation, and Minecraft runtime verification remain unconfirmed until `gradle clean build` succeeds on the target Windows environment and the resulting JAR is tested in Minecraft 1.20.1 Forge.
