# Stage 4.9 — Multirelease, first-person hand seals, and Binding AI usability

## Multirelease: real projectile positioning

`AbstractSpellBindingMixin` starts a short synchronous capture at native `AbstractSpell.castSpell` entry. `SealCastingLifecycleEvents` observes `EntityJoinLevelEvent`; only server-side `Projectile` instances owned by the active caster are recorded. At native cast return, the executor's own `onCast` method is called for extra releases, then every captured projectile in that cast family is laid out from the mean launch point using the caster's lateral vector and a small outward velocity divergence.

- One extra release = two projectiles placed left/right.
- Two extra releases = three projectiles placed left/center/right.
- No player yaw changes; unrelated entities and projectiles owned by others are ignored.
- The code expects each original native release to create the same number of projectiles as the original cast and warns if fewer were captured. It never spawns fake projectiles as a fallback.

**Still needs an in-game check:** whether all four allowlisted Iron's Spells projectile variants set owner before the entity-join event, and whether spacing/velocity angles look good for first- and third-person observers. This cannot be validated by the plain-JDK harness.

## Quick Release

The registered multiplier is `0.50`, so a nonzero native effective cast time should be halved. Base cast-time zero stays zero. Test with a channeled/cast-time spell and compare with/without the seal; also check that channel interruption and cooldown remain vanilla-owned.

## First-person blocky hand animation

`SealHandPoseRenderer` subscribes to Forge `RenderHandEvent`, and only acts while the state machine is `BASE_INPUT` or `ADDITIONAL_INPUT`, the player is in first-person, and no screen is open. It cancels that hand's vanilla render and draws a voxel hand using separate cuboids for palm, cuff, thumb, four fingers, and fingertips. The 12 `BasicSeal` values map to separate curl poses; the previous/current pose transitions over 180 ms.

The texture is intentionally white so per-part Minecraft vertex tint makes the palm skin tone, violet cuff, and old-gold cuff line. This is an initial stylized model, not a traced copy of the reference art. If the first render is clipped or displaced due to Forge's current hand transform, adjust only the small local transforms in this renderer after receiving a screenshot; do not rewrite the input state machine.

## Binding AI and local judging

- Ollama native API `num_predict` and OpenAI-compatible `max_tokens` increased from 360 to 700 to reduce truncated structured proposals.
- For recognizable open-ended brainstorming requests only, endpoint failure, empty model content, or missing concrete proposal can supply one of three explicitly labeled local rule candidates. The candidate goes through the existing UI precheck and server judge. It is not represented as model output or as pre-approved.
- Explicit requests are not replaced by fallback trades when the request is ambiguous/unsupported; they retain a truthful error/alternative.
- The local adjudicator retains its deterministic fair-trade scoring and supported-effect whitelist; this pass does not reduce the fair ratio or claim support for unimplemented mechanics. A local fallback is only a candidate generator, never the final adjudicator.

## Test checklist for the user's Forge instance

1. Run `gradle clean build` from the extracted root and share the complete log if compilation fails.
2. Test Magic Arrow and Firebolt with Multi Release: confirm two simultaneous launch positions are visibly left/right, and a player turning while the projectiles fly does not shift their paths.
3. Test Lightning Lance and Fireball separately. Confirm owner attribution, hit effects, fireball explosion radius, and spell growth triggers remain correct. Test Triune Release separately to see left/center/right.
4. Compare Quick Release on the same spell with a known nonzero cast time, with stable conditions; it should take around half as long. Instant spell should not change.
5. In first person, start seal input and tap multiple different seals rapidly. Verify both hands replace the vanilla hand only during input; each finger is cubic/segmented, all twelve poses visibly differ, and there is no flicker or clipping. Cancel input or open a screen to ensure vanilla hands return.
6. With Ollama running, request an open-ended idea then an explicit unsupported mechanic. Repeat with Ollama stopped: only open-ended intent should receive the clearly labeled local candidate; explicit requests should get a truthful error. Submit a candidate and confirm server adjudication still decides acceptance.

## Honest verification status

The project's JDK-only model and source/configuration tests can verify declared effect values, supported scope, event/mixin source shape, AI fallback labels and asset existence. They cannot compile Minecraft/Forge render APIs, verify Mixin descriptors, or prove in-game rendering/trajectory correctness. No `gradle` command or Gradle wrapper is present in the current build environment, so `gradle clean build` and Minecraft real-instance validation remain unperformed.
