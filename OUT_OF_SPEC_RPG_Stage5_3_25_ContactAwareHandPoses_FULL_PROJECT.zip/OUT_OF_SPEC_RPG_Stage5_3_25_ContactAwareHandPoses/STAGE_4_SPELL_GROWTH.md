# Stage 4 — Spell Discovery, Growth and Grimoire Casting

## Scope and non-goals

This is a source-level implementation on top of the Stage 3.8 Binding Contracts + Stage 2.9 real seal casting project. It does not select V202, edit the bundled Stage 1.1 rollback JAR, or implement spell executors that are absent from the base. The growth catalog intentionally contains only `irons_spellbooks:firebolt`, `irons_spellbooks:magic_arrow`, `irons_spellbooks:fireball`, and `irons_spellbooks:lightning_lance`.

## Main design

### Independent concepts

- **Tier** is the designer-assigned classification for a spell's overall scope, complexity, and effects. It does not increase when the player levels the spell.
- **Level** is player progression for one learned spell, currently Lv.1–Lv.5. It changes the real `AbstractSpell#getSpellPower` level contribution. Normal level-up is a server action requested through the UI, never an automatic threshold crossing.
- **Proficiency** is earned on real spell releases and must reach the current threshold. It is consumed by a committed level upgrade.
- **Breakthrough** is the Lv.3 → Lv.4 transition. It requires proficiency, effective damage-hit records for that spell, an Arcane Core and tier-scaled amethyst cost. The player chooses one persistent branch: Refinement, Burst or Control.

### Study flow

1. A scroll's `inventoryTick` records discovery in persistent player NBT.
2. The Research Archive presents known spells, scroll stock, base chance and Arcane Core-assisted chance.
3. Server validates the spell ID, scroll count and optional core before starting a committed attempt.
4. The scroll (and the core, if selected) is consumed before rolling the attempt. Success sets `learned=true` and starts the spell at Lv.1; failure keeps discovery but does not refund items.
5. The four growth-enabled spells cannot use the legacy Iron's Spells `isLearned` flag as a shortcut around research. Non-catalog spells keep their original behavior.

### Current starting values

| Tier | Base research chance | Proficiency per released spell | Shards per ordinary upgrade | Effective spell damage hits for breakthrough |
|---|---:|---:|---:|---:|
| Lower | 82% | 8 | 1 | 4 |
| Middle | 60% | 10 | 2 | 5 |
| Upper | 28% | 12 | 3 | 7 |
| Super | 10% | 15 | 4 | 10 |

Required proficiency begins at 80 / 100 / 140 / 180 by tier and rises by 60 for each current level above Lv.1. Arcane Core study assistance adds 20 percentage points up to 95%. After Lv.4, ordinary level-up shard cost gains +1. Breakthrough consumes 1 Arcane Core and `3 + tier material cost` amethyst shards. These are prototype defaults, intended for subsequent balance iteration.

### Scroll sources

Hostile monster kills have a 12% chance to yield a scroll. Conditional weights: Firebolt 72%, Magic Arrow 18%, Fireball 9%, Lightning Lance 1%. A level-5 Librarian can trade one held Arcane Core for one Lightning Lance inheritance scroll while the player is sneaking; each villager accepts only one inheritance. This provides both a very rare direct high-tier field drop and a deliberate NPC route.

### Interfaces and SAO Menu integration

- The SAO Menu `skills` submenu receives four localized entries using the same optional `SAOMenuScreen` Mixin bridge as the Binding Contract terminal: Research Archive, Growth Terminal, Seal Codex and Arcane Grimoire Terminal.
- These screens do not register separate `I / L / U` global keybindings. The grimoire item can still open its own configuration UI when used.
- A growth screen opened from SAO Menu retains that menu as its parent; close/Esc returns to the previous SAO Menu rather than dumping the player back to gameplay.

The Research Archive hides spell names until discovered or until a corresponding scroll is in inventory. The combat seal HUD remains a transient input-progress UI; it does not display all complete spell formulas continuously.

### Optional Arcane Grimoire

The item does not grant spell knowledge and is not needed for ordinary seal casting. It is required only for its special casting UI. Automatic casting starts one learned spell through the real Iron's Spells initiation path. Two-layer casting queues a second learned spell after the first reaches its real `castSpell` release hook, then starts the second on a later server tick. Thus this version is a chained/sequential implementation, not two spells cast at the same instant or a custom merged projectile. All real spell initiation checks, cooldowns, mana rules and existing binding restrictions still apply.

### Persistence

Per-spell discovery, learning, proficiency, level, challenge hits and branch choice are stored in player persistent data under `out_of_spec_spell_growth`. `PlayerEvent.Clone` copies this compound to the respawned player, including branch choices.

## Test boundary

The pure-Java regression harness and source audit validate the tier/catalog rules and guard important runtime wiring. Resource JSON and `mods.toml` parsing are checked; the bundled Stage 1.1 JAR SHA-256 and ZIP CRC are also checked. None of these can certify Mixin transformation or a running Forge server.

The environment running this package has no Gradle executable or `gradlew` and cannot download Gradle. Full ForgeGradle compilation/reobfuscation and Minecraft in-game testing have therefore **not been performed**. Treat the ZIP as a Stage 4 source project, not an already-built mod JAR. Required in-game checks are listed in `README_CN.txt` and `VALIDATION_REPORT.md`.
