# OUT OF SPEC RPG — Stage 5.1: Bilateral Release, First-Person Hand Signs, Binding AI Iteration

**Build marker:** `OUT_OF_SPEC_STAGE_5_1_0.6.2`  
**Mod version:** `0.6.2`  
**Baseline:** Stage 4.9 complete project, incrementally modified. The Stage 1.1 baseline JAR remains byte-for-byte unchanged.

## Changes

### Multirelease becomes a visible left/right formation

The previous implementation only performed post-spawn repositioning with narrow spacing. Stage 5.1 arranges each native projectile from `EntityJoinLevelEvent`, while the projectile is joining the level and before normal tracking sends its initial spawn state. The native projectile remains the actual spell object; owner, damage, impact, and special behavior remain owned by Iron's Spells. It uses original velocity plus outward yaw to form two side-by-side paths, or three left/center/right paths. A post-capture fallback restores captured native velocities before re-layout when the full join-event sequence is not observed.

Formation targets: two projectiles have 0.72-block center-to-center spacing and ±5° yaw; three have 0.72-block adjacent spacing, 1.44-block outside-to-outside spacing, and ±10° outer yaw. Mana multipliers remain 1.40× for multi-release and 1.85× for triune release. No projectile is fabricated if native entity capture fails; a visible server/client completion message states that fact.

### Quick Release is half time and reports itself

`QUICK_RELEASE` remains an actual cast-time multiplier of `0.50`, not a flat animation. A successful seal-cast acknowledgement explicitly states that effective casting time has been halved, and clarifies that instant spells or spells with a one-tick cast cannot show a noticeable reduction. The server-side Iron's Spells `getEffectiveCastTime` hook remains the real execution path.

### First-person voxel hand-sign animation

`SealHandPoseRenderer` only replaces vanilla hand rendering while seal-input session is active and camera mode is first-person. It builds cuboid palms, cuffs, thumb, four independently articulated fingers, and fingertips; twelve sign poses have per-finger curl plus per-hand wrist roll/yaw/pitch, blended over 180 ms between key presses. Vanilla hands remain untouched during normal gameplay, screens, and third person.

This is a stylized block-hand approximation guided by the supplied twelve-seal reference sheet; it is not a real player rig or pixel-perfect tracing of every finger joint. Visual placement, arm transforms, and pose readability must still be verified in a live Minecraft instance.

### Binding AI and local adjudication

The local fallback now distinguishes a creative request from an explicit trade: it can preserve a supported target domain (cooldown/mana, cast time, casting movement speed, visibility, damage/power) and generate vetted alternate candidates. Every fallback candidate is passed through `BindingContractJudge` and target-scope protection. It will not change a fully written trade or silently turn a single-spell request into a global-only attribute. Unsupported mechanics (teleport, healing, summon count, shields, voice/hand-seal contract prerequisites, bilateral-player negotiation, breach penalties) remain fail-closed until their real executor exists.

The expanded regression set includes permanent slowness/insomnia trades, one-use spell costs, all-spell rewards, cast roots, named spell scopes, and both balanced and unbalanced exchanges. This is a deterministic candidate generator plus the local rules judge, not a claim that arbitrary prose can be accepted without rule or executor constraints.

## Test/verification boundaries

- The pure-Java projectile formation harness tests symmetric offsets and outward angles.
- The project regression scripts verify source wiring, recipe definitions, client renderer assets, contract judging, registry data, baseline JAR hash, and packaging integrity.
- ForgeGradle compilation and in-game testing have not been performed in this environment. In particular, the first-person view/hand transform and entity-join event timing need a game test; source assertions are not a substitute.
- The Stage 4.7 Codex/Growth UI magic-circle/text overlap is intentionally carried forward for a later single UI pass, as requested.
