# Stage 5.2.1 — First-Person Hand-Sign Rig

## Why the previous in-game result failed

The earlier implementation intercepted `RenderHandEvent` and drew a custom hand rig before Minecraft had entered its per-arm first-person transform. This made the parts appear as oversized geometry around the camera instead of as the player's hands. It also had the finger segments extending back into the forearm, and the two thumbs/finger orders were not mirrored.

## Current rendering path

1. While the seal-input state machine is accepting basic/additional seals, the client `SealFirstPersonHandMixin` intercepts `ItemInHandRenderer.renderArmWithItem` for the local player.
2. It invokes the existing native `renderPlayerArm` method with the same partial/equip/swing values. Minecraft therefore owns the ordinary first-person arm placement and equip/swing transform.
3. The native first-person player renderer posts Forge's `RenderArmEvent` at the arm pivot. The event is cancelled only while the seal rig is active (or during the brief exit blend), and the rig renders in the provided pose stack instead of the vanilla arm mesh.
4. Arm and sleeve use the player's actual skin texture and the standard/slim model width. The hand has a palm, a mirrored thumb with a joint, and four independently bent fingers; each finger contains a base, middle joint and tip.
5. On seal changes, finger curl/spread and wrist angles blend over 180 ms. The arm blend-in takes 260 ms and blend-out takes 220 ms. It does not replace the normal hand in third person or while a screen is open.

This path is a model-space articulated animation, not an overlay at the camera origin. It still replaces the native arm mesh during seal input because vanilla player arms have no five-finger skeleton to pose; the replacement is attached to the same native first-person arm transform.

## This iteration's self-review fixes

- Finger segments now continue from the palm past the wrist endpoint, rather than pointing backwards into the forearm.
- Left and right hands have mirrored thumb anchors, thumb cuboid direction, and finger order so the index finger stays adjacent to the thumb on both hands.
- Thumb curl now rotates around its in-plane bend axis, with the thumb tip bending separately; it is no longer mostly a twist that is hard to see.
- Mirrored arm convergence was raised to 0.38 radians, with a small yaw adjustment to bring the hands into the central sign area.
- Enter and exit blends avoid snapping to the sealing pose or popping instantly back to the vanilla hand.
- The three per-seal matrices are checked for all twelve enum values (`子丑寅卯辰巳午未申酉戌亥`), with geometry-direction and mirroring assertions in `tests/check_first_person_hand_rig.py`.

## Verification status

The standard scripted suite exits with code 0 and records 379 `PASS` lines. The deep suite exits with code 0 and records 380 `PASS` lines; the latter additionally compiles and runs the JDK-only merge fixture and confirms the bundled Stage 1.1 baseline payload remains byte-for-byte intact (SHA-256 `ebb72ec47f22b64fbac3ab58ff96f9d0df5fe276638bb3cb57bf3b1832fd1fda`).

These are source/model/configuration and packaging checks, **not** a ForgeGradle compile or an in-game render test. This environment has Java 17 tools (`java`/`javac`) but no `gradle` executable. The user's client must still run `gradle clean build` and inspect the live result before the motion can be described as Naruto-accurate. The twelve pose profiles are authored procedural poses based on the supplied hand-sign reference, not motion-captured anime keyframes.

## First live-client review checklist

1. Enter a world in first person and press `K` to begin seal input. The two hands should appear at the normal lower-left/lower-right first-person positions, move inward, and never cover most of the screen.
2. Enter `Z`, `C`, and `R` separately with a short pause between them to inspect the `子`, `寅`, and `酉` poses. The fingertips must be visible beyond the sleeves, and each pose must look distinct rather than like two identical fists.
3. Repeat using both Classic and Slim player skins. Skin/sleeve texture must stay aligned and fingers must not show large UV tears.
4. Press `P` to cancel. The hands should smoothly move back to vanilla over a short ease-out; in third person, when a screen is open, and outside seal input, normal Minecraft hand/item rendering must remain unchanged.
5. Test with empty hands and with an item selected, then send screenshots of the first successful pose and the worst-looking pose. Those screenshots are needed to tune the 12 wrist/palm transforms against the actual client camera; source tests alone cannot certify the final appearance.
