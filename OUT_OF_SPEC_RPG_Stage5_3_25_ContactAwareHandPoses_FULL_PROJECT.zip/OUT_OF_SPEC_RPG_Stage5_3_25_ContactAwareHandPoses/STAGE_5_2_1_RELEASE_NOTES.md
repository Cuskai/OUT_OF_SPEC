# OUT OF SPEC RPG — Stage 5.2.1 / Mod 0.6.4

## First-person hand-sign self-iteration

- Removed the camera-origin `RenderHandEvent` approach that caused giant blocking geometry.
- Entered Minecraft's normal first-person hand-render path through a client mixin invoking `ItemInHandRenderer.renderPlayerArm`, then used Forge's `RenderArmEvent` arm pivot for the custom articulated model.
- Corrected the model-space direction of the three-segment fingers so the digits continue beyond the wrist instead of being hidden inside the forearm.
- Mirrored thumb bases, thumb cuboids, and index-to-pinky order between left/right hands.
- Changed thumb bend to use the thumb's in-plane curl axis; included a separate thumb-tip bend.
- Increased arm convergence to 0.38 rad and added a subtle mirrored yaw contribution to aim both hands toward the central signing area.
- Added eased activation (260 ms), inter-sign interpolation (180 ms), and exit transition (220 ms) to avoid sudden pops.
- Added structural regression checks for 12 pose-table rows, expected matrix widths/ranges, mirrored hand wiring, hand-tip coordinates beyond the wrist, native render invoker, and renderer scope.

## Carried-forward systems

The original dynamic spell directory, spell growth and breakthrough systems, SAO Menu integration, learned additional seals, real spell invocation, bilateral/triune projectile formation, quick release, and Binding Contracts/AI judgment remain in the incremental project. The known Codex/Growth text-versus-sigil overlap remains deferred per the project plan.

## Test status

- Standard suite: exit code 0, 379 `PASS` records.
- Deep suite: exit code 0, 380 `PASS` records, including a JDK-only archive merge/read-back fixture and byte-for-byte baseline payload verification.
- Bundled Stage 1.1 baseline SHA-256 remains `ebb72ec47f22b64fbac3ab58ff96f9d0df5fe276638bb3cb57bf3b1832fd1fda`.
- A Gradle executable/wrapper is not present in the authoring environment. The actual ForgeGradle `gradle clean build`, reobfuscation, and Minecraft client visual test have not been run. Therefore the source architecture and automated tests are improved, but the mod must not yet be described as compiled or Naruto-accurate in-game.

## First client validation

Use the new project ZIP, run `gradle clean build`, and install only the merged JAR generated under `build/libs`. Start seal input with `K`, inspect `Z` / `C` / `R` separately with small pauses, verify Classic and Slim skins, and press `P` to cancel. Confirm the hands meet near the center without covering the view, the fingers remain visible and skin UVs do not tear, and the original hand/item rendering returns after the short exit blend. Tuning for anime-level pose fidelity requires at least one actual client screenshot from this iteration.
