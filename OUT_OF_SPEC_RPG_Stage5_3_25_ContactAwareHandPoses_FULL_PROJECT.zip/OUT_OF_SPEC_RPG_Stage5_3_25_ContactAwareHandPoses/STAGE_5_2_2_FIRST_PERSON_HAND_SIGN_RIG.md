# Stage 5.2.2 — Bilateral First-Person Hand-Sign Rig

## Why Stage 5.2.1 still looked wrong in the live screenshot

The prior mixin intercepted `ItemInHandRenderer.renderArmWithItem`, which is a per-selected-hand hook. Minecraft can choose not to render an empty offhand, so the second arm did not reliably enter the custom render path. The added fingers also continued almost directly along the forearm axis and were too chunky at first-person distance, making the hand read as one large skin-coloured mass.

## Current rendering path

1. `SealFirstPersonHandMixin` now intercepts the whole `renderHandsWithItems` pass only while basic/additional-seal input is active in first person.
2. During that state, it calls Minecraft's native `renderPlayerArm` path once for the player's main-side arm and once for its opposite. This explicitly requests both sides even when the offhand is empty. Normal vanilla held-item/hand selection is cancelled only for that sealing frame.
3. Each native call reaches Forge `RenderArmEvent`, whose purpose is to allow replacing the first-person arm. The event is handled only for the local player; the renderer cancels that arm event and draws the matching left/right articulated arm in the event pose stack.
4. `equipProgress` is fixed at `0.0F` to use the fully-equipped idle hand height rather than adding the extra lowering associated with `1.0F`. The arm convergence/hand poses animate the sealing motion from there.
5. Classic and Slim arms use matching player-skin/sleeve UV regions. The palm is narrower/shallower; each of the four fingers has three separate segments (base, middle, tip); the thumb base and tip were reduced to stop overpowering the palm.
6. A 64-degree palm-presentation bend plus each sign's wrist angle directs the hand plane toward the view. Finger curl, spread, wrist and appended hand geometry all follow the activation envelope, so entering/exiting seal input should ease instead of popping.
7. The inward arm roll is `0.44` radians with a smaller mirrored yaw correction. All twelve BasicSeal profiles have separate curl/spread/wrist combinations.

## Seven explicit iteration passes

1. **Render-path iteration:** moved from per-hand `renderArmWithItem` interception to the full `renderHandsWithItems` pass and explicitly rendered both arm sides. This addresses the empty-offhand selection edge case.
2. **Proportion iteration:** shortened the finger chain and reduced the palm from a broad 4.6-pixel block to a slimmer palm. Reduced the palm anchor extension beyond the forearm.
3. **Palm-orientation iteration:** added a base presentation pitch so fingers do not remain edge-on along the forearm axis.
4. **Placement/safety iteration:** adjusted mirrored inward convergence, reduced yaw skew, and restricted event cancellation to the actual local player.
5. **Transition iteration:** animated the appended hand's scale, curl and wrist angles along with the arm activation/deactivation blend.
6. **Finger-readability iteration:** reduced finger and thumb widths, strengthened the gaps between adjacent finger blocks, and added an audit asserting all 12 pose profiles are distinct.
7. **Native-height iteration:** changed the hand invoker's equip progress from `1.0F` to `0.0F`, avoiding an unnecessary additional downward translation in the native first-person transform.

## Automated verification

- Standard regression script: exit code 0, 379 `PASS` lines.
- Deep regression script: exit code 0, 380 `PASS` lines.
- The deep script compiles/runs the JDK-only merge fixture, reads back the produced synthetic merged archive, and checks that the bundled Stage 1.1 baseline JAR payload remains unchanged (SHA-256 `ebb72ec47f22b64fbac3ab58ff96f9d0df5fe276638bb3cb57bf3b1832fd1fda`).
- The hand-rig audit checks both arm calls, the whole-hand render interception, local-player guard, 3-stage finger geometry, mirrored thumb/finger placement, non-zero tip extension beyond the forearm, activation/deactivation blending, and 12 distinct pose tables.

These checks are source/model/package checks only. They are **not** a ForgeGradle compile or a live Minecraft render test. The user's latest screenshot came from the previous build; the fix must be tested using the new built artifact before visual success can be claimed. The pose matrices are hand-authored procedural transforms based on the supplied Naruto sign reference, not captured anime animation data.

## Live test checklist

1. Run `gradle clean build` from this project root.
2. Install the newly built merged JAR, not the previous Stage 5.2.1/Mod 0.6.4 build.
3. In first person, begin seal input and verify both lower-left and lower-right hands appear even with an empty offhand.
4. Check `子`, `寅`, `酉`, then a tightly curled sign such as `亥`; fingers should be separated and the palms should meet near the central lower view without covering the crosshair.
5. Repeat with Classic and Slim player skins. Cancel with `P`; normal held item rendering should return, and third-person/GUI behavior should remain unchanged.

Do not call it Naruto-accurate until these live screenshots are reviewed and the wrist/palm poses can be iterated against them.
