# Stage 5.2.2 — Iteration Log

| Pass | Finding | Change | Check |
|---|---|---|---|
| 1 | Per-hand hook did not guarantee an empty offhand was rendered. | Hook the complete `renderHandsWithItems` pass; explicitly invoke both arms. | Hand-rig source audit passed. |
| 2 | Palm/finger dimensions were bulky and finger extension too long. | Reduced palm depth/height/width and shortened all three finger segments. | Initial audit caught stale dimension expectations; assertions were updated to the new geometry and passed. |
| 3 | Fingers followed the forearm axis and collapsed visually. | Added a 64° presentation-pitch base blended with each sign's wrist data. | Pose/a-axis assertion passed. |
| 4 | Arms needed safer local-player targeting and central convergence. | Added local-player guard, reduced yaw correction, roll set to 0.44 rad. | Audit required mirrored roll and local-player guard. |
| 5 | The hand geometry jumped to the final pose as the arm blended in. | Blend hand scale, curl/spread and wrist rotations using activation progress. | Transition and scale assertions passed after updating the expected active blend. |
| 6 | Finger gaps/thumb were too chunky and profiles needed uniqueness proof. | Thinned finger/thumb boxes and assert 12 distinct profiles. | Pose-table audit passed. |
| 7 | `equipProgress=1.0F` adds extra down-translation to the native first-person pose. | Use fully-equipped idle height `0.0F` before animated convergence. | Both arm invocations and neutral equipment height assertions passed. |

Final suite results: standard exit code 0 / 379 `PASS` lines; deep exit code 0 / 380 `PASS` lines. The Stage 1.1 baseline JAR hash was preserved. ForgeGradle compilation and in-game visual acceptance remain unverified.
