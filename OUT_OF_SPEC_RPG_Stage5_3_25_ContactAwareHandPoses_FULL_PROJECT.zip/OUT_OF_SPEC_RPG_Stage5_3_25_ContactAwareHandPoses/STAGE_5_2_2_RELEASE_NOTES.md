# OUT OF SPEC RPG Stage 5.2.2 / Mod 0.6.5 — Release Notes

## User-reported problem
The Stage 5.2.1 live screenshot showed a single oversized hand in the lower-right foreground. This was not accepted as a successful first-person seal animation.

## Seven iterations in this release
1. Replaced the per-selected-hand `renderArmWithItem` hook with a full `renderHandsWithItems` interception while seal input is active.
2. Explicitly invoke the native arm render path for both the main-side and opposite arm, so rendering does not rely on vanilla selecting an empty offhand.
3. Reduced palm and finger dimensions to prevent a large single block silhouette.
4. Changed the palm presentation pitch so fingers do not remain aligned along the forearm and collapse edge-on.
5. Adjusted mirrored arm convergence and added a local-player-only guard.
6. Blended hand scale, finger curl/spread, and wrist angles with the arm activation/deactivation envelope; added a 12-distinct-pose audit.
7. Changed native `equipProgress` to `0.0F` to avoid an additional lowering offset.

## Automated checks
- Standard suite: exit code 0, 379 `PASS` lines.
- Deep suite: exit code 0, 380 `PASS` lines.
- First-person hand rig audit: passed.
- `validate_project.py`: passed; bundled Stage 1.1 baseline JAR SHA-256 remains `ebb72ec47f22b64fbac3ab58ff96f9d0df5fe276638bb3cb57bf3b1832fd1fda`.
- Deep package fixture used a JDK-only archive rewrite/read-back test. It is not a ForgeGradle compile.

## Important verification boundary
This package has **not** been compiled with ForgeGradle in the current environment because Gradle and a project wrapper are unavailable here. It has also not been accepted against a live Stage 5.2.2 Minecraft screenshot yet. The changes specifically target the single-hand/oversized-hand failure, but arm placement, silhouette, pose fidelity, and skin variants must be reviewed in-game before calling it Naruto-accurate.
