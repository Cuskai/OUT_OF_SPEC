# Stage 5.2.3 — First-person seal-hand API fix

## Root cause
The Stage 5.2.2 build log showed three compile errors because Minecraft 1.20.1 `ModelPart` does not expose `scaleX`, `scaleY`, or `scaleZ` fields. These were invalid API uses; the previous source-only checks did not catch them.

## Fix
- Removed all direct `ModelPart.scale*` assignments.
- While rendering an arm, temporarily hide the hand child so the forearm/sleeve pass does not draw the hand unscaled.
- Apply the arm's parent transform to the current Forge first-person `RenderArmEvent` pose stack.
- Render the hand and articulated finger children in a separate pass, applying the scale through `PoseStack` around the hand's local wrist pivot.
- Use `pushPose()` and `popPose()` in a `try/finally` block to avoid leaking transforms into later rendering.
- Restore the hand's visibility after the custom pass.
- Expanded the specialized source audit to ensure the unsupported scale fields are absent and the wrist-pivot transform exists.

## Validation boundary
The source/model regression tests and package checks are run for this release. They are not a replacement for `gradle clean build`; the current Linux execution environment has no installed Gradle executable, so ForgeGradle compilation cannot be claimed here. The supplied compile errors should be rechecked by the user's next Windows `gradle clean build`. After compilation, a live screenshot is still required to confirm exact hand placement and pose quality.
