# OUT OF SPEC RPG Stage 5.2.3 / Mod 0.6.6 — Release notes

- Fixed the three reported Forge `compileJava` errors in `SealHandPoseRenderer.java` by removing unsupported `ModelPart.scaleX`, `scaleY`, and `scaleZ` members.
- The hand mesh is now rendered in a separate pose-stack pass after rendering the forearm and sleeve. Its scale is centered around the hand's own wrist pivot.
- The pose stack uses `try/finally` to ensure transform restoration. Hand visibility is restored after the custom draw.
- Added/updated a regression audit specifically for the invalid API regression.
- Kept existing game systems and baseline JAR unchanged.

Validation: standard source/model suite passed with 379 PASS lines and deep source/model suite passed with 380 PASS lines; both exited 0. See `test-results/Stage5_2_3_standard_tests.log`, `test-results/Stage5_2_3_deep_tests.log`, and `test-results/Stage5_2_3_hand_rig_audit.log`. These are source/model and packaging checks. A real ForgeGradle `gradle clean build` has not been run in this environment; the user must confirm the compile fix on Windows and then inspect the live hand animation.
