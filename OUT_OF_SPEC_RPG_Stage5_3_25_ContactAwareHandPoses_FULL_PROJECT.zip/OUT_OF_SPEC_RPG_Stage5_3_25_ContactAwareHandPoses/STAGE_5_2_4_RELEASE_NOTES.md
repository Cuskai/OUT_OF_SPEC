# OUT OF SPEC RPG — Stage 5.2.4 / Mod 0.6.7

## Compile fix
- Fixed the six user-reported `cannot find symbol: hand` errors in `SealHandPoseRenderer.onRenderArm` by binding `ModelPart hand = arm.getChild("seal_hand")` before the pose/render lifecycle uses it.
- The same child object now drives pose setup, temporary visibility, separate PoseStack-scaled rendering, and visibility restoration.
- Added an explicit regression assertion that `hand` is bound before its first visibility access.
- Kept the prior `PoseStack` pivot scaling approach, the project baseline JAR, first-person pose data, and all other systems unchanged.

## Automated checks
- Standard source/model suite: exit code 0, 376 PASS-prefixed log records; no failure/error/traceback markers.
- Deep source/model suite: exit code 0, 377 PASS-prefixed log records; includes the JDK merger fixture write/read verification.
- First-person hand rig audit and package/config validation pass.
- Stage 1.1 baseline JAR hash is unchanged.

See `STAGE_5_2_4_SCOPE_FIX.md` and `test-results/Stage5_2_4_*.log`.

## Not yet verified
No real ForgeGradle build or Minecraft client launch was available in this environment. Run `gradle clean build` in Windows before installing the merged JAR; then verify two-hand rendering in a live client.
