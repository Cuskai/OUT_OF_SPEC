# Stage 5.2.4 — hand ModelPart scope compile fix

## User-reported failure
The Windows ForgeGradle compiler reported six `cannot find symbol` errors in `SealHandPoseRenderer.java`, all for `hand` inside `onRenderArm` (the visibility flag, render call, and restoration paths).

## Root cause
The previous patch converted direct per-ModelPart scaling to a separate `PoseStack` render pass, but it referenced `hand` without declaring a local `ModelPart` in the method. The child existed in the model tree but had only been fetched inline in `applyHandPose(...)`; that call did not create a local variable for later use.

## Incremental fix
- Resolve the exact child once: `ModelPart hand = arm.getChild("seal_hand");`.
- Pass the same part instance into `applyHandPose(...)`, then reuse it for the visibility guard, arm/sleeve pass, wrist-pivot scaled pass, and restoration in `finally`.
- Do not change the rendering architecture, finger geometry, pose table, casting behavior, Binding AI, or other systems.
- Add a regression assertion verifying that the binding occurs before the first visibility use.
- Bump project identity to Stage 5.2.4 / mod version 0.6.7 and sync Gradle output paths plus source assertions.

## Checks completed in this environment
- Standard source/model suite: exit code 0, 376 lines beginning with `PASS`, no `FAIL`, `ERROR`, traceback, or assertion error.
- Deep source/model suite: exit code 0, 377 lines beginning with `PASS`, no `FAIL`, `ERROR`, traceback, or assertion error. The optional JDK-only merger fixture compiled and executed; output archive read-back and baseline payload preservation were verified.
- Dedicated first-person hand rig audit: passed, including the local `ModelPart hand` scope assertion.
- Package/config audit: passed; 12 resource JSON files parse, expanded `mods.toml` parses, Stage 5.2.4 identity and Java 17 targets agree, bundled baseline JAR remains intact with SHA-256 `ebb72ec47f22b64fbac3ab58ff96f9d0df5fe276638bb3cb57bf3b1832fd1fda`.

## Validation boundary
This environment has JDK 21 (`javac`) but no Gradle executable or project wrapper. A real ForgeGradle `gradle clean build` has **not** been run here. Thus this source fix is ready for your Windows compile attempt but is not being represented as Forge compilation or in-game verification. Once compilation passes, the two-hand visual layout still needs a live Minecraft screenshot check.
