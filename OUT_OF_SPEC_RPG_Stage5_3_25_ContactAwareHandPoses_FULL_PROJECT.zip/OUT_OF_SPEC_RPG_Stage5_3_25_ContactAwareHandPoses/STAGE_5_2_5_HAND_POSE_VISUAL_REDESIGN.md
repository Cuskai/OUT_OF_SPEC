# OUT OF SPEC RPG Stage 5.2.5 — Hand Pose Visual Redesign

Mod version: 0.6.8. Incremental update to the Stage 5.2.4 source tree.

## Visual changes based on the supplied reference
- Keep the native first-person arms as the anchoring coordinate system; no model is placed directly at the camera origin.
- Keep palm pitch near neutral (`-8°` baseline instead of the prior `+64°` correction), increase separation/readability of block-shaped finger segments, vary middle/index/ring/pinky lengths, and reduce the extra arm roll from `0.44` to `0.20` radians.
- Use arm-specific base-skin UV regions: right arm starts at V=22, left arm starts at V=54. Palm and segmented finger UVs remain inside the base skin rows, avoiding sleeve-overlay sampling on the fingertips.
- Isolate both direct `renderPlayerArm` invocations with independent `PoseStack.pushPose()` / `popPose()` pairs protected by `try/finally`, matching the per-hand transform isolation normally supplied by vanilla’s wrapper. This targets the previous one-hand symptom where the second invocation could inherit the first invocation’s matrix changes.
- Retain all twelve pose tables, actual seal input logic, spells, additional seals, contracts, growth, and UI.

## Validation status
- Standard source/model regression: 379 PASS-prefixed records, exit code 0.
- Deep regression: 380 PASS-prefixed records, exit code 0, including the JDK-only merger fixture write/read-back test.
- The new audit checks both isolated pose-stack scopes and the estimated skin UV bounds in addition to the pose table and geometry checks.
- The Stage 1.1 baseline JAR payload hash remains unchanged.
- **Not verified:** real ForgeGradle compilation or Minecraft in-game rendering. The hand layout changes are targeted fixes, not a claim that live gameplay visuals have been approved.

## Next manual validation
Run `gradle clean build` on Windows. Then test first-person casting with both Classic and Slim player skins and observe: (1) both hands visible at once, (2) hands entering from bottom left and bottom right at natural scale, (3) five fingers visibly distinct, (4) sleeve texture not bleeding onto fingers, and (5) the hands return to normal on cast completion/cancel.
