# Stage 5.2.5 Release Notes — Mod 0.6.8

Based on the supplied Stage 5.2.4 complete source tree. No subsystem was removed.

## First-person hand-pose iteration
1. **Palm orientation:** near-neutral base pitch (-8° rather than the previous +64° flip).
2. **Hand silhouette:** separate Minecraft-style cuboid fingers with stepped segment sizes, gaps, and varied lengths.
3. **Arm convergence:** reduced extra Z roll to 0.20 radians to avoid unnatural overshoot.
4. **Skin texture:** remapped palm/finger UVs within the base-skin UV bands of the right/left arms, avoiding overlay/sleeve sampling on fingertips.
5. **Two-hand transform isolation:** separate `PoseStack` push/pop scopes around each direct `renderPlayerArm` invocation.

The previous render invocation bypassed vanilla’s per-hand wrapper. The two fresh pose-stack scopes prevent transformation state from the first arm leaking into the second. The UV audit separately checks that right-hand palm/finger coordinates remain within rows 16–31 and left-hand coordinates within 48–63.

## Regression results
- Standard suite: 379 PASS-prefixed records; exit code 0.
- Deep suite: 380 PASS-prefixed records; exit code 0, including actual JDK merger fixture write/read-back.
- Hand-rig audit includes twelve unique pose profiles, mirrored finger layout, isolated pose-stack calls, and UV bound checks.
- Baseline Stage 1.1 JAR SHA-256 remains unchanged.

## Unverified
The editing environment has no Gradle executable or wrapper. This ZIP has not yet been validated by a real `gradle clean build` or Minecraft client. A live screenshot is still required before claiming that both hands and fingers look correct.
