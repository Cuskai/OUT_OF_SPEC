# Stage 5.3.0 — Ten Iteration Log

This log records the ten concrete implementation/review gates run against the Stage 5.2.5 source. It does not claim ten in-game screenshot iterations; only a live Minecraft test can confirm the final appearance.

1. **Visibility state split.** Added `shouldRenderFirstPersonHands()` so ordinary first-person hands render with no active seal session. Seal-latch logic remains responsible for pose blending only. Checked: source assertion for independent predicates.
2. **Normal item path preserved.** Removed the cancellable HEAD interception of `renderHandsWithItems`. This prevents the custom rig from hiding held-item renders merely because the player is entering a seal. Checked: test forbids `ci.cancel()` in this mixin.
3. **Per-frame bilateral tracking.** Added a local render-pass owner and separate left/right bit flags to `SealHandPoseRenderer`; each normal `RenderArmEvent` marks its side. Checked: both side masks and pass reset present.
4. **Missing empty-hand fallback.** Added a `RETURN` injection that invokes the native `renderPlayerArm` only for a side not seen in the pass. Checked: use of the native invoker and `wasHandRendered` predicate.
5. **Native arm-transform continuity.** The fallback runs through `renderPlayerArm`; both the normal event path and fallback retain native camera/equip transform behavior. Checked: renderer remains attached to `RenderArmEvent`, no pre-transform `RenderHandEvent` model draw.
6. **Permanent non-zero hand scale.** Hand visibility is set true for the hand subpart and the hand scale uses fixed `0.78/0.76/0.78` values. The seal activation blend no longer multiplies scale or decides visibility. Checked: source audit rejects animation-dependent scale.
7. **Distal skin UV anchoring.** Changed the right palm/fingers to start at `(40,28)` and left palm/fingers at `(32,60)`, corresponding to the final hand rows in the base arm skin regions. Checked: expected UV anchors.
8. **UV spill prevention.** Reduced palm depth/thickness and reused the distal hand patch for finger base/middle/tip so cube UV mapping stays in the 4-row hand region. Checked: computed palm extents and exact builder offsets.
9. **Pose-only animation and idle stance.** Set a light idle finger curl and left 12 unique curl/spread/wrist profiles and transition blending intact. Arm convergence is only applied by the seal pose blend. Checked: all 12 profile rows/values and range assertions.
10. **Regression and package gate.** Updated project naming/runtime marker/tests, rewrote the hand-rig audit around permanent bilateral behavior, changed the additional-seal audit to require item-flow preservation, then ran standard and deep suites and validated the bundle. Checked: standard 379 PASS records; deep 380 PASS records; JDK merge/read-back fixture passed; baseline payload hash unchanged.

## Remaining acceptance work

- User-side `gradle clean build` is required because this environment has no Gradle executable.
- Live Minecraft screenshots must confirm that both hands are visible, have a readable pixel-skin texture, and keep the existing held item unobstructed.
- If the two-hand fallback does not render in-game, next debugging should log whether the Mixin HEAD/RETURN injections fire and whether `RenderArmEvent` sees both native and fallback arm requests before adjusting geometry again.
