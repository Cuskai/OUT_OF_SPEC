# Stage 5.3.0 — Permanent Bilateral First-Person Hands

Mod version: 0.6.9  
Baseline: Stage 5.2.5 Hand Pose Visual Redesign  
Target: Minecraft 1.20.1 Forge, Java 17

## Goal

The first-person hand rig must exist during ordinary gameplay, not only while the seal-input state machine is active. Seal input changes finger/wrist/arm pose; it must not determine whether the palms/fingers exist. The normal vanilla held-item flow must remain enabled.

## Implementation

- `SealInputDebugClient.shouldRenderFirstPersonHands()` checks that a local world/player is active, no screen is open, and the camera is first-person. This is intentionally independent of whether a seal is currently being entered.
- `SealHandPoseRenderer.onRenderArm` replaces only the native arm draw for the local first-person player. It marks which side was rendered in the current `renderHandsWithItems` pass, then draws the native arm/sleeve plus a separate articulated palm/hand at a fixed non-zero scale.
- `SealFirstPersonHandMixin` no longer cancels `renderHandsWithItems`. Vanilla items still render; after the native pass, the mixin invokes the engine's own `renderPlayerArm` method only for a hand that vanilla omitted. Each fallback call gets its own `PoseStack` scope.
- Hand pose activation is a separate blend from visibility and size. The idle pose has lightly curled fingers; the 12 seal poses drive articulation during input and ease out afterward.
- Palm and finger UV anchors move to the distal base-skin hand bands: right arm `(40,28)` and left arm `(32,60)`. Palm/finger cuboid dimensions and UV offsets are constrained so the generated UV rectangles remain inside those final four rows rather than drifting into overlay/sleeve pixels.
- Each hand is rendered inside the original first-person arm transform. Left/right parts keep mirrored pivots, separate arm tracking, mirrored thumb anchors, and independent articulated finger chains.

## Ten iteration gates

1. Separate persistent-hand visibility from the seal state machine.
2. Remove cancellation of the full hand-and-item render pass.
3. Track each native arm event independently per render pass.
4. Add only the missing empty hand at `renderHandsWithItems` return.
5. Ensure arm replacement still uses Minecraft's native arm transform and player skin.
6. Make hand visibility and scale independent of seal animation activation.
7. Move hand UV anchors to the base skin's distal hand rows.
8. Keep palm, thumb, finger-base, joint, and tip UV rectangles within the distal hand texture patch.
9. Keep all twelve hand-pose profiles distinct while making idle/entry/exit change articulation only.
10. Update package identity and rerun standard/deep model/source/package regression, including real JDK merger read-back.

## Validation boundary

The project-local standard suite completed with exit code 0 and 379 `PASS`-prefixed records. The deep suite completed with exit code 0 and 380 `PASS`-prefixed records, including compilation/execution of the JDK-only archive-merger fixture and byte-for-byte verification of the bundled baseline payload. The specialized first-person audit covers persistent visibility, held-item-flow preservation, missing-arm fallback, mirrored UV regions, fixed non-zero hand scale, the 12 seal pose tables, and perspective/API guards.

This environment does not have Gradle installed. ForgeGradle compilation, Mixin transformation inside Minecraft, and in-game appearance are **not verified**. Do not treat the automated source audit as proof that both hands render correctly in a live client; the next acceptance gate is `gradle clean build` followed by a screenshot in Minecraft.


## Superseded implementation note (Stage 5.3.2)

The original Stage 5.3.0 handler described replacing the native arm draw. That approach produced the user's reported single oversized/malformed hand and is no longer the current implementation. Stage 5.3.2 keeps vanilla's forearm and held-item rendering intact, uses `RenderArmEvent` to attach only the palm/finger mesh to the native arm pivot, places that mesh in front of the sleeve's front face, and falls back to vanilla's own arm renderer only for an empty arm omitted by the normal pass. Live Forge compilation and in-game visual validation remain pending.
