# OUT OF SPEC RPG — Stage 5.3.0 / Mod 0.6.9

## Main changes

- Rebuilt the first-person hand rig as a persistent bilateral base layer rather than a temporary seal-input overlay.
- Retained vanilla's `renderHandsWithItems` execution so scrolls, swords/items, maps, food, and other item renderers are not suppressed by seal posing.
- Added per-pass left/right arm tracking. Only an arm omitted by vanilla's selection is requested through the native `renderPlayerArm` path at the end of the hand pass.
- Separated pose activation from visibility/scale; idle hands remain visible at a fixed non-zero size with lightly curled fingers.
- Corrected UV anchors to the distal base arm skin rows and constrained hand geometry/UV layout to that patch.
- Reworked the hand-rig source audit and package validation for persistent bilateral behavior.

## Test status

- Standard test script: exit code 0, 379 PASS-prefixed output records.
- Deep test script: exit code 0, 380 PASS-prefixed output records. The JDK-only merger fixture compiled and ran, wrote/read a disposable archive, and verified baseline payload preservation.
- Bundled Stage 1.1 baseline SHA-256 remains `ebb72ec47f22b64fbac3ab58ff96f9d0df5fe276638bb3cb57bf3b1832fd1fda`.
- ForgeGradle build and live Minecraft rendering are not yet verified; this environment has no `gradle` executable.
