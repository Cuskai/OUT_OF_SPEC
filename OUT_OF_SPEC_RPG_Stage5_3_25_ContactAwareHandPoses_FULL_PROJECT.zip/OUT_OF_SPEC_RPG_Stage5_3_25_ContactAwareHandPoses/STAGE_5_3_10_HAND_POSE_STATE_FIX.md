# Stage 5.3.10 — Hand Pose State Fix

## Findings from Stage 5.3.9 feedback

The renderer used one neutral child-hand orientation for every state even though Punchy's first-person arm transform differs between empty idle, locomotion, and held-item poses. Idle empty hands therefore inherited a palm-out/thumb-down orientation, while held-arm transforms added a reported quarter-turn. Finger sections totalled about 1.6 model units, too short to read clearly against a 12-unit arm.

## Changes

- Added separate target orientation for three states: empty/stationary (180-degree longitudinal twist), empty/locomotion (keep Punchy's native palm-down animation), and held item (counter the reported +/-90-degree arm-axis twist per physical side).
- Smoothed changes between base orientations so state changes do not snap abruptly. The correction is applied to the hand child only; it does not change the physical arm position or Punchy's held item rendering.
- Extended all four fingers by increasing the base, middle-joint, and tip segments from a combined 1.6-ish units to roughly 2.1–2.5 units, with separate middle and tip dimensions retained.
- Lengthened the thumb and thumb tip while preserving classic/slim width variants, skin atlas regions, physical left/right attachment, and the existing twelve-seal interpolation data.

## State table

| State | Base twist target | Why |
|---|---:|---|
| Empty + stationary | 180 degrees about the hand's longitudinal local axis | Fix thumb-down / palm-out neutral orientation |
| Empty + moving | 0 degrees | Preserve Punchy's existing palm-down locomotion animation |
| Holding an item | -90 degrees on right arm, +90 on left arm | Counter reported held-pose quarter-turn without changing arm placement |
| Seal pose active | Empty/held target above plus existing per-seal articulation | Share a corrected base rig across all twelve signs |

These angles are source-level corrections based on the reported in-game states, not a claim of final visual validation. ForgeGradle compilation and in-game verification remain required.
