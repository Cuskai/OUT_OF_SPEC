# Stage 5.3.10 Release Notes

- Mod version: 0.6.19
- Based on Stage 5.3.9; no project rebuild or existing-system removal.
- Split base hand orientation into empty-idle, locomotion, held-item, and seal-active states.
- Added smooth state transition and lengthened all finger segments and thumb.
- Automated test results only establish source/model checks; ForgeGradle build and Minecraft visual verification are still pending.
