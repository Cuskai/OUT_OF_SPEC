# Stage 5.3.11 — Idle Palm Facing Viewport Center

Mod version: `0.6.20`  
Build marker: `OUT_OF_SPEC_STAGE_5_3_11.0.6.20`

## Exact change

- Preserve Punchy’s native locomotion (run/swim) hand motion, whose palm-down direction the user confirmed is correct. The moving-empty-hand branch remains `targetTwist = 0.0f`.
- Change only the idle/latched baseline from a symmetric 180° half-turn to a side-specific inward yaw: physical left hand `+90°`, physical right hand `-90°` around the hand’s local Y axis. This turns the palm normal toward the horizontal viewport center instead of simply reversing the palm front/back.
- Leave the current held-item compensation branch unchanged.
- Leave hand location, scale, finger dimensions, UV mapping, Punchy hooks, and seal articulation tables unchanged.

## Verification boundary

The hand-specific source audit asserts the inward yaw signs and preserved movement branch. The project’s Java/model tests and package validation are run separately. No ForgeGradle compilation or in-game visual verification is claimed by this source environment. The user should compile with `gradle clean build`, then confirm: idle empty palms face inward, running/swimming remain palm-down, and holding an item behaves exactly as before.
