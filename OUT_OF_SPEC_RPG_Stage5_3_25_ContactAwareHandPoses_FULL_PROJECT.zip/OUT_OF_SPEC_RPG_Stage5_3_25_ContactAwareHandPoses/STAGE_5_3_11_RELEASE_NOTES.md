# Stage 5.3.11 Release Notes

- Mod version: `0.6.20`
- Scope: correct only the stationary/latched empty-hand palm direction.
- Physical left palm turns toward viewport +X with +90° local Y yaw; physical right palm turns toward viewport -X with -90° local Y yaw.
- Punchy run/swim pose remains unchanged at zero extra local twist.
- Existing held-item compensation, hand geometry, UVs, bilateral fallback and spell/casting systems remain unchanged.
- No ForgeGradle compile or Minecraft screenshot verification is claimed.
