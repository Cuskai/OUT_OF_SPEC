# Stage 5.3.12 — Hand-Seal Pose Data and Bone Controller

## Baseline protection

- Starting baseline: Stage 5.3.11 / Mod 0.6.20, supplied as the full project ZIP.
- New version: Stage 5.3.12 / Mod 0.6.21.
- Unchanged: hand and finger cuboid sizes, skin UV regions, base wrist attachment, Punchy first-person Mixin targets, missing-hand fallback, seal input/casting, add-on seals, binding contracts, spell growth, SAO Menu hooks, and Punchy embedding pipeline.
- `SealHandPoseRenderer` continues to blend from the neutral pose; idle/locomotion/held-item transforms remain state-dependent as before.

## Architecture

`HandSealPoseLibrary` is data-only and can be compiled/tested with Java 17 without Minecraft classes. It declares:

- Anatomical `LEFT` / `RIGHT`, based on the caster rather than the viewer.
- Independent `DigitPose` per thumb/index/middle/ring/pinky: base/middle/tip flexion, spread, yaw, and local XYZ pivot offset.
- Independent `HandPose` per physical hand: wrist roll/yaw/pitch and hand-relative XYZ offset.
- `ContactConstraint` metadata for tip contact, insertion, wrap, cover, interlock, proximity, and crossover. Unknown foreground order stays unresolved rather than being guessed.
- A distinct named profile for each `BasicSeal` value.

`SealHandPoseRenderer` interpolates the old/new pose and activation, then writes each joint separately. The controller never scales or hides the hand. Local hand offsets are blended from the existing wrist pivot so the idle pose retains its original pivot.

## Pose intent coverage

| Seal | Explicit profile intent | Known unresolved visual detail |
|---|---|---|
| 子 ZI | L index/middle straight; L ring/pinky curled; R hand wraps upright fingers | Which R joint contacts L1/L2 |
| 丑 CHOU | Close hands, outward thumbs, L middle/ring contact R dorsum | Full forearm crossing is not yet driven by an arm-bone controller |
| 寅 YIN | Both index/middle pairs straight; lower ring/pinky interlock draft | Exact interlocking pair order / foreground layer |
| 卯 MAO | L thumb/index gap; R pinky independently enters it | Exact cuboid contact boundary |
| 辰 CHEN | Separately layered semi-curled fingers; lower pinkies approach | Near versus touch, thumb direction, other interleaving order |
| 巳 SI | Ten separately articulated fingers and alternating depth draft | Exact adjacent finger pairing and thumb order |
| 午 WU | Index fingertips touch; other fingers curve below | Final contact placement and occlusion |
| 未 WEI | Upright L/R index-middle pairs; distinct lower interlock | Exact ring/pinky pair order |
| 申 SHEN | R pinky enters L thumb/index gap with different wrist pose from 卯 | Exact entry boundary, side-view calibration |
| 酉 YOU | Thumb tips touch; index/ring crossovers represented as separate constraints | Crossover partners and which hand is in front |
| 戌 XU | R fist; L flat close-set palm covers R fist | Contact plane and collision-free fit |
| 亥 HAI | Both hands half-curled, palm sides close | Exact palm-side seam and near-horizontal forearms |

## Verification boundary

- Dependency-free hand-pose harness: 442 assertions passed.
- Full standard project test runner: exit code 0, 381 PASS records, no FAIL/ERROR records; the deep archive merge fixture is a separate opt-in test.
- ForgeGradle build: not run in this authoring environment because neither a `gradle` executable nor a Gradle wrapper/distribution was available.
- Minecraft runtime: not run. No in-game visual claim is made.

## Next real visual calibration

Use the same player skin and camera position to capture each of the following in front, side, and oblique views: (1) 子, (2) 丑, (3) 寅, (4) 卯, (5) 辰, (6) 巳, (7) 午, (8) 未, (9) 申, (10) 酉, (11) 戌, (12) 亥. Prioritize 卯/辰/巳/申 as requested, and tune only the profile data unless a verified rig/controller defect requires code changes.
