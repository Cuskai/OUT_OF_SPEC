# Stage 5.3.12 Iteration Log

1. Used the supplied Stage 5.3.11 / Mod 0.6.20 full project as the incremental source baseline.
2. Added `HandSealPoseLibrary`, a data-only Java 17 profile table with anatomical left/right sides, twelve independent seal profiles, three joint-flexion channels per digit, digit spread/yaw/local XYZ offsets, wrist rotations, hand-relative offsets, and typed contact/crossing metadata.
3. Replaced the renderer's `CURL`, `FINGER_SPREAD`, and `WRIST_ANGLES` arrays with smooth per-profile joint interpolation. Preserved the neutral rest pose by blending each digit from the existing neutral joint angles and each hand from the existing wrist pivot.
4. Kept the model-builder geometry methods (`createLayer`, `addHandRig`, and `addFinger`), Punchy Mixin entry points, UV coordinates, and bilaterality fallback unchanged. No arm-bone controller was introduced; 丑印's full forearm crossover remains an explicit TODO rather than being claimed as done.
5. Updated source audits and added `HandSealPoseLibraryHarness` with 442 assertions.
6. Bumped version/build identity to Stage 5.3.12 / 0.6.21 and retained the bundled Stage 1.1 baseline and embedded Punchy package inputs.
7. Full standard test runner: exit code 0, 381 PASS lines, no FAIL/ERROR. Deep opt-in test runner: exit code 0, 382 PASS lines, no FAIL/ERROR; includes the synthetic JDK-only Punchy embed + Stage 1.1 merge fixture.
8. ForgeGradle build was not executable in this environment: no `gradle` command or `gradlew` wrapper/distribution was available, and obtaining a distribution failed. Minecraft was not launched. No claim of Forge compile or visual acceptance is made.
9. Fixed the first user-reported Windows ForgeGradle compile blocker: `slim` was passed to `applyHandPose(...)` without being declared in `renderArm(...)`. The model-name check is now stored in a method-local boolean and reused for both rig selection and hand offset handling. No rendering entrypoint or base orientation changed. Post-fix standard tests and deep package/merge fixture exit successfully; actual ForgeGradle rebuild on Windows remains pending.
