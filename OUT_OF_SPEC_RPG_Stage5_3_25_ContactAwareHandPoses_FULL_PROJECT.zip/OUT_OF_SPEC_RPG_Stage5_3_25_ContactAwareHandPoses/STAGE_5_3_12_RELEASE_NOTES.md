# Stage 5.3.12 Release Notes

- Version: `0.6.21`
- Build marker: `OUT_OF_SPEC_STAGE_5_3_12.0.6.21`
- Added a dedicated left/right anatomical pose library for all twelve basic hand seals.
- Replaced normalized shared finger curl derivation with independent base, middle, and distal joint values for each digit.
- Added per-digit local offsets and independent hand wrist/position controls.
- Added explicit contact/crossing metadata with status flags so unspecified overlap order is not falsely treated as confirmed.
- Kept the Stage 5.3.11 rig geometry, base wrist pivot, Punchy render hooks, locomotion baseline, held-item compensation, and casting/input systems unchanged.
- Added 442 pure-Java pose-library assertions and updated source audits.
- Standard automated suite passed. ForgeGradle compile and Minecraft visual validation remain unverified in this environment.

## Compile hotfix follow-up

- Corrected the `SealHandPoseRenderer` compile error reported by the first Windows `gradle clean build`: the renderer now defines `boolean slim = "slim".equals(player.getModelName())` in the method scope and reuses it for rig selection and `applyHandPose(...)`.
- This fixes the reported `cannot find symbol: variable slim` error without changing the hand model geometry, Punchy rendering hooks, base orientation, or pose logic.
- Standard repository tests and the deep JDK-only package/merge fixture were rerun after the source fix and exited successfully. A ForgeGradle build of this corrected package and Minecraft client validation still need to be confirmed on the user's Windows setup.
