# Stage 5.3.13 — Thickness-Layered First-Person Hands

- Project baseline: Stage 5.3.12 CompileFix, Mod 0.6.21
- New identity: Stage 5.3.13, Mod 0.6.22
- Runtime marker: `OUT_OF_SPEC_STAGE_5_3_13.0.6.22`
- Target: Minecraft 1.20.1 Forge, Java 17

## Geometry changes

The hand is now proportioned from an 8-unit reference palm width, and the reference ratios are scaled to the existing Classic/Slim palm widths. This replaces the prior geometry where a finger was about 0.6 units wide but 3.24 units deep.

| Part | Reference proportion | Classic (palm width 3.45) | Slim (palm width 2.65) |
|---|---:|---:|---:|
| Palm depth | 3.75 / 8 | 1.617 | 1.242 |
| Wrist bridge width | 5.5 / 8 | 2.372 | 1.822 |
| Wrist bridge depth | 4.5 / 8 | 1.941 | 1.491 |
| Finger base depth | 1.95 / 8 | 0.841 | 0.646 |
| Thumb depth | 2.75 / 8 | 1.186 | 0.911 |

The four finger base widths now correspond to approximately 1.41–1.58 reference units (Classic) and 1.44–1.60 (Slim). Each finger's middle segment is 92% of the base depth, and the tip is 82%. These are starting model proportions for in-game review, not a claim of final visual approval.

## Hierarchy and placement

`seal_hand` is the wrist joint/root. Its children are `wrist_transition` and `palm`; the palm owns `thumb`, `index`, `middle`, `ring`, and `pinky`. The thumb has its own tip joint, and each of the other fingers retains base, middle and tip segments. Thumb and selected fingers have subtle neutral Z offsets so they do not all occupy the exact same depth plane.

The palm's visible Y range is intended to remain at the old endpoint: the palm component moves to the end of the native arm and uses a shorter local box to account for the 0.75-unit forearm overlap. Finger and thumb global neutral Y locations remain aligned with the previous rig, while their front/back depths are much thinner.

## Preserved systems

- Punchy `renderArm` Mixin entrypoint, bilateral fallback, accessors, and skin-atlas selection.
- Native forearm dimensions and wrist pivot.
- State-specific idle, locomotion, held-item orientation logic; no new 180-degree correction was introduced.
- All twelve `HandSealPoseLibrary` profiles and per-joint articulation data.
- Spell/seal input, additional seals, binding contracts, growth systems, SAO Menu integration, and bundled Stage 1.1 baseline.

## Current limitation

The wrist-transition geometry and UV mapping have only been source-audited. The actual appearance of the wrist seam, finger visibility, texture sampling, and thumb side must still be reviewed in Minecraft. The Forge-dependent renderer was not compiled in this environment, and Minecraft was not launched. The user should run `gradle clean build` and then inspect idle, running/swimming, held-item, and seal-pose states before treating the geometry as accepted.
