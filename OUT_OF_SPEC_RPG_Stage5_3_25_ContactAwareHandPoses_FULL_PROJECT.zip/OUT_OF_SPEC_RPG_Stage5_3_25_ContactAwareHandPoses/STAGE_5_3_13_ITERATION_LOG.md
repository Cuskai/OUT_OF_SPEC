# Stage 5.3.13 Iteration Log — Thickness-Layered Hands

1. Started from the supplied Stage 5.3.12 CompileFix full project, not a rebuilt project.
2. Replaced the full-depth finger geometry (`3.24` front/back depth for roughly `0.6` visible width) with normalized finger depth `palmWidth * 1.95 / 8`, plus proportional reductions for middle and tip segments.
3. Reduced palm depth from the fixed `3.72` to `palmWidth * 3.75 / 8`; scaled thumb depth to `palmWidth * 2.75 / 8` and added a subtle thumb depth offset.
4. Split `seal_hand` into a wrist root with a `wrist_transition` child and a separately placed `palm` child. The palm owns all five digits; each finger still has its own three-segment hierarchy.
5. Added small neutral Z differences for index/ring/pinky fingers so selected digits sit on slightly different depth planes, while seal pose offsets continue to add on top.
6. Kept the native arm geometry dimensions, wrist root position, Punchy entrypoints, and base orientation branches unchanged. Adjusted source audits and UV-footprint bounds for the thinner geometry.
7. Bumped the output identity to Stage 5.3.13 / Mod 0.6.22 to distinguish this artifact from Stage 5.3.12.
8. Standard test runner: exit code 0, 381 PASS output records, no FAIL/ERROR/traceback.
9. Deep test runner: exit code 0, 382 PASS output records, no FAIL/ERROR/traceback; includes the JDK-only Punchy embed + Stage 1.1 merge fixture and the baseline payload-preservation check.
10. ForgeGradle build and Minecraft in-game visual validation were not available in this environment. They remain required before final visual acceptance.
