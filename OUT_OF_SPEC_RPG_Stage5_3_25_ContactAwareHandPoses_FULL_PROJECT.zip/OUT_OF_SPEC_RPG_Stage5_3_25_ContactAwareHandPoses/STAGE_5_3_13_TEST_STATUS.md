# Stage 5.3.13 Test Status

## Passed

- **Standard automation/source/package runner:** `bash tests/run_judge_tests.sh` — exit code 0; 381 PASS output records; no FAIL, ERROR, or traceback.
- **Deep automation/source/package runner:** `OUT_OF_SPEC_DEEP_PACKAGE_TEST=1 bash tests/run_judge_tests.sh` — exit code 0; 382 PASS output records; no FAIL, ERROR, or traceback.
- **Hand-seal pose data harness:** all 442 pose-library assertions pass.
- **Thickness geometry audit:** validates normalized palm, wrist, finger, and thumb depth; separate wrist/palm hierarchy; independent finger depth offsets; UV footprints; and preserved Punchy hooks.
- **Deep package fixture:** compiled and ran the JDK-only Punchy embedder and Stage 1.1 merger; verified Punchy assets, license, mixins and mod declarations; Stage 1.1 baseline payload remained byte-for-byte unchanged.
- **Version/configuration checks:** Stage 5.3.13 marker, Mod 0.6.22, output JAR name, resources JSON, Java 17 target, and bundled baseline identity pass source/package validation.

## Not run / still pending

- **ForgeGradle `clean build`: NOT RUN.** This environment has no `gradle` executable and the project archive has no Gradle wrapper. This means the Forge-dependent renderer has not been proven to compile after the geometry change.
- **Minecraft runtime / visual inspection: NOT RUN.** The exact appearance of the wrist transition, slimmer fingers, texture UVs, thumb placement, and collisions/overlaps between seal poses still needs testing in-game.

The passed source checks do not constitute Forge compilation or real-client acceptance. Use this as the next candidate build, not as a visually verified stable baseline yet.
