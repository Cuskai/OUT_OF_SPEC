# Stage 5.3.14 — Neutral Punchy Hand Basis + Longer Finger Segments

## Goal

Investigate the user's observation that the hand still appears to have a 90-degree roll after the thickness-layered hand update, and lengthen each finger segment slightly without making fingers thicker.

## What source inspection found

`SealHandPoseRenderer.java` had explicit custom, state-dependent quarter-turn compensation:

- held item: adds a side-specific `+/- PI/2` local yaw;
- idle/casting: adds a side-specific `+/- PI/2` yaw through `inwardPalmTwist`;
- locomotion: targets zero yaw.

These angles were based on an assumption about Punchy's held-arm transform, not measured from Punchy's runtime arm matrix. Since the custom hand is already attached as a child to Punchy's live native `ModelPart`, that extra baseline correction could itself produce the observed quarter-turn.

## Change made

- Removed `BASELINE_TWIST`, `targetTwist`, `inwardPalmTwist`, and the `approachAngle` baseline transition.
- The idle hand now inherits the native Punchy arm transform directly. `hand.yRot` only comes from the active seal pose's `wristYawDeg` (`wristYaw * active`).
- No Punchy source classes, renderer mixin entrypoints, arm dimensions, wrist pivot, or hand model root position were changed.
- This is a diagnostic candidate: it tests the old custom compensation against direct native-bone inheritance. If the 90-degree roll remains in-game, the next investigation should capture the inherited Punchy/model-bone transform and inspect the mesh's local axis before introducing any new correction.

## Geometry changes

Four-finger segment lengths are lengthened approximately 10–13% while their thickness values remain unchanged:

| Digit | Base segment | Middle segment | Tip segment |
|---|---:|---:|---:|
| Index | 1.25 | 0.82 | 0.61 |
| Middle | 1.32 | 0.88 | 0.65 |
| Ring | 1.25 | 0.83 | 0.61 |
| Pinky | 1.12 | 0.74 | 0.54 |

Thumb segment lengths are increased from 1.36 to 1.50 and from 0.84 to 0.92, with corresponding child offset adjusted from 1.00 to 1.10. No finger-depth or palm-depth increase was introduced.

## Identity

- Project: Stage 5.3.14
- Mod version: `0.6.23`
- Build marker: `OUT_OF_SPEC_STAGE_5_3_14.0.6.23`
- Final merged JAR name: `OUT_OF_SPEC_RPG_IronSpell_SAO_Stage5_3_14_NeutralPunchyHandBasis.jar`

## Verification boundary

Standard automated runner passed with exit code 0 and 381 lines beginning with `PASS`; all 442 `HandSealPoseLibrary` assertions passed. Deep runner passed with exit code 0 and 382 `PASS` records, including compilation and execution of the JDK-only Punchy embedder and Stage 1.1 merge test fixture. The Stage 1.1 baseline payload remains byte-for-byte unchanged.

ForgeGradle `clean build` was not run because this environment has no `gradle` executable and the project does not include a Gradle wrapper. Minecraft runtime/visual inspection has not been performed. Do not mark the orientation fixed until the user tests the candidate in Minecraft.
