# Stage 5.3.14 Test Status

## Passed

- `bash tests/run_judge_tests.sh`: exit code 0; 381 `PASS` records; no test runner failure.
- `OUT_OF_SPEC_DEEP_PACKAGE_TEST=1 bash tests/run_judge_tests.sh`: exit code 0; 382 `PASS` records; no test runner failure.
- Hand-seal pose library harness: all 442 assertions passed.
- First-person hand source audit: verifies the native Punchy arm transform is inherited, no automatic state-dependent quarter-turn compensation remains, finger/thumb segments are longer, the hand rig remains under Punchy's live arm model, and twelve side-specific pose profiles are retained.
- Package/source configuration: 12 resource JSON files parsed; mod TOML expanded and parsed; Java 17 target, refmap, identity, output artifact and bundled baseline checked.
- Deep package fixture: JDK-only Punchy embedder and Stage 1.1 merger compiled and ran. Punchy classes/resources/license/mixins and both mod declarations were found in the merged fixture; all baseline payload entries were retained byte-for-byte.

## Not run / still pending

- **ForgeGradle `gradle clean build`: NOT RUN.** `gradle` is unavailable in this environment and the project zip has no Gradle wrapper. The user must run this on Windows with Gradle 8.14.5 and JDK 17.
- **Minecraft in-game visual validation: NOT RUN.** The 90-degree issue is not confirmed fixed. This build intentionally removes the add-on's hard-coded quarter-turn so the user can verify whether the remaining orientation comes from Punchy's inherited native arm transform or the custom mesh's local basis. Check idle, moving, held-item and seal poses; also confirm skin UVs, thumb side, wrist seam, and longer digit silhouette.

Automated tests prove only the tested source/configuration and pure-Java behavior. They do not prove Forge compilation or correct in-game rendering.
