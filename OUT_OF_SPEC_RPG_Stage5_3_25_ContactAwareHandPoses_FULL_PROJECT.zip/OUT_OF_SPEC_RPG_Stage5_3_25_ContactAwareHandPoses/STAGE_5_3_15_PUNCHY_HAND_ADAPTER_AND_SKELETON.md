# Stage 5.3.15 — Punchy Hand Adapter + Explicit Hand Skeleton

## Goal

Stop mixing Punchy's animated arm transform with OUT OF SPEC's own hand orientation adjustments. Keep the animation that Punchy authors for its arms/items intact, but give the hand its own local basis and wrist joint. Preserve a clear integration boundary for a future optional Epic Fight bridge.

## Simplest explanation

Think of the model as four connected blocks:

1. **Punchy arm** — controls where the whole arm moves.
2. **Hand mount** — attaches to the wrist and follows the arm. It adds no rotation of its own.
3. **Hand basis** — translates the host's coordinate convention into the hand's anatomical convention. For Punchy this is a fixed 180-degree roll around the forearm's long axis, based on the user's earlier visual test where the thumb became visible. It does not change between empty hand, movement, held item, or seal states.
4. **Wrist + fingers** — wrist animation and every finger joint are controlled independently by the OUT OF SPEC pose library.

The old guessed `+/-90-degree` compensation that changed by state remains removed. The fixed 180-degree basis is intentionally isolated in its own node and adapter, so it cannot be confused with a motion clip or added to the forearm twice.

## Source changes

- Added `FirstPersonHandRigAdapter`, which defines how a renderer host exposes its live arm bone and the fixed local basis conversion.
- Added `PunchyFirstPersonHandRigAdapter`, the current host implementation. It accesses the exact cached first-person `PlayerModel` arm passed by Punchy's `renderArm` hook. It leaves the Punchy arm's own transform matrix untouched.
- Changed `SealHandPoseRenderer` to accept a host adapter instead of resolving left/right arms directly from Punchy's `PlayerModel`.
- Split the geometry into `seal_hand` (mount) -> `hand_basis` -> `wrist_joint` -> `palm` -> separate thumb/finger joints.
- Moved wrist pose rotations and hand-pose offsets from the mount to the downstream `wrist_joint`. The mount's X/Y/Z rotations are explicitly reset to zero every render.
- Kept the thickness-layered palm/finger proportions and the longer finger lengths from Stage 5.3.14.
- Updated project identity to Stage 5.3.15 / Mod 0.6.24.

## Epic Fight future path

The main mod has no hard compile-time EF dependency. The adapter boundary is preparation, not a claim that EF is already integrated. The next EF work should be a separate optional add-on built against the exact chosen Epic Fight 1.20.1 Forge version. It will map the same shared hand pose data to EF's applicable first-person armature/render path, without rewriting the twelve pose profiles or duplicating Punchy's logic.

## Test scope

Source tests can verify adapter separation, hierarchy shape, fixed-vs-state-dependent basis semantics, and retained joint data. Only ForgeGradle compilation and Minecraft visual tests can establish that the Mixin applies and the 180-degree host basis really exposes the thumb in all tested states.
