# Stage 5.3.15 Test Status

## Completed source and packaging checks

- `bash tests/run_judge_tests.sh`: exit code 0; 381 PASS records; no test runner failure.
- `OUT_OF_SPEC_DEEP_PACKAGE_TEST=1 bash tests/run_judge_tests.sh`: exit code 0; 382 PASS records; no test runner failure.
- Hand-seal pose library harness: all 442 assertions passed in both test runs.
- First-person hand source audit verifies the generic host-adapter boundary, Punchy's live arm anchor, one inherited native-arm transform, a dedicated hand-basis bone, a dedicated wrist-joint bone, fixed host coordinate conversion, and the twelve retained pose profiles.
- Project/package validation parsed all resource JSON files and `mods.toml`, verified Java 17 target and output artifact identity, found the licensed Punchy reference JAR, and checked the Stage 1.1 baseline SHA-256.
- Deep fixture compiled and ran both JDK-only packaging tools. It verified that Punchy classes/resources/license/mixins and both mod declarations are present, and that the original Stage 1.1 baseline payload is retained byte-for-byte.

## Not completed / not claimed

- **ForgeGradle `gradle clean build`: not run in this environment.** There is no installed `gradle` executable and this project has no Gradle Wrapper. Re-run it in Windows PowerShell with Gradle 8.14.5 and JDK 17.
- **Minecraft in-game verification: not run.** The fixed 180-degree host-basis twist is based on the user's earlier observation that this revealed the thumb. Stage 5.3.15 still needs testing in idle, movement, held-item, and seal states. This is not claimed as visually fixed yet.
- **Epic Fight runtime bridge: not included yet.** The release establishes a host adapter interface and keeps EF optional, but it does not yet contain a working EF-specific add-on. The follow-up bridge must be implemented against the exact chosen Epic Fight 1.20.1 Forge build.

Automated source/package tests do not prove Forge compilation, Mixin application, or visual correctness.
