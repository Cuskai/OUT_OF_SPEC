# Stage 5.3.16 — Remove Extra Hand-Axis Rotation

## Change

- Removed the fixed 180-degree `hand_basis.yRot` correction retained in Stage 5.3.15.
- Removed `neutralHandAxisTwistDegrees` from `FirstPersonHandRigAdapter` and removed the 180-degree constant and provider from `PunchyFirstPersonHandRigAdapter`.
- Kept `hand_basis` as an identity-only hierarchy node: X/Y/Z rotation are explicitly set to zero.
- Preserved the current palm thickness, segment lengths, skin UV mapping, wrist pivot, Punchy Mixin entry points, existing spell systems, and twelve hand-seal pose profiles.
- Retained real wrist articulation driven by active hand-seal pose data. This is not locomotion/held-item compensation and is only applied during a seal pose.

## Plain-language explanation

Before, OUT OF SPEC rotated the whole hand 180 degrees even though Punchy already animates the arm. When Punchy turned the arm for running or holding an item, our extra turn could make the palm point up. This version removes OUT OF SPEC's extra turn entirely; Punchy alone determines the movement/held-item arm direction.

## Verification boundary

Automated source/model/package checks can confirm that no hand-basis twist parameter or fixed 90/180-degree correction remains. They cannot prove the visual result. Run ForgeGradle and then test idle, running, held-item, and seal poses in Minecraft.
