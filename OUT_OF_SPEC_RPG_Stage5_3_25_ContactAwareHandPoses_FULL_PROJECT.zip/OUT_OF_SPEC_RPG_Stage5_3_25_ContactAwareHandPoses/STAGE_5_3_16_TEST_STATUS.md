# Stage 5.3.16 Test Status

## Code change
- Removed Stage 5.3.15's fixed 180-degree `hand_basis` rotation.
- Removed `neutralHandAxisTwistDegrees` from `FirstPersonHandRigAdapter`; removed the 180-degree constant/provider from `PunchyFirstPersonHandRigAdapter`.
- `hand_basis` is kept as a hierarchy node, but all three rotations are explicitly zero.
- Removed no Punchy-native rotation. Punchy's own arm animation is inherited once and unchanged.
- Kept seal-driven wrist articulation, existing finger/palm geometry, UV mapping, and all 12 seal pose profiles.

## Automated verification
- **Standard source/model/package regression:** 381 PASS lines; exit code 0.
- **Deep source/model/package regression:** 382 PASS lines; exit code 0.
- **Hand pose data harness:** 442 assertions passed.
- **Punchy embed + Stage 1.1 merge fixture:** passed; JDK packaging tools compiled and archive contents validated; Stage 1.1 baseline preserved byte-for-byte.
- **Focused hand rig audit:** passed; no host twist API or fixed host-axis compensation remains in active renderer/adapter code.

See `STAGE_5_3_16_standard_tests.log` and `STAGE_5_3_16_deep_tests.log` for the complete output.

## Not yet verified
- **ForgeGradle `gradle clean build`: not run** in this environment because a Gradle executable/wrapper is unavailable here. Run it with the project's Gradle 8.14.5 / JDK 17 setup on Windows.
- **Minecraft in-game visual validation: not run.** Check idle, running, held-item, and seal poses. The source tests establish that OUT OF SPEC no longer adds the fixed twist; they cannot prove the resulting pose is visually correct in-game.
