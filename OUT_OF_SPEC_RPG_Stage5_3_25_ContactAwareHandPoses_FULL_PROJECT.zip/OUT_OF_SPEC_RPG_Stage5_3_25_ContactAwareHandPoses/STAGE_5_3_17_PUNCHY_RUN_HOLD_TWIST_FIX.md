# OUT OF SPEC RPG — Stage 5.3.17: Punchy 跑动/持物手臂扭转隔离

## 本次目标

修正 Punchy 在本地第一人称手臂的冲刺或持物状态下施加的、会让自定义手掌方向异常的前臂长轴扭转。此补丁不把它误判为 OUT OF SPEC 手部自身的基础朝向问题。

## 保留内容

- 恢复并保留 Stage 5.3.15 中已经过用户实机观察、能正确露出拇指的 `NEUTRAL_HAND_AXIS_TWIST_DEGREES = 180.0f` 手部解剖基准。
- 保留 Stage 5.3.13 的掌心厚度分层、手指长度/厚度与独立关节数据。
- 保留 Punchy 原始 JAR、原动画资源、授权说明与 Stage 1.1 回滚基线。
- 不改 Punchy 的原始类文件；在 OUT OF SPEC 的客户端 Mixin 中适配它最终输出的第一人称手臂矩阵。

## 修正方式

`PunchyArmRotationIsolationMixin` 注入 `punchy.client.render.PunchyArmRenderer.applyGeoArmToPlayer` 的返回位置，只处理本地玩家，并仅在冲刺或对应手臂持物时运行。它根据 Punchy 的 root matrix 和手臂稳定姿势基准，计算最终旋转相对稳定姿势的四元数差，移除其中绕手臂局部 Y 轴（前臂长轴）的 twist 分量；保留最终矩阵的平移和缩放，以及剩余的 swing 旋转。

这不是把整条手臂强制重置成静态姿势，也不是移除 OUT OF SPEC 的 180° 手部基准。目标是仅移除导致掌心异常翻转的轴向扭转，同时尽量保留 Punchy 的位移和其他运动表现。

持物物品本身的模型显示变换没有被这个 Mixin 直接修改。

## 测试状态

- `tests/run_judge_tests.sh`：通过（退出代码 0）。
- 手印姿势库：442 项断言通过。
- `OUT_OF_SPEC_DEEP_PACKAGE_TEST=1` 下的完整回归：通过（退出代码 0）。
- Punchy JAR 嵌入与 Stage 1.1 合并夹具：通过；确认 Punchy 类、资源、授权文件和 baseline 内容仍在打包结果中。
- ForgeGradle `clean build`：本环境没有 Gradle 可执行程序，未能执行。
- Minecraft 实机：尚未验证，不能据此声称掌心翻转已在游戏中解决。

## 实机验证建议

解压到新目录后在 Windows PowerShell 运行 `gradle clean build`。进入游戏后依次检查：空手静止、冲刺空手、右手持物、左手持物。重点确认静止时 Stage 5.3.15 的拇指朝向没有退回，冲刺/持物时掌心不再因额外长轴扭转而朝上；再检查普通走动和游泳是否仍有相同现象。
