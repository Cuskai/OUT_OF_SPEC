# Stage 5.3.17 测试状态

| 检查项 | 结果 | 说明 |
|---|---|---|
| 标准自动化回归 | PASS | `tests/run_judge_tests.sh` 退出代码 0 |
| 手印姿势库 | PASS | 442 项断言 |
| Punchy 旋转隔离源码审计 | PASS | 检查固定 180° 手部基准仍存在，Punchy 的 sprint/持物矩阵后处理已注册，平移/缩放与 swing 保留 |
| 打包配置 | PASS | 资源 JSON、mods.toml、客户端 refmap、输出身份和 Java 17 设置通过检查 |
| Punchy 嵌入 + Stage 1.1 合并夹具 | PASS | 使用 JDK-only 工具执行并读取合并结果，baseline payload 保持完整 |
| ForgeGradle `clean build` | NOT RUN | 当前容器没有 Gradle 可执行程序或项目 Wrapper |
| Minecraft 实机 | NOT RUN | 需要在用户本机测试 |

重要限制：上述通过项是自动化/源码/打包检查，不替代 ForgeGradle 编译，也不证明游戏内的 90°/掌心朝上问题已经解决。最终需以实机静止、冲刺与持物画面确认。
