# OUT OF SPEC RPG — Stage 5.3.18 Compile Fix

## Root cause

`PunchyArmRotationIsolationMixin` checked `ModelPart` directly with `instanceof TransformablePart`. At compile time, Forge's mapped Minecraft `ModelPart` type does not declare the interface added to it by Punchy's runtime `ModelPartMixin`, so javac rejects those checks as incompatible types. At runtime, Punchy's Mixin adds `TransformablePart` to the transformed `ModelPart` class.

## Fix

Changed the two checks to perform the interface test through `Object`:

- `((Object) outputArm instanceof TransformablePart transformable)`
- `((Object) part instanceof TransformablePart transformable && ...)`

This preserves the intended runtime interface dispatch while compiling against the untransformed Minecraft API type. The rotation isolation algorithm and the restored Stage 5.3.15 hand-axis baseline are unchanged. No hand geometry, finger proportions, skill logic, or Punchy original code was changed in this compile fix.

## Validation

- JDK 17 isolated compile probe with a `final ModelPart` class and separate interface: PASS.
- Standard project regression (`bash tests/run_judge_tests.sh`): PASS, exit 0.
- Deep package test (`OUT_OF_SPEC_DEEP_PACKAGE_TEST=1 bash tests/run_judge_tests.sh`): PASS, exit 0; Punchy embedding / Stage 1.1 merge fixture passed.
- Full ForgeGradle `gradle clean build`: not run in this environment; confirm on Windows.
- Minecraft in-game animation: not verified by this source-only compile fix.
