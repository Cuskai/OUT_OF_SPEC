# Stage 5.3.18 Test Status

- **Java 17 compile probe for the exact runtime-added interface-check pattern:** PASS.
- **Standard automated regression:** `bash tests/run_judge_tests.sh`, exit code 0; all test and source audits passed, including 442 hand-pose library assertions.
- **Deep package/merge regression:** `OUT_OF_SPEC_DEEP_PACKAGE_TEST=1 bash tests/run_judge_tests.sh`, exit code 0; JDK packaging tools compiled and Punchy embedding + Stage 1.1 merge fixture passed.
- **ForgeGradle `gradle clean build`:** not run in this environment. Re-run from the extracted project folder on Windows.
- **Minecraft in-game test:** not run. Build success is not the same as verifying the Punchy sprint/held-item arm-twist behavior.

The original Stage 1.1 baseline hash remains validated by `tests/validate_project.py`; this release updates the project identity to Stage 5.3.18 / Mod 0.6.27.
