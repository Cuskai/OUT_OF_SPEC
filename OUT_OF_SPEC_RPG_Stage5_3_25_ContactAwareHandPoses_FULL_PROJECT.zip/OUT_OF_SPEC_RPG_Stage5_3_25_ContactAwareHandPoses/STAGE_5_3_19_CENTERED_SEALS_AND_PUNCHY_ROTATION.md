# OUT OF SPEC RPG — Stage 5.3.19
## Punchy movement/held rotation isolation and centered hand-seal posing

### Scope

This increment addresses the two reported first-person problems:

1. Punchy's locomotion/held-item presentation rotation leaves the custom blocky fingers facing an inconsistent direction.
2. During hand-seal input, the hands should travel inward and physically meet around the screen centre instead of staying at the ordinary arm edges.

It preserves the approved hand model from Stage 5.3.13 onward, including the thinner thickness-layered fingers, the longer segment lengths, and the fixed 180-degree anatomical conversion on the custom `hand_basis` bone. That conversion belongs to the custom hand, not the Punchy arm.

### Rotation behavior

`PunchyHandTransformIsolationMixin` injects at the end of Punchy's `applyGeoArmToPlayer` method.

- **Neutral idle:** leaves Punchy's current arm transform alone.
- **Walking/running input or an item held by that anatomical hand:** replaces the procedural arm orientation with the authored arm basis while preserving the live translation and scale. This clears the Punchy-added presentation rotation that has caused the quarter-turn discrepancy. It deliberately avoids the previous guessed-axis quaternion decomposition.
- **Seal input active:** takes precedence over locomotion/held handling. The left and right arm pivots are moved symmetrically toward the centre line, and the current transforms blend toward this centred target using the existing activation progress. The native arm is intentionally moved in this mode so the two hand rigs can meet; this differs from normal locomotion handling.

The target pivot distance is derived from the hand mesh instead of a guessed constant: Classic uses half-width `3.45 / 2` plus its `1.0` wrist-mount offset, while Slim uses half-width `2.65 / 2` plus its `0.5` offset. This places the inner palm edges at the centre line rather than deeply overlapping. It remains a starting alignment subject to in-game tuning; it is not a claim that all twelve complex contacts have passed visual verification.

### Seal activation timing

`SealInputDebugClient.handPoseActivationProgress()` already returns a smoothstep-eased value. `SealHandPoseRenderer` now clamps this value rather than easing it a second time, so the joint pose and centred-arm blend use a consistent activation curve.

### Mixin compatibility cleanup

The four Punchy client mixins/invoker now use `@Mixin(value = PunchyArmRenderer.class, remap = false)` for the public target type rather than a string-only target. This is compatible with the declared Punchy `compileOnly` dependency and removes avoidable MixinGradle warnings about specifying a public target via `value`.

### Preserved systems

- Punchy 2.8f is retained and embedded with the recorded author permission.
- The Stage 1.1 baseline JAR is retained byte-for-byte.
- The native held item renderer is not directly rewritten by this mixin; it may still visually depend on the arm transform and must be checked in-game.
- Existing spell input, binding contracts, growth, SAO Menu integration, hand-pose profile data, and per-finger joint geometry remain in place.
- The host adapter boundary remains suitable for a future optional Epic Fight bridge; that bridge is not implemented in this increment.

### Known limitations

- The twelve poses contain explicit per-digit/profile data, but entries marked `NEEDS_REFERENCE` have not been visually calibrated against side and oblique reference images.
- This environment does not provide Gradle/ForgeGradle, so a full Forge compilation could not be run here.
- No Minecraft client was launched here. In-game validation is still required for the arm rotation, held-item alignment, hand-centering distance, and all twelve visual seals.

### Simple explanation

When the player walks/runs or holds an item, OUT OF SPEC tells Punchy’s arm to use its stable authored direction instead of the extra presentation rotation, without moving the arm's current position. When seal input starts, both arm anchors instead slide inward to meet, and the independent finger bones form the selected pose. The custom hand's previously approved 180-degree anatomical basis stays untouched.
