# Stage 5.3.19 iteration log

1. Started from the Stage 5.3.18 full-project package, preserving the source tree, Punchy dependency/permission assets, and rollback baseline.
2. Audited the previous twist-decomposition mixin and identified that it reconstructed the entire arm matrix from a guessed quaternion axis, which could retain/recompose the unwanted quarter-turn.
3. Replaced that logic with a stable authored orientation on locomotion input and the corresponding held-hand state. Live translation and scale are preserved. This is not a per-finger orientation patch.
4. Made hand-seal input a separate, higher-priority transform mode. Both arm pivots blend toward a symmetric, model-width-derived edge-to-edge target; normal locomotion handling does not win over seal mode.
5. Kept the user-approved fixed 180-degree anatomical conversion on the custom `hand_basis` and retained all current hand thickness/length parameters.
6. Removed double easing of `handPoseActivationProgress`, which already returns a smoothstep value.
7. Switched four public Punchy mixin targets from string-only `targets` to the typed `value` form to avoid MixinGradle warnings about public target classes.
8. Updated the Punchy-transform and first-person rig audits to test the intended current contract, rather than stale child-counter-transform assumptions from an abandoned design.
9. Optimized the baseline spell-bytecode test to extract the handful of class files it inspects before invoking `javap`. This avoids scanning the complete 19 MB baseline JAR on every invocation without changing what is asserted.
10. Ran targeted hand/rotation checks and broad regression tests. Results and anything not verified are summarized in `STAGE_5_3_19_TEST_STATUS.md`.
