# Stage 5.3.19 / Mod 0.6.28 release notes

- Preserve the approved thickness-layered hand model, longer finger segments, and fixed 180-degree custom hand anatomical basis.
- Normalize Punchy's procedural arm orientation during locomotion input and on the side holding an item, preserving live position/scale.
- Move both arm pivots inward during hand-seal input, with a centre target calculated from Classic/Slim palm width and each model's wrist-mount offset so palm edges meet rather than overlap deeply.
- Avoid applying the activation smoothstep twice.
- Use typed Mixin target references for public Punchy renderer integration points.
- Improve the JDK-only packaging path with faster ZIP compression and CRC/size-based retained-entry verification plus byte comparisons for representative classes.
- Keep Epic Fight integration optional and unimplemented until the selected EF version's animation API is separately verified.

This release is source/test validated and its JDK-only merge fixture passes. Full ForgeGradle compilation and Minecraft visual testing remain outstanding.
