# Stage 5.3.19 test status

## Results from this environment

| Check | Result | Notes |
|---|---|---|
| Full `tests/run_judge_tests.sh` | PASS, exit code 0 | 382 lines beginning with `PASS`; includes pure-Java harnesses, all source audits, hand-rig audit, Punchy transform audit, spell-bytecode baseline audit, and package identity validation. |
| Punchy/hand rotation source audit | PASS | Keeps the approved 180-degree basis on the custom hand bone; asserts locomotion/held orientation normalization and the centred seal path. |
| First-person hand-rig audit | PASS | Confirms the shared hand rig, side-specific articulated poses, model proportions, and Punchy renderer integration. |
| JDK packaging tools compile | PASS | `javac --release 17` compiled `PunchyJarEmbedder.java` and `Stage11JarMerger.java`. |
| Deep embed/merge fixture | PASS, exit code 0 | Punchy classes, assets, license and mixin configurations embed correctly; merged Stage 1.1 entries preserve CRC/size and representative runtime classes compare byte-for-byte. |
| Baseline identity | PASS | Stage 1.1 baseline SHA-256 remains `ebb72ec47f22b64fbac3ab58ff96f9d0df5fe276638bb3cb57bf3b1832fd1fda`. |
| Complete ForgeGradle `gradle clean build` | NOT RUN | This environment has no `gradle` executable and the project has no `gradlew` wrapper. The user's Windows machine must perform this validation. |
| Minecraft client / in-game animation | NOT RUN | No Forge client was launched here. The 90-degree orientation fix and the actual visual contact between all twelve signs still require in-game confirmation. |

The standard regression harness reported these aggregate counts: 421 spell-growth catalog assertions, 4,502 generated-sequence stress assertions, 106 contract assertions, 84 Stage 2.6 model assertions, 54 Stage 2.7 input-session assertions, 44 diagnostic-recipe assertions, 573 Stage 2.9/4.8 casting-recipe assertions, 18 projectile-formation assertions, and 442 hand-pose-library assertions. The combined 138 model/input summary line is an aggregate of the 84 + 54 checks and should not be added again.

## Behaviour implemented in this increment

- During walking/running input, or when the corresponding anatomical hand holds an item, Punchy's procedural arm orientation is replaced with its authored arm basis; the live arm translation and scale are preserved.
- The fixed 180-degree anatomical conversion stays on OUT OF SPEC's custom `hand_basis`, so the run/held correction does not undo the user's previously approved hand angle.
- While the seal-input state is active, both arm anchors blend inward to a model-width-derived edge-to-edge meeting target. Classic and Slim widths use separate proportions rather than one arbitrary centre offset.
- Seal activation is no longer smoothed twice: `handPoseActivationProgress()` already returns a smoothstep value, so the renderer clamps it instead of applying another ease curve.
- Four public Punchy mixin targets use typed `@Mixin(value = PunchyArmRenderer.class, remap = false)` declarations.
- The JDK-only packaging tools use `Deflater.BEST_SPEED` to reduce unnecessary archive-build wait time. The deep fixture verified the resulting merged archive.

## Important limitation

These results establish the pure-Java logic, source contracts, package contents, and JDK-only packager. They do **not** prove the whole Forge mod compiles or that the in-game arm looks correct. Once this archive is built on Windows and loaded in Minecraft, specifically check idle hand orientation, walking, sprinting, left/right held items, and each seal's palm/finger contacts.
