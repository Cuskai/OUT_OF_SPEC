# Stage 5.3.1 — Compile Fix for Duplicate `active` Local Variable

Mod version: `0.6.10`  
Build marker: `OUT_OF_SPEC_STAGE_5_3_1.0.6.10`

## Root cause

The real Gradle output from the Stage 5.3.0 project reported `variable active is already defined in method onRenderArm(RenderArmEvent)`. The method already computed `active` from `sealPoseLatched`; a second declaration later in the same scope was redundant and prevented `compileJava`.

## Fix

Removed the duplicate declaration and reused the existing activation value. When no seal pose is active, this value is zero for pose blending only; persistent base-hand visibility and fixed scale remain independent. No rendering architecture or gameplay feature was removed.

## Validation boundary

The source/model regression suite and JDK merger fixture are run for this package. These do not replace a real `gradle clean build`; please run that command on the Windows ForgeGradle environment, because the previous compile error was observed there.
