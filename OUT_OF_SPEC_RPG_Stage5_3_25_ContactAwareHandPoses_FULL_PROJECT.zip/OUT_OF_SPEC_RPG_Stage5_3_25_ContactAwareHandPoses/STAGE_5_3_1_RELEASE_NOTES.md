# OUT OF SPEC RPG — Stage 5.3.1 / Mod 0.6.10

This is a minimal compile-fix increment on Stage 5.3.0. It removes one duplicate local variable declaration in `SealHandPoseRenderer.onRenderArm` and adds a regression assertion so the specific `compileJava` failure does not return.

All existing spell, contract, growth, additional-seal, UI, and first-person hand systems are retained. The activation value is computed once: zero outside a seal pose, positive during the pose transition. Base hand visibility and fixed scale remain independent.

Do not treat source regression as Forge build or in-game verification. Run `gradle clean build` from the project root.
