# Stage 5.3.20 Iteration Log

- Removed the bundled `punchy-2.8f-forge-1.20.1.jar`, Punchy embedder, Punchy arm mixins/accessors, and the associated active mod metadata. The project no longer has a Punchy runtime or compile dependency.
- Replaced early-frame bilateral hand drawing with a targeted injection into vanilla `ItemInHandRenderer.renderPlayerArm`, so custom geometry is drawn within the incoming per-arm PoseStack already prepared for the current vanilla item/use state.
- Removed the separate `PlayerRenderer` duplicate-arm suppression mixin and the thread-local render-pass guard; cancelling `renderPlayerArm` now suppresses only the vanilla arm geometry, not the held item renderer.
- Preserved the user-approved 180-degree local hand anatomy basis, thickness-layered palm/wrist, slim fingers, extended finger segments, separate digit joints, and all twelve pose profiles.
- Preserved seal-only center/lift offsets. Idle and held poses do not receive the seal centering shift.
- Updated Windows and Unix regression runners to test the standalone render hook, pose hierarchy, dimensions/UV envelope, config, and absence of live Punchy references.
- Removed stale Punchy embedding tasks from Gradle and aligned project/version/build output to Stage 5.3.20 / Mod 0.6.29.
- Kept the Stage 1.1 baseline JAR unchanged; packaging integration test checks retained-entry CRC and size plus byte equality for critical spell classes.
