# OUT OF SPEC RPG Stage 5.3.20 — Release Notes

**Mod version:** 0.6.29  
**Target:** Minecraft 1.20.1 Forge 47.4.0, Java 17, Gradle 8.14.5

## Changes

- Standalone OUT OF SPEC first-person arm/hand renderer replaces the vanilla per-arm geometry at `ItemInHandRenderer.renderPlayerArm`.
- Removed all active Punchy renderer/matrix integration and stopped bundling/registering Punchy.
- Kept vanilla item rendering and per-item arm pose context intact by rendering custom hand geometry at vanilla's per-arm render call.
- Preserved the current hand geometry and 180-degree local anatomical basis; seal poses retain independent wrist/finger articulation and screen-center movement.
- Updated source tests and both Unix/Windows test runners for the new standalone design.

## Verification

- Pure-Java model/harness and source audits are run by `tests/run_judge_tests.sh` (or `tests/run_judge_tests.bat`).
- The JDK-only Stage 1.1 merge fixture tests the standalone output, no Punchy metadata, baseline entry CRC/size, and representative critical class byte equality.
- Full ForgeGradle `gradle clean build` was not run in the current authoring environment because Gradle is not installed.
- Minecraft 1.20.1 in-game visual verification was not run. The custom renderer must still be checked in idle, running, held-item/use, and each seal pose before declaring the 90-degree rotation and centered-seal requirements fully fixed.
