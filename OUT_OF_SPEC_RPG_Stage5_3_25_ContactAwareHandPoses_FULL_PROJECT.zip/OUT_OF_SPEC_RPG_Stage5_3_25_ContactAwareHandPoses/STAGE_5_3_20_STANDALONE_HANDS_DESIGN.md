# Stage 5.3.20 — Standalone First-Person Hands

## Why Punchy was removed

The custom palm, thumb, finger segments, and twelve pose profiles are owned by OUT OF SPEC. They do not need Punchy's model or renderer. Repeatedly changing a hand child while still inheriting Punchy's full runtime arm matrices kept coupling the hand orientation to third-party run/held-item poses. Stage 5.3.20 removes that coupling rather than patching another 90-degree correction into it.

The current release does not redistribute Punchy's JAR, does not declare the `punchy` mod ID, has no Punchy `compileOnly` entry, no Punchy embedder task, and no active Punchy Mixin. The old permission note is retained only as historical project documentation.

## Rendering path

`StandaloneFirstPersonHandsMixin` targets Minecraft 1.20.1's `ItemInHandRenderer.renderPlayerArm(PoseStack, MultiBufferSource, int, float, float, HumanoidArm)` method. This is the point where vanilla decided it needs to draw an arm. The incoming `PoseStack` contains the current vanilla item/use transform; OUT OF SPEC uses it, applies the standard first-person arm transform for the custom geometry, draws the skin-textured articulated arm, and cancels only the duplicate vanilla arm geometry. Vanilla item rendering continues independently.

This avoids pre-rendering two arms at the start of `renderHandsWithItems`, which would draw the hands before the renderer has selected the correct per-item pose. It also avoids rewriting a third-party full-arm matrix. The hand rig does not know about Punchy.

## Rig / animation

`SealHandPoseRenderer` owns Classic and Slim arm variants. The hand hierarchy is:

`arm → seal_hand → hand_basis → wrist_joint → palm → thumb / index / middle / ring / pinky`

The hand basis retains the 180-degree local anatomical orientation previously confirmed by the user because it exposes the thumb correctly. It is now a local transform of the custom model, not a correction layered on top of Punchy. The wrist and finger joints animate from `HandSealPoseLibrary` independently.

During a seal pose only, the standard arm transform blends inward via `SEAL_CENTER_INSET` and slightly upward via `SEAL_ARM_Y_LIFT`, while a small inward yaw aligns the hands toward the middle. Neutral/running/held poses do not use this seal-only centering offset. Because the mixin takes the pose stack from vanilla's per-arm render call, held items still use vanilla's own item rendering path.

## Future Epic Fight compatibility

The core pose library remains separate from the renderer and does not depend on Epic Fight. A future EF integration should provide an optional pose/armature bridge using the chosen EF version's actual interfaces. It must not route the standalone rig back through Punchy or add state-specific quarter-turn guesses.

## Limits

This is a major change in rendering ownership, not yet an in-game-verified fix. Vanilla-style swing/equip transforms are reproduced in the custom renderer, and the active mixin method signature is consistent with the 1.20.1 mapping documentation. ForgeGradle compilation and these visual checks remain required: idle both hands, running, left/right held items, bow/crossbow/map use, and each seal pose moving both hands together in screen center.
