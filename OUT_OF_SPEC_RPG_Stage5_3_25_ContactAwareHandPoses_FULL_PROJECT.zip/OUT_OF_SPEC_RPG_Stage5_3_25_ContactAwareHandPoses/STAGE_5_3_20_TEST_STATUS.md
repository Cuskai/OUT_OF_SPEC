# Stage 5.3.20 Test Status

## Completed in the current authoring environment

- **Standard regression:** `bash tests/run_judge_tests.sh` returned exit code `0`. Its saved log has 381 lines beginning with `PASS` and no `FAIL`, traceback, assertion error, or `ERROR` lines. It includes the pure-Java gameplay/model harnesses, source/configuration audits, the standalone hand-render audit, and the Stage 1.1 spell bytecode audit.
- **Hand pose model:** 442 hand-pose library assertions passed; 4,502 generated seal-sequence stress assertions passed; the projectile-formation model harness also passed.
- **Deep standalone packaging:** `OUT_OF_SPEC_DEEP_PACKAGE_TEST=1 python3 tests/validate_project.py` returned exit code `0`. The JDK-only Stage 1.1 merger compiled, merged a synthetic standalone add-on, retained baseline entry CRC/size, preserved representative critical spell classes byte-for-byte, and confirmed no Punchy mod metadata.
- **Python syntax:** `python3 -m py_compile tests/*.py` completed successfully.
- **Baseline:** Stage 1.1 JAR SHA-256 remains `ebb72ec47f22b64fbac3ab58ff96f9d0df5fe276638bb3cb57bf3b1832fd1fda`.

## Not yet verified

- **ForgeGradle compile:** not run. No Gradle executable or Wrapper distribution is installed in the current authoring environment; downloading Gradle 8.14.5 from the official distribution endpoint failed. Therefore `gradle clean build` is not claimed to have passed.
- **Minecraft in-game visual verification:** not run. The new renderer replaces vanilla's `ItemInHandRenderer.renderPlayerArm` call, but the visual result must still be checked in the actual Minecraft client.

## User acceptance checklist

1. Idle: both custom hands visible, thumb points correctly, current thinner/longer finger proportions are preserved.
2. Running: no Punchy-specific 90-degree arm rotation can be inherited, since Punchy is not in this rendering path.
3. Held items/use: vanilla item models still render; test both left/right held items plus bow/crossbow/map states for alignment.
4. Seals: both hands move toward the center and meet near the middle while the correct per-finger pose plays.
5. Existing spell input, casting, additional seals, binding contracts, growth UI, and SAO Menu remain functional.

This status distinguishes source/model test success from Forge compilation and visual in-game acceptance.
