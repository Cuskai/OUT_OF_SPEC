# Stage 5.3.21 — Bilateral Standalone First-Person Hands

## Why this increment exists

Punchy was originally adopted in part because vanilla Minecraft does not always request rendering for both empty first-person arms. Stage 5.3.20 removed the Punchy dependency but still replaced only `ItemInHandRenderer.renderPlayerArm`; therefore it could render only the sides vanilla actually requested. A missing empty off-hand could remain invisible.

## Change

- `StandaloneFirstPersonHandsMixin` now brackets `renderHandsWithItems` with HEAD/RETURN injections.
- At frame start, `SealHandPoseRenderer.beginFirstPersonHandFrame` resets left/right draw tracking and snapshots whether a bilateral seal pose is active.
- Vanilla-requested arm calls keep their existing per-side pose for non-seal rendering, and each successfully replaced side is marked as drawn.
- At frame end, if the frame is not in seal mode, only a side vanilla did not request is synthesized using that side's equip interpolation.
- During seal mode, individual `renderPlayerArm` calls are cancelled and both articulated arms are drawn from the same base camera `PoseStack` at frame end. This gives them the same center-line composition and avoids one hand inheriting a different item-specific matrix from the other.
- Vanilla still draws held item models normally; this patch does not cancel `renderHandsWithItems` or held-item rendering.
- A duplicate same-side `renderPlayerArm` call in one frame is suppressed to avoid drawing the same arm twice.
- Added `@Shadow` access to vanilla hand height fields to interpolate main/off-hand equip progress for the missing-side fallback.

## Preserved

- No Punchy runtime, binary, renderer mixins, or embed task.
- Stage 1.1 baseline and core spell / contract / growth systems.
- Skin-atlas arm geometry, Classic/Slim variants, current thickness-layered hand model, 180-degree local anatomical basis, independent fingers and twelve pose profiles.
- Center/lift and wrist/digit animation remain seal-state-driven.

## Validation boundary

Source and scripted regression checks verify the frame hooks, bilateral state bookkeeping, per-side fallback, seal bilateral draw path, project metadata and baseline packaging. A complete ForgeGradle build and Minecraft visual test are not performed in this environment. Specifically, rendering API/Mixin application, exact hand-to-item alignment and the final visual contact of individual seals still require a local game run.
