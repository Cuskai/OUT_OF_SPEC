# OUT OF SPEC RPG Stage 5.3.21 / Mod 0.6.30

- Adds per-frame bilateral hand completion independent of Punchy.
- Keeps vanilla-requested per-hand poses for normal item interaction.
- Adds the missing empty side when vanilla skips that arm render.
- During a seal pose, defers individual arm draws and renders both custom arms together from the same camera-space pose.
- Retains vanilla held-item model rendering.
- Adds guards against duplicate arm draws within the same frame.
- No Punchy JAR or runtime/build dependency is reintroduced.

ForgeGradle and Minecraft in-game rendering remain awaiting local validation.
