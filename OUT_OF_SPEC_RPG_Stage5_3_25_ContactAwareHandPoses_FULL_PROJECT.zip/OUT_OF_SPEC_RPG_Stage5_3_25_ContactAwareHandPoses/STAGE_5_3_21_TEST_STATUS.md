# Stage 5.3.21 test status

## Passed

- Full portable test script: `bash tests/run_judge_tests.sh` exit code 0.
- 442 hand-pose library assertions passed; existing pure-Java casting, growth, contract and projectile formation harnesses passed.
- New source audit passed: per-frame hand bookkeeping, missing-empty-hand fallback, pair rendering during seal pose, and vanilla held-item rendering remains active.
- Project validation passed; Stage 1.1 baseline SHA-256 unchanged.
- Deep JDK-only merge/packaging test passed with `OUT_OF_SPEC_DEEP_PACKAGE_TEST=1 python3 tests/validate_project.py`; confirms addon and mixin merge, baseline CRC/sizes and critical class bytes remain unchanged, and Punchy metadata is absent.

## Not yet verified

- Complete `gradle clean build` / ForgeGradle compile: not executed in the current environment.
- Mixin application under actual Forge runtime: not executed.
- Minecraft in-game visual checks for two empty hands, left/right held items, sprint/swim, or all twelve contact/intersection poses: not executed.

Passing source/portable tests does not prove the Mixin applies or the hands look correct in game.
