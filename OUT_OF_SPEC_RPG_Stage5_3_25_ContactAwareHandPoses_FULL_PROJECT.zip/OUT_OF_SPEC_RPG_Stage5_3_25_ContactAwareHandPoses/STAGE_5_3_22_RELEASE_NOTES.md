# Stage 5.3.22 — Bilateral Hand Selection Fix

- Version: Mod 0.6.31
- Minecraft: 1.20.1 Forge / Java 17
- Baseline: Stage 1.1 merged into the installable build, without Punchy dependency.

## What changed

The first-person standalone hand integration now modifies `ItemInHandRenderer.evaluateWhichHandsToRender` at return. When OUT OF SPEC's first-person hands are active, it requests `RENDER_BOTH_HANDS` instead of relying only on a late-frame fallback for a hand that vanilla never requested. Active bow/crossbow/trident use is left to vanilla's special two-hand selection behavior.

The existing `renderPlayerArm` hook still replaces vanilla arm geometry with OUT OF SPEC's articulated hand rig. Frame-end completion remains as a fallback, and bilateral seal poses are still drawn together from the shared pose stack. Punchy is not reintroduced.

## Validation status

Static source tests and JDK-only package/merge checks are the validation performed in this environment. Full ForgeGradle compilation and Minecraft in-game validation have not been performed here. In-game validation remains necessary to confirm the second hand appears in the player's installed setup.
