# Stage 5.3.22 Test Status

## Source and regression checks

- `tests/check_standalone_hand_rendering.py`: run after adding the native selector override.
- `tests/check_first_person_hand_rig.py`: run.
- `tests/check_source.py`, `tests/check_spell_growth.py`, `tests/check_ui_polish.py`, `tests/validate_project.py`: run.
- Broader judge runner: started, but the 300-second execution window expired while it was still running; this is a timeout, not a reported assertion failure.
- Hand pose library: 442 assertions passed in the broader runner before it timed out.
- Deep JDK merge validation: to be run separately for this release.

## Not verified

- Full `gradle clean build` / ForgeGradle compilation: not run in this environment.
- Minecraft 1.20.1 client rendering: not run. The new selector targets the documented vanilla `evaluateWhichHandsToRender` logic and chooses `RENDER_BOTH_HANDS`, but only the user's actual Minecraft run can confirm the second hand is visually present and correctly positioned.
