# Stage 5.3.23 — Bilateral Hands Pre-Flush Fix

## Root cause found in Stage 5.3.22

The fallback path that draws a missing hand was injected at `renderHandsWithItems` **RETURN**. In vanilla 1.20.1, `renderHandsWithItems` calls `MultiBufferSource.BufferSource.endBatch()` before the method returns. The fallback hand was therefore submitted after the vanilla batch flush, so its vertices could miss the current hand-render batch. This explains why the normal vanilla-requested hand could remain visible while the synthesized second hand did not appear.

## Change

- Move `finishFirstPersonHandFrame` to an `@Inject` immediately **before** `MultiBufferSource.BufferSource.endBatch()` in `ItemInHandRenderer.renderHandsWithItems`.
- Keep the native `evaluateWhichHandsToRender` override as an additional route to get both ordinary hand calls.
- Keep the Stage 5.3.20 standalone hand renderer, current geometry, 180-degree anatomical hand basis, and bilateral seal pose intact.
- Do not reintroduce Punchy.
- Update the targeted source audit to require the pre-flush injection, preventing a future regression back to `RETURN`.

## Validation limitations

The source-level audit and project regression tests are run for this release. The complete ForgeGradle build and Minecraft client must still be tested in the user's Windows environment; a code audit alone cannot prove the second hand is visible in-game.
