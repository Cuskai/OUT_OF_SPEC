# Stage 5.3.23 Release Notes

- Mod version: 0.6.32
- Focus: make the synthesized second hand part of vanilla's current render batch.
- `finishFirstPersonHandFrame` now runs immediately before `MultiBufferSource.BufferSource.endBatch()` instead of at method return.
- Retains the native `RENDER_BOTH_HANDS` selector hook as a complementary path.
- Retains standalone hand geometry and bilateral seal poses. Punchy is not reintroduced.
- Validation: see `STAGE_5_3_23_TEST_STATUS.md` for precise pass/fail state and remaining in-game validation.
