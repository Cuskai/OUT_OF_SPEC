# Stage 5.3.24 — Unconditional Bilateral First-Person Hands

- Removed the unreliable per-side “missing hand” fallback and the earlier hand-selection-only assumption.
- While the standalone rig is active, cancel vanilla's individual arm geometry to avoid duplicate arms, allow vanilla to render held items, then emit custom LEFT and RIGHT arm/hand models unconditionally from the shared `renderHandsWithItems` outer camera pose.
- Explicitly flush custom vertices after the pair is emitted.
- Added a one-time client log marker confirming the paired draw path executes.
- Kept the accepted 180-degree local anatomical hand basis, layered cuboid proportions, three-segment fingers, and twelve independent hand-seal profiles.
- Punchy is not part of active source hooks, the build classpath, mod metadata, or packaged dependency. Epic Fight bridge remains future work.
- Focused source audits and JSON/Mixin configuration checks passed. Aggregate regression and full ForgeGradle build are not claimed complete; in-game visual verification is still required.
