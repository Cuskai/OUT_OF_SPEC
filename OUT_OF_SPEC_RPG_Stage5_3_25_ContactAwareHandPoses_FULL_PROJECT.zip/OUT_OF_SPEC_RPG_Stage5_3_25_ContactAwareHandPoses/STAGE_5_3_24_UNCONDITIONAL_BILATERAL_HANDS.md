# Stage 5.3.24 — Unconditional Bilateral Hands

## Why Stage 5.3.23 was not sufficient

Stage 5.3.22/5.3.23 source checks only proved that the native selector override and a conditional fallback existed. They did not prove that both custom hand models were actually emitted on every eligible frame. The old renderer relied on per-side flags to decide which hand was “missing”, which still coupled the result to the vanilla/Forge per-hand call path.

## Change in this iteration

- Removed the `evaluateWhichHandsToRender` override. It is not the mechanism used to guarantee that custom geometry is emitted.
- While the standalone rig is active, cancel vanilla's individual `renderPlayerArm` geometry to avoid drawing an extra arm on top of the custom pair.
- At `ItemInHandRenderer.renderHandsWithItems` RETURN, draw `HumanoidArm.LEFT` and `HumanoidArm.RIGHT` unconditionally from the same frame-level PoseStack.
- Explicitly call `BufferSource.endBatch()` after submitting the pair. Vanilla has already flushed its own item/hand batch by RETURN; custom geometry emitted after that must be flushed as well.
- Use main/offhand equip progress mapped through `player.getMainArm()` so left-dominant players are not assigned the wrong side's equip interpolation.
- Emit a one-time client log message when the paired draw path actually executes. If a future in-game test still shows one hand, this marker distinguishes “Mixin did not run” from “both draw calls ran but one model is not visible.”
- Preserve specialized vanilla map/bow/crossbow/trident arm layouts rather than overriding those cases in this iteration.
- Preserve the approved hand proportions, per-digit rig, 180-degree local anatomical basis, all twelve pose profiles, and Punchy-free build/runtime.

## Tests and limitations

Source audits and automated regression tests are run as part of this build. They verify that the renderer calls both sides unconditionally and flushes its own buffers. They cannot prove a live client displayed both sides. Complete ForgeGradle `gradle clean build` and Minecraft 1.20.1 in-game validation have not been executed in this environment and must not be described as passed.
