# Stage 5.3.2 — Hand In Front of Arm

## Why the previous implementation failed

Stage 5.3.1 only removed a duplicate local variable to fix `compileJava`; it did not substantially alter the malformed rendered mesh. Earlier handlers cancelled vanilla arm rendering and drew a second body-offset arm/sleeve model inside the first-person arm transform. The child palm/finger cuboids were within the sleeve depth, so depth testing hid most finger geometry. That meant the apparent hand could be one oversized mass or small nubs.

## Structural fix

- `RenderArmEvent` no longer cancels native arm rendering.
- Obtain the actual `PlayerModel` arm for the current side.
- Render only the custom `seal_hand` part after `nativeArm.translateAndRotate(pose)`, within an isolated `PoseStack` scope.
- The palm pivot uses `PartPose.offset(0.0F, 9.2F, -2.90F)`: its front-facing Z extent sits in front of the standard arm cube face at Z=-2, rather than inside the sleeve.
- Native forearm, sleeve, equip/swing transforms, and held item remain owned by Minecraft.
- `SealFirstPersonHandMixin` tracks each side and invokes vanilla's own `renderPlayerArm` only if the standard pass omitted an empty hand.
- Base hand geometry/visibility no longer collapses with seal activation. Seal states only change joint and wrist angles.

## Texture layout

The palm/finger models use the player's skin texture. UV audit now checks Mojang's full cuboid layout extent (horizontal `2*width + 2*depth`; vertical `depth + height`) against the native 16×16 arm texture tile: right arm U40..56/V16..32 and left arm U32..48/V48..64.

## Ten source-review gates

1. Trace render event and `renderHandsWithItems` hook locations.
2. Remove full-arm event cancellation.
3. Retain vanilla held item and arm pass.
4. Attach hand mesh to actual side-specific native arm pivot.
5. Place palm/fingers in front of sleeve depth.
6. Keep left/right render masks independent.
7. Invoke native empty-arm fallback only for sides omitted by vanilla.
8. Isolate every manual render with `pushPose`/`popPose` and `try/finally`.
9. Audit five-finger articulated geometry, twelve seal profiles, and full skin UV extent.
10. Re-run targeted source/package checks and JDK archive merger read-back.

These are source-review gates, not ten live Minecraft visual iterations. In-game quality is not yet confirmed.
