# Stage 5.3.2 iteration log — real rendering architecture correction

1. Re-read the source packaged in Stage 5.3.1 instead of relying on earlier summaries; confirmed that Stage 5.3.1 was only a duplicate-local-variable compile fix and did not change the failed mesh architecture.
2. Located the critical rendering error: `onRenderArm` cancelled vanilla and painted an entire custom arm/sleeve into an already transformed first-person hand pass, duplicating body-space pivots.
3. Removed cancellation of `RenderArmEvent`; vanilla remains responsible for forearm, sleeve, swing/equip transform and held item.
4. Rendered only the palm/finger `seal_hand` child instead of a duplicated arm/sleeve.
5. Attached the hand part to the side-specific native `PlayerModel` arm using `nativeArm.translateAndRotate(pose)`.
6. Moved the palm pivot to Z=-2.90 so its complete depth lies in front of the native arm’s Z=-2 front face.
7. Kept persistent base-hand rendering separate from seal activation, so inactive pose no longer controls hand visibility or scale.
8. Retained two-side per-frame tracking and the vanilla `renderPlayerArm` fallback for an omitted empty hand.
9. Corrected the UV test to validate the full cuboid layout (`2*width + 2*depth` horizontally, `depth + height` vertically) against the native 16×16 arm texture tile.
10. Ran all target audits individually plus the deep JDK archive-merger/read-back check, updated documentation and packaged the complete project.

These are source-level iteration gates, not ten live-client visual trials. No claim of in-game success is made.
