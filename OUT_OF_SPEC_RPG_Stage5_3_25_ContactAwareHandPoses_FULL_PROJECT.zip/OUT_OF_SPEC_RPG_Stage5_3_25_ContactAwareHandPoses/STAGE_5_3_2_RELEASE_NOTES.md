# Stage 5.3.2 Release Notes

- Mod version: 0.6.11
- Build marker: OUT_OF_SPEC_STAGE_5_3_2.0.6.11
- Baseline: Stage 5.3.1 compile-fix package

## First-person hands
- Replaces the failed custom full-arm overlay with a palm/finger-only mesh in the native arm transform.
- Keeps vanilla arm, sleeve, held-item rendering and equip/swing transform active.
- Moves hand mesh in front of sleeve depth.
- Keeps the base hand visible regardless of seal activation and uses input only for joint pose.
- Missing empty hand fallback calls vanilla `renderPlayerArm` after the standard pass.
- Adds a complete UV extent assertion for both base arm texture tiles.

## Validation boundary
- `check_first_person_hand_rig.py`: passed.
- `check_additional_seals.py`: passed.
- `check_source.py`: passed.
- `check_spell_growth.py`: passed.
- `check_ui_polish.py`: passed.
- `check_spell_power_baseline.py`: passed.
- `validate_project.py`: passed; deep JDK merger write/read test passed.
- `tests/run_judge_tests.sh`: did not complete before the execution time limit. Do not interpret the targeted checks as a full-suite pass.
- Gradle/Forge compilation and Minecraft live rendering: not run in this environment.
