# Stage 5.3.3 — First-person arm hook redesign

## What changed
- Punchy 2.8f for Forge 1.20.1 was inspected as a behavioral reference. Its general architecture replaces arm rendering at the `ItemInHandRenderer` layer and keeps left/right arm poses within a coherent first-person pass; its ARR-licensed code/assets are not copied into OUT OF SPEC RPG.
- OUT OF SPEC retains vanilla's first-person arm model and held-item pipeline. The custom palm/finger rig is now attached after the corresponding vanilla sleeve `ModelPart.render` call, instead of being drawn from `RenderArmEvent` before the arm/sleeve depth pass.
- `RenderArmEvent` now only tracks which side was selected during the pass. The existing end-of-pass fallback still invokes vanilla `renderPlayerArm` only for the side omitted by vanilla selection; the new render hook then attaches that hand after its sleeve.
- The rig does not draw a duplicate forearm or a camera-origin model. It uses the native arm pivot and current render stack, preserving vanilla skin, equipment/swing transforms, and item rendering.

## Validation boundary
The provided test scripts perform source/model audits and packaging checks only. They do not prove the mixin target matches the remapped 1.20.1 bytecode, nor do they replace `gradle clean build` or in-game screenshot validation. In particular, the new redirect target descriptor must be confirmed by ForgeGradle compilation on the user's environment.
