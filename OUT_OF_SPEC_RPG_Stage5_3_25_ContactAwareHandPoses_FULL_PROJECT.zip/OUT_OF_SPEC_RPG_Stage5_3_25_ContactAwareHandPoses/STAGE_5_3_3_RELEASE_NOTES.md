# Stage 5.3.3 release notes

- Moved articulated hand rendering to the point after the vanilla sleeve mesh has rendered inside `ItemInHandRenderer.renderPlayerArm`.
- Kept `RenderArmEvent` for per-side presence tracking only.
- Preserved native held-item rendering and the existing missing-empty-hand fallback.
- Updated Mod version to `0.6.12` and build marker to `OUT_OF_SPEC_STAGE_5_3_3.0.6.12`.
- Punchy 2.8f was used only as an architectural reference; no Punchy code/assets were copied or bundled.
- ForgeGradle compile and live Minecraft visual validation remain pending.
