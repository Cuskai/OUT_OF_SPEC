# Stage 5.3.3 validation status

## Passed checks
- Seven platform-independent Java harnesses compiled using `javac --release 17` and each exited with code 0: 421 spell-growth catalog assertions; 4,502 generated-sequence stress assertions; 106 binding-judge assertions; 84 Stage 2.6 plus 54 Stage 2.7/138 combined composable-casting assertions; 44 diagnostic recipe assertions; 573 real-seal-casting recipe assertions; and 18 projectile-formation assertions.
- Each individual source/config audit in `tests/` exited with code 0.
- The Stage 5.3.3 hand-render audit verifies that the mixin retains the native arm and item calls, attaches fingers after the matching sleeve, tracks/falls back to a missing hand, retains twelve hand-sign pose profiles, and isolates the matrix stack.
- `OUT_OF_SPEC_DEEP_PACKAGE_TEST=1 python tests/validate_project.py` exited with code 0. Its synthetic JDK-only jar merger compiled and completed write/read-back checks; the Stage 1.1 baseline payload remained byte-identical.

## Not validated
- The aggregate `tests/run_judge_tests.sh` did not finish within the available execution time limit, so this report does not claim that aggregate script exited successfully. Its harnesses and audits were run separately as listed above.
- No Gradle executable is available in this work environment. ForgeGradle compile, Mixin remapping/application at runtime, and Minecraft in-game visuals have not been validated here.
- The new `ItemInHandRenderer.renderPlayerArm` redirect target must be confirmed by the user's real `gradle clean build`; visual quality must then be checked in-game. Source assertions are not a substitute.

## Punchy reference
The user-provided Punchy 2.8f Forge 1.20.1 JAR was inspected only as an architecture reference. It is not included in this project archive, and no Punchy source code or assets were copied. The mod keeps its independent OUT OF SPEC hand model and seal pose data.
