# Stage 5.3.4 — Mixin mapping conflict compile fix

Mod version: `0.6.13`

## Reported failure
ForgeGradle compileJava failed with a Mixin Annotation Processor error on `@Invoker("renderPlayerArm")` in `SealFirstPersonHandMixin`, reporting a mapping conflict for `m_109346_`.

## Fix
- Moved the `@Invoker("renderPlayerArm")` declaration into a dedicated `ItemInHandRendererArmInvoker` interface mixin.
- Registered the accessor interface in `out_of_spec_binding.client.mixins.json`.
- Changed the fallback call to cast the target instance through the accessor interface.
- Kept the `@Redirect(method = "renderPlayerArm")` in `SealFirstPersonHandMixin`, but no longer co-located it with the invoker annotation.
- Updated source audits and project validation to lock in this separation.

The split is intended to prevent the refmap mapping collision triggered when the accessor and redirect target share the same mixin class. It does not claim to fix unrelated runtime rendering issues.

## Validation status
- Targeted hand-render source audit: passed.
- Additional-seal/source/growth/UI audits: passed.
- Project config/metadata: passed after correcting the stale version regex; the deep JDK merger fixture also passed.
- Full `tests/run_judge_tests.sh`: timed out in this build environment; do not treat it as a full-suite pass. Targeted source audits and the deep package merger fixture completed successfully.
- Full `gradle clean build`: not available in this build environment; the user's reported mapping conflict is the latest real Forge compile result so far.
- Minecraft in-game visual result: not yet validated.
