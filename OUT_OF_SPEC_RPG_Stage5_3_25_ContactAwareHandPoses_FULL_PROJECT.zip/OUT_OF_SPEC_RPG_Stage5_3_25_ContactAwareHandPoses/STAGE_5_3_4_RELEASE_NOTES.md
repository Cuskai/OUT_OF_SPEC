# OUT OF SPEC RPG Stage 5.3.4 release notes

- Mod version: `0.6.13`
- Base: Stage 5.3.3 Punchy-style arm hook
- Fix: isolate `renderPlayerArm` invoker into a dedicated client accessor mixin to avoid Mixin AP mapping conflict.
- Preserve: the existing first-person sleeve redirect, native arm/item rendering, bilateral-hand fallback, seal poses, spell growth, additional seals and binding contract systems.
- Tests: first-person hand audit, additional-seal/source/growth/UI/spell-power audits and project metadata checks passed; deep JDK merger read-back passed. The unified script timed out and is not marked as a full-suite pass.
- Not claimed: no successful ForgeGradle build or in-game verification has been run in this environment.
