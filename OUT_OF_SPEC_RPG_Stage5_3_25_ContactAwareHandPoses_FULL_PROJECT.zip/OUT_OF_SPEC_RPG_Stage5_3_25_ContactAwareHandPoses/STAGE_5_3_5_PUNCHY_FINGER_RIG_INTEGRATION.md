# Stage 5.3.5 — Punchy first-person rig integration

## Why the previous implementation failed
The earlier OUT OF SPEC hand hook targeted vanilla `ItemInHandRenderer.renderPlayerArm` and queried the world `PlayerRenderer` model. Punchy draws first-person arms with its own cached `PlayerModel` in `punchy.client.render.PunchyArmRenderer.renderArm`; the model tested by the previous hook was not the live model that Punchy actually drew. This explains why the arm presentation could change while the articulated finger child was missing or unrelated to the visible arm.

## Integration in this build
- The user supplied `punchy-2.8f-forge-1.20.1.jar` and reports explicit permission from author Dev Punchy Man to include its code and resources.
- The build uses that JAR as a compile-only target for the Punchy arm Mixin, then `PunchyJarEmbedder` copies Punchy's compiled classes, textures/assets, service-provider files, refmap, Mixin configs, icon, and original `LICENSE_Punchy` into the reobfuscated OUT OF SPEC add-on. Its original `META-INF/mods.toml` is not copied; the integrated TOML registers both `out_of_spec_binding` and `punchy` so Forge does not scan duplicate metadata entries.
- `PunchyArmHandsMixin` injects at the head of Punchy's private `renderArm` method and passes the exact first-person `PlayerModel` instance to `SealHandPoseRenderer.attachAndPosePunchyHand`.
- `ModelPartChildrenAccessor` exposes the live arm's child map. The persistent `seal_hand` part (palm, thumb, index, middle, ring, and pinky) is attached once to the matching live left/right arm model. The custom hand is not attached to the world entity renderer model.
- Classic/slim arm wrist X offsets are computed from each model cuboid center (`-1/+1` classic, `-0.5/+0.5` slim). The hand sits at `y=10.45`, slightly overlapping the wrist and at `z=-2.55`, in front of the sleeve surface.
- The current arm, sleeve, equip/swing transforms, and held item stay owned by Punchy's renderer. This integration does not cancel the whole hand/item render pass. Seal input blends wrist and finger joints only; activation does not scale the entire hand down or toggle its visibility.
- `mods.toml` retains the Punchy display name, author, icon, credits and description. `LICENSE_Punchy` and `PUNCHY_INTEGRATION_PERMISSION.md` remain in the project/final JAR.

## Installing the merged artifact
The final merged JAR declares both `out_of_spec_binding` and `punchy`. Remove the standalone Punchy JAR from the `mods` folder while using the merged OUT OF SPEC artifact; installing both would register `punchy` twice. The source reference JAR remains in `libs/` only so Gradle can compile the Mixin target and embed its exact authorized bytes during packaging.

## Verification boundary
The source tests confirm Mixin wiring, persistent live-arm attachment, UV-safe cube footprints, twelve seal pose tables, multi-mod TOML, Punchy entry/license/icon/mixins in the package, and the JDK-only embed/merge flow. The deep archive fixture compiles `PunchyJarEmbedder.java` and `Stage11JarMerger.java`, embeds the actual Punchy JAR into a synthetic add-on, merges it with the Stage 1.1 baseline, checks CRCs, verifies all four Mixin configs/two mod IDs and Punchy resources, and compares all baseline payload entries byte-for-byte.

This does **not** prove ForgeGradle `compileJava` succeeds or that the fingers look correct in Minecraft. No Gradle executable or running Minecraft client was available in the authoring environment. The user must run `gradle clean build` and inspect a new in-game screenshot before visual acceptance.
