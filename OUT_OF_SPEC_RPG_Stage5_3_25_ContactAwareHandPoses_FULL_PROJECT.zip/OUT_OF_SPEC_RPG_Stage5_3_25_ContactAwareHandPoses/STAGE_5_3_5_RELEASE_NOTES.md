# OUT OF SPEC RPG Stage 5.3.5 / Mod 0.6.14

## Main change
Integrated Punchy 2.8f for Forge 1.20.1 (the user reports explicit author permission) and changed the custom articulated fingers to attach to Punchy's actual first-person `PlayerModel` arm tree.

## Included
- Punchy original classes/resources/service providers/refmap/client Mixin configs/icon/license, embedded after reobfuscation.
- One installable merged JAR declares both OUT OF SPEC RPG and Punchy. Do not install the standalone Punchy JAR alongside it.
- `PunchyArmHandsMixin` targets `PunchyArmRenderer.renderArm`; old vanilla `renderPlayerArm` redirect/invoker mixins were removed.
- Corrected classic/slim model wrist center offsets; persistent custom hand part with palm, two-piece thumb and three-segment index/middle/ring/pinky; 12-seal pose tables retained.
- Original OUT OF SPEC systems and Stage 1.1 baseline retained.

## Tests
- Individual Java model harness outputs: catalog (421 assertions), generated sequence stress (4,502), binding judge (106), seal/session and diagnostics harnesses, real seal recipes (573), and projectile formation (18) emitted their PASS summaries during the suite run.
- The source audit scripts (including binding judge, composable model, input session, HUD, additional seals, first-person rig, spell growth, UI polish, and spell-power/baseline checks) passed when run individually.
- `validate_project.py` passed; with `OUT_OF_SPEC_DEEP_PACKAGE_TEST=1`, the JDK-only Punchy embed + Stage 1.1 merge fixture exited 0, checked the merged archive, confirmed both mod IDs and four Mixin configs, and verified baseline payloads byte-for-byte.
- The monolithic `tests/run_judge_tests.sh` did not yield a recorded exit code before the execution tool timeout, so it is not claimed as a single successful suite run.
- Real ForgeGradle compile and Minecraft runtime/visual test remain pending; this environment does not provide Gradle.
