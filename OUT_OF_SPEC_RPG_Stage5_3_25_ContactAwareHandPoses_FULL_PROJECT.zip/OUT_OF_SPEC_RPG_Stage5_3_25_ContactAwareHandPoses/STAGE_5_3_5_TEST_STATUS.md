# Stage 5.3.5 validation status

| Layer | Result | Scope |
|---|---|---|
| Source/config audits | PASS individually | The current Punchy hook, permanent live-model finger child, UI, spell-growth, casting, contract and mixin config were checked. |
| Java pure-model harnesses | PASS summaries observed | 421 growth catalog assertions; 4,502 generated sequence stress assertions; 106 binding-judge assertions; 573 real seal recipe assertions; 18 projectile formation assertions plus session/composable/diagnostic harnesses. |
| `validate_project.py` | PASS | Source project/version/TOML/resources/baseline integrity. |
| Deep JDK-only embed/merge fixture | PASS, exit code 0 | Compiled both packaging helpers; embedded actual Punchy 2.8f; merged into a synthetic add-on and Stage 1.1 baseline; checked output CRC, both mod IDs, four Mixin configs, Punchy classes/assets/license/icon, and byte-identical baseline payload. |
| One-command `tests/run_judge_tests.sh` | INCOMPLETE | Execution tool timed out after writing a large log; no reliable final exit code was recorded. Individual checks were run separately. |
| ForgeGradle `compileJava` / `gradle clean build` | NOT RUN HERE | No Gradle executable available in this authoring environment. |
| Minecraft real-time visual test | NOT RUN HERE | Requires running Forge 1.20.1 and a new user screenshot. |

Do not treat source audits as compile or gameplay verification. The next validation step is running `gradle clean build` from the extracted Stage 5.3.5 project, then testing the merged JAR in Minecraft with the standalone Punchy JAR removed.
