# Stage 5.3.6 — Client Mixin Refmap Fix

## Root cause from the supplied crash report

The crash report at 2026-10-18 01:35:36 showed:

`InvalidAccessorException: No candidates were found matching children:Ljava/util/Map; in net/minecraft/client/model/geom/ModelPart`

followed by:

`AbstractMethodError: ModelPart ... does not define ... ModelPartChildrenAccessor.getOutOfSpecChildren()`

The main mixin config (`out_of_spec_binding.mixins.json`) declared `out_of_spec_binding.refmap.json`, but the client config (`out_of_spec_binding.client.mixins.json`) did not. The client-side `@Accessor("children")` therefore attempted to find the named field in the runtime SRG namespace and failed. Punchy's render hook later invoked that non-working accessor and crashed during first-person rendering.

## Fix

- Added `"refmap": "out_of_spec_binding.refmap.json"` to `out_of_spec_binding.client.mixins.json`.
- Kept `ModelPartChildrenAccessor` in the client mixin list.
- Added regression assertions to both `tests/validate_project.py` and `tests/check_first_person_hand_rig.py`.
- Bumped the project marker/version to Stage 5.3.6 / Mod 0.6.15 and changed the output artifact name so this build cannot be confused with Stage 5.3.5.
- No spell system, contract system, UI, hand pose geometry, or bundled Stage 1.1 baseline payload was intentionally changed in this fix.

## Validation boundary

The uploaded crash log is sufficient to identify this runtime mapping error. The local checks validate config shape and project packaging. This environment does not provide the user's Windows Gradle runtime, so a new `gradle clean build` and game launch still need confirmation on the user's machine.

## Packaging hardening

`PunchyJarEmbedder` now refuses to emit the final merged add-on unless the client mixin JSON references `out_of_spec_binding.refmap.json` and that generated refmap is present. The deep synthetic merge test includes the refmap entry and verifies the merged archive retained it.
