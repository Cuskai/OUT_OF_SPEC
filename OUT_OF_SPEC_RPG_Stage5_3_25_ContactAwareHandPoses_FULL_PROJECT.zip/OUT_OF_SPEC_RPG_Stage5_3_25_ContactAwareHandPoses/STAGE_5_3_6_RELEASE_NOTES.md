# OUT OF SPEC RPG Stage 5.3.6 / Mod 0.6.15

### Fixed
- Fixed the client mixin mapping crash reported in `错误报告-18-10-2026_1.35.41_am.zip`.
- Client mixin config now points to `out_of_spec_binding.refmap.json`, so the `ModelPart.children` accessor can be remapped from the official source name to the Forge runtime name.
- Added regression assertions for the refmap in project validation and first-person hand-rig audit.

### Preserved
- Punchy 2.8f integration path and author/license metadata.
- Persistent hand rig / twelve-seal pose data.
- Spell discovery, spell growth, additional seals, binding-contract AI, and SAO UI.
- Bundled Stage 1.1 baseline JAR payload.

### Not claimed
This package has not yet been confirmed by a new ForgeGradle build or Minecraft launch on the user's machine.
