# Stage 5.3.6 Test Status — Client Refmap Crash Fix

## Root cause confirmed from the supplied crash report

`crash-2026-10-18_01.35.36-client.txt` reports:
- `InvalidAccessorException: No candidates were found matching children:Ljava/util/Map; in net/minecraft/client/model/geom/ModelPart`
- Followed by `AbstractMethodError` for `ModelPartChildrenAccessor.getOutOfSpecChildren()` called from `SealHandPoseRenderer.attachAndPosePunchyHand`.

The main mixin config referenced `out_of_spec_binding.refmap.json`; the client mixin config did not. The accessor's source-level field name `children` was therefore not mapped for the Forge/SRG runtime. This exact configuration omission caused the accessor mixin to fail, and the later first-person hook invoked the absent accessor implementation.

## Changes in Stage 5.3.6 / Mod 0.6.15

1. Added `"refmap": "out_of_spec_binding.refmap.json"` to `out_of_spec_binding.client.mixins.json`.
2. Added regression assertions to `validate_project.py` and `check_first_person_hand_rig.py`.
3. Strengthened `PunchyJarEmbedder` to fail packaging unless:
   - the final client mixin JSON names the generated refmap, and
   - `out_of_spec_binding.refmap.json` is present in the add-on JAR.
4. Updated synthetic deep-package fixture to include and validate the same refmap association.
5. Bumped project version/output identity to Stage 5.3.6 / Mod 0.6.15 to prevent confusion with the previous 0.6.14 JAR.

## Checks actually run and passed (exit code 0)

- `OUT_OF_SPEC_DEEP_PACKAGE_TEST=1 python tests/validate_project.py`
  - Parsed all resource JSON, validated version/config, source Punchy package/license, compiled both JDK-only packaging tools, embedded Punchy into a synthetic add-on, merged it with the Stage 1.1 baseline, read the result back, and checked original baseline payloads remain byte-for-byte unchanged.
- `python tests/check_first_person_hand_rig.py`
- `python tests/check_source.py`
- `python tests/check_additional_seals.py`
- `python tests/check_spell_growth.py`
- `python tests/check_ui_polish.py`

Individual stdout logs are in `test-results/stage5_3_6_client_refmap_fix/`.

## Limits / not claimed

- The complete `tests/run_judge_tests.sh` attempt exceeded the execution time limit; its overall exit status is not claimed as successful.
- Gradle is not installed in this working environment, so ForgeGradle `compileJava` / `gradle clean build` was not run here.
- Minecraft has not been launched with the patched 0.6.15 artifact in this environment. The provided crash diagnosis is confirmed; successful runtime startup after the patch still needs the user's launch test.

The crash log also shows Java 25.0.1. That is not the cause of the logged accessor mapping failure; if unrelated launch issues remain after this fix, use the Java 17 runtime recommended for this 1.20.1 Forge setup.
