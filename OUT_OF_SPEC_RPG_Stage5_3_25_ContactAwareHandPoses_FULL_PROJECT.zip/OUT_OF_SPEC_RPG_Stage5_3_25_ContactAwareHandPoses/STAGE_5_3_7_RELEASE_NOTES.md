# OUT OF SPEC RPG Stage 5.3.7 / Mod 0.6.16

## 主变更
- 增加 Punchy 帧级 LEFT/RIGHT 记录，在本帧渲染结束前补绘未渲染的空手；补绘复用 Punchy 的第一人称 `PlayerModel` 和 `renderArm`。
- 遵循真实持物、Punchy 视觉副手切换栈以及 `isHandBlacklisted` 配置；不取消正常物品渲染。
- 手掌更深并与腕部重叠；UV 调整到左右臂正面手部区域；中立四指微弯且稍微收拢。
- 保留 Punchy 作者许可文档、源 JAR、资源、许可证和 Mixin 配置合并步骤。

## 测试状态
- `tests/run_judge_tests.sh`: exit code 0; log contains 380 lines beginning `PASS`.
- `tests/check_first_person_hand_rig.py`: passed as part of the suite.
- `OUT_OF_SPEC_DEEP_PACKAGE_TEST=1 python tests/validate_project.py`: exit code 0; JDK-only embed/merge tools compiled, merged ZIP was read back, baseline payload remained byte-identical.
- ForgeGradle `compileJava` and Minecraft in-game rendering were not executed in this environment; do not treat the above as a real mod build or visual acceptance.
