# Stage 5.3.7 — 根因审计与双手渲染修复

## 结论

Stage 5.3.6 的实机截图里只出现一只手，不是一个单一的“角度参数”问题，而是三个彼此独立的问题叠加：

1. **只装饰已被 Punchy 选择渲染的手。** 原来的 `PunchyArmHandsMixin` 只在 `PunchyArmRenderer.renderArm(...)` 的 HEAD 执行。Punchy 的 `renderFirstPersonInternal(...)` 会按两组布尔条件分别调用左、右 `renderArm`；未被它选中的空手根本不会进入这个 hook，因此这个 hook 不可能凭空补出第二只手。
2. **闲置姿势过于摊开。** 旧指根固定在 `x = -1.23, -0.41, 0.41, 1.23`，四指闲置弯曲仅 `0.14`，拇指弯曲 `0.34`。这让手势看起来像张开的扇形手掌，而不是自然放松的 Minecraft 方块手。
3. **掌腕几何和皮肤 UV 不匹配。** 旧掌心位于 `(wristCenterX, 10.45, -2.55)`，掌深只有 `0.52`；相对于手臂末端 `y≈10` 和袖子前表面 `z≈-2.25`，连接只剩很窄的边缘接触。旧的右手 UV 从 `(40,28)` 开始、左手从 `(32,60)` 开始，偏向手臂侧面 atlas 区域，而不是手背/手掌正面的末端区域；每个指节又复用同一个小 UV 起点，使手指表面颜色和明暗缺乏一致的正面映射。

## 依据

- `PunchyArmRenderer.renderFirstPersonInternal(...)` 的字节码中，左臂和右臂的 `renderArm(...)` 调用分别受条件跳转控制。只向 `renderArm` 注入手指并不能强制绘制被跳过的那一侧。
- `PunchyArmRenderer.renderArm(...)` 是 Punchy 自己的第一人称手臂绘制入口，负责使用缓存的第一人称 `PlayerModel`、皮肤纹理和该 Mod 的手臂变换；不能使用世界实体渲染器那份 `PlayerModel` 来推算第一人称手部位置。
- `SealHandPoseRenderer` 的掌面和指节是附加到 Punchy 缓存模型的 `leftArm/rightArm` 子部件。父臂的变换、可见性、皮肤纹理和绘制时机都会直接影响它们。

## Stage 5.3.7 修复

### A. 在整帧级别补齐缺失的空手

新建 `PunchyBilateralHandsMixin`，在 `renderFirstPersonInternal` 开始时建立每帧状态；`PunchyArmHandsMixin` 在原版/Punchy 每次真正进入 `renderArm` 时记录该侧。Punchy 完成原本的臂/物品选择后、第一人称 PoseStack 最外层 `popPose()` 前，`PunchyBilateralHandRenderState` 检查 LEFT/RIGHT：

- 这帧已经渲染的手不会重复绘制；
- 只有缺失且对应交互手为空的那一侧才会补绘；
- 遵守 `PunchyConfig.isHandBlacklisted(...)`；如果 Punchy 正处于副手物品视觉切换，也通过 `HandEquipStateMachine.getVisualOffhandStack(...)` 跳过补绘；
- 通过独立 `PunchyArmRendererInvoker` 调用 Punchy 自己的缓存模型和 `renderArm`，不在摄像机原点另画模型；
- 原版/Punchy 持物调用没有被取消。

### B. 让手腕连接到前臂而不是只在边缘碰到

- 掌心枢轴从 `(wristCenterX, 10.45, -2.55)` 改为 `(wristCenterX, 9.75, -2.55)`，与手臂末端产生明确重叠。
- 掌面尺寸改为约 `0.82 × 1.28 × 0.70`，深度跨过袖子前平面，但 UV 展开仍受 4×4 手部图集区域检查约束。
- 四指锚点收拢到 `-1.05, -0.35, 0.35, 1.05`，指节宽度相应变窄，以留出可见分隔。

### C. 修正皮肤图集区域与闲置手姿势

- 右手末端正面 UV 使用 `(44,28)`；左手使用 `(36,60)`。
- 闲置状态依然显示完整掌面和五指，结印状态只改变姿势；四指的中立弯曲从 `0.14` 增至约 `0.30–0.34`，拇指中立弯曲为 `0.42`。这减少完全摊平的“星形手掌”。

### D. 继续保留既有系统

没有更改结印输入状态机、十二种地支印姿势数据、法术目录/成长、追加印执行、束缚契约、SAO Menu，也没有修改内置 Stage 1.1 基线 JAR。

## 仍需实机确认的风险

- 这轮没有在当前环境完成 ForgeGradle 编译或 Minecraft 实机启动；因此双手是否在用户配置下实际出现、UV 在其自定义皮肤上是否自然、Punchy 配置是否改变手臂占屏比例，都不能通过源码测试完全证明。
- 四指/掌心使用玩家皮肤末端的小区域作为纹理源，这保留玩家皮肤颜色，但并不会在皮肤 atlas 中凭空创造独立手指纹理。若实机仍然像一团颜色，需要下一步对每个面实施明确的 UV 展开或建立动态手部纹理，而不是再调旋转参数。
