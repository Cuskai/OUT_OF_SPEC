# Stage 5.3.8 Iteration Log

1. Removed item-stack and item-blacklist gating from the permanent-hand fallback.
2. Added pre-item-pass completion so supplementary arms render beneath held items.
3. Kept the frame-tail fallback for frames without an item-render call.
4. Forced visibility/skipDraw state only for the live local first-person arm before fallback draw.
5. Moved hand pivot from camera-side `z=-2.55` onto native arm plane `z=0`.
6. Replaced four thin palm tiles with a single full-depth palm cuboid.
7. Matched palm width to classic/slim player-arm variants.
8. Made fingers extend along the native arm-local +Y axis, with depth near the forearm depth.
9. Mirrored left-hand digit ordering so index remains adjacent to thumb.
10. Remapped palm, thumb, and fingers into base-arm skin atlas regions and expanded the audit to check their full UV footprints.

Unverified: actual ForgeGradle compilation and in-game visuals. The iteration number is an audit checklist, not a claim that the final image is visually perfect.
