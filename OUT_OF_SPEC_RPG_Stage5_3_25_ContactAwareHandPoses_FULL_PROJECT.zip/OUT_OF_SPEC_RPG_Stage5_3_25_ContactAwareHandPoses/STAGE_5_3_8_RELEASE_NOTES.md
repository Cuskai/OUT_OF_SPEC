# OUT OF SPEC RPG Stage 5.3.8 / Mod 0.6.17

This stage corrects the native first-person arm adaptation rather than tuning the prior thin overlay.

- Always-complete bilateral arms: the render state supplements any side Punchy omitted, regardless of an empty/non-empty item stack, and does so before held-item drawing whenever possible.
- Native arm orientation: hand root `(wristCenterX, 9.25, 0)`, no idle wrist rotation, palm depth 3.72, arm-width-aware palm width, fingers extending along the arm-local +Y axis.
- Thumb/hand anatomy: a thick outer thumb and separate three-segment fingers. Left-hand finger ordering is mirrored to keep the index beside the thumb.
- Texture: uses the base-arm skin atlas regions (right `(40,24)`, left `(32,56)`) and per-finger strip offsets rather than reusing a tiny patch for every joint.
- Existing Punchy-integrated item path remains intact. No stage 1.1 baseline bytes are modified.

No claim is made that the ForgeGradle build or in-game visual acceptance passed; those need the user's Windows build and screenshot.
