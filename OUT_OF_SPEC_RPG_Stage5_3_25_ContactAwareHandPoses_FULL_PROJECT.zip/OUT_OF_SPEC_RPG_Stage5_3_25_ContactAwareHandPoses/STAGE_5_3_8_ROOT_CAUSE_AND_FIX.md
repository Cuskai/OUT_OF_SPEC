# Stage 5.3.8 — 根因复查与手臂轴向适配

## 本次根因

用户指出此前仍然只在某些持物状态显示一只手，且掌面薄、朝向错误。复查 Stage 5.3.7 源码发现：

1. `PunchyBilateralHandRenderState.renderMissingEmptyHands()` 把补绘条件限制为对应 `ItemStack` 为空、`visualOffhand` 为空且不在 Punchy 黑名单中。逻辑本身与“常驻双手”需求冲突，因此空手会继续被跳过。
2. 补绘只在 `renderFirstPersonInternal` 的最终 `popPose()` 前进行，此时 Punchy 的物品已经绘制完成。若缺失侧刚好参与持物状态，简单补画手臂会有遮住物品的风险，上一版所以又通过 stack gate 跳过，形成了死结。
3. 掌面根部为 `(wristCenterX, 9.75, -2.55)`，掌面分成四片 `0.82 × 1.28 × 0.70` 的薄块。其 Z 偏移把掌面放到摄像机侧，而不是和原版手臂共面；厚度远小于原版手臂约 4 单位的深度，造成薄片、掌心朝向错误和腕部连接不自然。
4. 左手沿用了右手相同的四指左右排序，拇指却已经镜像，导致左手食指/小指相对拇指的位置反了。

## 修复

- 在 `renderFirstPersonInternal` 开始记录实际绘制的左右臂。
- 在第一次 `renderItemInHand(...)` 调用前补齐未绘制侧，确保缺失手臂先绘制、物品后绘制；末尾 `popPose()` 前仍保留兜底，以兼容没有物品绘制调用的帧。
- 移除补绘逻辑对 item stack/visual offhand/黑名单的 gate。补绘前针对 Punchy 的缓存第一人称模型强制设置目标臂 `visible=true`、`skipDraw=false`，然后仍调用 Punchy 自己的 `renderArm` 方法。
- 手掌改为一个完整 cuboid：根部 `(wristCenterX, 9.25, 0)`，Z=0，经典臂宽 3.45、slim 臂宽 2.65、厚度 3.72。它在 Y 轴上与原版前臂重叠约 0.75 单位并自然延伸过腕端。
- 五指使用沿本地 +Y 轴的厚块三段结构，四指在 X 轴分开，左手顺序镜像；拇指同样使用接近手掌厚度的三维盒体。
- 皮肤 UV 从右臂基础 atlas 区域 `(40,24)` 与左臂 `(32,56)` 取样。每根手指有独立的 U 起始偏移，UV footprint 检查按实际的 16×8 arm patch 检查，而不是错误要求一个 4×4 patch 容纳整只手。

## 验证边界

自动化测试可以检查上述结构和条件，但不能证明真实游戏中的手掌方向、模型遮挡与动画外观已符合参考图。ForgeGradle 编译和 Minecraft 实机验收仍需要在 Windows 环境执行，结果会与源码测试分开记录。
