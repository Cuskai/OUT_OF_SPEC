# Stage 5.3.10 — First-Person Hand Orientation Swap

Mod version: `0.6.19`  
Build marker: `OUT_OF_SPEC_STAGE_5_3_10.0.6.19`

## User-reported issue

The Stage 5.3.8 hand model had visibly reversed left/right hand orientation. The user requested swapping the orientation, not swapping which physical arm appears at each screen side.

## Exact change

1. The physical left and right arm attachment points remain on `model.leftArm` and `model.rightArm`; their positions, the base-arm skin atlas regions, classic/slim width behavior, permanent visibility, item renderer, Punchy integration, and bilateral fallback remain unchanged.
2. The hand-geometry handedness flags are swapped: `rightArm` now uses `mirror=true`; `leftArm` now uses `mirror=false`. This exchanges thumb side and the X-order of the four finger segments without moving the forearms to the opposite screen sides.
3. The pose/profile handedness passed into `applyHandPose` is also swapped (`!left`). The per-hand finger curl/spread channels, wrist roll/yaw selection, and thumb rotation sign now agree with the swapped geometry.
4. The hand-rig audit has been updated to fail if the former mapping returns.

This is deliberately a focused orientation correction. It does not invent the twelve detailed hand-seal poses; the user will provide their detailed pose specification separately.

## Validation boundary

- `tests/check_first_person_hand_rig.py`: PASS.
- `tests/check_source.py`: PASS.
- `tests/check_spell_growth.py`: PASS.
- `tests/check_ui_polish.py`: PASS.
- `tests/check_spell_power_baseline.py`: PASS.
- `tests/validate_project.py`: PASS.
- `OUT_OF_SPEC_DEEP_PACKAGE_TEST=1 python tests/validate_project.py --deep`: PASS, including JDK merger/embedder build and merged archive read-back; the Stage 1.1 baseline hash remains unchanged.
- The full `tests/run_judge_tests.sh` produced PASS output for the Java model harnesses and source audits, but exceeded the execution time limit at the final UI carry-forward audit; its overall exit code was therefore not confirmed and is not claimed as a pass.
- No Gradle executable is available in this environment, so ForgeGradle compilation and in-game rendering are not yet verified.
