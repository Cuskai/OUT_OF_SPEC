# Stage 5.3.10 Release Notes

- Version: `0.6.19`
- Build marker: `OUT_OF_SPEC_STAGE_5_3_10.0.6.19`
- Focus: swap reversed left/right hand orientation only.
- The two physical arm positions remain unchanged. Hand geometry handedness and per-hand pose profiles are swapped together so thumb side, finger order, spread, and wrist channels agree.
- Retains Punchy 2.8f integration, permanent bilateral empty-hand render, native held-item rendering, current skin UVs, and all existing spell/binding systems.
- Detailed twelve-sign pose refinements are deferred until the user supplies their written pose specification.

## Validation

The focused hand-rig, source, growth, UI, spell-power baseline, project configuration, and deep package-merge checks passed. The full umbrella script ran beyond the environment time limit after emitting PASS results for model harnesses and several source audits; overall exit status was not confirmed. No Gradle executable was available, so ForgeGradle compile and Minecraft runtime were not tested here.
