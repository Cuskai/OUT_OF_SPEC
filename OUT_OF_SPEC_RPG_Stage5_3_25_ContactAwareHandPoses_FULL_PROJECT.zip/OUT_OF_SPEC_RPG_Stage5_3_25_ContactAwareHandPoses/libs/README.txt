This standalone project does not bundle a third-party first-person arm-renderer binary.
