package cn.blockforge.outofspec.binding;

import cn.blockforge.outofspec.binding.network.BindingCastingNetwork;
import cn.blockforge.outofspec.binding.network.SealCastingNetwork;
import cn.blockforge.outofspec.spellcraft.item.SpellGrowthItems;
import cn.blockforge.outofspec.spellcraft.growth.SpellGrowthEvents;
import cn.blockforge.outofspec.spellcraft.growth.SpellGrowthCatalog;
import cn.blockforge.outofspec.spellcraft.network.SpellGrowthNetwork;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(BindingCastingMod.MOD_ID)
public final class BindingCastingMod {
    public static final String MOD_ID = "out_of_spec_binding";

    public BindingCastingMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        SpellGrowthItems.ITEMS.register(modBus);
        modBus.addListener(SpellGrowthItems::addCreativeContents);
        // Iron's Spells registry is populated before CommonSetup. Initialize the unified
        // growth + seal directory here, not in a static field during mod construction.
        modBus.addListener(SpellGrowthCatalog::onCommonSetup);
        BindingCastingNetwork.register();
        SealCastingNetwork.register();
        SpellGrowthNetwork.register();
        // Explicitly register the complete Forge-side growth event class. This includes scroll
        // discovery hooks and /oosgrowth diagnostics; do not rely only on automatic subscriber scanning.
        MinecraftForge.EVENT_BUS.register(SpellGrowthEvents.class);
    }
}
