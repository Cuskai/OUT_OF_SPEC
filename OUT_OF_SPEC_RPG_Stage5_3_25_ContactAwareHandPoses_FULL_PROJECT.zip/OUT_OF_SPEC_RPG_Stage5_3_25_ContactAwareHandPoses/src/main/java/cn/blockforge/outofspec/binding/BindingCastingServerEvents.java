package cn.blockforge.outofspec.binding;

import io.redspace.ironsspellbooks.api.events.SpellCooldownAddedEvent;
import io.redspace.ironsspellbooks.api.events.SpellDamageEvent;
import io.redspace.ironsspellbooks.api.events.SpellOnCastEvent;
import io.redspace.ironsspellbooks.api.magic.MagicData;
import io.redspace.ironsspellbooks.damage.SpellDamageSource;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.network.chat.Component;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerSleepInBedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.UUID;

/** Applies all accepted contract effects on the authoritative server. */
@Mod.EventBusSubscriber(modid = BindingCastingMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class BindingCastingServerEvents {
    private static final UUID MOVE_MODIFIER_ID = UUID.fromString("9ab6cb38-7e86-4d4d-94b9-78d0f9626a42");
    private BindingCastingServerEvents() {}

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side.isClient() || !(event.player instanceof ServerPlayer player)) return;
        boolean contractExpired = BindingCastingState.tick(player);
        if (contractExpired) player.displayClientMessage(Component.literal("限时束缚期限已结束；不可撤销的永久代价仍然保留。"), true);

        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed == null) return;
        MagicData magicData = MagicData.getPlayerMagicData(player);
        double wanted = 0.0;
        if (magicData.isCasting()) {
            String castingSpellId = magicData.getCastingSpellId();
            wanted += BindingCastingState.permanentCastMoveSpeedModifier(player, castingSpellId);
            for (BindingContract contract : BindingCastingState.getEffectContracts(player)) {
                if (contract.permanentCastMoveSpeedCost()
                        || Math.abs(contract.moveSpeedDeltaPct()) < 0.001
                        || !contract.matchesMoveSpeedSpell(castingSpellId)
                        || !contract.healthConditionMet(player.getHealth(), player.getMaxHealth())) continue;
                wanted += contract.moveSpeedModifier();
            }
        }
        // No arbitrary +25% gameplay ceiling. Only prevent a negative movement-speed multiplier.
        wanted = Math.max(-1.0, wanted);
        AttributeModifier current = speed.getModifier(MOVE_MODIFIER_ID);
        if (Math.abs(wanted) < 0.001) {
            if (current != null) speed.removeModifier(MOVE_MODIFIER_ID);
            return;
        }
        if (current != null && Math.abs(current.getAmount() - wanted) < 0.0001) return;
        if (current != null) speed.removeModifier(MOVE_MODIFIER_ID);
        speed.addTransientModifier(new AttributeModifier(MOVE_MODIFIER_ID,
                "OUT OF SPEC accepted binding contract", wanted, AttributeModifier.Operation.MULTIPLY_TOTAL));
    }

    /** Apply mana-cost trades through Iron's Spells' cast event and arm any next-cast reward. */
    @SubscribeEvent
    public static void onSpellCast(SpellOnCastEvent event) {
        if (event.getEntity().level().isClientSide) return;
        BindingContract contractBeforeCast = BindingCastingState.getContract(event.getEntity());
        boolean armed = BindingCastingState.onSpellCast(event.getEntity(), event.getSpellId());
        if (armed) {
            event.getEntity().displayClientMessage(Component.literal("一次性束缚已触发：本次 "
                    + spellName(event.getSpellId()) + " 的伤害倍率为 ×" + BindingContract.format(contractBeforeCast.spellDamageMultiplier()) + "。"), true);
        }
        double costMultiplier = 1.0;
        for (BindingContract contract : BindingCastingState.getEffectContracts(event.getEntity())) {
            if (Math.abs(contract.manaCostDeltaPct()) >= 0.001
                    && contract.healthConditionMet(event.getEntity().getHealth(), event.getEntity().getMaxHealth())) {
                costMultiplier *= contract.manaCostMultiplier();
                if (!Double.isFinite(costMultiplier)) costMultiplier = Double.MAX_VALUE;
            }
        }
        if (Math.abs(costMultiplier - 1.0) < 0.001) return;
        int originalCost = Math.max(0, event.getManaCost());
        double scaledCost = Math.ceil(originalCost * costMultiplier);
        int adjustedCost = (int) Math.max(0L, Math.min(Integer.MAX_VALUE, (long) Math.min(Integer.MAX_VALUE, scaledCost)));
        event.setManaCost(adjustedCost);
    }

    /** Multiply spell damage only when the active contract scope and lifetime match. */
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onSpellDamage(SpellDamageEvent event) {
        if (event.getEntity().level().isClientSide) return;
        SpellDamageSource source = event.getSpellDamageSource();
        if (source == null || source.spell() == null) return;
        Entity attacker = source.getEntity();
        if (!(attacker instanceof ServerPlayer) && source.getDirectEntity() instanceof Projectile projectile
                && projectile.getOwner() instanceof ServerPlayer owner) {
            attacker = owner;
        }
        if (!(attacker instanceof ServerPlayer player)) return;
        double multiplier = BindingCastingState.consumeDamageMultiplierFor(player, source.spell().getSpellId());
        if (multiplier <= 1.000001) return;
        double adjusted = event.getAmount() * multiplier;
        if (!Double.isFinite(adjusted)) adjusted = Float.MAX_VALUE;
        event.setAmount((float) Math.max(0.0, Math.min(Float.MAX_VALUE, adjusted)));
    }

    /** Apply cooldown trades to the final cooldown Iron's Spells is about to register. */
    @SubscribeEvent
    public static void onSpellCooldown(SpellCooldownAddedEvent.Pre event) {
        if (event.getEntity() == null || event.getEntity().level().isClientSide) return;
        double cooldownMultiplier = 1.0;
        for (BindingContract contract : BindingCastingState.getEffectContracts(event.getEntity())) {
            if (Math.abs(contract.cooldownDeltaPct()) >= 0.001
                    && contract.healthConditionMet(event.getEntity().getHealth(), event.getEntity().getMaxHealth())) {
                cooldownMultiplier *= contract.cooldownMultiplier();
                if (!Double.isFinite(cooldownMultiplier)) cooldownMultiplier = Double.MAX_VALUE;
            }
        }
        if (Math.abs(cooldownMultiplier - 1.0) < 0.001) return;
        int originalCooldown = Math.max(0, event.getEffectiveCooldown());
        double scaled = Math.ceil(originalCooldown * cooldownMultiplier);
        int adjustedCooldown = originalCooldown == 0 ? 0 : (int) Math.max(0L,
                Math.min(Integer.MAX_VALUE, (long) Math.min(Integer.MAX_VALUE, scaled)));
        event.setEffectiveCooldown(adjustedCooldown);
    }

    /** Permanent insomnia is a real sleep restriction, not just a line in the contract UI. */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onSleepInBed(PlayerSleepInBedEvent event) {
        if (event.getEntity().level().isClientSide || !BindingCastingState.hasPermanentInsomnia(event.getEntity())) return;
        event.setResult(net.minecraft.world.entity.player.Player.BedSleepingProblem.OTHER_PROBLEM);
        event.getEntity().displayClientMessage(Component.literal("永久束缚仍在生效：你已经失去睡眠能力。"), true);
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!event.getEntity().level().isClientSide) {
            BindingCastingState.enforcePermanentCosts(event.getEntity());
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        removeMovementModifier(event.getEntity());
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        BindingCastingState.copyFrom(event.getEntity(), event.getOriginal());
        removeMovementModifier(event.getEntity());
    }

    private static void removeMovementModifier(net.minecraft.world.entity.player.Player player) {
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) speed.removeModifier(MOVE_MODIFIER_ID);
    }

    private static String spellName(String id) {
        return SpellNameResolver.displayName(BindingContract.normalizeSpellId(id));
    }
}
