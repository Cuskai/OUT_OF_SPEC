package cn.blockforge.outofspec.binding;

import io.redspace.ironsspellbooks.api.magic.MagicData;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import java.util.ArrayList;
import java.util.List;

/**
 * Server-authoritative active contracts plus irreversible burdens. Permanent costs are stored
 * outside the replaceable active contract so clearing/replacing a reward cannot erase the cost.
 */
public final class BindingCastingState {
    public static final String NBT_KEY = "out_of_spec_binding_contract_v3";
    private static final String LEGACY_NBT_KEY = "out_of_spec_binding_contract_v2";
    private static final String PERMANENT_KEY = "out_of_spec_binding_permanent_costs_v1";
    private static final String ACTIVE_CAST_KEY = "out_of_spec_binding_active_cast_damage_v1";
    private static final String CAST_PREPARATION_PROGRESS_KEY = "out_of_spec_binding_cast_preparation_v1";
    private static final long ONE_CAST_DAMAGE_WINDOW_TICKS = 600L;

    private BindingCastingState() {}

    public static BindingContract getContract(Player player) {
        if (player == null) return BindingContract.empty();
        CompoundTag data = player.getPersistentData();
        if (data.contains(NBT_KEY, Tag.TAG_COMPOUND)) {
            return readContractTag(data.getCompound(NBT_KEY));
        }
        // Read older persisted contracts from previous Stage 2.1 / Stage 3.0 versions.
        if (data.contains(LEGACY_NBT_KEY, Tag.TAG_COMPOUND)) {
            CompoundTag tag = data.getCompound(LEGACY_NBT_KEY);
            return new BindingContract(tag.getString("source"), tag.getDouble("spell_power_delta"),
                    tag.getDouble("move_speed_delta"), tag.getDouble("cast_time_delta"),
                    tag.getDouble("visibility_reduction"), tag.getDouble("mana_cost_delta"),
                    tag.getDouble("cooldown_delta"));
        }
        return BindingContract.empty();
    }

    public static void setContract(Player player, BindingContract contract) {
        if (player == null) return;
        CompoundTag data = player.getPersistentData();
        if (contract == null || contract.isEmpty()) {
            data.remove(NBT_KEY);
            data.remove(LEGACY_NBT_KEY);
            return;
        }

        // Commit irreversible costs before storing the reward. They live independently from the
        // replaceable contract and are copied by PlayerEvent.Clone across death and respawn.
        if (contract.permanentSlownessCost()) registerPermanentSlowness(player);
        if (contract.permanentInsomniaCost()) registerPermanentInsomnia(player);
        if (contract.singleUseSpellCost()) registerOneUseLimit(player, contract.singleUseSpellId(), false);
        if (contract.immediateSealCost()) registerOneUseLimit(player, contract.singleUseSpellId(), true);
        if (contract.damagePerSealedSpellPct() > 0.000001)
            registerSealStackReward(player, contract.spellScopeId(), contract.damagePerSealedSpellPct());
        if (contract.permanentCastMoveSpeedCost() && contract.moveSpeedDeltaPct() < -0.001)
            registerPermanentCastMoveSpeedPenalty(player, contract.moveSpeedScopeId(), contract.moveSpeedDeltaPct());

        if (BindingContract.MODE_PERMANENT.equals(contract.damageMode())) {
            CompoundTag burdens = data.getCompound(PERMANENT_KEY);
            ListTag permanent = burdens.getList("permanent_contract_effects", Tag.TAG_COMPOUND);
            CompoundTag serialized = writeContractTag(contract);
            // Re-submitting the exact same text cannot duplicate a permanent reward for free.
            boolean duplicate = false;
            for (int i = 0; i < permanent.size(); i++) {
                if (permanent.getCompound(i).getString("source").equals(contract.source())) {
                    duplicate = true;
                    break;
                }
            }
            if (!duplicate) permanent.add(serialized);
            burdens.put("permanent_contract_effects", permanent);
            data.put(PERMANENT_KEY, burdens);
            data.remove(NBT_KEY);
        } else {
            data.put(NBT_KEY, writeContractTag(contract));
        }
        data.remove(LEGACY_NBT_KEY);
    }

    /** All live effect-bearing contracts: irreversible effects first, then the current replaceable contract. */
    public static List<BindingContract> getEffectContracts(Player player) {
        if (player == null) return List.of();
        List<BindingContract> result = new ArrayList<>();
        CompoundTag data = player.getPersistentData();
        if (data.contains(PERMANENT_KEY, Tag.TAG_COMPOUND)) {
            ListTag permanent = data.getCompound(PERMANENT_KEY).getList("permanent_contract_effects", Tag.TAG_COMPOUND);
            for (int i = 0; i < permanent.size(); i++) result.add(readContractTag(permanent.getCompound(i)));
        }
        BindingContract active = getContract(player);
        if (!active.isEmpty()) result.add(active);
        return result;
    }

    private static BindingContract readContractTag(CompoundTag tag) {
        return new BindingContract(tag.getString("source"),
                tag.getDouble("spell_power_delta"), tag.getDouble("move_speed_delta"),
                tag.getDouble("cast_time_delta"), tag.getDouble("visibility_reduction"),
                tag.getDouble("mana_cost_delta"), tag.getDouble("cooldown_delta"),
                tag.contains("spell_scope_id", Tag.TAG_STRING) ? tag.getString("spell_scope_id") : BindingContract.ALL_SPELLS,
                tag.contains("single_use_spell_id", Tag.TAG_STRING) ? tag.getString("single_use_spell_id") : BindingContract.ALL_SPELLS,
                tag.contains("spell_damage_multiplier") ? tag.getDouble("spell_damage_multiplier") : 1.0,
                tag.contains("damage_mode", Tag.TAG_STRING) ? tag.getString("damage_mode") : BindingContract.MODE_NONE,
                tag.getBoolean("permanent_slowness_cost"), tag.getBoolean("single_use_spell_cost"),
                tag.getInt("duration_ticks"), tag.getBoolean("damage_reward_spent"),
                tag.contains("spell_power_scope_id", Tag.TAG_STRING) ? tag.getString("spell_power_scope_id") : BindingContract.ALL_SPELLS,
                tag.contains("move_speed_scope_id", Tag.TAG_STRING) ? tag.getString("move_speed_scope_id") : BindingContract.ALL_SPELLS,
                tag.getBoolean("permanent_insomnia_cost"),
                tag.contains("health_threshold_pct") ? tag.getDouble("health_threshold_pct") : -1.0,
                tag.contains("damage_per_sealed_spell_pct") ? tag.getDouble("damage_per_sealed_spell_pct") : 0.0,
                tag.contains("delayed_seal_spell_id", Tag.TAG_STRING) ? tag.getString("delayed_seal_spell_id") : BindingContract.ALL_SPELLS,
                tag.getBoolean("immediate_seal_cost"), tag.getBoolean("permanent_cast_move_speed_cost"),
                tag.contains("preparation_mode", Tag.TAG_STRING) ? tag.getString("preparation_mode") : BindingContract.PREPARATION_NONE,
                tag.contains("preparation_spell_id", Tag.TAG_STRING) ? tag.getString("preparation_spell_id") : BindingContract.ALL_SPELLS,
                tag.getInt("preparation_ticks"));
    }

    private static CompoundTag writeContractTag(BindingContract contract) {
        CompoundTag tag = new CompoundTag();
        tag.putString("source", contract.source());
        tag.putDouble("spell_power_delta", contract.spellPowerDeltaPct());
        tag.putDouble("move_speed_delta", contract.moveSpeedDeltaPct());
        tag.putDouble("cast_time_delta", contract.castTimeDeltaPct());
        tag.putDouble("visibility_reduction", contract.visibilityReductionPct());
        tag.putDouble("mana_cost_delta", contract.manaCostDeltaPct());
        tag.putDouble("cooldown_delta", contract.cooldownDeltaPct());
        tag.putString("spell_scope_id", contract.spellScopeId());
        tag.putString("single_use_spell_id", contract.singleUseSpellId());
        tag.putDouble("spell_damage_multiplier", contract.spellDamageMultiplier());
        tag.putString("damage_mode", contract.damageMode());
        tag.putBoolean("permanent_slowness_cost", contract.permanentSlownessCost());
        tag.putBoolean("single_use_spell_cost", contract.singleUseSpellCost());
        tag.putInt("duration_ticks", contract.durationTicks());
        tag.putInt("duration_remaining_ticks", contract.durationTicks());
        tag.putBoolean("damage_reward_spent", contract.damageRewardSpent());
        tag.putString("spell_power_scope_id", contract.spellPowerScopeId());
        tag.putString("move_speed_scope_id", contract.moveSpeedScopeId());
        tag.putBoolean("permanent_insomnia_cost", contract.permanentInsomniaCost());
        tag.putDouble("health_threshold_pct", contract.healthThresholdPct());
        tag.putDouble("damage_per_sealed_spell_pct", contract.damagePerSealedSpellPct());
        tag.putString("delayed_seal_spell_id", contract.delayedSealSpellId());
        tag.putBoolean("immediate_seal_cost", contract.immediateSealCost());
        tag.putBoolean("permanent_cast_move_speed_cost", contract.permanentCastMoveSpeedCost());
        tag.putString("preparation_mode", contract.preparationMode());
        tag.putString("preparation_spell_id", contract.preparationSpellId());
        tag.putInt("preparation_ticks", contract.preparationTicks());
        return tag;
    }

    public static boolean hasPermanentSlowness(Player player) {
        return player != null && player.getPersistentData().contains(PERMANENT_KEY, Tag.TAG_COMPOUND)
                && player.getPersistentData().getCompound(PERMANENT_KEY).getBoolean("permanent_slowness");
    }

    public static boolean hasPermanentInsomnia(Player player) {
        return player != null && player.getPersistentData().contains(PERMANENT_KEY, Tag.TAG_COMPOUND)
                && player.getPersistentData().getCompound(PERMANENT_KEY).getBoolean("permanent_insomnia");
    }

    public static boolean hasPermanentBurdens(Player player) {
        if (player == null || !player.getPersistentData().contains(PERMANENT_KEY, Tag.TAG_COMPOUND)) return false;
        CompoundTag burdens = player.getPersistentData().getCompound(PERMANENT_KEY);
        ListTag limits = burdens.getList("single_use_spell_limits", Tag.TAG_COMPOUND);
        ListTag stackRewards = burdens.getList("permanent_seal_rewards", Tag.TAG_COMPOUND);
        ListTag permanentEffects = burdens.getList("permanent_contract_effects", Tag.TAG_COMPOUND);
        ListTag permanentCastSlows = burdens.getList("permanent_cast_move_speed_costs", Tag.TAG_COMPOUND);
        return burdens.getBoolean("permanent_slowness") || burdens.getBoolean("permanent_insomnia")
                || !limits.isEmpty() || !stackRewards.isEmpty() || !permanentEffects.isEmpty() || !permanentCastSlows.isEmpty();
    }

    /** Return the stored permanent cast-speed penalty for a spell ID, as a summed multiplier delta. */
    public static double permanentCastMoveSpeedModifier(Player player, String rawSpellId) {
        if (player == null || !player.getPersistentData().contains(PERMANENT_KEY, Tag.TAG_COMPOUND)) return 0.0;
        String spellId = BindingContract.normalizeSpellId(rawSpellId);
        ListTag penalties = player.getPersistentData().getCompound(PERMANENT_KEY)
                .getList("permanent_cast_move_speed_costs", Tag.TAG_COMPOUND);
        double result = 0.0;
        for (int i = 0; i < penalties.size(); i++) {
            CompoundTag entry = penalties.getCompound(i);
            String scope = entry.getString("spell_id");
            if (BindingContract.ALL_SPELLS.equals(scope) || scope.equals(spellId)) {
                result += entry.getDouble("move_speed_delta_pct") / 100.0;
            }
        }
        return Double.isFinite(result) ? result : -0.99;
    }

    /** Returns the strongest already-committed permanent penalty for duplicate-cost validation. */
    public static double permanentCastMoveSpeedCostPct(Player player, String rawSpellId) {
        if (player == null || !player.getPersistentData().contains(PERMANENT_KEY, Tag.TAG_COMPOUND)) return 0.0;
        String spellId = BindingContract.normalizeSpellId(rawSpellId);
        ListTag penalties = player.getPersistentData().getCompound(PERMANENT_KEY)
                .getList("permanent_cast_move_speed_costs", Tag.TAG_COMPOUND);
        double result = 0.0;
        for (int i = 0; i < penalties.size(); i++) {
            CompoundTag entry = penalties.getCompound(i);
            String scope = entry.getString("spell_id");
            if (BindingContract.ALL_SPELLS.equals(scope) || scope.equals(spellId))
                result = Math.min(result, entry.getDouble("move_speed_delta_pct"));
        }
        return result;
    }

    private static void registerPermanentCastMoveSpeedPenalty(Player player, String rawSpellId, double deltaPct) {
        String spellId = BindingContract.normalizeSpellId(rawSpellId);
        CompoundTag burdens = player.getPersistentData().getCompound(PERMANENT_KEY);
        ListTag penalties = burdens.getList("permanent_cast_move_speed_costs", Tag.TAG_COMPOUND);
        for (int i = 0; i < penalties.size(); i++) {
            CompoundTag entry = penalties.getCompound(i);
            if (entry.getString("spell_id").equals(spellId)) {
                // Commit the strongest offered penalty; reusing a previous cost can't make it weaker.
                entry.putDouble("move_speed_delta_pct", Math.min(entry.getDouble("move_speed_delta_pct"), deltaPct));
                burdens.put("permanent_cast_move_speed_costs", penalties);
                player.getPersistentData().put(PERMANENT_KEY, burdens);
                return;
            }
        }
        CompoundTag entry = new CompoundTag();
        entry.putString("spell_id", spellId);
        entry.putDouble("move_speed_delta_pct", deltaPct);
        penalties.add(entry);
        burdens.put("permanent_cast_move_speed_costs", penalties);
        player.getPersistentData().put(PERMANENT_KEY, burdens);
    }

    /** True if this irreversible spell-use cost has already been committed, whether used or not. */
    public static boolean hasSpellUseCommitment(Player player, String rawSpellId) {
        if (player == null || !player.getPersistentData().contains(PERMANENT_KEY, Tag.TAG_COMPOUND)) return false;
        String spellId = BindingContract.normalizeSpellId(rawSpellId);
        ListTag limits = player.getPersistentData().getCompound(PERMANENT_KEY)
                .getList("single_use_spell_limits", Tag.TAG_COMPOUND);
        for (int i = 0; i < limits.size(); i++) {
            if (limits.getCompound(i).getString("spell_id").equals(spellId)) return true;
        }
        return false;
    }

    public static String summary(Player player) {
        BindingContract current = getContract(player);
        StringBuilder summary = new StringBuilder(current.shortSummary());
        if (hasPermanentBurdens(player)) {
            CompoundTag burdens = player.getPersistentData().getCompound(PERMANENT_KEY);
            if (summary.toString().equals("无生效契约")) summary.setLength(0);
            if (!summary.isEmpty()) summary.append("；");
            summary.append("不可撤销的永久状态：");
            boolean needsSeparator = false;
            if (burdens.getBoolean("permanent_slowness")) {
                summary.append("永久缓慢状态");
                needsSeparator = true;
            }
            if (burdens.getBoolean("permanent_insomnia")) {
                if (needsSeparator) summary.append("、");
                summary.append("永久无法睡眠");
                needsSeparator = true;
            }
            ListTag limits = burdens.getList("single_use_spell_limits", Tag.TAG_COMPOUND);
            for (int i = 0; i < limits.size(); i++) {
                CompoundTag limit = limits.getCompound(i);
                if (needsSeparator) summary.append("、");
                summary.append(spellName(limit.getString("spell_id"))).append("只允许一次成功施放");
                if (limit.getBoolean("used")) summary.append("（已使用，已封存）");
                else summary.append("（尚未使用）");
                needsSeparator = true;
            }
            ListTag stackRewards = burdens.getList("permanent_seal_rewards", Tag.TAG_COMPOUND);
            for (int i = 0; i < stackRewards.size(); i++) {
                CompoundTag rule = stackRewards.getCompound(i);
                if (needsSeparator) summary.append("、");
                summary.append("永久累积：每封存一个法术，").append(spellName(rule.getString("spell_id")))
                        .append("伤害 +").append(BindingContract.format(rule.getDouble("bonus_pct"))).append("%");
                needsSeparator = true;
            }
            ListTag permanentCastSlows = burdens.getList("permanent_cast_move_speed_costs", Tag.TAG_COMPOUND);
            for (int i = 0; i < permanentCastSlows.size(); i++) {
                CompoundTag penalty = permanentCastSlows.getCompound(i);
                if (needsSeparator) summary.append("、");
                String spellId = penalty.getString("spell_id");
                summary.append(BindingContract.ALL_SPELLS.equals(spellId) ? "全部法术" : spellName(spellId))
                        .append("施法期间永久移速降低 ")
                        .append(BindingContract.format(-penalty.getDouble("move_speed_delta_pct"))).append("%");
                needsSeparator = true;
            }
            ListTag permanentEffects = burdens.getList("permanent_contract_effects", Tag.TAG_COMPOUND);
            for (int i = 0; i < permanentEffects.size(); i++) {
                if (needsSeparator) summary.append("、");
                summary.append("永久契约：").append(readContractTag(permanentEffects.getCompound(i)).shortSummary());
                needsSeparator = true;
            }
        }
        CompoundTag activeCast = getActiveCastTag(player);
        if (activeCast != null && player.level().getGameTime() < activeCast.getLong("expires_at")) {
            if (!summary.isEmpty()) summary.append("；");
            summary.append("本次伤害强化已启动：").append(spellName(activeCast.getString("spell_id")));
        }
        return summary.isEmpty() ? "无生效契约" : summary.toString();
    }

    public static boolean hasUnspentIrrevocableReward(Player player) {
        BindingContract contract = getContract(player);
        return contract.hasPermanentCost() && contract.hasDamageReward()
                && BindingContract.MODE_NEXT_CAST.equals(contract.damageMode())
                && !contract.damageRewardSpent();
    }

    public static boolean hasPendingDelayedSeal(Player player) {
        BindingContract contract = getContract(player);
        return !BindingContract.ALL_SPELLS.equals(contract.delayedSealSpellId()) && contract.durationTicks() > 0;
    }

    public static boolean canReplaceContract(Player player) {
        return !hasUnspentIrrevocableReward(player) && !hasPendingDelayedSeal(player);
    }

    public static boolean canManuallyClearContract(Player player) {
        return canReplaceContract(player);
    }

    /** Tick timed contracts, expire cast-local damage windows, and enforce irreversible burdens. */
    public static boolean tick(Player player) {
        if (player == null || player.level().isClientSide) return false;
        boolean expired = false;
        CompoundTag data = player.getPersistentData();
        if (data.contains(NBT_KEY, Tag.TAG_COMPOUND)) {
            CompoundTag active = data.getCompound(NBT_KEY);
            int remaining = active.getInt("duration_remaining_ticks");
            if (remaining > 0) {
                remaining--;
                active.putInt("duration_remaining_ticks", remaining);
                if (remaining <= 0) {
                    String delayedSeal = active.contains("delayed_seal_spell_id", Tag.TAG_STRING)
                            ? active.getString("delayed_seal_spell_id") : BindingContract.ALL_SPELLS;
                    if (!BindingContract.ALL_SPELLS.equals(delayedSeal)) {
                        registerOneUseLimit(player, delayedSeal, true);
                        player.displayClientMessage(Component.literal("限时契约到期：" + spellName(delayedSeal) + "已被永久封存。"), true);
                    }
                    data.remove(NBT_KEY);
                    expired = true;
                }
            }
        }
        CompoundTag cast = getActiveCastTag(player);
        if (cast != null && player.level().getGameTime() >= cast.getLong("expires_at")) data.remove(ACTIVE_CAST_KEY);
        enforcePermanentCosts(player);
        updateCastingPreparationProgress(player);
        return expired;
    }

    /** Returns the strongest required sneak-and-still hold for this spell across live contracts. */
    public static int requiredPreparationTicks(Player player, String rawSpellId) {
        if (player == null || player.level().isClientSide) return 0;
        String spellId = BindingContract.normalizeSpellId(rawSpellId);
        int required = 0;
        for (BindingContract contract : getEffectContracts(player)) {
            if (BindingContract.PREPARATION_SNEAK_STATIONARY.equals(contract.preparationMode())
                    && contract.matchesPreparationSpell(spellId)) {
                required = Math.max(required, contract.preparationTicks());
            }
        }
        return required;
    }

    /** Returns consecutive server ticks during which the player stayed crouched, grounded and still. */
    public static int castingPreparationProgressTicks(Player player) {
        if (player == null || player.level().isClientSide || !player.isCrouching() || !player.onGround()) return 0;
        CompoundTag data = player.getPersistentData();
        if (!data.contains(CAST_PREPARATION_PROGRESS_KEY, Tag.TAG_COMPOUND)) return 0;
        CompoundTag progress = data.getCompound(CAST_PREPARATION_PROGRESS_KEY);
        String dimension = player.level().dimension().location().toString();
        if (!dimension.equals(progress.getString("dimension"))) return 0;
        double dx = player.getX() - progress.getDouble("x");
        double dy = player.getY() - progress.getDouble("y");
        double dz = player.getZ() - progress.getDouble("z");
        if (dx * dx + dy * dy + dz * dz > 0.0025) return 0;
        if (player.getDeltaMovement().horizontalDistanceSqr() > 0.0004) return 0;
        return Math.max(0, progress.getInt("ticks"));
    }

    /** Consume a completed preparation window after an actual successful cast initiation.
     * The next cast must earn its own consecutive hold instead of reusing stale progress.
     */
    public static void consumeCastingPreparationProgress(Player player) {
        if (player == null || player.level().isClientSide) return;
        player.getPersistentData().remove(CAST_PREPARATION_PROGRESS_KEY);
    }

    private static void updateCastingPreparationProgress(Player player) {
        boolean required = false;
        for (BindingContract contract : getEffectContracts(player)) {
            if (BindingContract.PREPARATION_SNEAK_STATIONARY.equals(contract.preparationMode())) {
                required = true;
                break;
            }
        }
        CompoundTag data = player.getPersistentData();
        if (!required) {
            data.remove(CAST_PREPARATION_PROGRESS_KEY);
            return;
        }
        CompoundTag previous = data.contains(CAST_PREPARATION_PROGRESS_KEY, Tag.TAG_COMPOUND)
                ? data.getCompound(CAST_PREPARATION_PROGRESS_KEY) : new CompoundTag();
        String dimension = player.level().dimension().location().toString();
        boolean posture = player.isCrouching() && player.onGround();
        double dx = player.getX() - previous.getDouble("x");
        double dy = player.getY() - previous.getDouble("y");
        double dz = player.getZ() - previous.getDouble("z");
        boolean initialized = previous.contains("initialized") && previous.getBoolean("initialized");
        boolean sameDimension = dimension.equals(previous.getString("dimension"));
        boolean stationary = dx * dx + dy * dy + dz * dz <= 0.0025
                && player.getDeltaMovement().horizontalDistanceSqr() <= 0.0004;
        int ticks = posture ? (initialized && sameDimension && stationary
                ? Math.min(1_728_000, previous.getInt("ticks") + 1) : 1) : 0;
        CompoundTag next = new CompoundTag();
        next.putBoolean("initialized", true);
        next.putString("dimension", dimension);
        next.putDouble("x", player.getX());
        next.putDouble("y", player.getY());
        next.putDouble("z", player.getZ());
        next.putInt("ticks", ticks);
        data.put(CAST_PREPARATION_PROGRESS_KEY, next);
    }

    public static void enforcePermanentCosts(Player player) {
        if (player == null || player.level().isClientSide || !hasPermanentSlowness(player)) return;
        MobEffectInstance current = player.getEffect(MobEffects.MOVEMENT_SLOWDOWN);
        if (current == null || current.getDuration() < 100 || current.getAmplifier() < 0) {
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,
                    Integer.MAX_VALUE, 0, true, false, true));
        }
    }

    /** Called on the authoritative Iron's Spells cast event. Returns true if this cast consumes a one-shot reward. */
    public static boolean onSpellCast(Player player, String rawSpellId) {
        if (player == null || player.level().isClientSide) return false;
        String spellId = BindingContract.normalizeSpellId(rawSpellId);
        markOneUseSpellUsed(player, spellId);
        BindingContract contract = getContract(player);
        if (contract.damageRewardSpent() && BindingContract.MODE_NEXT_CAST.equals(contract.damageMode())) {
            CompoundTag previousCast = getActiveCastTag(player);
            if (previousCast != null && previousCast.getString("spell_id").equals(spellId)) {
                // If the reward was already spent and the player starts a later cast of the same
                // spell, do not accidentally pay out the old reward on this newer projectile.
                player.getPersistentData().remove(ACTIVE_CAST_KEY);
            }
        }
        if (!contract.hasDamageReward() || contract.damageRewardSpent()
                || !BindingContract.MODE_NEXT_CAST.equals(contract.damageMode())
                || !contract.matchesSpell(spellId) || !healthConditionMet(player, contract)) return false;

        CompoundTag contractTag = player.getPersistentData().getCompound(NBT_KEY);
        contractTag.putBoolean("damage_reward_spent", true);
        player.getPersistentData().put(NBT_KEY, contractTag);
        CompoundTag activeCast = new CompoundTag();
        activeCast.putString("spell_id", spellId);
        activeCast.putDouble("multiplier", contract.spellDamageMultiplier());
        activeCast.putLong("expires_at", player.level().getGameTime() + ONE_CAST_DAMAGE_WINDOW_TICKS);
        player.getPersistentData().put(ACTIVE_CAST_KEY, activeCast);
        return true;
    }

    /** Returns the multiplier for this exact spell source. A next-cast reward is consumed by its first hit. */
    public static double consumeDamageMultiplierFor(Player player, String rawSpellId) {
        if (player == null || player.level().isClientSide) return 1.0;
        String spellId = BindingContract.normalizeSpellId(rawSpellId);
        double multiplier = 1.0;
        for (BindingContract contract : getEffectContracts(player)) {
            if (!contract.hasDamageReward() || !contract.matchesSpell(spellId)
                    || !healthConditionMet(player, contract)) continue;
            if (BindingContract.MODE_NEXT_CAST.equals(contract.damageMode())) {
                // The next-cast reward is armed at SpellOnCast and consumed below on its first hit.
                continue;
            }
            multiplier = multiplySafely(multiplier, contract.spellDamageMultiplier());
        }
        multiplier = multiplySafely(multiplier, permanentSealStackMultiplier(player, spellId));
        CompoundTag activeCast = getActiveCastTag(player);
        if (activeCast != null && player.level().getGameTime() < activeCast.getLong("expires_at")
                && BindingContract.normalizeSpellId(activeCast.getString("spell_id")).equals(spellId)) {
            multiplier = multiplySafely(multiplier, activeCast.getDouble("multiplier"));
            player.getPersistentData().remove(ACTIVE_CAST_KEY);
        }
        return Double.isFinite(multiplier) ? Math.max(1.0, multiplier) : 1.0;
    }

    private static double multiplySafely(double left, double right) {
        if (!Double.isFinite(left) || !Double.isFinite(right) || left <= 0.0 || right <= 0.0) return 1.0;
        double product = left * right;
        return Double.isFinite(product) ? Math.min(Float.MAX_VALUE, product) : Float.MAX_VALUE;
    }

    private static boolean healthConditionMet(Player player, BindingContract contract) {
        return contract.healthConditionMet(player.getHealth(), player.getMaxHealth());
    }

    private static double permanentSealStackMultiplier(Player player, String spellId) {
        if (player == null || !player.getPersistentData().contains(PERMANENT_KEY, Tag.TAG_COMPOUND)) return 1.0;
        CompoundTag burdens = player.getPersistentData().getCompound(PERMANENT_KEY);
        ListTag limits = burdens.getList("single_use_spell_limits", Tag.TAG_COMPOUND);
        int sealedCount = 0;
        for (int i = 0; i < limits.size(); i++) if (limits.getCompound(i).getBoolean("used")) sealedCount++;
        if (sealedCount == 0) return 1.0;
        ListTag rules = burdens.getList("permanent_seal_rewards", Tag.TAG_COMPOUND);
        double bonusPct = 0.0;
        String normalized = BindingContract.normalizeSpellId(spellId);
        for (int i = 0; i < rules.size(); i++) {
            CompoundTag rule = rules.getCompound(i);
            if (BindingContract.ALL_SPELLS.equals(rule.getString("spell_id")) || normalized.equals(rule.getString("spell_id"))) {
                bonusPct += Math.max(0.0, rule.getDouble("bonus_pct")) * sealedCount;
            }
        }
        double multiplier = 1.0 + bonusPct / 100.0;
        return Double.isFinite(multiplier) ? Math.max(1.0, multiplier) : 1.0;
    }

    public static boolean isSpellPermanentlyBlocked(Player player, String rawSpellId) {
        if (player == null || !player.getPersistentData().contains(PERMANENT_KEY, Tag.TAG_COMPOUND)) return false;
        String spellId = BindingContract.normalizeSpellId(rawSpellId);
        ListTag limits = player.getPersistentData().getCompound(PERMANENT_KEY)
                .getList("single_use_spell_limits", Tag.TAG_COMPOUND);
        for (int i = 0; i < limits.size(); i++) {
            CompoundTag limit = limits.getCompound(i);
            if (limit.getString("spell_id").equals(spellId) && limit.getBoolean("used")) return true;
        }
        return false;
    }

    public static void copyFrom(Player target, Player original) {
        if (target == null || original == null) return;
        CompoundTag from = original.getPersistentData();
        // PlayerEvent.Clone is fired when a death creates the respawned Player. These commitments
        // are copied even if the active/revocable contract has already expired or been cleared.
        if (from.contains(PERMANENT_KEY, Tag.TAG_COMPOUND)) target.getPersistentData().put(PERMANENT_KEY, from.getCompound(PERMANENT_KEY).copy());
        BindingContract contract = getContract(original);
        if (!contract.isEmpty()) setContract(target, contract);
        // Preparation is a current physical state, not a permanent commitment; death resets it.
        target.getPersistentData().remove(CAST_PREPARATION_PROGRESS_KEY);
        CompoundTag activeCast = getActiveCastTag(original);
        if (activeCast != null) target.getPersistentData().put(ACTIVE_CAST_KEY, activeCast.copy());
    }

    public static boolean isBoundCasting(Player player) {
        if (player == null || player.level().isClientSide || getEffectContracts(player).isEmpty()) return false;
        return MagicData.getPlayerMagicData(player).isCasting();
    }

    private static void registerPermanentSlowness(Player player) {
        CompoundTag burdens = player.getPersistentData().getCompound(PERMANENT_KEY);
        burdens.putBoolean("permanent_slowness", true);
        player.getPersistentData().put(PERMANENT_KEY, burdens);
    }

    private static void registerPermanentInsomnia(Player player) {
        CompoundTag burdens = player.getPersistentData().getCompound(PERMANENT_KEY);
        burdens.putBoolean("permanent_insomnia", true);
        player.getPersistentData().put(PERMANENT_KEY, burdens);
    }

    private static void registerSealStackReward(Player player, String rawSpellId, double bonusPct) {
        String spellId = BindingContract.normalizeSpellId(rawSpellId);
        CompoundTag burdens = player.getPersistentData().getCompound(PERMANENT_KEY);
        ListTag rules = burdens.getList("permanent_seal_rewards", Tag.TAG_COMPOUND);
        for (int i = 0; i < rules.size(); i++) {
            CompoundTag existing = rules.getCompound(i);
            if (existing.getString("spell_id").equals(spellId)) {
                existing.putDouble("bonus_pct", Math.max(existing.getDouble("bonus_pct"), bonusPct));
                burdens.put("permanent_seal_rewards", rules);
                player.getPersistentData().put(PERMANENT_KEY, burdens);
                return;
            }
        }
        CompoundTag rule = new CompoundTag();
        rule.putString("spell_id", spellId);
        rule.putDouble("bonus_pct", bonusPct);
        rules.add(rule);
        burdens.put("permanent_seal_rewards", rules);
        player.getPersistentData().put(PERMANENT_KEY, burdens);
    }

    private static void registerOneUseLimit(Player player, String rawSpellId, boolean immediatelyUsed) {
        if (BindingContract.ALL_SPELLS.equals(rawSpellId)) return;
        String spellId = BindingContract.normalizeSpellId(rawSpellId);
        CompoundTag burdens = player.getPersistentData().getCompound(PERMANENT_KEY);
        ListTag limits = burdens.getList("single_use_spell_limits", Tag.TAG_COMPOUND);
        for (int i = 0; i < limits.size(); i++) if (limits.getCompound(i).getString("spell_id").equals(spellId)) {
            if (immediatelyUsed) limits.getCompound(i).putBoolean("used", true);
            burdens.put("single_use_spell_limits", limits);
            player.getPersistentData().put(PERMANENT_KEY, burdens);
            return;
        }
        CompoundTag limit = new CompoundTag();
        limit.putString("spell_id", spellId);
        limit.putBoolean("used", immediatelyUsed);
        limits.add(limit);
        burdens.put("single_use_spell_limits", limits);
        player.getPersistentData().put(PERMANENT_KEY, burdens);
    }

    private static void markOneUseSpellUsed(Player player, String spellId) {
        if (!player.getPersistentData().contains(PERMANENT_KEY, Tag.TAG_COMPOUND)) return;
        CompoundTag burdens = player.getPersistentData().getCompound(PERMANENT_KEY);
        ListTag limits = burdens.getList("single_use_spell_limits", Tag.TAG_COMPOUND);
        boolean changed = false;
        for (int i = 0; i < limits.size(); i++) {
            CompoundTag limit = limits.getCompound(i);
            if (limit.getString("spell_id").equals(spellId) && !limit.getBoolean("used")) {
                limit.putBoolean("used", true);
                changed = true;
            }
        }
        if (changed) {
            burdens.put("single_use_spell_limits", limits);
            player.getPersistentData().put(PERMANENT_KEY, burdens);
        }
    }

    private static CompoundTag getActiveCastTag(Player player) {
        if (player == null || !player.getPersistentData().contains(ACTIVE_CAST_KEY, Tag.TAG_COMPOUND)) return null;
        return player.getPersistentData().getCompound(ACTIVE_CAST_KEY);
    }

    private static String spellName(String id) {
        return SpellNameResolver.displayName(BindingContract.normalizeSpellId(id));
    }
}
