package cn.blockforge.outofspec.binding;

import java.util.Locale;
import java.util.Objects;

/**
 * Server-authoritative contract data. Irreversible costs are committed to independent player NBT;
 * reward scope, reward lifetime and conditional activation are represented separately.
 */
public record BindingContract(
        String source,
        double spellPowerDeltaPct,
        double moveSpeedDeltaPct,
        double castTimeDeltaPct,
        double visibilityReductionPct,
        double manaCostDeltaPct,
        double cooldownDeltaPct,
        String spellScopeId,
        String singleUseSpellId,
        double spellDamageMultiplier,
        String damageMode,
        boolean permanentSlownessCost,
        boolean singleUseSpellCost,
        int durationTicks,
        boolean damageRewardSpent,
        String spellPowerScopeId,
        String moveSpeedScopeId,
        boolean permanentInsomniaCost,
        double healthThresholdPct,
        double damagePerSealedSpellPct,
        String delayedSealSpellId,
        boolean immediateSealCost,
        boolean permanentCastMoveSpeedCost,
        String preparationMode,
        String preparationSpellId,
        int preparationTicks) {

    public static final String MODE_NONE = "NONE";
    public static final String MODE_NEXT_CAST = "NEXT_CAST";
    public static final String MODE_TIMED = "TIMED";
    public static final String MODE_PERSISTENT = "PERSISTENT"; // continuous/revocable until cleared or replaced
    public static final String MODE_PERMANENT = "PERMANENT"; // irreversible: persisted independently across death/relog
    public static final String PREPARATION_NONE = "NONE";
    public static final String PREPARATION_SNEAK_STATIONARY = "SNEAK_STATIONARY";
    public static final String ALL_SPELLS = "*";
    public static final String LIGHTNING_LANCE = "irons_spellbooks:lightning_lance";

    /** Compatibility constructor for the Stage 3.7 schema. */
    public BindingContract(String source, double spellPowerDeltaPct, double moveSpeedDeltaPct,
                           double castTimeDeltaPct, double visibilityReductionPct,
                           double manaCostDeltaPct, double cooldownDeltaPct,
                           String spellScopeId, String singleUseSpellId, double spellDamageMultiplier,
                           String damageMode, boolean permanentSlownessCost, boolean singleUseSpellCost,
                           int durationTicks, boolean damageRewardSpent, String spellPowerScopeId,
                           String moveSpeedScopeId, boolean permanentInsomniaCost, double healthThresholdPct,
                           double damagePerSealedSpellPct, String delayedSealSpellId, boolean immediateSealCost,
                           boolean permanentCastMoveSpeedCost) {
        this(source, spellPowerDeltaPct, moveSpeedDeltaPct, castTimeDeltaPct, visibilityReductionPct,
                manaCostDeltaPct, cooldownDeltaPct, spellScopeId, singleUseSpellId, spellDamageMultiplier,
                damageMode, permanentSlownessCost, singleUseSpellCost, durationTicks, damageRewardSpent,
                spellPowerScopeId, moveSpeedScopeId, permanentInsomniaCost, healthThresholdPct,
                damagePerSealedSpellPct, delayedSealSpellId, immediateSealCost, permanentCastMoveSpeedCost,
                PREPARATION_NONE, ALL_SPELLS, 0);
    }

    /** Compatibility constructor for the previous Stage 3.2 schema. */
    public BindingContract(String source, double spellPowerDeltaPct, double moveSpeedDeltaPct,
                           double castTimeDeltaPct, double visibilityReductionPct,
                           double manaCostDeltaPct, double cooldownDeltaPct,
                           String spellScopeId, String singleUseSpellId, double spellDamageMultiplier,
                           String damageMode, boolean permanentSlownessCost, boolean singleUseSpellCost,
                           int durationTicks, boolean damageRewardSpent) {
        this(source, spellPowerDeltaPct, moveSpeedDeltaPct, castTimeDeltaPct, visibilityReductionPct,
                manaCostDeltaPct, cooldownDeltaPct, spellScopeId, singleUseSpellId, spellDamageMultiplier,
                damageMode, permanentSlownessCost, singleUseSpellCost, durationTicks, damageRewardSpent,
                ALL_SPELLS, ALL_SPELLS, false, -1.0, 0.0, ALL_SPELLS, false, false);
    }

    /** Compatibility constructor for legacy Stage 2.1 / Stage 3.0 contracts. */
    public BindingContract(String source, double spellPowerDeltaPct, double moveSpeedDeltaPct,
                           double castTimeDeltaPct, double visibilityReductionPct,
                           double manaCostDeltaPct, double cooldownDeltaPct) {
        this(source, spellPowerDeltaPct, moveSpeedDeltaPct, castTimeDeltaPct, visibilityReductionPct,
                manaCostDeltaPct, cooldownDeltaPct, ALL_SPELLS, ALL_SPELLS, 1.0, MODE_NONE,
                false, false, 0, false, ALL_SPELLS, ALL_SPELLS, false, -1.0, 0.0, ALL_SPELLS, false, false);
    }

    public BindingContract {
        source = Objects.requireNonNullElse(source, "");
        if (source.length() > 512) source = source.substring(0, 512);
        spellScopeId = normalizeSpellId(spellScopeId);
        singleUseSpellId = normalizeSpellId(singleUseSpellId);
        spellPowerScopeId = normalizeSpellId(spellPowerScopeId);
        moveSpeedScopeId = normalizeSpellId(moveSpeedScopeId);
        delayedSealSpellId = normalizeSpellId(delayedSealSpellId);
        if (!Double.isFinite(spellDamageMultiplier) || spellDamageMultiplier < 1.0) spellDamageMultiplier = 1.0;
        if (!Double.isFinite(healthThresholdPct) || healthThresholdPct < 0.0 || healthThresholdPct > 100.0) healthThresholdPct = -1.0;
        if (!Double.isFinite(damagePerSealedSpellPct) || damagePerSealedSpellPct < 0.0) damagePerSealedSpellPct = 0.0;
        damageMode = Objects.requireNonNullElse(damageMode, MODE_NONE).toUpperCase(Locale.ROOT);
        if (!damageMode.equals(MODE_NEXT_CAST) && !damageMode.equals(MODE_TIMED)
                && !damageMode.equals(MODE_PERSISTENT) && !damageMode.equals(MODE_PERMANENT)) damageMode = MODE_NONE;
        if (damagePerSealedSpellPct > 0.000001 && MODE_NONE.equals(damageMode)) damageMode = MODE_PERMANENT;
        durationTicks = Math.max(0, durationTicks);
        if (durationTicks > 0 && damageMode.equals(MODE_PERSISTENT)) damageMode = MODE_TIMED;
        preparationMode = Objects.requireNonNullElse(preparationMode, PREPARATION_NONE).toUpperCase(Locale.ROOT);
        if (!preparationMode.equals(PREPARATION_NONE)
                && !preparationMode.equals(PREPARATION_SNEAK_STATIONARY)) preparationMode = PREPARATION_NONE;
        preparationSpellId = normalizeSpellId(preparationSpellId);
        preparationTicks = Math.max(0, Math.min(1_728_000, preparationTicks)); // fail-closed one-day ceiling
        if (preparationMode.equals(PREPARATION_NONE) || preparationTicks == 0) {
            preparationMode = PREPARATION_NONE;
            preparationSpellId = ALL_SPELLS;
            preparationTicks = 0;
        }
    }

    public static BindingContract empty() {
        return new BindingContract("", 0, 0, 0, 0, 0, 0, ALL_SPELLS, ALL_SPELLS, 1.0,
                MODE_NONE, false, false, 0, false, ALL_SPELLS, ALL_SPELLS, false, -1.0,
                0.0, ALL_SPELLS, false, false);
    }

    public boolean isEmpty() {
        return Math.abs(spellPowerDeltaPct) < 0.001
                && Math.abs(moveSpeedDeltaPct) < 0.001
                && Math.abs(castTimeDeltaPct) < 0.001
                && Math.abs(visibilityReductionPct) < 0.001
                && Math.abs(manaCostDeltaPct) < 0.001
                && Math.abs(cooldownDeltaPct) < 0.001
                && spellDamageMultiplier <= 1.000001
                && damagePerSealedSpellPct <= 0.000001
                && !permanentSlownessCost && !permanentInsomniaCost && !permanentCastMoveSpeedCost
                && !singleUseSpellCost && !immediateSealCost
                && ALL_SPELLS.equals(delayedSealSpellId)
                && PREPARATION_NONE.equals(preparationMode);
    }

    public double spellPowerMultiplier() { return 1.0 + spellPowerDeltaPct / 100.0; }
    public double moveSpeedModifier() { return moveSpeedDeltaPct / 100.0; }
    public double castTimeMultiplier() { return 1.0 + castTimeDeltaPct / 100.0; }
    public double visibilityMultiplier() { return Math.max(0.0, 1.0 - visibilityReductionPct / 100.0); }
    public double manaCostMultiplier() { return Math.max(0.0, 1.0 + manaCostDeltaPct / 100.0); }
    public double cooldownMultiplier() { return Math.max(0.0, 1.0 + cooldownDeltaPct / 100.0); }
    public boolean hasDamageReward() {
        return (spellDamageMultiplier > 1.000001 && !MODE_NONE.equals(damageMode)) || damagePerSealedSpellPct > 0.000001;
    }
    public boolean hasPermanentCost() {
        return permanentSlownessCost || permanentInsomniaCost || permanentCastMoveSpeedCost
                || singleUseSpellCost || immediateSealCost || !ALL_SPELLS.equals(delayedSealSpellId);
    }
    public boolean isTimed() { return durationTicks > 0 || MODE_TIMED.equals(damageMode); }
    public boolean matchesSpell(String spellId) { return matchesScope(spellScopeId, spellId); }
    public boolean matchesPowerSpell(String spellId) { return matchesScope(spellPowerScopeId, spellId); }
    public boolean matchesMoveSpeedSpell(String spellId) { return matchesScope(moveSpeedScopeId, spellId); }
    public boolean matchesPreparationSpell(String spellId) { return matchesScope(preparationSpellId, spellId); }
    private static boolean matchesScope(String scope, String spellId) {
        return ALL_SPELLS.equals(scope) || normalizeSpellId(spellId).equals(scope);
    }
    public boolean healthConditionMet(double currentHealth, double maxHealth) {
        if (healthThresholdPct < 0.0 || maxHealth <= 0.0) return true;
        return currentHealth / maxHealth * 100.0 <= healthThresholdPct;
    }

    public static String normalizeSpellId(String raw) {
        if (raw == null || raw.isBlank() || raw.trim().equals("*")) return ALL_SPELLS;
        String value = raw.trim().toLowerCase(Locale.ROOT).replace(' ', '_');
        String resolved = SpellNameResolver.canonicalize(value);
        if (resolved != null) return resolved;
        if (!value.contains(":")) value = "irons_spellbooks:" + value;
        return value;
    }

    public String shortSummary() {
        if (isEmpty()) return "无生效契约";
        StringBuilder out = new StringBuilder();
        append(out, "法术强度", spellPowerDeltaPct, true);
        append(out, "施法中移速", moveSpeedDeltaPct, true);
        append(out, "施法时间", castTimeDeltaPct, false);
        append(out, "生物可见度降低", visibilityReductionPct, false);
        append(out, "法力消耗", manaCostDeltaPct, true);
        append(out, "冷却时间", cooldownDeltaPct, true);
        if (hasDamageReward()) {
            String scope = ALL_SPELLS.equals(spellScopeId) ? "全部法术" : spellName(spellScopeId);
            String timing = MODE_NEXT_CAST.equals(damageMode) ? (damageRewardSpent ? "一次性强化已消耗" : "下一次施法")
                    : MODE_TIMED.equals(damageMode) ? "限时强化"
                    : MODE_PERMANENT.equals(damageMode) ? "永久强化（不可撤销）" : "持续强化（可解除）";
            if (spellDamageMultiplier > 1.000001) addTerm(out, scope + "伤害倍率 ×" + format(spellDamageMultiplier) + "（" + timing + "）");
            if (damagePerSealedSpellPct > 0.000001) addTerm(out, scope + "伤害每累计封存一个法术永久增加" + format(damagePerSealedSpellPct) + "%");
        }
        if (healthThresholdPct >= 0.0) addTerm(out, "生命值低于" + format(healthThresholdPct) + "%时激活");
        if (durationTicks > 0) addTerm(out, "契约剩余期限由服务端计时");
        if (permanentSlownessCost) addTerm(out, "永久代价：缓慢状态");
        if (permanentInsomniaCost) addTerm(out, "永久代价：无法睡眠");
        if (permanentCastMoveSpeedCost) addTerm(out, "永久代价：指定法术施法期间移速降低");
        if (singleUseSpellCost) addTerm(out, spellName(singleUseSpellId) + "成功施放一次后永久封存");
        if (immediateSealCost) addTerm(out, "立即永久封存" + spellName(singleUseSpellId));
        if (!ALL_SPELLS.equals(delayedSealSpellId)) addTerm(out, "期限结束后永久封存" + spellName(delayedSealSpellId));
        if (PREPARATION_SNEAK_STATIONARY.equals(preparationMode)) addTerm(out,
                (ALL_SPELLS.equals(preparationSpellId) ? "全部法术" : spellName(preparationSpellId))
                        + "施放前需潜行静止 " + format(preparationTicks / 20.0) + " 秒");
        return out.toString();
    }

    public String sacrificeSummary() {
        StringBuilder out = new StringBuilder();
        if (spellPowerDeltaPct < -0.001) addTerm(out, "法术强度削弱 " + format(-spellPowerDeltaPct) + "%");
        if (moveSpeedDeltaPct < -0.001) addTerm(out, (ALL_SPELLS.equals(moveSpeedScopeId) ? "施法中" : spellName(moveSpeedScopeId) + "施法期间") + "移速降低 " + format(-moveSpeedDeltaPct) + "%");
        if (castTimeDeltaPct > 0.001) addTerm(out, "施法时间延长 " + format(castTimeDeltaPct) + "%");
        if (visibilityReductionPct < -0.001) addTerm(out, "生物可见度提高 " + format(-visibilityReductionPct) + "%");
        if (manaCostDeltaPct > 0.001) addTerm(out, "法力消耗增加 " + format(manaCostDeltaPct) + "%");
        if (cooldownDeltaPct > 0.001) addTerm(out, "冷却时间延长 " + format(cooldownDeltaPct) + "%");
        if (permanentSlownessCost) addTerm(out, "永久承担缓慢状态（不可通过解除契约移除）");
        if (permanentInsomniaCost) addTerm(out, "永久失去睡眠能力（死亡、重生和重新登录后仍保留）");
        if (permanentCastMoveSpeedCost) addTerm(out, "永久承担" + (ALL_SPELLS.equals(moveSpeedScopeId) ? "全部法术" : spellName(moveSpeedScopeId)) + "施法期间移速降低（不会因解除契约消失）");
        if (singleUseSpellCost) addTerm(out, spellName(singleUseSpellId) + "成功施放一次后永久封存");
        if (immediateSealCost) addTerm(out, "立即永久封存" + spellName(singleUseSpellId));
        if (!ALL_SPELLS.equals(delayedSealSpellId)) addTerm(out, "限时结束后永久封存" + spellName(delayedSealSpellId));
        if (PREPARATION_SNEAK_STATIONARY.equals(preparationMode)) addTerm(out,
                (ALL_SPELLS.equals(preparationSpellId) ? "全部法术" : spellName(preparationSpellId))
                        + "施放前必须潜行静止 " + format(preparationTicks / 20.0) + " 秒");
        return out.isEmpty() ? "无可识别代价" : out.toString();
    }

    public String benefitSummary() {
        StringBuilder out = new StringBuilder();
        if (spellPowerDeltaPct > 0.001) addTerm(out, (ALL_SPELLS.equals(spellPowerScopeId) ? "法术强度提高 " : spellName(spellPowerScopeId) + "法术强度提高 ") + format(spellPowerDeltaPct) + "%");
        if (moveSpeedDeltaPct > 0.001) addTerm(out, "施法中移速提高 " + format(moveSpeedDeltaPct) + "%");
        if (castTimeDeltaPct < -0.001) addTerm(out, "施法时间缩短 " + format(-castTimeDeltaPct) + "%");
        if (visibilityReductionPct > 0.001) addTerm(out, "生物可见度降低 " + format(visibilityReductionPct) + "%");
        if (manaCostDeltaPct < -0.001) addTerm(out, "法力消耗降低 " + format(-manaCostDeltaPct) + "%");
        if (cooldownDeltaPct < -0.001) addTerm(out, "冷却时间缩短 " + format(-cooldownDeltaPct) + "%");
        if (spellDamageMultiplier > 1.000001) {
            String scope = ALL_SPELLS.equals(spellScopeId) ? "全部法术" : spellName(spellScopeId);
            String timing = MODE_NEXT_CAST.equals(damageMode) ? "下一次命中伤害"
                    : MODE_TIMED.equals(damageMode) ? "期限内伤害"
                    : MODE_PERMANENT.equals(damageMode) ? "永久性伤害" : "持续期间伤害";
            addTerm(out, scope + timing + "达到基础伤害的 " + format(spellDamageMultiplier * 100.0) + "%");
        }
        if (damagePerSealedSpellPct > 0.000001) addTerm(out, "每永久封存一个法术，目标伤害额外永久提高 " + format(damagePerSealedSpellPct) + "%");
        if (healthThresholdPct >= 0.0) addTerm(out, "生命值不高于 " + format(healthThresholdPct) + "% 时激活收益");
        return out.isEmpty() ? "无可识别收益" : out.toString();
    }

    private static String spellName(String id) { return SpellNameResolver.displayName(id); }
    private static void addTerm(StringBuilder out, String term) { if (!out.isEmpty()) out.append("、"); out.append(term); }
    private static void append(StringBuilder out, String label, double value, boolean directSign) {
        if (Math.abs(value) < 0.001) return;
        if (!out.isEmpty()) out.append(" · ");
        boolean positive = value > 0;
        String amount = format(Math.abs(value)) + "%";
        if (directSign) out.append(label).append(positive ? "+" : "−").append(amount);
        else if (label.equals("施法时间")) out.append(value > 0 ? "施法延长" : "施法缩短").append(amount);
        else out.append(value > 0 ? "可见度降低" : "可见度提高").append(amount);
    }
    public static String format(double number) {
        if (Math.abs(number - Math.rint(number)) < 0.001) return Long.toString(Math.round(number));
        return String.format(Locale.ROOT, "%.1f", number);
    }
}
