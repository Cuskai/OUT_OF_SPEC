package cn.blockforge.outofspec.binding;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Deterministic local adjudication. Percentage caps are not used as a balance shortcut:
 * the evaluator prices the commitment/lifetime of costs and rewards. Only impossible or
 * unsafe numeric domains, unknown scope/condition syntax, and unimplemented effects fail closed.
 */
public final class BindingContractJudge {
    public enum Status { ACCEPTED, UNRECOGNIZED, UNSUPPORTED, OUT_OF_BOUNDS, NO_TRADE, UNBALANCED }
    public record Result(Status status, BindingContract contract, double sacrificeScore,
                         double benefitScore, double ratio, String reason, String suggestion) {
        public boolean accepted() { return status == Status.ACCEPTED; }
    }

    private static final double MIN_FAIR_RATIO = 1.15;
    private static final Pattern UNSUPPORTED_STAT = Pattern.compile(
            "(?:施法范围|攻击范围|作用范围|作用半径|爆炸半径|(?<!适用)范围|施法距离|攻击距离|射程|弹道速度|投射物速度|"
            + "治疗量|治疗效果|恢复生命|回血|抗性|护甲|防御力|减伤|攻击力|攻击速度|攻速|暴击率|暴击伤害|"
            + "召唤数量|弹射次数|弹射|穿透次数|穿透|击退|击飞|护盾强度|生命上限|最大生命值|"
            + "瞬移|瞬间移动|短距离传送|空间移动|传送到|位移技能)", Pattern.CASE_INSENSITIVE);
    private static final Pattern DAMAGE_TERM = Pattern.compile("(?:法术伤害|技能伤害|伤害倍率|伤害|damage)", Pattern.CASE_INSENSITIVE);
    private static final Pattern UNSUPPORTED_SCOPE = Pattern.compile(
            "(?:仅对|只对|专门对|只适用于|仅适用于|适用于(?!所有法术|全部法术)|针对|限定为|专属|仅限(?:于)?(?!下一次|下次|这次|本次|下一发|这一发|一发|一次)|限于|指定法术|特定法术|指定技能|特定技能|适用法术\\s*[:：]\\s*(?!全部法术|所有法术)|适用范围\\s*[:：]\\s*(?!全部法术|所有法术)|对(?!所有法术|全部法术)[^，,；;。\\n]{1,18}(?:法术|技能|咒语|生效|有效|适用))",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern DURATION_PATTERN = Pattern.compile(
            "(?:(?:持续时间|持续时长|有效期|维持时间|持续|维持|未来|接下来|在)\\s*(?:为|是|：|:)?\\s*)?(\\d+(?:\\.\\d+)?)\\s*(秒|分鐘|分钟|分|tick|ticks|刻)(?:内|期间|后)?",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern UNSUPPORTED_TIME_UNIT = Pattern.compile(
            "\\d+(?:\\.\\d+)?\\s*(?:秒|分鐘|分钟|分|tick|ticks|刻)(?:后|内|期间|持续|生效|触发|解除|结束|恢复)?",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern UNSUPPORTED_CONDITION = Pattern.compile(
            "(?:若|如果|假如|除非|只有|仅当|只在(?!施法|咏唱|读条|准备|蓄力)|仅在(?!施法|咏唱|读条|准备|蓄力)|"
            + "当[^，,；;。\\n]{1,24}(?:时|期间|后|前|达到|低于|高于)|生命值|血量|距离目标|目标在|"
            + "处于(?:潜行|疾跑|水中|空中)|下雨时|雨天|夜间|白天|疾跑时|奔跑时|跑动时|潜行时|水中时|空中时|"
            + "(?:命中|击杀|受伤|跳跃|落地|被攻击|攻击命中)[^，,；;。\n]{0,12}后|跳跃时|落地时|被攻击时|攻击命中时|每次|每当|冷却结束后|施法次数|使用次数)",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern PERMANENT_SLOW_COST = Pattern.compile(
            "(?:(?:永久|永远|终身|终生|一辈子|永久性|永不解除|不可解除|永远保持|一直承受)[^，,；;。\\n]{0,24}(?:缓慢状态|缓慢效果|永久减速|移动迟缓|缓慢\\s*(?:I{1,3}|[1-3]|[一二三])?)|"
            + "(?:缓慢状态|缓慢效果|永久减速|移动迟缓|缓慢\\s*(?:I{1,3}|[1-3]|[一二三])?)[^，,；;。\\n]{0,24}(?:永久|永远|终身|终生|一辈子|不可解除|永不解除))",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern PERMANENT_INSOMNIA_COST = Pattern.compile(
            "(?:(?:一直|永远|永久|终身|终生|再也|此后永不|永不|永远都|今后永不)[^，,；;。\\n]{0,24}(?:睡不了觉|睡不了眠|不能睡觉|无法睡觉|不能入睡|无法入睡|无法睡眠|不能睡眠|失去睡觉能力|失去睡眠能力|睡眠能力被剥夺|睡眠能力被封印)|"
            + "(?:睡不了觉|睡不了眠|不能睡觉|无法睡觉|不能入睡|无法入睡|无法睡眠|不能睡眠|失去睡觉能力|失去睡眠能力|睡眠能力被剥夺|睡眠能力被封印)[^，,；;。\\n]{0,24}(?:永久|永远|终身|终生|再也|一直|今后永不|不可解除))",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern PERMANENT_CAST_SPEED_COST = Pattern.compile(
            "(?:(?:永久|永久性|永远|终身|终生|不可解除|永不解除)[^，,；;。\n]{0,42}(?:施法|释放|施放|咏唱|读条)[^，,；;。\n]{0,30}(?:期间|时)?[^，,；;。\n]{0,18}(?:移动速度|移动速率|移速)|"
            + "(?:施法|释放|施放|咏唱|读条)[^，,；;。\n]{0,30}(?:移动速度|移动速率|移速)[^，,；;。\n]{0,20}(?:永久|永久性|永远|终身|终生|不可解除|永不解除))",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern PERMANENT_SEAL_COST = Pattern.compile(
            "(?:永久|永远|终身|终生|永不解除|不可逆|不可撤销|永久性)[^，,；;。\\n]{0,16}(?:封存|禁用|失去使用权|不能再使用|无法再使用)|"
            + "(?:封存|禁用|失去使用权|不能再使用|无法再使用)[^，,；;。\\n]{0,16}(?:永久|永远|终身|终生|不可逆|不可撤销)",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern DELAYED_SEAL_COST = Pattern.compile(
            "(?:期限结束|时间结束|期满|到期|倒计时结束|持续期结束)(?:后|时)?[^。\\n]{0,28}(?:永久)?(?:封存|禁用|失去使用权|不能再使用|无法再使用)",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern PERMANENT_LIFETIME = Pattern.compile(
            "(?:永久性|永久生效|永久强化|永久提高|永久提升|永久获得|永久伤害|永久增强|永久加成|永久收益|永久缩短|永久降低|永久减少|永久加快|永久延长|永久压缩|不可撤销的强化|不可撤销收益)",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern CONTINUOUS_LIFETIME = Pattern.compile(
            "(?:持续性|持续生效|持续强化|持续提高|持续提升|持续获得|一直生效|持续期间|契约期间|生效期间|始终保持|始终提高|始终获得|只要契约存在|直到解除|直到被替换)",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern HEALTH_THRESHOLD = Pattern.compile(
            "(?:(?:当|如果|若|假如)\\s*)?(?:玩家(?:的)?)?(?:当前)?(?:生命值|血量|生命)\\s*(?:低于|少于|不足|小于|不高于|不超过|≤|<)\\s*(\\d+(?:\\.\\d+)?)\\s*%(?:时)?",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern SEAL_STACK_BONUS = Pattern.compile(
            "每(?:永久)?封存(?:一个|一种|个)?法术[^\\n。；;]{0,32}?(?:额外)?(?:提高|提升|增加|增强)(?:到)?\\s*(\\d+(?:\\.\\d+)?)\\s*%",
            Pattern.CASE_INSENSITIVE);
    /** Real, server-enforced preparation cost: crouch and remain still before the named cast. */
    private static final Pattern SNEAK_STATIONARY_REQUIREMENT = Pattern.compile(
            "(?:(?:施法|施放|释放|使用|发动)[^，,；;。\\n]{0,24}?(?:前|之前)[^，,；;。\\n]{0,12})?"
                    + "(?:必须|需要|要求)?[^，,；;。\\n]{0,5}(?:潜行|蹲下|按住潜行)[^，,；;。\\n]{0,12}"
                    + "(?:并且|且|同时)?[^，,；;。\\n]{0,8}(?:静止|保持静止|不移动|保持不动)"
                    + "[^，,；;。\\n]{0,12}(\\d+(?:\\.\\d+)?)\\s*(秒钟|秒|分钟|分鐘|分|ticks|tick|刻)",
            Pattern.CASE_INSENSITIVE);
    /** These modes are refused until their actual consent/violation/input executor exists. */
    private static final Pattern UNSUPPORTED_ADVANCED_MECHANIC = Pattern.compile(
            "(?:双方玩家|双方签订|双方缔结|玩家之间|与另一名玩家|和另一名玩家|对方玩家|目标玩家|双向契约|"
                    + "违约惩罚|违约后|违约时|违反契约|违背契约|背叛契约|违反条款|违背条款|"
                    + "(?:施法|施放|释放|使用|发动)[^，,；;。\\n]{0,20}(?:前|之前)[^，,；;。\\n]{0,30}(?:结印|手印|结手印|印式|咏唱|念咒|唱诵|语音识别)|"
                    + "(?:必须|需要|要求)[^，,；;。\\n]{0,16}(?:结印|手印|结手印|印式|咏唱|念咒|唱诵|语音识别))",
            Pattern.CASE_INSENSITIVE);
    // Recognize the restriction phrase independently from the spell's name. The name is resolved
    // from the complete localized Iron's Spells catalogue rather than being hard-coded to one spell.
    private static final Pattern ONE_USE_LIMIT = Pattern.compile(
            "(?:(?:只能|只可|只允许|仅允许|限制为|限于|限定为|最多|永远只能)[^，,；;。\\n]{0,24}?(?:成功)?(?:施放|释放|施展|使用|用|发动|召唤)?[^，,；;。\\n]{0,12}?(?:一次|一回)|"
            + "(?:只能|只可|只允许|仅允许|限制为|限于|限定为|最多)[^，,；;。\\n]{0,24}?(?:一次|一回))",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern REWARD_CONNECTOR = Pattern.compile("(?:来)?换取|换来|交换得到|交换获得|以此获得|从而获得|换成");
    private static final Pattern EXPLICIT_ALL_SPELLS = Pattern.compile(
            "(?:所有(?:的)?法术|全部(?:的)?法术|任何(?:一种)?法术|任意法术|每个法术|全体法术|所有技能|全部技能|不论哪种法术)",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern EXPLICIT_SPELL_SCOPE = Pattern.compile(
            "(?:仅对|只对|专门对|只适用于|仅适用于|针对|指定法术|特定法术|指定技能|特定技能)",
            Pattern.CASE_INSENSITIVE);

    private BindingContractJudge() {}

    public static Result evaluate(String rawText) {
        String text = rawText == null ? "" : rawText.trim();
        if (text.isEmpty()) return result(Status.UNRECOGNIZED, BindingContract.empty(), 0, 0, 0,
                "先写出愿意付出的代价和想换取的效果。你可以使用一次性、限时或永久代价。",
                "例如：永久承受缓慢，换取下一次雷鸣长枪的伤害提高到1000%。");
        if (text.length() > 512) return result(Status.UNRECOGNIZED, BindingContract.empty(), 0, 0, 0,
                "契约描述太长，请控制在512个字符以内。", "只保留代价、收益、作用对象和持续期限。");
        if (hasRepeatedStat(text)) return result(Status.UNRECOGNIZED, BindingContract.empty(), 0, 0, 0,
                "同一属性在一份契约中出现了多次，容易产生互相覆盖。请先把它合并成一个净变化。",
                "把重复的同一属性合并成一个最终值，并明确代价和收益的期限。");

        String costClause = beforeRewardClause(text);
        String rewardClause = afterRewardClause(text);
        Double power = parsePower(text);
        Double speed = parseMoveSpeed(text);
        Double castTime = parseCastTime(text);
        Double visibility = parseVisibility(text);
        Double manaCost = parseManaCost(text);
        Double cooldown = parseCooldown(text);
        Matcher stackMatcher = SEAL_STACK_BONUS.matcher(rewardClause);
        Double damagePerSealedSpell = stackMatcher.find() ? Double.parseDouble(stackMatcher.group(1)) : null;
        Double damageMultiplier = damagePerSealedSpell == null ? parseDamageMultiplier(text) : null;
        boolean permanentSlowCost = PERMANENT_SLOW_COST.matcher(costClause).find();
        boolean permanentInsomniaCost = PERMANENT_INSOMNIA_COST.matcher(costClause).find();
        boolean permanentCastMoveSpeedCost = speed != null && speed < 0.0
                && PERMANENT_CAST_SPEED_COST.matcher(costClause).find();
        boolean oneUseLimitPhrase = ONE_USE_LIMIT.matcher(costClause).find();
        boolean immediateSealPhrase = PERMANENT_SEAL_COST.matcher(costClause).find();
        java.util.Set<String> costSpellIds = SpellNameResolver.findSpellIds(costClause);
        boolean delayedSealPhrase = DELAYED_SEAL_COST.matcher(text).find();
        String delayedSealSpellId = BindingContract.ALL_SPELLS;
        if (delayedSealPhrase) {
            Matcher delayed = DELAYED_SEAL_COST.matcher(text);
            if (delayed.find()) {
                String delayedTail = text.substring(delayed.end());
                Matcher connector = REWARD_CONNECTOR.matcher(delayedTail);
                if (connector.find()) delayedTail = delayedTail.substring(0, connector.start());
                int punctuation = delayedTail.length();
                for (char separator : new char[]{'，', ',', '；', ';', '。'}) {
                    int at = delayedTail.indexOf(separator);
                    if (at >= 0) punctuation = Math.min(punctuation, at);
                }
                delayedTail = delayedTail.substring(0, punctuation);
                java.util.Set<String> delayedIds = SpellNameResolver.findSpellIds(delayedTail);
                if (delayedIds.size() == 1) delayedSealSpellId = delayedIds.iterator().next();
            }
        }
        boolean immediateSealCost = immediateSealPhrase && !delayedSealPhrase && costSpellIds.size() == 1;
        boolean oneUseSpellCost = oneUseLimitPhrase && costSpellIds.size() == 1 && !immediateSealCost;
        boolean unresolvedOneUseCost = ((oneUseLimitPhrase || immediateSealPhrase) && costSpellIds.isEmpty())
                || (delayedSealPhrase && BindingContract.ALL_SPELLS.equals(delayedSealSpellId));
        boolean ambiguousOneUseCost = (oneUseLimitPhrase || immediateSealPhrase) && costSpellIds.size() > 1;
        String singleUseSpellId = (oneUseSpellCost || immediateSealCost) ? costSpellIds.iterator().next() : BindingContract.ALL_SPELLS;
        java.util.Set<String> rewardSpellIds = SpellNameResolver.findSpellIds(rewardClause);
        boolean explicitAllSpellReward = EXPLICIT_ALL_SPELLS.matcher(rewardClause).find();
        boolean ambiguousRewardScope = (damageMultiplier != null || damagePerSealedSpell != null)
                && !explicitAllSpellReward && rewardSpellIds.size() > 1;
        String spellScopeId = (damageMultiplier == null && damagePerSealedSpell == null) ? BindingContract.ALL_SPELLS
                : parseDamageScope(rewardClause, singleUseSpellId, explicitAllSpellReward, rewardSpellIds);
        String spellPowerScopeId = parsePowerScope(power, rewardClause, costClause);
        String moveSpeedScopeId = parseMoveSpeedScope(speed, costClause, rewardClause);
        double healthThresholdPct = parseHealthThreshold(text);
        Matcher preparationMatcher = SNEAK_STATIONARY_REQUIREMENT.matcher(text);
        boolean hasPreparationRequirement = preparationMatcher.find();
        int preparationTicks = hasPreparationRequirement ? parsePreparationTicks(preparationMatcher) : 0;
        String preparationMode = hasPreparationRequirement && preparationTicks > 0
                ? BindingContract.PREPARATION_SNEAK_STATIONARY : BindingContract.PREPARATION_NONE;
        String preparationSpellId = BindingContract.ALL_SPELLS;
        if (hasPreparationRequirement && preparationTicks > 0) {
            String requirementClause = clauseAround(text, preparationMatcher.start(), preparationMatcher.end());
            java.util.Set<String> requirementSpellIds = SpellNameResolver.findSpellIds(requirementClause);
            if (requirementSpellIds.size() == 1) preparationSpellId = requirementSpellIds.iterator().next();
            else if (requirementSpellIds.size() > 1) preparationTicks = -1;
        }
        String durationSource = SNEAK_STATIONARY_REQUIREMENT.matcher(text).replaceAll(" ");
        int durationTicks = parseDurationTicks(durationSource);
        boolean explicitNextCast = Pattern.compile("(?:这次|本次|下一次|下次|仅此一次|一次性|这一发|下一发|这发)", Pattern.CASE_INSENSITIVE).matcher(rewardClause).find();
        boolean explicitPermanentReward = PERMANENT_LIFETIME.matcher(rewardClause).find();
        boolean explicitContinuousReward = CONTINUOUS_LIFETIME.matcher(rewardClause).find();
        boolean explicitlyTimed = durationTicks > 0;
        boolean explicitLifetime = explicitNextCast || explicitlyTimed || explicitPermanentReward
                || explicitContinuousReward || damagePerSealedSpell != null;
        // A normal reward must choose exactly one lifetime. The cost clause may still be
        // permanent while its reward is one-shot/timed; irreversible costs are parsed separately.
        int declaredRewardLifetimes = (explicitNextCast ? 1 : 0) + (explicitlyTimed ? 1 : 0)
                + (explicitPermanentReward ? 1 : 0) + (explicitContinuousReward ? 1 : 0);
        boolean conflictingLifetime = declaredRewardLifetimes > 1;
        boolean hasRecognizedBenefit = (power != null && power > 0.0)
                || (speed != null && speed > 0.0)
                || (castTime != null && castTime < 0.0)
                || (visibility != null && visibility > 0.0)
                || (manaCost != null && manaCost < 0.0)
                || (cooldown != null && cooldown < 0.0)
                || (damageMultiplier != null && damageMultiplier > 1.0)
                || damagePerSealedSpell != null;
        String damageMode = BindingContract.MODE_NONE;
        if (hasRecognizedBenefit) {
            if (damagePerSealedSpell != null) damageMode = BindingContract.MODE_PERMANENT;
            else if (explicitNextCast) damageMode = BindingContract.MODE_NEXT_CAST;
            else if (explicitlyTimed) damageMode = BindingContract.MODE_TIMED;
            else if (explicitPermanentReward) damageMode = BindingContract.MODE_PERMANENT;
            else if (explicitContinuousReward) damageMode = BindingContract.MODE_PERSISTENT;
        }

        BindingContract contract = new BindingContract(text,
                value(power), value(speed), value(castTime), value(visibility), value(manaCost), value(cooldown),
                spellScopeId, singleUseSpellId, damageMultiplier == null ? 1.0 : damageMultiplier, damageMode,
                permanentSlowCost, oneUseSpellCost, durationTicks, false,
                spellPowerScopeId, moveSpeedScopeId, permanentInsomniaCost, healthThresholdPct,
                value(damagePerSealedSpell), delayedSealSpellId, immediateSealCost, permanentCastMoveSpeedCost,
                preparationMode, preparationSpellId, Math.max(0, preparationTicks));

        boolean unsupportedNamedStatScope = (castTime != null
                && hasNamedSpellInStatClause(text, "(?:施法时间|读条时间|准备时间|蓄力时间|咏唱时间|cast\\s*time)"))
                || (visibility != null && hasNamedSpellInStatClause(text,
                    "(?:被发现概率|被发现率|被侦测概率|发现概率|发现率|可见度|visibility|隐蔽性|隐蔽程度|隐匿性|潜行效果)"))
                || (manaCost != null && hasNamedSpellInStatClause(text,
                    "(?:法力消耗|魔力消耗|蓝耗|mana\\s*cost|mana\\s*consumption)"))
                || (cooldown != null && hasNamedSpellInStatClause(text,
                    "(?:冷却(?:时间)?|技能冷却|spell\\s*cooldown|cooldown)"));
        boolean hasUnsupportedScopeOrCondition = containsUnsupportedScopeOrCondition(text, durationTicks, spellScopeId, healthThresholdPct)
                || unsupportedNamedStatScope
                || UNSUPPORTED_ADVANCED_MECHANIC.matcher(text).find()
                || preparationTicks < 0
                || hasConflictingDurationDeclarations(durationSource);
        boolean requestsNamedScope = EXPLICIT_SPELL_SCOPE.matcher(text).find()
                && !SpellNameResolver.findSpellIds(text).isEmpty();
        if (requestsNamedScope && damageMultiplier == null) hasUnsupportedScopeOrCondition = true;
        boolean hasUnsupportedStat = UNSUPPORTED_STAT.matcher(text).find()
                || (DAMAGE_TERM.matcher(text).find() && damageMultiplier == null && damagePerSealedSpell == null)
                || (damageMultiplier != null && damageMultiplier < 1.0);
        if (unresolvedOneUseCost || ambiguousOneUseCost || ambiguousRewardScope) hasUnsupportedScopeOrCondition = true;
        if (delayedSealPhrase && BindingContract.ALL_SPELLS.equals(delayedSealSpellId)) hasUnsupportedScopeOrCondition = true;
        if (damagePerSealedSpell != null && !(oneUseSpellCost || immediateSealCost || !BindingContract.ALL_SPELLS.equals(delayedSealSpellId)))
            hasUnsupportedScopeOrCondition = true;
        boolean hasAnyRecognizedEffect = power != null || speed != null || castTime != null || visibility != null
                || manaCost != null || cooldown != null || damageMultiplier != null || damagePerSealedSpell != null
                || permanentSlowCost || permanentInsomniaCost || permanentCastMoveSpeedCost
                || oneUseSpellCost || immediateSealCost || delayedSealPhrase;
        boolean ambiguousLifetime = hasAnyRecognizedEffect && !explicitLifetime && durationTicks == 0;
        if (ambiguousLifetime || conflictingLifetime) hasUnsupportedScopeOrCondition = true;
        if (explicitNextCast && damageMultiplier == null && damagePerSealedSpell == null)
            hasUnsupportedScopeOrCondition = true;

        int recognized = (power == null ? 0 : 1) + (speed == null ? 0 : 1)
                + (castTime == null ? 0 : 1) + (visibility == null ? 0 : 1)
                + (manaCost == null ? 0 : 1) + (cooldown == null ? 0 : 1)
                + (damageMultiplier == null ? 0 : 1) + (damagePerSealedSpell == null ? 0 : 1)
                + (permanentSlowCost ? 1 : 0) + (permanentInsomniaCost ? 1 : 0)
                + (permanentCastMoveSpeedCost ? 1 : 0)
                + (oneUseSpellCost ? 1 : 0) + (immediateSealCost ? 1 : 0)
                + (delayedSealPhrase ? 1 : 0) + (hasPreparationRequirement && preparationTicks > 0 ? 1 : 0);

        if (recognized < 2) {
            if (hasUnsupportedScopeOrCondition || hasUnsupportedStat) return result(Status.UNSUPPORTED, contract, 0, 0, 0,
                    hasUnsupportedStat
                            ? "描述中包含尚未接入实际效果的属性；整份契约不会生效。"
                            : unresolvedOneUseCost || ambiguousOneUseCost
                                ? "我识别到了永久封存/一次性限制，但无法唯一识别目标法术。请写出游戏中的法术名称，或使用 irons_spellbooks:spell_id。"
                                : conflictingLifetime
                                    ? "收益期限写法互相冲突。请在下一次/一次性、限时、持续性、永久性中选择一种。"
                                    : ambiguousLifetime
                                        ? "这类交易的收益期限有歧义。请在收益部分明确写‘下一次/一次性’、‘限时N秒/持续N秒’、‘持续性’或‘永久性’。语义明确不可逆的代价（永久封存、永久失去睡眠能力等）会自动识别为永久代价。"
                                        : "我识别到了期限、作用范围或使用限制，但当前写法还不能安全执行。",
                    "已支持法术名识别、永久失眠、指定法术施法减速、低生命值条件、期限后封存和永久封存累积强化；瞬移等未接入机制仍会被拒绝。");
            return result(Status.UNRECOGNIZED, contract, 0, 0, 0,
                    "我还不能稳定识别出至少一项代价和一项收益。",
                    "示例：永久承受缓慢，换取下一次雷鸣长枪的伤害提高到1000%。");
        }

        String domainError = checkNumericDomain(contract);
        if (domainError != null) return result(Status.OUT_OF_BOUNDS, contract, 0, 0, 0,
                domainError, "调整到具有明确游戏含义的数值；正向收益不再使用固定的50%封顶。");
        if (hasUnsupportedScopeOrCondition || hasUnsupportedStat) {
            String reason = UNSUPPORTED_ADVANCED_MECHANIC.matcher(text).find()
                    ? "这份契约要求双方玩家同意、违约惩罚、结印或真实咏唱；这些执行器尚未接入，整份契约不会生效。潜行静止前置条件已实现，但不能替代结印或语音识别。"
                    : unsupportedNamedStatScope
                    ? "这份契约把施法时间、法力消耗、冷却或可见度属性绑定到单个法术；这些属性当前只实现全局效果，不能安全模拟成单法术作用域，因此整份契约不会生效。"
                    : hasUnsupportedStat
                    ? "这份契约包含当前尚未接入执行层的属性（例如瞬移、护甲、范围或召唤数量）。整份契约不会生效。"
                    : conflictingLifetime
                        ? "收益期限相互冲突；请只选一次性、限时、持续性或永久性中的一种。"
                        : ambiguousLifetime
                            ? "收益期限不明确。请明确声明一次性、限时、持续性或永久性；永久封存、永久失眠这类明确不可逆代价会自动识别。"
                            : "这份契约包含当前尚未接入的作用范围或触发条件；不能静默忽略它们。整份契约不会生效。";
            String suggestion = UNSUPPORTED_ADVANCED_MECHANIC.matcher(text).find()
                    ? "目前可用真正执行的潜行静止施法前置条件；双方玩家契约、违约后果、结印与语音咏唱需要单独的服务端/输入执行器，完成前不会降级为普通单人契约。"
                    : unsupportedNamedStatScope
                    ? "把该项属性明确写成全部法术范围，或改用目前具有单法术作用域的伤害倍率、法术强度、施法期间移速。"
                    : hasUnsupportedStat
                    ? "伤害倍率可以作用于全部法术，也可以通过中文名、英文名或 registry ID 指定已识别法术；瞬移、范围、治疗、防御等机制尚未接入。"
                    : unresolvedOneUseCost || ambiguousOneUseCost || ambiguousRewardScope
                        ? "请在代价和收益两侧分别写清法术名称，避免系统把永久封存的对象和伤害强化对象混为一谈。"
                        : "支持一次性、限时、持续性（可解除）、永久性（不可撤销）、低生命值条件、限时结束后永久封存、永久失眠与施法期间移速代价；未接入效果会被拒绝。";
            return result(Status.UNSUPPORTED, contract, 0, 0, 0, reason, suggestion);
        }

        double sacrifice = 0.0;
        double benefit = 0.0;
        sacrifice += negativeMagnitude(contract.spellPowerDeltaPct()) * 1.35;
        benefit += positiveMagnitude(contract.spellPowerDeltaPct()) * 1.20;
        double movementPenaltyPct = negativeMagnitude(contract.moveSpeedDeltaPct());
        boolean timedSpellScopedCastLock = movementPenaltyPct > 0.0
                && contract.durationTicks() > 0
                && !BindingContract.ALL_SPELLS.equals(contract.moveSpeedScopeId())
                && Pattern.compile("(?:施法|施放|释放|咏唱|读条)[^，,；;。\\n]{0,40}?(?:期间|时)")
                    .matcher(contract.source()).find();
        if (timedSpellScopedCastLock) {
            // A full 100% movement lock while casting is qualitatively harsher than a linear
            // percentage loss: the player loses all dodge/reposition ability for every cast in
            // the named time window. Price severity quadratically so 20%-80% losses are not
            // accidentally treated as equivalent to being completely rooted. This is valuation,
            // not a universal percentage cap; the underlying effect still must pass domain checks.
            double severity = Math.min(1.0, movementPenaltyPct / 100.0);
            sacrifice += movementPenaltyPct * (1.0 + 3.0 * severity * severity);
        } else {
            sacrifice += movementPenaltyPct * 1.00;
        }
        benefit += positiveMagnitude(contract.moveSpeedDeltaPct()) * 1.80;
        if (BindingContract.PREPARATION_SNEAK_STATIONARY.equals(contract.preparationMode())) {
            // Deliberately price the repeated pre-cast commitment by actual hold time rather than
            // treating it as free text. This is a gameplay-cost weight, not a % stat cap.
            sacrifice += (contract.preparationTicks() / 20.0) * 25.0;
        }
        sacrifice += positiveMagnitude(contract.castTimeDeltaPct()) * 0.80;
        benefit += negativeMagnitude(contract.castTimeDeltaPct()) * 1.40;
        sacrifice += negativeMagnitude(contract.visibilityReductionPct()) * 1.00;
        benefit += positiveMagnitude(contract.visibilityReductionPct()) * 1.10;
        sacrifice += positiveMagnitude(contract.manaCostDeltaPct()) * 1.15;
        benefit += negativeMagnitude(contract.manaCostDeltaPct()) * 1.25;
        sacrifice += positiveMagnitude(contract.cooldownDeltaPct()) * 0.70;
        benefit += negativeMagnitude(contract.cooldownDeltaPct()) * 1.55;

        // A permanent burden is valued over a long horizon. A one-use lock is a lasting loss of
        // future access to that spell. A one-shot reward is priced differently from a repeatable one.
        if (contract.permanentSlownessCost()) sacrifice += 900.0;
        if (contract.permanentInsomniaCost()) sacrifice += 850.0;
        if (contract.permanentCastMoveSpeedCost()) sacrifice += 500.0;
        if (contract.singleUseSpellCost()) sacrifice += 650.0;
        if (contract.immediateSealCost()) sacrifice += 700.0;
        if (!BindingContract.ALL_SPELLS.equals(contract.delayedSealSpellId())) sacrifice += 450.0;
        if (contract.hasDamageReward()) {
            double bonusPct = Math.max(0.0, (contract.spellDamageMultiplier() - 1.0) * 100.0);
            double weight = switch (contract.damageMode()) {
                case BindingContract.MODE_NEXT_CAST -> 0.80;
                case BindingContract.MODE_TIMED -> 1.60;
                default -> 1.75;
            };
            benefit += bonusPct * weight;
            if (contract.healthThresholdPct() >= 0.0) benefit *= 0.55;
            // The only permitted use of a spell is also the exact one-shot payoff. Sealing future
            // access to that same spell scales as a real permanent cost; sealing an unrelated spell
            // cannot subsidize an arbitrary all-spell damage buff.
            if (contract.singleUseSpellCost()
                    && BindingContract.MODE_NEXT_CAST.equals(contract.damageMode())
                    && contract.singleUseSpellId().equals(contract.spellScopeId())) {
                sacrifice += bonusPct * weight * 1.20;
            }
        }

        if (contract.damagePerSealedSpellPct() > 0.000001) {
            // Estimate four permanent seals conservatively when pricing a stacking reward.
            benefit += contract.damagePerSealedSpellPct() * 1.40 * 4.0;
        }
        double ratio = benefit < 0.01 ? 0.0 : sacrifice / benefit;
        if (sacrifice < 0.01 || benefit < 0.01) return result(Status.NO_TRADE, contract, sacrifice, benefit, ratio,
                "契约必须同时包含真实代价和真实收益；不能只写奖励，也不能只写惩罚。",
                "可以组合可量化属性、一次性使用权、持续期限或永久代价。");
        if (ratio + 1.0e-9 < MIN_FAIR_RATIO) {
            return result(Status.UNBALANCED, contract, sacrifice, benefit, ratio,
                    "按代价承诺和收益期限估算后，代价仍不足以支撑收益。代价估值 "
                            + BindingContract.format(sacrifice) + "，收益估值 " + BindingContract.format(benefit)
                            + "，交换比 " + BindingContract.format(ratio) + "（当前需要至少 "
                            + BindingContract.format(MIN_FAIR_RATIO) + "）。",
                    buildSuggestion(contract, benefit));
        }
        return result(Status.ACCEPTED, contract, sacrifice, benefit, ratio,
                "契约通过：已识别代价与收益期限。服务端会再次复核；永久代价与一次性法术封存不会因解除当前契约而消失。",
                "可缔结。下一次强化仅作用于匹配法术的一次施法；限时条目由服务端计时，永久代价独立保存。");
    }

    /** True only when both descriptions pass local adjudication and encode the same executable trade. */
    public static boolean equivalentAcceptedTrade(String firstText, String secondText) {
        Result firstResult = evaluate(firstText);
        Result secondResult = evaluate(secondText);
        if (!firstResult.accepted() || !secondResult.accepted()) return false;
        BindingContract a = firstResult.contract();
        BindingContract b = secondResult.contract();
        return close(a.spellPowerDeltaPct(), b.spellPowerDeltaPct())
                && close(a.moveSpeedDeltaPct(), b.moveSpeedDeltaPct())
                && close(a.castTimeDeltaPct(), b.castTimeDeltaPct())
                && close(a.visibilityReductionPct(), b.visibilityReductionPct())
                && close(a.manaCostDeltaPct(), b.manaCostDeltaPct())
                && close(a.cooldownDeltaPct(), b.cooldownDeltaPct())
                && a.spellScopeId().equals(b.spellScopeId())
                && a.singleUseSpellId().equals(b.singleUseSpellId())
                && close(a.spellDamageMultiplier(), b.spellDamageMultiplier())
                && a.damageMode().equals(b.damageMode())
                && a.permanentSlownessCost() == b.permanentSlownessCost()
                && a.singleUseSpellCost() == b.singleUseSpellCost()
                && a.durationTicks() == b.durationTicks()
                && a.spellPowerScopeId().equals(b.spellPowerScopeId())
                && a.moveSpeedScopeId().equals(b.moveSpeedScopeId())
                && a.permanentInsomniaCost() == b.permanentInsomniaCost()
                && close(a.healthThresholdPct(), b.healthThresholdPct())
                && close(a.damagePerSealedSpellPct(), b.damagePerSealedSpellPct())
                && a.delayedSealSpellId().equals(b.delayedSealSpellId())
                && a.immediateSealCost() == b.immediateSealCost()
                && a.permanentCastMoveSpeedCost() == b.permanentCastMoveSpeedCost()
                && a.preparationMode().equals(b.preparationMode())
                && a.preparationSpellId().equals(b.preparationSpellId())
                && a.preparationTicks() == b.preparationTicks();
    }

    private static boolean close(double a, double b) {
        return Double.isFinite(a) && Double.isFinite(b) && Math.abs(a - b) < 0.01;
    }

    private static double value(Double value) { return value == null ? 0.0 : value; }

    private static String beforeRewardClause(String text) {
        Matcher matcher = REWARD_CONNECTOR.matcher(text);
        return matcher.find() ? text.substring(0, matcher.start()) : text;
    }

    private static String afterRewardClause(String text) {
        Matcher matcher = REWARD_CONNECTOR.matcher(text);
        return matcher.find() ? text.substring(matcher.end()) : text;
    }

    private static String parseDamageScope(String rewardClause, String costSpellId,
                                           boolean explicitAll, java.util.Set<String> rewardSpellIds) {
        if (explicitAll) return BindingContract.ALL_SPELLS;
        if (rewardSpellIds.size() == 1) return rewardSpellIds.iterator().next();
        if (rewardSpellIds.size() > 1) return BindingContract.ALL_SPELLS; // rejected as ambiguous above
        if (!BindingContract.ALL_SPELLS.equals(costSpellId)
                && Pattern.compile("(?:该法术|这个法术|此法术|同一法术|该魔法|这个魔法|此魔法|它的)").matcher(rewardClause).find()) {
            return costSpellId;
        }
        // Without a named target the reward intentionally applies to all spells.
        return BindingContract.ALL_SPELLS;
    }

    private static int parsePreparationTicks(Matcher matcher) {
        try {
            double amount = Double.parseDouble(matcher.group(1));
            String unit = matcher.group(2).toLowerCase(java.util.Locale.ROOT);
            double ticks = (unit.equals("秒") || unit.equals("秒钟") ? amount * 20.0
                    : unit.equals("分钟") || unit.equals("分鐘") || unit.equals("分") ? amount * 1200.0 : amount);
            if (!Double.isFinite(ticks) || ticks < 1.0 || ticks > 1_728_000.0) return -1;
            return (int) Math.ceil(ticks);
        } catch (RuntimeException ex) {
            return -1;
        }
    }

    private static String clauseAround(String text, int start, int end) {
        int left = start;
        while (left > 0 && "，,；;。\n".indexOf(text.charAt(left - 1)) < 0) left--;
        int right = end;
        while (right < text.length() && "，,；;。\n".indexOf(text.charAt(right)) < 0) right++;
        return text.substring(left, right);
    }

    private static boolean hasConflictingDurationDeclarations(String text) {
        Matcher matcher = DURATION_PATTERN.matcher(text);
        Integer firstTicks = null;
        while (matcher.find()) {
            int ticks;
            try {
                double amount = Double.parseDouble(matcher.group(1));
                String unit = matcher.group(2).toLowerCase(java.util.Locale.ROOT);
                double raw = (unit.equals("秒") ? amount * 20.0
                        : unit.equals("分钟") || unit.equals("分鐘") || unit.equals("分") ? amount * 1200.0 : amount);
                if (!Double.isFinite(raw) || raw < 1 || raw > Integer.MAX_VALUE) return true;
                ticks = (int) Math.ceil(raw);
            } catch (RuntimeException ex) { return true; }
            if (firstTicks == null) firstTicks = ticks;
            else if (firstTicks != ticks) return true;
        }
        return false;
    }

    private static int parseDurationTicks(String text) {
        Matcher m = DURATION_PATTERN.matcher(text);
        if (!m.find()) return 0;
        try {
            double amount = Double.parseDouble(m.group(1));
            String unit = m.group(2).toLowerCase();
            double ticks = (unit.equals("秒") ? amount * 20.0
                    : unit.equals("分钟") || unit.equals("分鐘") || unit.equals("分") ? amount * 1200.0 : amount);
            if (!Double.isFinite(ticks) || ticks < 1 || ticks > Integer.MAX_VALUE) return -1;
            return (int) Math.ceil(ticks);
        } catch (NumberFormatException ex) { return -1; }
    }

    /** Fail closed when an otherwise-global stat is written next to a named spell. */
    private static boolean hasNamedSpellInStatClause(String text, String statRegex) {
        Matcher matcher = Pattern.compile(statRegex, Pattern.CASE_INSENSITIVE).matcher(text);
        while (matcher.find()) {
            String clause = clauseAround(text, matcher.start(), matcher.end());
            if (!SpellNameResolver.findSpellIds(clause).isEmpty()) return true;
        }
        return false;
    }

    private static boolean containsUnsupportedScopeOrCondition(String text, int durationTicks, String spellScopeId,
                                                               double healthThresholdPct) {
        String check = SNEAK_STATIONARY_REQUIREMENT.matcher(text).replaceAll(" ");
        if (healthThresholdPct >= 0.0) check = HEALTH_THRESHOLD.matcher(check).replaceAll(" ");
        if (!BindingContract.ALL_SPELLS.equals(spellScopeId)) {
            // Strip only explicit directives for the recognized target; other target scopes and
            // unsupported conditions remain visible to the fail-closed scanner.
            for (String alias : SpellNameResolver.aliasesFor(spellScopeId)) {
                String quoted = Pattern.quote(alias);
                check = check.replaceAll("(?i)(?:仅对|只对|专门对|只适用于|仅适用于|针对|对)\\s*(?:本次|下一次|下次|这次|该|此)?\\s*" + quoted
                        + "(?:\\s*(?:法术|技能))?\\s*(?:生效|有效|使用)?", " ");
                check = check.replaceAll("(?i)(?:指定法术|特定法术|指定技能|特定技能)\\s*[:：]?\\s*" + quoted, " ");
            }
        }
        if (durationTicks > 0) check = DURATION_PATTERN.matcher(check).replaceAll(" ");
        if (durationTicks == -1) return true;
        return UNSUPPORTED_SCOPE.matcher(check).find()
                || UNSUPPORTED_TIME_UNIT.matcher(check).find()
                || UNSUPPORTED_CONDITION.matcher(check).find();
    }

    private static double parseHealthThreshold(String text) {
        Matcher matcher = HEALTH_THRESHOLD.matcher(text);
        if (!matcher.find()) return -1.0;
        try {
            double value = Double.parseDouble(matcher.group(1));
            return value >= 0.0 && value <= 100.0 ? value : -1.0;
        } catch (NumberFormatException ex) {
            return -1.0;
        }
    }

    private static String parsePowerScope(Double power, String rewardClause, String costClause) {
        if (power == null) return BindingContract.ALL_SPELLS;
        String clause = power > 0.0 ? rewardClause : costClause;
        java.util.Set<String> ids = SpellNameResolver.findSpellIds(clause);
        if (ids.size() == 1) return ids.iterator().next();
        if (ids.isEmpty() && power > 0.0) {
            java.util.Set<String> costs = SpellNameResolver.findSpellIds(costClause);
            if (costs.size() == 1 && Pattern.compile("(?:该法术|这个法术|此法术|同一法术|该魔法|这个魔法|此魔法)").matcher(rewardClause).find())
                return costs.iterator().next();
        }
        return BindingContract.ALL_SPELLS;
    }

    private static String parseMoveSpeedScope(Double speed, String costClause, String rewardClause) {
        if (speed == null) return BindingContract.ALL_SPELLS;
        String clause = speed < 0.0 ? costClause : rewardClause;
        if (!Pattern.compile("(?:施放|释放|施法|使用|咏唱|读条)[^，,；;。\\n]{0,40}?(?:期间|时)").matcher(clause).find())
            return BindingContract.ALL_SPELLS;
        java.util.Set<String> ids = SpellNameResolver.findSpellIds(clause);
        return ids.size() == 1 ? ids.iterator().next() : BindingContract.ALL_SPELLS;
    }

    private static boolean hasRepeatedStat(String text) {
        return count(text, "(?:法术强度(?:系数)?|魔法强度(?:系数)?|法术威力|魔法威力|spell\\s*power(?:\\s*coefficient)?)") > 1
                || count(text, "(?:施法时)?(?:移动速度|移动速率|移速|跑动速度|movement\\s*speed)") > 1
                || count(text, "(?:施法时间|读条时间|准备时间|蓄力时间|咏唱时间|cast\\s*time)") > 1
                || count(text, "(?:被发现概率|被发现率|被侦测概率|发现概率|发现率|可见度|visibility|隐蔽性|隐蔽程度|隐匿性|潜行效果)") > 1
                || count(text, "(?:法力消耗|魔力消耗|蓝耗|mana\\s*cost|mana\\s*consumption)") > 1
                || count(text, "(?:冷却(?:时间)?|技能冷却|spell\\s*cooldown|cooldown)") > 1;
    }

    private static int count(String text, String regex) {
        Matcher matcher = Pattern.compile(regex, Pattern.CASE_INSENSITIVE).matcher(text);
        int count = 0;
        while (matcher.find()) count++;
        return count;
    }

    private static String checkNumericDomain(BindingContract c) {
        double[] values = { c.spellPowerDeltaPct(), c.moveSpeedDeltaPct(), c.castTimeDeltaPct(),
                c.visibilityReductionPct(), c.manaCostDeltaPct(), c.cooldownDeltaPct(), c.spellDamageMultiplier() };
        for (double v : values) if (!Double.isFinite(v) || Math.abs(v) > 1.0e9)
            return "数值超出服务器能够安全计算的范围；这不是游戏平衡上限，请使用有限数值。";
        // Only reject values that would create an impossible or inverted game-state multiplier.
        if (c.spellPowerMultiplier() < 0) return "法术强度倍率不能为负数；可以降至0%，但不能变成负伤害系数。";
        if (c.moveSpeedModifier() < -1.0) return "施法期间移动速度不能变成负数；将移速降至0%是可识别的边界。";
        if (c.castTimeMultiplier() < 0) return "施法时间不能变成负数；若想瞬间施法，请使用恰好缩短100%的描述。";
        if (c.visibilityReductionPct() > 100.0) return "可见度降低的物理含义最多为100%；这属于属性定义边界而非收益封顶。";
        if (c.manaCostMultiplier() < 0) return "法力消耗倍率不能为负数；降低到0%已代表不消耗法力。";
        if (c.cooldownMultiplier() < 0) return "冷却倍率不能为负数；降低到0%已代表没有冷却。";
        if (c.damageMode().equals(BindingContract.MODE_NEXT_CAST) && !c.hasDamageReward())
            return "一次性伤害奖励没有有效的伤害倍率。";
        return null;
    }

    private static String buildSuggestion(BindingContract c, double benefitScore) {
        StringBuilder s = new StringBuilder("建议：");
        if (c.hasDamageReward()) s.append("提高代价的承诺程度（例如永久代价或永久封存指定法术），或缩短伤害强化的持续范围；");
        else if (c.moveSpeedDeltaPct() > 0) s.append("增加代价或明确采用一次性/限时收益；");
        else s.append("增加可量化代价，或者把重复生效的收益改成下一次施法的一次性收益；");
        s.append("没有50%这类任意统一封顶；最终按效果风险、代价承诺和收益期限综合判定。");
        return s.toString();
    }

    private static Result result(Status status, BindingContract contract, double sacrifice, double benefit,
                                 double ratio, String reason, String suggestion) {
        return new Result(status, contract, sacrifice, benefit, ratio, reason, suggestion);
    }

    private static double negativeMagnitude(double x) { return x < 0 ? -x : 0; }
    private static double positiveMagnitude(double x) { return x > 0 ? x : 0; }

    private static Double parseDamageMultiplier(String text) {
        String damage = "(?:法术伤害|技能伤害|伤害倍率|伤害|damage(?:\\s*multiplier)?)";
        // Common full-sentence phrasing: “最终伤害达到基础伤害的300%”. Here the number is
        // the final multiplier, not an additive increase.
        Matcher baseFraction = Pattern.compile(damage + "[^，,；;。\\n]{0,24}?(?:达到|等于|为|变为|相当于|提高到|提升到|调整为)\\s*(?:原始|基础)?伤害(?:的)?\\s*(\\d+(?:\\.\\d+)?)\\s*%", Pattern.CASE_INSENSITIVE).matcher(text);
        if (baseFraction.find()) return Double.parseDouble(baseFraction.group(1)) / 100.0;
        Matcher target = Pattern.compile(damage + "[^，,；;。\\n]{0,20}?(?:提高到|提升到|增加到|增至|提升至|达到|变为|设为|调整为)\\s*(\\d+(?:\\.\\d+)?)\\s*%", Pattern.CASE_INSENSITIVE).matcher(text);
        if (target.find()) return Double.parseDouble(target.group(1)) / 100.0;
        Matcher targetReverse = Pattern.compile("(?:提高到|提升到|增加到|增至|提升至|达到|变为|设为)\\s*(\\d+(?:\\.\\d+)?)\\s*%\\s*(?:的)?(?:基础)?" + damage, Pattern.CASE_INSENSITIVE).matcher(text);
        if (targetReverse.find()) return Double.parseDouble(targetReverse.group(1)) / 100.0;
        Matcher add = Pattern.compile(damage + "[^，,；;。\\n]{0,20}?(?:提高|提升|增加|增强|上升)\\s*(\\d+(?:\\.\\d+)?)\\s*%", Pattern.CASE_INSENSITIVE).matcher(text);
        if (add.find()) return 1.0 + Double.parseDouble(add.group(1)) / 100.0;
        Matcher addReverse = Pattern.compile("(?:提高|提升|增加|增强|上升)\\s*(\\d+(?:\\.\\d+)?)\\s*%\\s*(?:的)?(?:法术)?" + damage, Pattern.CASE_INSENSITIVE).matcher(text);
        if (addReverse.find()) return 1.0 + Double.parseDouble(addReverse.group(1)) / 100.0;
        return null;
    }

    private static Double parsePower(String text) {
        String stat = "(?:法术强度(?:系数)?|魔法强度(?:系数)?|法术威力|魔法威力|spell\\s*power(?:\\s*coefficient)?)";
        Matcher target = Pattern.compile(stat + "\\s*(?:降低至|减少至|降至|降到|降为|降低到|降低为|下降至|变为|调整为|设为)\\s*(\\d+(?:\\.\\d+)?)\\s*%", Pattern.CASE_INSENSITIVE).matcher(text);
        if (target.find()) return Double.parseDouble(target.group(1)) - 100.0;
        Double v = parseDirect(text, stat, "(?:降低|减少|下降|削弱|损失|牺牲)", "(?:提高|提升|增加|增强|上升|变强)");
        if (v != null) return v;
        Matcher prefixCost = Pattern.compile("(?:牺牲|损失|削弱)[^，,；;。\\n]{0,12}?" + stat + "[^，,；;。\\n]{0,16}?(\\d+(?:\\.\\d+)?)\\s*%", Pattern.CASE_INSENSITIVE).matcher(text);
        if (prefixCost.find()) return -Double.parseDouble(prefixCost.group(1));
        return null;
    }

    private static Double parseMoveSpeed(String text) {
        String stat = "(?:施法时)?(?:移动速度|移动速率|移速|跑动速度|movement\\s*speed)";
        Matcher to = Pattern.compile(stat + "[^，,；;。\\n]{0,28}?(?:降低至|减少至|降至|降到|降为|降低到|降低为|减少为|下降为|变为|调整为|设为)\\s*(?:(?:正常|基础|原本|当前|普通)(?:移动)?速度(?:的)?\\s*)?(\\d+(?:\\.\\d+)?)\\s*%", Pattern.CASE_INSENSITIVE).matcher(text);
        if (to.find()) return Double.parseDouble(to.group(1)) - 100.0;
        // Accept natural order such as “永久降低雷鸣长枪施法期间移动速度20%”.
        Matcher scopedDecrease = Pattern.compile("(?:永久|永久性|永远|终身|终生|不可解除|永不解除)?[^，,；;。\\n]{0,16}?(?:降低|减少|下降|变慢|牺牲|损失)[^，,；;。\\n]{0,36}?" + stat
                + "[^，,；;。\\n]{0,8}?(\\d+(?:\\.\\d+)?)\\s*%", Pattern.CASE_INSENSITIVE).matcher(text);
        if (scopedDecrease.find()) return -Double.parseDouble(scopedDecrease.group(1));
        return parseDirect(text, stat, "(?:降低|减少|下降|变慢|牺牲|损失|变弱)", "(?:提高|增加|提升|加快|上升|变快)");
    }

    private static Double parseCastTime(String text) {
        String stat = "(?:施法时间|读条时间|准备时间|蓄力时间|咏唱时间|cast\\s*time)";
        Double value = parseDirect(text, stat, "(?:延长|增加|提高|变长|加长|变慢)", "(?:缩短|减少|降低|变短|压缩|加快|变快)");
        // For casting time, a longer duration is the sacrifice (positive delta), a shorter time is a benefit (negative delta).
        return value == null ? null : -value;
    }

    private static Double parseManaCost(String text) {
        String stat = "(?:法力消耗|魔力消耗|蓝耗|mana\\s*cost|mana\\s*consumption)";
        return parseDirect(text, stat,
                "(?:降低|减少|下降|压低|节省|减免|变少)",
                "(?:提高|增加|提升|上升|变多|加重|增加消耗)");
    }

    private static Double parseCooldown(String text) {
        String stat = "(?:冷却(?:时间)?|技能冷却|spell\\s*cooldown|cooldown)";
        // Longer cooldown is a sacrifice (positive); shorter cooldown is a benefit (negative).
        return parseDirect(text, stat,
                "(?:缩短|降低|减少|下降|压缩|加快|变短)",
                "(?:延长|增加|提高|上升|变长|加长|变慢)");
    }

    private static Double parseVisibility(String text) {
        String detection = "(?:被发现概率|被发现率|被侦测概率|发现概率|发现率|可见度|visibility)";
        Matcher lower = Pattern.compile(detection + "[^，,；;。\\n]{0,24}?(?:降低|减少|下降|减弱)\\s*(\\d+(?:\\.\\d+)?)\\s*%", Pattern.CASE_INSENSITIVE).matcher(text);
        if (lower.find()) return Double.parseDouble(lower.group(1));
        Matcher lowerActionFirst = Pattern.compile("(?:降低|减少|下降|减弱)\\s*(\\d+(?:\\.\\d+)?)\\s*%\\s*(?:的)?\\s*" + detection, Pattern.CASE_INSENSITIVE).matcher(text);
        if (lowerActionFirst.find()) return Double.parseDouble(lowerActionFirst.group(1));
        Matcher raise = Pattern.compile(detection + "[^，,；;。\\n]{0,24}?(?:提高|增加|上升|增强)\\s*(\\d+(?:\\.\\d+)?)\\s*%", Pattern.CASE_INSENSITIVE).matcher(text);
        if (raise.find()) return -Double.parseDouble(raise.group(1));
        Matcher raiseActionFirst = Pattern.compile("(?:提高|增加|上升|增强)\\s*(\\d+(?:\\.\\d+)?)\\s*%\\s*(?:的)?\\s*" + detection, Pattern.CASE_INSENSITIVE).matcher(text);
        if (raiseActionFirst.find()) return -Double.parseDouble(raiseActionFirst.group(1));
        Matcher stealthUp = Pattern.compile("(?:隐蔽性|隐蔽程度|隐匿性|潜行效果)[^，,；;。\\n]{0,24}?(?:提高|增加|提升|增强)\\s*(\\d+(?:\\.\\d+)?)\\s*%", Pattern.CASE_INSENSITIVE).matcher(text);
        if (stealthUp.find()) return Double.parseDouble(stealthUp.group(1));
        Matcher stealthDown = Pattern.compile("(?:隐蔽性|隐蔽程度|隐匿性|潜行效果)[^，,；;。\\n]{0,24}?(?:降低|减少|下降|削弱)\\s*(\\d+(?:\\.\\d+)?)\\s*%", Pattern.CASE_INSENSITIVE).matcher(text);
        if (stealthDown.find()) return -Double.parseDouble(stealthDown.group(1));
        return null;
    }

    private static Double parseDirect(String text, String stat, String negativeWords, String positiveWords) {
        Matcher negative = Pattern.compile(stat + "[^，,；;。\\n]{0,24}?" + negativeWords + "\\s*(\\d+(?:\\.\\d+)?)\\s*%", Pattern.CASE_INSENSITIVE).matcher(text);
        if (negative.find()) return -Double.parseDouble(negative.group(1));
        Matcher positive = Pattern.compile(stat + "[^，,；;。\\n]{0,24}?" + positiveWords + "\\s*(\\d+(?:\\.\\d+)?)\\s*%", Pattern.CASE_INSENSITIVE).matcher(text);
        if (positive.find()) return Double.parseDouble(positive.group(1));
        Matcher explicitSign = Pattern.compile(stat + "[^，,；;。\\n]{0,24}?([+-])\\s*(\\d+(?:\\.\\d+)?)\\s*%", Pattern.CASE_INSENSITIVE).matcher(text);
        if (explicitSign.find()) return (explicitSign.group(1).equals("+") ? 1 : -1) * Double.parseDouble(explicitSign.group(2));

        // Also accept action-first and amount-first phrasing such as “提高12%移动速度” or
        // “牺牲20%法术强度”; do not require one single sentence template.
        Matcher actionFirstNegative = Pattern.compile(negativeWords + "\\s*(\\d+(?:\\.\\d+)?)\\s*%\\s*(?:的)?\\s*" + stat, Pattern.CASE_INSENSITIVE).matcher(text);
        if (actionFirstNegative.find()) return -Double.parseDouble(actionFirstNegative.group(1));
        Matcher actionFirstPositive = Pattern.compile(positiveWords + "\\s*(\\d+(?:\\.\\d+)?)\\s*%\\s*(?:的)?\\s*" + stat, Pattern.CASE_INSENSITIVE).matcher(text);
        if (actionFirstPositive.find()) return Double.parseDouble(actionFirstPositive.group(1));
        Matcher amountFirstNegative = Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*%\\s*(?:的)?\\s*" + stat + "[^，,；;。\\n]{0,16}?" + negativeWords, Pattern.CASE_INSENSITIVE).matcher(text);
        if (amountFirstNegative.find()) return -Double.parseDouble(amountFirstNegative.group(1));
        Matcher amountFirstPositive = Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*%\\s*(?:的)?\\s*" + stat + "[^，,；;。\\n]{0,16}?" + positiveWords, Pattern.CASE_INSENSITIVE).matcher(text);
        if (amountFirstPositive.find()) return Double.parseDouble(amountFirstPositive.group(1));
        return null;
    }
}
