package cn.blockforge.outofspec.binding;

import cn.blockforge.outofspec.binding.network.SealCastingNetwork;
import cn.blockforge.outofspec.spellcraft.runtime.SealedCastEffectState;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Cleans up server-owned cast-local modifiers when a cast is interrupted or a player leaves. */
@Mod.EventBusSubscriber(modid = BindingCastingMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class SealCastingLifecycleEvents {
    private SealCastingLifecycleEvents() {}

    @SubscribeEvent
    public static void onEntityJoinLevel(EntityJoinLevelEvent event) {
        if (event.getEntity() != null && !event.getEntity().level().isClientSide) {
            SealedCastEffectState.captureSpawnedEntity(event.getEntity());
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) return;
        java.util.UUID requestId = SealedCastEffectState.cleanupIfNoLongerCasting(player);
        if (requestId != null) SealCastingNetwork.notifyCastFinished(player, requestId, false,
                "本次施法在到达法术执行器前被取消或中断；追加印临时效果已清理。", "");
        SealCastingNetwork.flushPendingCastFinished(player);
    }

    @SubscribeEvent
    public static void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            SealedCastEffectState.clear(player);
            SealCastingNetwork.forgetPlayer(player.getUUID());
        }
    }
}
