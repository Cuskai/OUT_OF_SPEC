package cn.blockforge.outofspec.binding;

import java.util.*;
import java.util.regex.Pattern;

/** Resolves localized Iron's Spells names to canonical registry IDs (1.20.1-3.16.3).
 * The table is generated from the bundled mod language resources and includes Chinese, English,
 * registry path and namespaced ID aliases. Unknown free-form names fail closed. */
public final class SpellNameResolver {
    private record Spell(String id, String zh, String en) {}
    private static final List<Spell> SPELLS = List.of(
            new Spell("irons_spellbooks:abyssal_shroud", "深渊庇佑", "Abyssal Shroud"),
            new Spell("irons_spellbooks:acid_orb", "腐蚀喷吐", "Acid Spit"),
            new Spell("irons_spellbooks:acupuncture", "猩红刺狱", "Acupuncture"),
            new Spell("irons_spellbooks:angel_wing", "天使之翼", "Angel Wings"),
            new Spell("irons_spellbooks:arcane_shackle", "奥术镣铐", "Arcane Shackle"),
            new Spell("irons_spellbooks:arrow_volley", "万箭齐发", "Arrow Volley"),
            new Spell("irons_spellbooks:ascension", "飞升", "Ascension"),
            new Spell("irons_spellbooks:ball_lightning", "闪电球", "Ball Lightning"),
            new Spell("irons_spellbooks:black_hole", "黑洞", "Black Hole"),
            new Spell("irons_spellbooks:blaze_storm", "烈焰风暴", "Blaze Storm"),
            new Spell("irons_spellbooks:blessing_of_life", "生命祝福", "Blessing of Life"),
            new Spell("irons_spellbooks:blight", "枯萎术", "Blight"),
            new Spell("irons_spellbooks:blizzard", "暴风雪", "Blizzard"),
            new Spell("irons_spellbooks:blood_needles", "猩红之刺", "Blood Needles"),
            new Spell("irons_spellbooks:blood_slash", "猩红斩击", "Blood Slash"),
            new Spell("irons_spellbooks:blood_step", "血步", "Blood Step"),
            new Spell("irons_spellbooks:burning_dash", "烈焰冲锋", "Burning Dash"),
            new Spell("irons_spellbooks:chain_creeper", "苦力怕之环", "Chain Creeper"),
            new Spell("irons_spellbooks:chain_lightning", "连锁闪电", "Chain Lightning"),
            new Spell("irons_spellbooks:charge", "超负荷", "Charge"),
            new Spell("irons_spellbooks:cleanse", "净化", "Cleanse"),
            new Spell("irons_spellbooks:cloud_of_regeneration", "再生云域", "Cloud of Regeneration"),
            new Spell("irons_spellbooks:cone_of_cold", "刺骨寒风", "Cone of Cold"),
            new Spell("irons_spellbooks:counterspell", "法术反制", "Counterspell"),
            new Spell("irons_spellbooks:creeper_revenge", "苦力怕复仇", "Revenge of the Creeper"),
            new Spell("irons_spellbooks:devour", "嗜血啃咬", "Devour"),
            new Spell("irons_spellbooks:divine_smite", "神圣打击", "Divine Smite"),
            new Spell("irons_spellbooks:dragon_breath", "龙息", "Dragon's Breath"),
            new Spell("irons_spellbooks:earthquake", "地震", "Earthquake"),
            new Spell("irons_spellbooks:echoing_strikes", "回响打击", "Echoing Strikes"),
            new Spell("irons_spellbooks:eldritch_blast", "邪术冲击波", "Eldritch Blast"),
            new Spell("irons_spellbooks:electrocute", "电刑", "Electrocute"),
            new Spell("irons_spellbooks:evasion", "末影闪避", "Evasion"),
            new Spell("irons_spellbooks:fang_strike", "唤魔尖牙", "Fang Strike"),
            new Spell("irons_spellbooks:fang_swirl", "尖牙漩涡", "Fang Swirl"),
            new Spell("irons_spellbooks:fang_ward", "尖牙之环", "Fang Ward"),
            new Spell("irons_spellbooks:fire_arrow", "爆裂炽焰箭", "Fire Arrow"),
            new Spell("irons_spellbooks:fire_breath", "火焰吐息", "Fire Breath"),
            new Spell("irons_spellbooks:fireball", "火球术", "Fireball"),
            new Spell("irons_spellbooks:firebolt", "火焰箭", "Firebolt"),
            new Spell("irons_spellbooks:firecracker", "烟火四射", "Firecracker"),
            new Spell("irons_spellbooks:firefly_swarm", "萤火虫群", "Firefly Swarm"),
            new Spell("irons_spellbooks:flaming_barrage", "炽焰追踪弹幕", "Flaming Barrage"),
            new Spell("irons_spellbooks:flaming_strike", "炽焰斩击", "Flaming Strike"),
            new Spell("irons_spellbooks:fortify", "神圣守护", "Fortify"),
            new Spell("irons_spellbooks:frost_step", "霜步", "Frost Step"),
            new Spell("irons_spellbooks:frostbite", "霜噬", "Frostbite"),
            new Spell("irons_spellbooks:frostwave", "冰浪", "Frostwave"),
            new Spell("irons_spellbooks:gluttony", "暴食", "Gluttony"),
            new Spell("irons_spellbooks:gravity_fissure", "引力分裂", "Gravity Fissure"),
            new Spell("irons_spellbooks:greater_heal", "强效治疗", "Greater Heal"),
            new Spell("irons_spellbooks:guiding_bolt", "曳光弹", "Guiding Bolt"),
            new Spell("irons_spellbooks:gust", "呼啸之风", "Gust"),
            new Spell("irons_spellbooks:haste", "急迫", "Haste"),
            new Spell("irons_spellbooks:heal", "治疗", "Heal"),
            new Spell("irons_spellbooks:healing_circle", "治愈之环", "Healing Circle"),
            new Spell("irons_spellbooks:heartstop", "止心术", "Heartstop"),
            new Spell("irons_spellbooks:heat_surge", "焰涌", "Heat Surge"),
            new Spell("irons_spellbooks:ice_block", "霜降", "Ice Block"),
            new Spell("irons_spellbooks:ice_spikes", "冰霜尖刺", "Ice Spikes"),
            new Spell("irons_spellbooks:ice_tomb", "冰霜之墓", "Ice Tomb"),
            new Spell("irons_spellbooks:icicle", "冰锥", "Icicle"),
            new Spell("irons_spellbooks:invisibility", "隐身术", "Invisibility"),
            new Spell("irons_spellbooks:lightning_bolt", "落雷", "Lightning Bolt"),
            new Spell("irons_spellbooks:lightning_lance", "雷鸣长枪", "Lightning Lance"),
            new Spell("irons_spellbooks:lob_creeper", "苦力怕迫击炮", "Lob Creeper"),
            new Spell("irons_spellbooks:magic_arrow", "魔法箭", "Magic Arrow"),
            new Spell("irons_spellbooks:magic_missile", "魔法飞弹", "Magic Missile"),
            new Spell("irons_spellbooks:magma_bomb", "岩浆炸弹", "Magma Bomb"),
            new Spell("irons_spellbooks:oakskin", "橡肤", "Oakskin"),
            new Spell("irons_spellbooks:planar_sight", "位面视觉", "Planar Sight"),
            new Spell("irons_spellbooks:pocket_dimension", "口袋维度", "Pocket Dimension"),
            new Spell("irons_spellbooks:poison_arrow", "毒箭射击", "Poison Arrow"),
            new Spell("irons_spellbooks:poison_breath", "毒雾喷射", "Poison Spray"),
            new Spell("irons_spellbooks:poison_splash", "毒液飞溅", "Poison Splash"),
            new Spell("irons_spellbooks:portal", "传送门", "Portal"),
            new Spell("irons_spellbooks:raise_dead", "驱役亡灵", "Raise Dead"),
            new Spell("irons_spellbooks:raise_hell", "地狱浮现", "Raise Hell"),
            new Spell("irons_spellbooks:ray_of_frost", "冰霜射线", "Ray of Frost"),
            new Spell("irons_spellbooks:ray_of_siphoning", "血吸光束", "Ray of Siphoning"),
            new Spell("irons_spellbooks:recall", "回溯", "Recall"),
            new Spell("irons_spellbooks:root", "纠缠根须", "Root"),
            new Spell("irons_spellbooks:sacrifice", "献祭", "Sacrifice"),
            new Spell("irons_spellbooks:scapegoat", "替罪羊", "Scapegoat"),
            new Spell("irons_spellbooks:scorch", "灼烧", "Scorch"),
            new Spell("irons_spellbooks:sculk_tentacles", "幽匿之触", "Sculk Tentacles"),
            new Spell("irons_spellbooks:shadow_slash", "暗影斩击", "Shadow Slash"),
            new Spell("irons_spellbooks:shield", "护盾术", "Shield"),
            new Spell("irons_spellbooks:shockwave", "震荡波", "Shockwave"),
            new Spell("irons_spellbooks:slow", "迟缓", "Slow"),
            new Spell("irons_spellbooks:snowball", "雪球术", "Snowball"),
            new Spell("irons_spellbooks:sonic_boom", "音爆", "Sonic Boom"),
            new Spell("irons_spellbooks:spectral_hammer", "幽冥锤", "Spectral Hammer"),
            new Spell("irons_spellbooks:spider_aspect", "蛛毒之相", "Aspect of the Spider"),
            new Spell("irons_spellbooks:starfall", "星海落瀑", "Starfall"),
            new Spell("irons_spellbooks:stomp", "践踏", "Stomp"),
            new Spell("irons_spellbooks:summon_ender_chest", "召唤末影箱", "Summon Ender Chest"),
            new Spell("irons_spellbooks:summon_horse", "召唤骏马", "Summon Horse"),
            new Spell("irons_spellbooks:summon_polar_bear", "召唤北极熊", "Summon Polar Bear"),
            new Spell("irons_spellbooks:summon_swords", "召唤利剑", "Summon Swords"),
            new Spell("irons_spellbooks:summon_vex", "召唤恼鬼", "Summon Vex"),
            new Spell("irons_spellbooks:sunbeam", "烈阳射线", "Sunbeam"),
            new Spell("irons_spellbooks:telekinesis", "念力", "Telekinesis"),
            new Spell("irons_spellbooks:teleport", "传送术", "Teleport"),
            new Spell("irons_spellbooks:throw", "投掷", "Throw"),
            new Spell("irons_spellbooks:thunder_step", "雷步", "Thunderstep"),
            new Spell("irons_spellbooks:thunderstorm", "雷暴", "Thunderstorm"),
            new Spell("irons_spellbooks:touch_dig", "点石成掘", "Touch Dig"),
            new Spell("irons_spellbooks:void_tentacles", "虚空之触", "Void Tentacles"),
            new Spell("irons_spellbooks:volt_strike", "伏特打击", "Volt Strike"),
            new Spell("irons_spellbooks:wall_of_fire", "火墙术", "Wall of Fire"),
            new Spell("irons_spellbooks:wisp", "圣灵", "Wisp"),
            new Spell("irons_spellbooks:wither_skull", "凋灵之首", "Wither Skull"),
            new Spell("irons_spellbooks:wololo", "Wololo", "Wololo")
    );
    private static final Map<String, Spell> BY_ID;
    static {
        Map<String, Spell> map = new LinkedHashMap<>();
        for (Spell spell : SPELLS) map.put(spell.id(), spell);
        BY_ID = Collections.unmodifiableMap(map);
    }
    private SpellNameResolver() {}

    private record Hit(String id, int start, int end) {}

    /** Negative prefixes are intentionally narrow: explicit exclusion/avoidance language directly
     * before an alias marks that mention as an excluded target. */
    private static final Pattern NEGATED_TARGET_PREFIX = Pattern.compile(
            "(?iu)(?:不要(?:再)?(?:使用|用|选择|選擇|选|選|对|對|给|給|指定)?|"
                    + "别(?:再)?(?:使用|用|选择|選擇|选|選|对|對|给|給)?|"
                    + "不想(?:再)?(?:使用|用|选择|選擇|选|選|要)|"
                    + "不希望(?:再)?(?:使用|用|选择|選擇|选|選|要)|"
                    + "不打算(?:再)?(?:使用|用|选择|選擇|选|選)|"
                    + "避免(?:使用|用|选择|選擇|选|選)?|禁止(?:使用|用|选择|選擇|选|選)?|"
                    + "排除|不允许(?:使用|用|选择|選擇|选|選)?|"
                    + "do not use|don't use|dont use|not use|exclude|without|avoid|"
                    + "do not want(?: to use)?|don't want(?: to use)?|dont want(?: to use)?)\\s*$");

    public static Set<String> findSpellIds(String text) {
        if (text == null || text.isBlank()) return Collections.emptySet();
        Set<String> found = new LinkedHashSet<>();
        for (Hit hit : visibleHits(text)) found.add(hit.id());
        return Collections.unmodifiableSet(found);
    }

    /** Returns spell IDs mentioned as positive targets, excluding explicit negated mentions. */
    public static Set<String> findPositiveSpellIds(String text) {
        if (text == null || text.isBlank()) return Collections.emptySet();
        Set<String> found = new LinkedHashSet<>();
        for (Hit hit : visibleHits(text)) if (!isNegatedMention(text, hit)) found.add(hit.id());
        return Collections.unmodifiableSet(found);
    }

    /** Returns all explicitly excluded spell IDs, even if the same ID is also mentioned positively. */
    public static Set<String> findNegatedSpellIds(String text) {
        if (text == null || text.isBlank()) return Collections.emptySet();
        Set<String> found = new LinkedHashSet<>();
        for (Hit hit : visibleHits(text)) if (isNegatedMention(text, hit)) found.add(hit.id());
        return Collections.unmodifiableSet(found);
    }

    private static boolean isNegatedMention(String text, Hit hit) {
        int from = Math.max(0, hit.start() - 40);
        String prefix = text.substring(from, hit.start()).replaceAll("[\\s，,、:：;；。.!！?？]+$", "");
        return NEGATED_TARGET_PREFIX.matcher(prefix).find();
    }

    /**
     * AI candidates may introduce spell names for an open-ended creative request, but they must
     * neither change/omit an explicitly requested target nor reintroduce an explicitly excluded
     * spell. This is a scope guard, not a substitute for the local judge or server re-adjudication.
     */
    public static boolean changesExplicitSpellScope(String intentText, String candidateText) {
        Set<String> positiveIntentIds = findPositiveSpellIds(intentText);
        Set<String> excludedIntentIds = findNegatedSpellIds(intentText);
        Set<String> candidateIds = findSpellIds(candidateText);

        for (String excludedId : excludedIntentIds) {
            if (candidateIds.contains(excludedId)) return true;
        }
        if (positiveIntentIds.isEmpty()) return false; // open-ended: AI may propose a supported spell
        return !candidateIds.equals(positiveIntentIds);
    }

    private static List<Hit> visibleHits(String text) {
        List<Hit> hits = new ArrayList<>();
        for (Spell spell : SPELLS) {
            String path = spell.id().substring(spell.id().indexOf(':') + 1);
            for (String alias : List.of(spell.zh(), spell.en(), spell.id(), path)) {
                for (int[] range : findAliasRanges(text, alias)) {
                    hits.add(new Hit(spell.id(), range[0], range[1]));
                }
            }
        }
        List<Hit> visible = new ArrayList<>();
        for (Hit hit : hits) {
            boolean hiddenInsideLongerSpellName = false;
            for (Hit other : hits) {
                if (!hit.id().equals(other.id()) && other.start() <= hit.start() && other.end() >= hit.end()
                        && (other.end() - other.start()) > (hit.end() - hit.start())) {
                    hiddenInsideLongerSpellName = true;
                    break;
                }
            }
            if (!hiddenInsideLongerSpellName) visible.add(hit);
        }
        return visible;
    }

    private static List<int[]> findAliasRanges(String text, String alias) {
        if (alias == null || alias.isBlank()) return List.of();
        List<int[]> ranges = new ArrayList<>();
        if (alias.matches(".*[\\p{IsHan}].*")) {
            int from = 0;
            while (from < text.length()) {
                int at = text.indexOf(alias, from);
                if (at < 0) break;
                ranges.add(new int[]{at, at + alias.length()});
                from = at + 1;
            }
        } else {
            Pattern p = Pattern.compile("(?i)(?<![\\p{L}\\p{N}_])" + Pattern.quote(alias)
                    + "(?![\\p{L}\\p{N}_])");
            java.util.regex.Matcher matcher = p.matcher(text);
            while (matcher.find()) ranges.add(new int[]{matcher.start(), matcher.end()});
        }
        return ranges;
    }

    public static Optional<String> findUniqueSpellId(String text) {
        Set<String> ids = findSpellIds(text);
        return ids.size() == 1 ? Optional.of(ids.iterator().next()) : Optional.empty();
    }

    /** Canonicalizes one whole alias/ID, rather than searching a whole sentence. */
    public static String canonicalize(String raw) {
        if (raw == null || raw.isBlank()) return null;
        String value = raw.trim();
        for (Spell spell : SPELLS) {
            if (value.equalsIgnoreCase(spell.id())
                    || value.equalsIgnoreCase(spell.id().substring(spell.id().indexOf(':') + 1))
                    || normalizeAlias(value).equals(normalizeAlias(spell.zh()))
                    || normalizeAlias(value).equals(normalizeAlias(spell.en()))) return spell.id();
        }
        return null;
    }

    public static String displayName(String rawId) {
        if (rawId == null) return "";
        Spell spell = BY_ID.get(rawId.trim().toLowerCase(Locale.ROOT));
        return spell == null ? rawId : spell.zh();
    }

    public static List<String> aliasesFor(String rawId) {
        if (rawId == null) return List.of();
        Spell spell = BY_ID.get(rawId.trim().toLowerCase(Locale.ROOT));
        if (spell == null) return List.of();
        String path = spell.id().substring(spell.id().indexOf(':') + 1);
        return List.of(spell.zh(), spell.en(), path, spell.id());
    }

    private static String normalizeAlias(String value) {
        return value.toLowerCase(Locale.ROOT).replaceAll("[\\s_-]+", "").trim();
    }
}
