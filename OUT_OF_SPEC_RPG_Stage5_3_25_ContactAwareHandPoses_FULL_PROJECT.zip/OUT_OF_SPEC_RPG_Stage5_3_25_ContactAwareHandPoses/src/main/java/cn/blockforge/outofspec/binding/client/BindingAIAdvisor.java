package cn.blockforge.outofspec.binding.client;

import cn.blockforge.outofspec.binding.BindingContract;
import cn.blockforge.outofspec.binding.BindingContractJudge;
import cn.blockforge.outofspec.binding.SpellNameResolver;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.List;
import java.util.Optional;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Optional AI adviser plus a local casebook. The casebook is retrieval/cache memory, not model
 * fine-tuning. Exact previously server-accepted intents can be reused instantly, while novel intents
 * still ask the model and receive a deterministic local and server-side recheck.
 */
public final class BindingAIAdvisor {
    private static final Gson GSON = new GsonBuilder().disableHtmlEscaping().create();
    private static final ExecutorService IO = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "out-of-spec-binding-ai");
        thread.setDaemon(true);
        return thread;
    });
    // Warm-up must not block a real user-request queued on the same executor.
    private static final ExecutorService PREWARM_IO = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "out-of-spec-binding-ai-prewarm");
        thread.setDaemon(true);
        return thread;
    });
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();
    private static final AtomicBoolean PREWARM_IN_FLIGHT = new AtomicBoolean(false);
    private static volatile long lastPrewarmMillis;
    private static volatile String lastPrewarmKey = "";
    private static PendingOutcome pendingOutcome;

    private static final String SYSTEM_PROMPT = """
            你是 Minecraft 模组 OUT OF SPEC 的束缚契约协商顾问。目标不只是评语，而是帮助玩家把想法变成可执行、条款明确、代价与收益相称的契约。
            【请求隔离】每次请求只以 <CURRENT_REQUEST> 为当前交易。历史案例仅是匿名机制标签，绝不能复制过去的法术名、数值、代价或收益。不要把历史案例拼入当前候选。若玩家提出的是开放式创意/求点子，请主动提出一个有新意但确实已实现的组合，并在 alternative 给出不同策略；若玩家给出明确交易，不得静默改写玩家目标，可在 alternative 中单独提出折中方案。具体交易必须保持本次明确指定的目标与排除项，不得偷偷替换或删除目标、重新引入被排除法术，也不得增加未请求的额外代价/收益；开放式求创意请求没有指定法术目标时，可以主动选择已支持的法术组合。
            【已实现的真实效果】法术强度、施法期间移动速度（可限定法术）、施法时间、生物可见度、法力消耗、冷却时间、法术伤害倍率。法术伤害倍率、法术强度与施法期间移动速度可以限定到唯一法术；施法时间、生物可见度、法力消耗、冷却时间当前只支持全局范围。当前尚不支持改变作用范围、爆炸半径、弹道速度、治疗量、护甲或击退，因此不要提议这些效果。收益期限支持下一次/一次性、限时 N 秒、持续可解除/替换、永久不可撤销。永久代价包括永久缓慢、永久失眠、永久施法期间减速、指定法术成功施放最后一次后永久封存、立即永久封存；也支持低生命值阈值、封存数量累积收益、限时结束后永久封存。
            【真实执行的施法前置】可以要求施法前潜行并在地面静止指定时长；当前采用服务端逐 tick 检查潜行、落地与位置变化，并在施法入口拒绝未完成准备的指定法术。条件可限定到本条款中的唯一法术，也可对全部法术生效。不要把普通施法默认改成需要结印。
            【重要执行边界】目前没有真正的结印输入/手势识别、语音咏唱识别、双方玩家同意/交换执行器或违约后果执行器；也没有瞬移、范围伤害、治疗、防御、召唤数量、暴击等效果。只要本次方案依赖这些，contract_text 必须留空并如实解释，不能把它们降级成普通单人契约或仅写进描述中。不同的多个限时数字目前不能被同一条款分别计时，必须留空并要求明确为相同期限；不可撤销的永久代价可以与一次性/限时收益搭配。
            不存在法术强度+50%或移速+25%这类任意统一封顶；只拒绝无法解释的非有限数值、会产生负倍率的物理不可能数值、歧义和未接入机制。应逐项明确代价、收益、法术目标、触发/消耗时机、收益期限，以及永久代价是否跨死亡/重登保留。
            百分比语义必须明确：“伤害达到基础伤害的1000%”是基础伤害的10倍；“基础伤害提高200%”表示额外增加200%，最终为基础伤害的300%。不要将“降低至99%”误读成降低99%——它代表减少1%。
            你应主动寻找本次目标可支持的创意组合，例如把指定法术永久封存换另一法术永久强化、用永久行动负担换低血量触发的一次性爆发，或先承担潜行静止准备换更强单点收益。但不要为了显得有创意而增加不相关条款。开放式请求未给数值时，请先提出一个保守、可执行的完整候选，不要因为玩家没有指定倍率就留空；将备选方案写进 alternative。如果一个效果不支持，保留目标不变，并在 alternative 提供另一个已实现效果的交易，不要伪装成原目标可执行。最终裁定由本地规则引擎完成，AI 的赞成不代表可执行。
            只返回一个 JSON 对象，不要 Markdown，字段：
            {"contract_text":"完整中文候选；若有任一关键效果未实现/作用对象不明确则留空","analysis":"说明本次交换与期限，以及哪些字段会被真实执行","alternative":"另一种可执行策略；未能提出时留空"}
            """;

    public record Advice(String contractText, String analysis, String alternative, String error) {
        public boolean hasProposal() {
            return contractText != null && !contractText.isBlank() && (error == null || error.isBlank());
        }
    }

    private record Config(String endpoint, String model, String apiKey, int timeoutSeconds,
                          int keepAliveMinutes, boolean experienceEnabled, boolean preloadModel) {}
    private record PendingOutcome(String intent, String contractText, String analysis, String alternative, String model) {}

    private BindingAIAdvisor() {}

    public static Path configPath() {
        return FMLPaths.CONFIGDIR.get().resolve("out_of_spec_binding_ai.properties");
    }

    public static String configuredModel() {
        try { return loadConfig().model(); }
        catch (Exception ignored) { return "qwen2.5:7b"; }
    }

    public static boolean experienceMemoryEnabled() {
        try { return loadConfig().experienceEnabled(); }
        catch (Exception ignored) { return false; }
    }

    /** Remember which AI proposal is being submitted, so a response can be recorded even if the screen closes. */
    public static synchronized void trackPendingServerOutcome(String intent, String proposedContract,
                                                               String submittedContract, String analysis,
                                                               String alternative) {
        if (!experienceMemoryEnabled() || intent == null || intent.isBlank()
                || proposedContract == null || proposedContract.isBlank()
                || submittedContract == null || submittedContract.isBlank()
                || !ContractExperienceStore.normalizeIntent(proposedContract)
                .equals(ContractExperienceStore.normalizeIntent(submittedContract))) {
            pendingOutcome = null;
            return;
        }
        pendingOutcome = new PendingOutcome(intent, proposedContract, analysis == null ? "" : analysis,
                alternative == null ? "" : alternative, configuredModel());
    }

    /** Called for all client-side status packets, independent of whether the contract screen is open. */
    public static synchronized void recordPendingServerOutcome(boolean succeeded, boolean hasContract, String message) {
        if (pendingOutcome == null || !isAdjudicationMessage(message)) return;
        PendingOutcome pending = pendingOutcome;
        pendingOutcome = null;
        if (!experienceMemoryEnabled()) return;
        boolean accepted = succeeded && hasContract;
        ContractExperienceStore.recordServerOutcome(pending.intent(), pending.contractText(), pending.analysis(),
                pending.alternative(), accepted, message, pending.model());
    }

    private static boolean isAdjudicationMessage(String message) {
        return message != null && (message.contains("服务端复核")
                || message.contains("当前契约包含尚未兑现") || message.contains("当前契约含有不可撤销"));
    }

    private static String memorySummary(Config config) {
        if (!config.experienceEnabled()) return "本地经验检索已关闭";
        return "经验库有 " + ContractExperienceStore.caseCount() + " 条案例，其中 "
                + ContractExperienceStore.verifiedAcceptedCount() + " 条曾获服务端通过";
    }

    /** Called when the contract screen opens, so model loading can happen while the player writes. */
    public static CompletableFuture<String> prewarmIfLocal() {
        return CompletableFuture.supplyAsync(() -> {
            Config config;
            try { config = loadConfig(); }
            catch (Exception ex) { return "AI 配置未能读取；首次协商时会再次尝试。"; }
            URI configured = URI.create(config.endpoint());
            if (!config.preloadModel() || !isLocalOllama(configured)) {
                return memorySummary(config) + "。";
            }
            String origin = origin(configured);
            String prewarmKey = origin + "|" + config.model();
            long now = System.currentTimeMillis();
            if (prewarmKey.equals(lastPrewarmKey) && now - lastPrewarmMillis < Duration.ofMinutes(10).toMillis()) {
                return "本地模型已预热；" + memorySummary(config) + "。";
            }
            if (!PREWARM_IN_FLIGHT.compareAndSet(false, true)) return "本地模型正在后台预热；可以先填写契约目标。";
            try {
                JsonObject body = new JsonObject();
                body.addProperty("model", config.model());
                body.addProperty("prompt", "");
                body.addProperty("stream", false);
                body.addProperty("keep_alive", config.keepAliveMinutes() + "m");
                JsonObject prewarmOptions = new JsonObject();
                prewarmOptions.addProperty("num_predict", 1);
                body.add("options", prewarmOptions);
                HttpRequest request = HttpRequest.newBuilder(URI.create(origin + "/api/generate"))
                        .timeout(Duration.ofSeconds(Math.max(90, config.timeoutSeconds())))
                        .header("Content-Type", "application/json; charset=utf-8")
                        .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(body), StandardCharsets.UTF_8))
                        .build();
                HttpResponse<String> response = HTTP.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
                if (response.statusCode() >= 200 && response.statusCode() < 300) {
                    lastPrewarmMillis = System.currentTimeMillis();
                    lastPrewarmKey = prewarmKey;
                    return "本地模型已预热，并会尽量保持驻留 " + config.keepAliveMinutes() + " 分钟。" + memorySummary(config) + "。";
                }
                return "本地模型预热未完成（HTTP " + response.statusCode() + "）；点击 AI 协商时仍会正常尝试。";
            } catch (Exception ex) {
                return "本地模型预热暂未完成；点击 AI 协商时仍会正常尝试。";
            } finally {
                PREWARM_IN_FLIGHT.set(false);
            }
        }, PREWARM_IO);
    }

    public static CompletableFuture<Advice> request(String intent) {
        String safeIntent = intent == null ? "" : intent.trim();
        if (safeIntent.isBlank()) {
            return CompletableFuture.completedFuture(new Advice("", "先写下你的目标，例如：永久承担一种代价，换取下一次指定法术的强化。", "", ""));
        }
        try {
            if (loadConfig().experienceEnabled()) {
                Optional<ContractExperienceStore.ExperienceCase> cached = ContractExperienceStore.exactAccepted(safeIntent);
                if (cached.isPresent()) {
                    ContractExperienceStore.ExperienceCase entry = cached.get();
                    String analysis = "本地经验库快速命中：这条相同目标曾获服务端通过；仍会重新进行本地与服务端裁定。 "
                            + entry.analysis();
                    return CompletableFuture.completedFuture(new Advice(entry.contractText(), analysis, entry.alternative(), ""));
                }
            }
        } catch (Exception ignored) {
            // A missing/corrupt config or casebook must never prevent using the AI adviser.
        }
        return CompletableFuture.supplyAsync(() -> requestBlocking(safeIntent), IO);
    }

    private static Advice requestBlocking(String intent) {
        try {
            Config config = loadConfig();
            URI configuredUri = URI.create(config.endpoint());
            boolean nativeOllama = isLocalOllama(configuredUri);
            List<ContractExperienceStore.ExperienceCase> examples = config.experienceEnabled()
                    ? ContractExperienceStore.relevant(intent) : List.of();

            JsonObject payload = new JsonObject();
            payload.addProperty("model", config.model());
            JsonArray messages = new JsonArray();
            messages.add(message("system", SYSTEM_PROMPT));
            if (!examples.isEmpty()) messages.add(message("system", buildExperienceContext(examples)));
            messages.add(message("user", "<CURRENT_REQUEST>\n" + intent + "\n</CURRENT_REQUEST>\n"
                    + "只为 CURRENT_REQUEST 设计一份交易。不要添加未被本次请求提及的旧法术、旧收益或旧代价；不要把历史契约拼进来。"
                    + "如果当前请求中的效果有歧义，contract_text 留空并指出需要澄清。只返回指定 JSON。"));

            URI requestUri;
            if (nativeOllama) {
                requestUri = URI.create(origin(configuredUri) + "/api/chat");
                payload.add("messages", messages);
                payload.addProperty("stream", false);
                payload.addProperty("keep_alive", config.keepAliveMinutes() + "m");
                JsonObject options = new JsonObject();
                options.addProperty("temperature", 0.2);
                options.addProperty("num_predict", 700);
                payload.add("options", options);
                payload.addProperty("format", "json");
            } else {
                requestUri = configuredUri;
                payload.addProperty("temperature", 0.2);
                payload.addProperty("max_tokens", 700);
                payload.add("messages", messages);
            }

            HttpRequest.Builder request = HttpRequest.newBuilder(requestUri)
                    .timeout(Duration.ofSeconds(config.timeoutSeconds()))
                    .header("Content-Type", "application/json; charset=utf-8")
                    .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(payload), StandardCharsets.UTF_8));
            if (!config.apiKey().isBlank() && !nativeOllama) {
                request.header("Authorization", "Bearer " + config.apiKey());
            }
            HttpResponse<String> response = HTTP.send(request.build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                String detail = response.body() == null ? "" : response.body().replaceAll("\\s+", " ");
                if (detail.length() > 180) detail = detail.substring(0, 180) + "…";
                return fallbackOrError(intent, "AI 服务返回 HTTP " + response.statusCode() + (detail.isBlank() ? "" : "：" + detail));
            }
            JsonObject responseJson = JsonParser.parseString(response.body()).getAsJsonObject();
            String content;
            if (nativeOllama) {
                JsonObject message = responseJson.getAsJsonObject("message");
                content = message == null || !message.has("content") ? "" : message.get("content").getAsString();
            } else {
                JsonArray choices = responseJson.getAsJsonArray("choices");
                if (choices == null || choices.isEmpty()) return fallbackOrError(intent, "AI 服务没有返回候选内容。请检查 endpoint 和 model 配置。");
                JsonObject message = choices.get(0).getAsJsonObject().getAsJsonObject("message");
                content = message == null || !message.has("content") ? "" : message.get("content").getAsString();
            }
            if (content.isBlank()) return fallbackOrError(intent, "AI 响应没有返回文本内容；请检查所选模型是否支持聊天接口。");
            JsonObject answer = parseAssistantObject(content);
            String contract = clean(answer, "contract_text", 512);
            String analysis = clean(answer, "analysis", 220);
            String alternative = clean(answer, "alternative", 180);
            if (contract.isBlank()) {
                if (isOpenEndedIntent(intent)) {
                    Advice repaired = requestRepair(config, configuredUri, nativeOllama, intent, "",
                            "第一轮模型没有生成完整的可执行候选");
                    if (isSafeModelProposal(intent, repaired)) {
                        return new Advice(repaired.contractText(), repaired.analysis() + "（第二轮修订候选已通过本地复核。）",
                                repaired.alternative(), "");
                    }
                    return localFallbackAdvice(intent, "AI 连续两轮都没有形成可执行候选；已切换为本地规则备用方案。");
                }
                return new Advice("", analysis.isBlank() ? "AI 判断该目标依赖尚未支持的效果，或没有形成可执行契约。" : analysis,
                        alternative, "");
            }
            BindingContractJudge.Result requestedIntent = BindingContractJudge.evaluate(intent);
            boolean explicitTransaction = hasExplicitTransaction(intent);
            if (explicitTransaction && requestedIntent.accepted()
                    && !BindingContractJudge.equivalentAcceptedTrade(intent, contract)) {
                // The player already authored a complete, locally executable trade. Preserve it
                // verbatim rather than allowing the model to improve it by changing its terms.
                return new Advice(intent, "你写出的原始交易本身已经通过本地预审；模型候选改变了规范代价/收益，因此保留你的原文，不静默替换条款。",
                        alternative, "");
            }
            if (explicitTransaction && !requestedIntent.accepted()
                    && !BindingContractJudge.equivalentAcceptedTrade(intent, contract)) {
                return new Advice("", "你已明确写出代价与收益，但原文尚未通过本地规则，模型候选又改变了交易条款。为避免擅自替你改交易，本次不自动替换。",
                        alternative, "");
            }
            BindingContractJudge.Result localCandidate = BindingContractJudge.evaluate(contract);
            boolean changedExplicitScope = SpellNameResolver.changesExplicitSpellScope(intent, contract);
            if (!localCandidate.accepted() || changedExplicitScope) {
                String reason = !localCandidate.accepted()
                        ? "模型候选未通过本地裁定：" + localCandidate.reason()
                        : "模型候选改变了已指定法术，触发范围保护";
                if (isOpenEndedIntent(intent)) {
                    Advice repaired = requestRepair(config, configuredUri, nativeOllama, intent, contract, reason);
                    if (isSafeModelProposal(intent, repaired)) {
                        return new Advice(repaired.contractText(), repaired.analysis() + "（第二轮修订候选已通过本地复核。）",
                                repaired.alternative(), "");
                    }
                    return localFallbackAdvice(intent, reason + "；第二轮模型候选仍未通过，改用本地规则备用方案。");
                }
                return new Advice("", "模型候选未通过本地裁定，且未自动改写你的具体交易：" + reason,
                        alternative.isBlank() ? localCandidate.suggestion() : alternative, "");
            }
            return new Advice(contract, analysis, alternative, "");
        } catch (java.net.http.HttpTimeoutException ex) {
            return fallbackOrError(intent, "AI 请求超时。初次加载本地模型可能较慢；可调高 timeout_seconds，或等待模型预热后重试。");
        } catch (java.net.ConnectException ex) {
            return fallbackOrError(intent, "连接不到 AI endpoint。请确认 Ollama 正在运行，并检查 out_of_spec_binding_ai.properties 中的 endpoint。");
        } catch (IllegalArgumentException ex) {
            return fallbackOrError(intent, "AI 配置或响应 JSON 无效。详情：" + safeMessage(ex));
        } catch (Exception ex) {
            return fallbackOrError(intent, "AI 协商失败：" + safeMessage(ex));
        }
    }

    /** One bounded repair pass. It only accepts a proposal that passes the same local judge. */
    private static Advice requestRepair(Config config, URI configuredUri, boolean nativeOllama,
                                        String intent, String rejectedContract, String rejectionReason) throws Exception {
        URI requestUri = nativeOllama ? URI.create(origin(configuredUri) + "/api/chat") : configuredUri;
        JsonObject payload = new JsonObject();
        payload.addProperty("model", config.model());
        JsonArray messages = new JsonArray();
        messages.add(message("system", SYSTEM_PROMPT));
        String repair = "<CURRENT_REQUEST>\n" + intent + "\n</CURRENT_REQUEST>\n"
                + "这是一次有上限的第二轮修订，不是新请求。上次候选：" + (rejectedContract == null || rejectedContract.isBlank() ? "（空）" : rejectedContract)
                + "。本地裁定原因：" + clamp(rejectionReason == null ? "未说明" : rejectionReason, 220) + "。"
                + "请依据原请求重新构造一个合理、可执行的完整交易；保留请求中明确指定的法术、排除项和数值，不得引入未实现效果。"
                + "只返回规定 JSON；仍无法满足时 contract_text 留空，并解释原因。";
        messages.add(message("user", repair));
        if (nativeOllama) {
            payload.add("messages", messages);
            payload.addProperty("stream", false);
            payload.addProperty("keep_alive", config.keepAliveMinutes() + "m");
            JsonObject options = new JsonObject();
            options.addProperty("temperature", 0.25);
            options.addProperty("num_predict", 700);
            payload.add("options", options);
            payload.addProperty("format", "json");
        } else {
            payload.add("messages", messages);
            payload.addProperty("temperature", 0.25);
            payload.addProperty("max_tokens", 700);
        }
        HttpRequest.Builder builder = HttpRequest.newBuilder(requestUri)
                .timeout(Duration.ofSeconds(Math.min(config.timeoutSeconds(), nativeOllama ? 90 : 30)))
                .header("Content-Type", "application/json; charset=utf-8")
                .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(payload), StandardCharsets.UTF_8));
        if (!config.apiKey().isBlank() && !nativeOllama) builder.header("Authorization", "Bearer " + config.apiKey());
        HttpResponse<String> response = HTTP.send(builder.build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            return new Advice("", "第二轮修订请求失败，HTTP " + response.statusCode(), "", "修订请求失败");
        }
        JsonObject responseJson = JsonParser.parseString(response.body()).getAsJsonObject();
        String content;
        if (nativeOllama) {
            JsonObject msg = responseJson.getAsJsonObject("message");
            content = msg == null || !msg.has("content") ? "" : msg.get("content").getAsString();
        } else {
            JsonArray choices = responseJson.getAsJsonArray("choices");
            if (choices == null || choices.isEmpty()) return new Advice("", "第二轮没有返回候选。", "", "修订候选为空");
            JsonObject msg = choices.get(0).getAsJsonObject().getAsJsonObject("message");
            content = msg == null || !msg.has("content") ? "" : msg.get("content").getAsString();
        }
        if (content == null || content.isBlank()) return new Advice("", "第二轮没有返回候选。", "", "修订候选为空");
        JsonObject answer = parseAssistantObject(content);
        return new Advice(clean(answer, "contract_text", 512), clean(answer, "analysis", 220),
                clean(answer, "alternative", 180), "");
    }

    private static boolean isSafeModelProposal(String intent, Advice advice) {
        if (advice == null || !advice.hasProposal()) return false;
        if (!BindingContractJudge.evaluate(advice.contractText()).accepted()) return false;
        return !SpellNameResolver.changesExplicitSpellScope(intent, advice.contractText());
    }

    private static boolean hasExplicitTransaction(String intent) {
        return intent != null && java.util.regex.Pattern.compile(
                "(?:换取|换来|交换得到|交换获得|以此获得|从而获得|换成|作为代价|为代价|代价是|代价[:：])")
                .matcher(intent).find();
    }

    private static Advice fallbackOrError(String intent, String error) {
        return isOpenEndedIntent(intent) ? localFallbackAdvice(intent, error)
                : new Advice("", "", "", error);
    }

    private static boolean isOpenEndedIntent(String intent) {
        if (intent == null || intent.isBlank()) return false;
        boolean opener = java.util.regex.Pattern.compile("(?:帮我.{0,8}(?:设计|想|推荐|构思)|(?:设计|想|推荐|生成|构思).{0,16}(?:契约|束缚)|有什么.{0,10}(?:契约|束缚)|给点灵感|求点子|发挥创意|随便来个|来个.{0,8}(?:契约|束缚)|给我一个方案|给个点子|随机生成)")
                .matcher(intent).find();
        if (!opener) return false;
        // An explicit transaction is the player's authored contract; never replace it with a
        // different local idea. In contrast, merely naming a supported stat is an idea constraint,
        // and should be preserved by the local generator when the model is offline or unhelpful.
        if (java.util.regex.Pattern.compile("(?:换取|换来|交换得到|交换获得|以此获得|从而获得|换成|作为代价|为代价|代价是|代价[:：])")
                .matcher(intent).find()) return false;
        // Do not downgrade requests for mechanics that do not yet have real execution hooks.
        if (java.util.regex.Pattern.compile("(?:瞬移|传送|治疗|回血|恢复生命|召唤|护盾|护甲|暴击|穿透|范围伤害|击退|击飞|结印|咏唱识别|语音|双方玩家|违约惩罚|生得术式|生得魔法)")
                .matcher(intent).find()) return false;
        if (!SpellNameResolver.findNegatedSpellIds(intent).isEmpty()) return false;
        return SpellNameResolver.findPositiveSpellIds(intent).size() <= 1;
    }

    private static Advice localFallbackAdvice(String intent, String cause) {
        if (!isOpenEndedIntent(intent)) {
            return new Advice("", "", "", cause == null ? "当前请求不能安全地改写为本地备用契约。" : cause);
        }
        java.util.ArrayList<String> candidates = new java.util.ArrayList<>();
        java.util.Set<String> targets = SpellNameResolver.findPositiveSpellIds(intent);
        String lowerIntent = intent.toLowerCase(java.util.Locale.ROOT);
        boolean allSpellsRequested = java.util.regex.Pattern.compile("(?:全部法术|所有法术|全体法术|所有技能|全部技能)").matcher(intent).find();
        boolean asksCooldown = lowerIntent.contains("冷却");
        boolean asksMana = lowerIntent.contains("法力") || lowerIntent.contains("魔力消耗") || lowerIntent.contains("蓝耗");
        boolean asksCastTime = lowerIntent.contains("施法时间") || lowerIntent.contains("吟唱时间") || lowerIntent.contains("读条时间");
        boolean asksMobility = lowerIntent.contains("移动速度") || lowerIntent.contains("移速") || lowerIntent.contains("跑动速度");
        boolean asksVisibility = lowerIntent.contains("可见度") || lowerIntent.contains("隐蔽") || lowerIntent.contains("被发现");
        if (targets.size() == 1 && (asksCooldown || asksMana || asksCastTime || asksVisibility)) {
            return new Advice("", "该想法提到了特定法术，但目前" + (asksCooldown ? "冷却时间" : asksMana ? "法力消耗" : asksCastTime ? "施法时间" : "可见度")
                    + "只接入全局效果。为避免把你的目标偷偷扩大到所有法术，本地判定没有自动替换。" + clamp(cause == null ? "" : cause, 100),
                    "可以去掉单法术限制，或改为该法术的伤害/法术强度交易；服务端只会接受真实接入的效果。", "");
        }
        if (targets.size() == 1) {
            String targetName = SpellNameResolver.displayName(targets.iterator().next());
            // Damage and spell power really support a single-spell scope. The other stat adapters
            // are currently global-only, so don't disguise them as a named-spell effect.
            if (asksMobility) {
                candidates.add("法术强度降低20%，换取施法时" + targetName + "移动速度提高12%，持续性");
                candidates.add("永久承受缓慢效果，换取下一次" + targetName + "的伤害提高到1000%");
            } else {
                candidates.add("永久承受缓慢效果，换取下一次" + targetName + "的伤害提高到1000%");
                candidates.add("永久失去睡眠能力，换取下一次" + targetName + "的伤害提高到1000%");
            }
        } else if (allSpellsRequested) {
            if (asksCooldown) {
                candidates.add("法力消耗增加40%，换取冷却时间缩短15%，持续性");
                candidates.add("冷却时间延长50%，换取法力消耗降低20%，持续性");
            } else if (asksMana) {
                candidates.add("冷却时间延长50%，换取法力消耗降低20%，持续性");
                candidates.add("法力消耗增加40%，换取冷却时间缩短15%，持续性");
            } else if (asksCastTime) {
                candidates.add("法术强度降低20%，换取所有法术施法时间永久缩短10%");
                candidates.add("法力消耗增加40%，换取施法时间缩短15%，持续性");
            } else if (asksMobility) {
                candidates.add("法术强度降低20%，换取施法时移动速度提高12%，持续性");
                candidates.add("冷却时间延长30%，换取施法时移动速度提高15%，持续性");
            } else if (asksVisibility) {
                candidates.add("永久承受缓慢效果，换取可见度降低30%，持续性");
                candidates.add("法力消耗增加40%，换取可见度降低20%，持续性");
            } else {
                candidates.add("永久承受缓慢效果，换取下一次全部法术伤害提高到1000%");
                candidates.add("永久失去睡眠能力，换取下一次所有法术伤害提高到1000%");
            }
        } else if (asksCooldown || asksMana) {
            candidates.add("法力消耗增加40%，换取冷却时间缩短15%，持续性");
            candidates.add("冷却时间延长50%，换取法力消耗降低20%，持续性");
        } else if (asksCastTime) {
            candidates.add("法术强度降低20%，换取施法时间缩短10%，持续性");
            candidates.add("法力消耗增加40%，换取施法时间缩短15%，持续性");
        } else if (asksMobility) {
            candidates.add("法术强度降低20%，换取施法时移动速度提高12%，持续性");
            candidates.add("冷却时间延长30%，换取施法时移动速度提高15%，持续性");
        } else if (asksVisibility) {
            candidates.add("永久承受缓慢效果，换取可见度降低30%，持续性");
            candidates.add("法力消耗增加40%，换取可见度降低20%，持续性");
        } else {
            candidates.add("永久承受缓慢效果，换取下一次雷鸣长枪的伤害提高到1000%");
            candidates.add("永久承受缓慢效果，换取下一次火球术的伤害提高到1000%");
            candidates.add("永久失去睡眠能力，换取下一次雷鸣长枪的伤害提高到1000%");
            candidates.add("只能使用一次火球术作为代价，换取下一次火球术的伤害增加到10000%");
        }
        String selected = "";
        BindingContractJudge.Result selectedResult = null;
        int start = Math.floorMod(intent.hashCode(), candidates.size());
        for (int i = 0; i < candidates.size(); i++) {
            String candidate = candidates.get((start + i) % candidates.size());
            if (SpellNameResolver.changesExplicitSpellScope(intent, candidate)) continue;
            BindingContractJudge.Result judged = BindingContractJudge.evaluate(candidate);
            if (judged.accepted()) { selected = candidate; selectedResult = judged; break; }
        }
        if (selected.isBlank()) {
            return new Advice("", "本地备用候选未通过本地规则预审，未自动替换你的请求。" + clamp(cause == null ? "" : cause, 100),
                    "请简化为已实现的代价与收益，或检查 AI 服务配置。", "");
        }
        final String selectedCandidate = selected;
        String alternative = candidates.stream().filter(c -> !c.equals(selectedCandidate)
                        && !SpellNameResolver.changesExplicitSpellScope(intent, c)
                        && BindingContractJudge.evaluate(c).accepted())
                .findFirst().orElse("");
        return new Advice(selected,
                "本地规则备用候选（未把模型故障伪装成 AI 成功：" + clamp(cause == null ? "模型不可用" : cause, 92)
                        + "）。该候选已通过本地规则预审，但只有服务器最终复核成功后才会生效。"
                        + (selectedResult == null ? "" : " 本地公平度：" + String.format(java.util.Locale.ROOT, "%.2f", selectedResult.ratio()) + "。"),
                alternative, "");
    }

    private static String buildExperienceContext(List<ContractExperienceStore.ExperienceCase> cases) {
        StringBuilder out = new StringBuilder(
                "这是历史案例的抽象机制索引，不包含旧契约原文，也不是本次用户需求。严禁把这里的效果、目标、法术或数值复制/追加到 CURRENT_REQUEST。\n");
        int index = 1;
        for (ContractExperienceStore.ExperienceCase entry : cases) {
            String label = switch (entry.outcome()) {
                case "SERVER_ACCEPTED" -> "曾获服务器通过";
                case "SERVER_REJECTED" -> "曾被服务器拒绝（状态可能相关）";
                case "LOCAL_REJECTED" -> "曾被本地预审拒绝，非最终服务器结论";
                default -> "历史案例";
            };
            BindingContract c = BindingContractJudge.evaluate(entry.contractText()).contract();
            java.util.List<String> tags = new java.util.ArrayList<>();
            if (c.permanentSlownessCost()) tags.add("永久缓慢代价");
            if (c.permanentInsomniaCost()) tags.add("永久失眠代价");
            if (c.permanentCastMoveSpeedCost()) tags.add("永久施法减速代价");
            if (c.singleUseSpellCost() || c.immediateSealCost() || !BindingContract.ALL_SPELLS.equals(c.delayedSealSpellId())) tags.add("法术封存代价");
            if (c.spellPowerDeltaPct() < 0.0) tags.add("法术强度牺牲");
            if (c.moveSpeedDeltaPct() < 0.0) tags.add("施法机动性牺牲");
            if (c.castTimeDeltaPct() > 0.0) tags.add("施法时间代价");
            if (c.manaCostDeltaPct() > 0.0) tags.add("法力消耗代价");
            if (c.cooldownDeltaPct() > 0.0) tags.add("冷却代价");
            if (c.hasDamageReward()) tags.add("伤害倍率收益");
            if (c.spellPowerDeltaPct() > 0.0) tags.add("法术强度收益");
            if (c.moveSpeedDeltaPct() > 0.0) tags.add("施法机动性收益");
            if (c.castTimeDeltaPct() < 0.0) tags.add("施法时间收益");
            if (c.manaCostDeltaPct() < 0.0) tags.add("法力节省收益");
            if (c.cooldownDeltaPct() < 0.0) tags.add("冷却缩短收益");
            if (c.damageMode().equals(BindingContract.MODE_NEXT_CAST)) tags.add("一次性收益期限");
            else if (c.damageMode().equals(BindingContract.MODE_TIMED)) tags.add("限时收益期限");
            else if (c.damageMode().equals(BindingContract.MODE_PERSISTENT)) tags.add("持续可解除收益期限");
            else if (c.damageMode().equals(BindingContract.MODE_PERMANENT)) tags.add("永久收益期限");
            if (c.durationTicks() > 0) tags.add("具有服务端期限");
            if (c.healthThresholdPct() >= 0.0) tags.add("生命阈值条件");
            if (tags.isEmpty()) tags.add("未完整解析的历史方案");
            out.append(index++).append(". [").append(label).append("] 机制标签：")
                    .append(String.join("、", tags)).append("。这些标签仅供判断可执行模式，不带入任何旧契约文本、法术名或百分比。\n");
        }
        out.append("再次强调：CURRENT_REQUEST 才是唯一当前交易；历史案例不可作为额外代价、收益或目标。\n");
        return out.toString();
    }

    private static JsonObject message(String role, String content) {
        JsonObject message = new JsonObject();
        message.addProperty("role", role);
        message.addProperty("content", content);
        return message;
    }

    private static JsonObject parseAssistantObject(String content) {
        String text = content == null ? "" : content.trim();
        int start = text.indexOf('{');
        int end = text.lastIndexOf('}');
        if (start < 0 || end <= start) throw new IllegalArgumentException("AI 返回内容不是约定的 JSON；请换用支持 JSON 输出的模型。");
        JsonElement element = JsonParser.parseString(text.substring(start, end + 1));
        if (!element.isJsonObject()) throw new IllegalArgumentException("AI 返回 JSON 的根节点不是对象。");
        return element.getAsJsonObject();
    }

    private static String clean(JsonObject object, String key, int maxLength) {
        if (object == null || !object.has(key) || object.get(key).isJsonNull()) return "";
        JsonElement value = object.get(key);
        if (!(value instanceof JsonPrimitive primitive) || !primitive.isString()) return "";
        return clamp(primitive.getAsString(), maxLength);
    }

    private static synchronized Config loadConfig() throws IOException {
        Path path = configPath();
        Files.createDirectories(path.getParent());
        Properties properties = new Properties();
        if (Files.exists(path)) {
            try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                properties.load(reader);
            }
        }
        boolean changed = false;
        changed |= setDefault(properties, "endpoint", "http://127.0.0.1:11434/v1/chat/completions");
        changed |= setDefault(properties, "model", "qwen2.5:7b");
        changed |= setDefault(properties, "api_key", "");
        changed |= setDefault(properties, "timeout_seconds", "180");
        changed |= setDefault(properties, "keep_alive_minutes", "30");
        changed |= setDefault(properties, "experience_memory_enabled", "true");
        changed |= setDefault(properties, "prewarm_local_model", "true");
        if (changed || !Files.exists(path)) {
            try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
                properties.store(writer, "OUT OF SPEC Binding AI settings; experience memory stays local");
            }
        }
        String endpoint = properties.getProperty("endpoint").trim();
        String model = properties.getProperty("model").trim();
        String apiKey = properties.getProperty("api_key", "").trim();
        int timeout = parseInt(properties.getProperty("timeout_seconds"), 180, 10, 300);
        int keepAlive = parseInt(properties.getProperty("keep_alive_minutes"), 30, 5, 240);
        boolean experienceEnabled = Boolean.parseBoolean(properties.getProperty("experience_memory_enabled", "true").trim());
        boolean preloadModel = Boolean.parseBoolean(properties.getProperty("prewarm_local_model", "true").trim());
        if (endpoint.isBlank() || model.isBlank()) throw new IllegalArgumentException("endpoint 和 model 不能为空。");
        URI uri = URI.create(endpoint);
        if (!("http".equalsIgnoreCase(uri.getScheme()) || "https".equalsIgnoreCase(uri.getScheme())) || uri.getHost() == null) {
            throw new IllegalArgumentException("endpoint 必须是有效的 http/https URL。");
        }
        return new Config(endpoint, model, apiKey, timeout, keepAlive, experienceEnabled, preloadModel);
    }

    private static boolean setDefault(Properties properties, String key, String value) {
        if (properties.containsKey(key)) return false;
        properties.setProperty(key, value);
        return true;
    }

    private static int parseInt(String text, int fallback, int min, int max) {
        int value;
        try { value = Integer.parseInt(text == null ? "" : text.trim()); }
        catch (NumberFormatException ignored) { value = fallback; }
        return Math.max(min, Math.min(max, value));
    }

    private static boolean isLocalOllama(URI uri) {
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(java.util.Locale.ROOT);
        boolean loopback = host.equals("localhost") || host.equals("127.0.0.1") || host.equals("::1") || host.equals("0:0:0:0:0:0:0:1");
        return loopback && (uri.getPort() == 11434 || (uri.getPort() == -1 && "http".equalsIgnoreCase(uri.getScheme())))
                && (uri.getPath() == null || uri.getPath().contains("chat/completions") || uri.getPath().equals("/api/chat"));
    }

    private static String origin(URI uri) {
        String authority = uri.getRawAuthority();
        if (authority == null || authority.isBlank()) throw new IllegalArgumentException("endpoint 缺少 host。");
        if (uri.getPort() == -1 && uri.getHost() != null
                && (uri.getHost().equalsIgnoreCase("localhost") || uri.getHost().equals("127.0.0.1") || uri.getHost().equals("::1"))) {
            authority += ":11434";
        }
        return uri.getScheme() + "://" + authority;
    }

    private static String clamp(String text, int maxLength) {
        if (text == null) return "";
        String safe = text.trim();
        return safe.length() > maxLength ? safe.substring(0, maxLength) : safe;
    }

    private static String safeMessage(Exception exception) {
        String message = exception.getMessage();
        if (message == null || message.isBlank()) return exception.getClass().getSimpleName();
        message = message.replaceAll("(?i)Bearer\\s+[^\\s,]+", "Bearer [redacted]");
        return message.length() > 200 ? message.substring(0, 200) + "…" : message;
    }
}
