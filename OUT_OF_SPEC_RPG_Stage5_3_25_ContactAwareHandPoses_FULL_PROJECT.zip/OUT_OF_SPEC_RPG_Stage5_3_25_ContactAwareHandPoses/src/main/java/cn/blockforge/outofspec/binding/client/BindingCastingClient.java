package cn.blockforge.outofspec.binding.client;

import cn.blockforge.outofspec.binding.BindingContract;
import cn.blockforge.outofspec.binding.network.BindingCastingNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

/** Lightweight client state shared between the SAO skill-menu entry and the contract screen. */
public final class BindingCastingClient {
    private static volatile boolean hasActiveContract;
    private static volatile String activeSummary = "正在读取服务器契约……";
    private BindingCastingClient() {}

    public static boolean hasActiveContract() { return hasActiveContract; }
    public static String activeSummary() { return activeSummary; }
    public static void requestCurrentContract() { BindingCastingNetwork.requestCurrentContract(); }
    public static void submit(String text, BindingContract canonicalContract) {
        BindingCastingNetwork.sendProposal(text, canonicalContract);
    }
    public static void clear() { BindingCastingNetwork.sendClear(); }

    public static void receiveStatus(boolean actionSucceeded, boolean hasContract, String summary, String message) {
        BindingAIAdvisor.recordPendingServerOutcome(actionSucceeded, hasContract, message);
        hasActiveContract = hasContract;
        activeSummary = hasContract ? summary : "无生效契约";
        Minecraft mc = Minecraft.getInstance();
        boolean delivered = BindingContractScreen.receiveBackgroundServerStatus(
                actionSucceeded, hasContract, summary, message);
        if (!delivered && mc.player != null) {
            mc.player.displayClientMessage(Component.literal(message), true);
        }
    }
}
