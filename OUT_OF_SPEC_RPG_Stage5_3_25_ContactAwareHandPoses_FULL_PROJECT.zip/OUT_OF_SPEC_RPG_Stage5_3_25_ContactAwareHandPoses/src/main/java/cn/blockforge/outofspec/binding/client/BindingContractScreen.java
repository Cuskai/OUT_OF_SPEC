package cn.blockforge.outofspec.binding.client;

import cn.blockforge.outofspec.binding.BindingContract;
import cn.blockforge.outofspec.binding.BindingContractJudge;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;

import java.util.List;

/** SAO-styled contract composer. The natural-language verdict is a local preview; the server rechecks it. */
public final class BindingContractScreen extends Screen {
    private static final ResourceLocation RITUAL_SEAL_TEXTURE = new ResourceLocation(
            "out_of_spec_binding", "textures/gui/ritual_seal.png");
    private static BindingContractScreen retainedInstance;
    private Screen parent;
    private String draftText = "";
    private EditBox input;
    private Button judgeButton;
    private Button forgeButton;
    private Button clearInputButton;
    private Button clearContractButton;
    private Button backButton;
    private Button aiButton;
    private Button closeButton;
    private BindingContractJudge.Result result;
    private String serverFeedback = "输入契约后，可先本地分析；也可以请求 AI 帮你设计候选契约。";
    private String aiResponse = "AI 是可选功能；首次使用会生成 AI 配置文件。";
    private boolean waitingForServer;
    private boolean aiBusy;
    private boolean aiResultPresented;
    private boolean applyingAiCandidate;
    private long aiRequestSequence;
    private long aiStartedAtMillis;
    private long aiLastDurationMillis;
    private int aiResponseScroll;
    private String lastAiIntent = "";
    private String lastAiProposalText = "";
    private String lastAiAnalysis = "";
    private String lastAiAlternative = "";
    private String lastSubmittedText = "";
    private int panelX, panelY, panelW, panelH;

    public BindingContractScreen(Screen parent) {
        super(Component.literal("OUT OF SPEC // 束缚契约终端"));
        this.parent = parent;
    }

    /** Reuse one screen/session so leaving for SAO Menu never discards an in-flight AI adjudication. */
    public static void openOrResume(Screen parent) {
        Minecraft mc = Minecraft.getInstance();
        if (retainedInstance == null) retainedInstance = new BindingContractScreen(parent);
        retainedInstance.parent = parent;
        mc.setScreen(retainedInstance);
    }

    /** Routes server replies to the retained draft even if the player has returned to the game. */
    public static boolean receiveBackgroundServerStatus(boolean succeeded, boolean hasContract, String summary, String message) {
        BindingContractScreen target = retainedInstance;
        if (target == null) return false;
        target.onServerStatus(succeeded, hasContract, summary, message);
        return true;
    }

    @Override
    protected void init() {
        this.panelW = Math.min(780, this.width - 24);
        this.panelH = Math.min(432, this.height - 20);
        this.panelX = (this.width - panelW) / 2;
        this.panelY = (this.height - panelH) / 2;

        int contentX = panelX + 18;
        int contentW = panelW - 36;
        input = new EditBox(this.font, contentX, panelY + 71, contentW, 22, Component.literal("契约描述"));
        input.setMaxLength(512);
        input.setBordered(false);
        input.setTextColor(0xFFF0EDFF);
        input.setTextColorUneditable(0xFFB8B1D0);
        input.setValue(draftText);
        input.setResponder(value -> {
            draftText = value == null ? "" : value;
            if (applyingAiCandidate) return;
            if (aiBusy) {
                // Editing while the model is still answering invalidates the old request so its
                // late callback can never overwrite a newly typed contract.
                aiRequestSequence++;
                aiBusy = false;
                aiStartedAtMillis = 0L;
                aiLastDurationMillis = 0L;
                aiResponseScroll = 0;
                if (aiButton != null) aiButton.active = true;
                aiResponse = "输入已变化；旧 AI 请求已作废，避免上一份契约覆盖或混入新输入。";
            }
            aiResultPresented = false;
            result = null;
            waitingForServer = false;
            lastAiIntent = "";
            lastAiProposalText = "";
            lastAiAnalysis = "";
            lastAiAlternative = "";
            lastSubmittedText = "";
            if (forgeButton != null) forgeButton.active = false;
            serverFeedback = "输入已修改；本次将作为独立的新契约重新裁定。";
        });
        addRenderableWidget(input);

        int gap = 8;
        int buttonW = Math.max(72, (contentW - gap * 4) / 5);
        int row1 = panelY + 105;
        judgeButton = addRenderableWidget(Button.builder(Component.literal("分析交易"), b -> evaluate())
                .bounds(contentX, row1, buttonW, 20).build());
        forgeButton = addRenderableWidget(Button.builder(Component.literal("缔结契约"), b -> submit())
                .bounds(contentX + buttonW + gap, row1, buttonW, 20).build());
        forgeButton.active = result != null && result.accepted() && !waitingForServer;
        aiButton = addRenderableWidget(Button.builder(Component.literal("AI 推演"), b -> requestAiAdvice())
                .bounds(contentX + (buttonW + gap) * 2, row1, buttonW, 20).build());
        aiButton.active = !aiBusy;
        clearInputButton = addRenderableWidget(Button.builder(Component.literal("清空输入"), b -> {
            input.setValue(""); input.setFocused(true); result = null; forgeButton.active = false;
        }).bounds(contentX + (buttonW + gap) * 3, row1, buttonW, 20).build());
        clearContractButton = addRenderableWidget(Button.builder(Component.literal("解除契约"), b -> {
            waitingForServer = true;
            serverFeedback = "正在请求服务端解除当前契约……";
            BindingCastingClient.clear();
        }).bounds(contentX + (buttonW + gap) * 4, row1, buttonW, 20).build());
        backButton = addRenderableWidget(Button.builder(Component.literal(aiBusy ? "返回菜单 · 推演继续" : "返回 SAO Menu"), b -> onClose())
                .bounds(contentX, panelY + 132, contentW, 20).build());
        closeButton = addRenderableWidget(Button.builder(Component.literal("×"), b -> onClose())
                .bounds(panelX + panelW - 28, panelY + 8, 18, 18).build());
        BindingCastingClient.requestCurrentContract();
        if (aiBusy) {
            aiResponse = "契约顾问正在后台推演。本界面可以随时关闭；请求不会取消，重新打开会恢复本次结果。";
            serverFeedback = "后台请求运行中；输入草稿会保留。";
        } else if (!aiResultPresented && result == null && (aiResponse == null || aiResponse.isBlank()
                || aiResponse.startsWith("AI 是可选功能") || aiResponse.startsWith("正在后台预热"))) {
            aiResponse = "正在后台预热本地 AI，并读取本机契约经验库……";
            BindingAIAdvisor.prewarmIfLocal().whenComplete((status, failure) -> Minecraft.getInstance().execute(() -> {
                if (minecraft == null || minecraft.screen != this || aiBusy || aiResultPresented) return;
                if (failure != null) return;
                if (status != null && !status.isBlank()) aiResponse = status;
            }));
        }
    }

    private void requestAiAdvice() {
        if (aiBusy) return;
        String intent = input.getValue() == null ? "" : input.getValue().trim();
        if (intent.isBlank()) {
            aiResponse = "先写下你的目标，例如：我想施法时移动更快，愿意承担更高法力消耗。";
            serverFeedback = "AI 需要先知道你想换取什么。";
            return;
        }
        final long requestToken = ++aiRequestSequence;
        aiBusy = true;
        aiStartedAtMillis = System.currentTimeMillis();
        aiLastDurationMillis = 0L;
        aiResponseScroll = 0;
        aiResultPresented = true;
        result = null;
        forgeButton.active = false;
        lastAiIntent = intent;
        lastAiProposalText = "";
        lastAiAnalysis = "";
        lastAiAlternative = "";
        lastSubmittedText = "";
        if (aiButton != null) aiButton.active = false;
        aiResponse = "正在查询本地契约经验；历史案例只提供抽象机制，不会拼进本次条款。";
        serverFeedback = "AI 正在处理本次独立请求；最终仍由本地规则和服务器复核。";
        BindingAIAdvisor.request(intent).whenComplete((advice, failure) -> Minecraft.getInstance().execute(() -> {
            if (requestToken != aiRequestSequence) return;
            aiBusy = false;
            if (aiStartedAtMillis > 0L) {
                aiLastDurationMillis = Math.max(0L, System.currentTimeMillis() - aiStartedAtMillis);
            }
            aiStartedAtMillis = 0L;
            aiResponseScroll = 0;
            // Deliberately process even while this retained screen is hidden. Returning to the game
            // is navigation, not cancellation; the candidate is stored on this instance for resume.
            if (minecraft == null) return;
            if (!intent.equals(input.getValue() == null ? "" : input.getValue().trim())) {
                aiResponse = "输入已在协商期间发生变化，旧候选已丢弃，没有覆盖新输入。";
                serverFeedback = "请对当前输入重新点击「AI 协商」。";
                if (aiButton != null) aiButton.active = true;
                return;
            }
            if (aiButton != null) aiButton.active = true;
            if (failure != null) {
                aiResponse = "AI 协商失败：" + failure.getClass().getSimpleName();
                serverFeedback = "AI 没有返回候选；原输入未被改变。";
                return;
            }
            if (advice.error() != null && !advice.error().isBlank()) {
                aiResponse = advice.error();
                serverFeedback = "AI 未能连接或返回有效结果；请检查 AI 配置文件。";
                return;
            }
            StringBuilder details = new StringBuilder();
            if (advice.analysis() != null && !advice.analysis().isBlank()) details.append(advice.analysis());
            if (advice.alternative() != null && !advice.alternative().isBlank()) {
                if (!details.isEmpty()) details.append(" 备选：");
                details.append(advice.alternative());
            }
            aiResponse = details.isEmpty() ? "AI 没有提供解释。" : details.toString();
            if (advice.hasProposal()) {
                String proposed = advice.contractText().trim();
                BindingContractJudge.Result proposedResult = BindingContractJudge.evaluate(proposed);
                BindingContractJudge.Result originalResult = BindingContractJudge.evaluate(intent);
                boolean changedExplicitSpellScope = cn.blockforge.outofspec.binding.SpellNameResolver
                        .changesExplicitSpellScope(intent, proposed);
                boolean changedAnAlreadyExecutableTrade = originalResult.accepted() && proposedResult.accepted()
                        && !BindingContractJudge.equivalentAcceptedTrade(intent, proposed);
                boolean shouldUseOriginal = originalResult.accepted()
                        && (!proposedResult.accepted() || changedAnAlreadyExecutableTrade || changedExplicitSpellScope);
                if (shouldUseOriginal) {
                    lastAiProposalText = intent;
                    lastAiAnalysis = stripExperienceHitPrefix(advice.analysis());
                    lastAiAlternative = advice.alternative() == null ? "" : advice.alternative();
                    applyingAiCandidate = true;
                    try { input.setValue(intent); } finally { applyingAiCandidate = false; }
                    result = originalResult;
                    forgeButton.active = true;
                    String why = changedExplicitSpellScope
                            ? "AI 候选改动了本次请求明确指定或排除的法术范围，已阻止串单。"
                            : "AI 候选与本次目标不一致或无法通过本地解析，已安全退回可执行的原始描述。";
                    serverFeedback = why + " 原始交易已通过本地预审，缔结时仍由服务器复核。";
                    aiResponse = why + " " + aiResponse;
                } else {
                    lastAiProposalText = proposed;
                    lastAiAnalysis = stripExperienceHitPrefix(advice.analysis());
                    lastAiAlternative = advice.alternative() == null ? "" : advice.alternative();
                    if (changedExplicitSpellScope) {
                        result = null;
                        forgeButton.active = false;
                        serverFeedback = "AI 候选改动了本次明确指定或排除的法术范围；为防止串单，未应用该候选。请重新协商或修正本次目标。";
                        aiResponse = "已阻止改变明确目标/排除项的候选。" + aiResponse;
                    } else {
                        applyingAiCandidate = true;
                        try { input.setValue(proposed); } finally { applyingAiCandidate = false; }
                        result = proposedResult;
                        forgeButton.active = result.accepted();
                        if (result.accepted()) {
                            serverFeedback = "候选已通过本地预审；缔结后服务器会复核，成功案例才会写入经验库。";
                        } else {
                            serverFeedback = "AI 的文字解释不是最终裁定；候选未通过本地预审，已显示具体原因。";
                            if (BindingAIAdvisor.experienceMemoryEnabled()) {
                                ContractExperienceStore.recordLocalRejection(lastAiIntent, proposed,
                                        lastAiAnalysis, lastAiAlternative,
                                        result.reason() + " " + result.suggestion(), BindingAIAdvisor.configuredModel());
                            }
                            aiResponse = "本地裁定拒绝：" + result.reason() + " " + result.suggestion() + "。AI 说明仅供参考。";
                        }
                    }
                }
            } else {
                // The model can correctly reason that a trade is reasonable yet leave contract_text
                // empty. If the user's own wording is already executable, use that exact text rather
                // than forcing the user through an empty-candidate dead end.
                BindingContractJudge.Result originalResult = BindingContractJudge.evaluate(intent);
                result = originalResult;
                lastAiAnalysis = stripExperienceHitPrefix(advice.analysis());
                lastAiAlternative = advice.alternative() == null ? "" : advice.alternative();
                if (originalResult.accepted()) {
                    lastAiProposalText = intent;
                    applyingAiCandidate = true;
                    try { input.setValue(intent); } finally { applyingAiCandidate = false; }
                    forgeButton.active = true;
                    serverFeedback = "AI 没有返回单独的规范化候选，但原始交易已通过本地预审；已保留原文，可直接缔结并由服务器复核。";
                    aiResponse = "已使用本次原始交易，不复用任何历史合同。" + aiResponse;
                } else {
                    lastAiProposalText = "";
                    forgeButton.active = false;
                    serverFeedback = "AI 没有生成可执行候选；本地规则也未通过。请按下方本地原因修改本次输入。";
                    aiResponse = "本地裁定拒绝：" + originalResult.reason() + " "
                            + originalResult.suggestion() + "。AI 对交易思路的评价不等于机制已经接入。";
                }
            }
        }));
    }

    private void evaluate() {
        waitingForServer = false;
        result = BindingContractJudge.evaluate(input.getValue());
        forgeButton.active = result.accepted();
        serverFeedback = result.accepted()
                ? "本地预审通过。点击「缔结契约」后，服务器还会独立复核。"
                : "预审未通过：先看下方原因与调整建议。";
    }

    private void submit() {
        if (result == null || !result.accepted() || waitingForServer) return;
        waitingForServer = true;
        lastSubmittedText = input.getValue() == null ? "" : input.getValue().trim();
        forgeButton.active = false;
        BindingAIAdvisor.trackPendingServerOutcome(lastAiIntent, lastAiProposalText, lastSubmittedText,
                lastAiAnalysis, lastAiAlternative);
        serverFeedback = "契约已提交，等待服务端复核……";
        // Send exactly the accepted structure currently shown in the preview. The server will
        // independently rebuild it from the submitted source and reject any schema mismatch.
        BindingCastingClient.submit(lastSubmittedText, result.contract());
    }

    public void onServerStatus(boolean succeeded, boolean hasContract, String summary, String message) {
        boolean wasWaitingForServer = waitingForServer;
        waitingForServer = false;
        serverFeedback = message;
        boolean adjudicationReply = message != null && (message.contains("服务端复核")
                || message.contains("当前契约包含尚未兑现") || message.contains("当前契约含有不可撤销"));
        if (adjudicationReply && !lastAiIntent.isBlank() && !lastAiProposalText.isBlank() && !lastSubmittedText.isBlank()
                && ContractExperienceStore.normalizeIntent(lastSubmittedText)
                .equals(ContractExperienceStore.normalizeIntent(lastAiProposalText))) {
            boolean acceptedByServer = succeeded && hasContract;
            if (acceptedByServer) {
                aiResponse = BindingAIAdvisor.experienceMemoryEnabled()
                        ? "本次契约已通过服务端验证并记入本地经验库。已验证通过案例："
                            + ContractExperienceStore.verifiedAcceptedCount() + " 条；完全相同的目标下次可直接快速复用。"
                        : "本次契约已通过服务端验证；本地经验记忆当前处于关闭状态。";
            } else {
                aiResponse = BindingAIAdvisor.experienceMemoryEnabled()
                        ? "本次服务端结果已写入本地经验库；拒绝案例只作参考，不会自动当作规则。"
                        : "本次服务端结果已收到；本地经验记忆当前处于关闭状态。";
            }
            lastAiIntent = "";
            lastAiProposalText = "";
        }
        // A successful commit ends the submitted draft. Clear the textbox so the next transaction
        // cannot be accidentally appended to the previous contract text. The active contract remains
        // visible in the status area until replaced or cleared.
        if (wasWaitingForServer && succeeded && hasContract) {
            applyingAiCandidate = true;
            try { input.setValue(""); } finally { applyingAiCandidate = false; }
            result = null;
            lastAiIntent = "";
            lastAiProposalText = "";
            lastAiAnalysis = "";
            lastAiAlternative = "";
            lastSubmittedText = "";
            aiResultPresented = false;
            forgeButton.active = false;
            serverFeedback = (message == null ? "契约已生效。" : message)
                    + " 已自动清空输入框；当前生效契约仍保留显示，下一份束缚会作为独立交易处理。";
            aiResponse = "上一份契约已缔结。输入框已清空，避免把上一份条款带入下一份交易。";
            return;
        }
        // The same button can replace an existing contract; only the in-flight request disables it.
        forgeButton.active = result != null && result.accepted();
    }

    @Override
    public void onClose() {
        if (input != null) draftText = input.getValue() == null ? "" : input.getValue();
        if (backButton != null && aiBusy) {
            backButton.setMessage(Component.literal("返回菜单 · 推演继续"));
        }
        // Keep the retained screen instance alive. AI futures and server replies can update this
        // draft while the player is back in the world; openOrResume() returns to the same instance.
        if (minecraft != null) minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (aiResponse != null && !aiResponse.isBlank()
                && mouseX >= panelX + 18 && mouseX <= panelX + panelW - 18
                && mouseY >= panelY + 326 && mouseY <= panelY + panelH - 30) {
            int visibleLines = aiVisibleLineCount(panelY + 328, panelY + panelH - 30);
            int totalLines = wrappedAiResponse(panelW - 56).size();
            int maxScroll = Math.max(0, totalLines - visibleLines);
            if (maxScroll > 0) {
                int direction = delta > 0 ? -1 : delta < 0 ? 1 : 0;
                if (direction != 0) {
                    aiResponseScroll = Math.max(0, Math.min(maxScroll, aiResponseScroll + direction * 3));
                    return true;
                }
            }
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        int outer = 0xA56A458E;
        int panel = 0xF0090B19;
        int inner = 0xE814172B;
        int cyan = 0xFF91E5FF;
        int violet = 0xFFC7A4FF;
        int gold = 0xFFFFD88A;
        g.fill(panelX - 4, panelY - 4, panelX + panelW + 4, panelY + panelH + 4, outer);
        g.fill(panelX - 2, panelY - 2, panelX + panelW + 2, panelY + panelH + 2, 0xFF050610);
        g.fill(panelX, panelY, panelX + panelW, panelY + panelH, panel);
        drawPixelArcaneFrame(g, panelX, panelY, panelW, panelH);
        // Split header rails leave deliberate breathing room for the central purple crystal.
        g.fill(panelX + 24, panelY + 3, panelX + panelW / 2 - 16, panelY + 4, 0xFF7B6040);
        g.fill(panelX + panelW / 2 + 16, panelY + 3, panelX + panelW - 24, panelY + 4, 0xFF7B6040);
        g.fill(panelX + 14, panelY + 45, panelX + panelW - 14, panelY + 46, 0xFF403458);
        g.fill(panelX + 14, panelY + 148, panelX + panelW - 14, panelY + panelH - 28, inner);
        // The ritual wheel is a subdued engraved watermark; all actionable text is drawn over it.
        g.blit(RITUAL_SEAL_TEXTURE, panelX + panelW - 158, panelY + 166, 132, 132,
                0.0F, 0.0F, 256, 256, 256, 256);
        frame(g, panelX + 14, panelY + 148, panelW - 28, panelH - 176, 0xFF322B49);
        drawRitualCorners(g, panelX + 14, panelY + 148, panelW - 28, panelH - 176, 0xFF7864A8);
        g.drawString(font, "⟡  OUT OF SPEC  /  契约铭文", panelX + 18, panelY + 10, cyan, false);
        g.drawCenteredString(font, "束 缚 刻 印  ·  BINDING OATH", width / 2, panelY + 24, 0xFFF1E9FF);
        drawOathSigil(g, panelX + panelW - 31, panelY + 25, violet, gold);
        g.drawString(font, "以明确的代价换取明确的术式收益", panelX + 18, panelY + 52, gold, false);
        String rightMeta = aiBusy ? "◇ AI 正在后台推演" : waitingForServer ? "◇ 服务端复核中" : "◇ 术式交换仪式";
        g.drawString(font, rightMeta, panelX + panelW - font.width(rightMeta) - 18, panelY + 52,
                aiBusy || waitingForServer ? gold : violet, false);
        g.drawString(font, "可指定单一术式或全部法术；代价、收益与期限最终均由服务端复核。",
                panelX + 18, panelY + 62, 0xFFACA7C8, false);

        // An inset inscription rail replaces EditBox's default gray frame and anchors the input
        // field visually into the ritual instrument instead of looking like a vanilla form.
        if (input != null) {
            g.fill(input.getX() - 4, input.getY() - 3, input.getX() + input.getWidth() + 4,
                    input.getY() + input.getHeight() + 3, 0xF31A1830);
            frame(g, input.getX() - 4, input.getY() - 3, input.getWidth() + 8,
                    input.getHeight() + 6, 0xFF63518C);
            g.fill(input.getX() - 2, input.getY() + input.getHeight() + 1,
                    input.getX() + input.getWidth() + 2, input.getY() + input.getHeight() + 2, cyan);
        }

        super.render(g, mouseX, mouseY, partialTick);

        int contentX = panelX + 22;
        int contentW = panelW - 44;
        g.drawString(font, "当前生效的契约", contentX, panelY + 158, cyan, false);
        drawWrapped(g, "服务器已缔结的当前生效契约（新候选通过前不会替换）", contentX + 130, panelY + 158, contentW - 130, 0xFF9E92C2, 1);
        drawWrapped(g, BindingCastingClient.activeSummary(), contentX + 1, panelY + 171, contentW, 0xFFE9E0FF, 1);
        drawWrapped(g, "期限：一次性 / 限时 / 持续可解除 / 永久不可撤销。永久代价跨死亡与重生保留。",
                contentX, panelY + 187, contentW, 0xFF9B94BA, 1);

        if (result != null) {
            int verdictColor = result.accepted() ? 0xFF82EDB5 : 0xFFFFBD83;
            String verdict = result.accepted() ? "◈ 本地预审通过" : "◈ 本地裁定：" + statusName(result.status());
            g.drawString(font, verdict, contentX, panelY + 204, verdictColor, false);
            BindingContract preview = result.contract();
            drawWrapped(g, "代价  ·  " + preview.sacrificeSummary(), contentX, panelY + 219, contentW, 0xFFFFD09B, 1);
            drawWrapped(g, "收益  ·  " + preview.benefitSummary(), contentX, panelY + 232, contentW, 0xFF9CEAC3, 1);
            String scores = "代价权重 " + BindingContract.format(result.sacrificeScore())
                    + "   /   收益权重 " + BindingContract.format(result.benefitScore())
                    + "   /   交换比 " + (result.benefitScore() <= 0 ? "—" : BindingContract.format(result.ratio()));
            g.drawString(font, font.plainSubstrByWidth(scores, contentW), contentX, panelY + 246, 0xFFC6BEDF, false);
            drawWrapped(g, result.reason(), contentX, panelY + 261, contentW, 0xFFE4DDF5, 2);
            drawWrapped(g, result.suggestion(), contentX, panelY + 284, contentW, 0xFFAFA0D8, 2);
        } else {
            drawWrapped(g, "本地裁定会检查交易是否可执行与是否失衡；未接入的效果会被明确拒绝，不会只写进描述。",
                    contentX, panelY + 204, contentW, 0xFFCCC2E4, 2);
            drawWrapped(g, "高级、复杂或开放式的交换可以先交给 AI 推演，完成后再回来查看候选。", contentX, panelY + 230, contentW, 0xFF9C91C0, 2);
        }

        if (aiResponse != null && !aiResponse.isBlank()) {
            String aiHeading = "✧ 契约顾问 / 推演记录";
            g.drawString(font, aiHeading, contentX, panelY + 314, violet, false);
            String scrollStatus;
            if (aiBusy && aiStartedAtMillis > 0L) {
                scrollStatus = "正在推演 · 已等待 " + formatElapsed(System.currentTimeMillis() - aiStartedAtMillis) + " · 滚轮浏览";
            } else if (aiLastDurationMillis > 0L) {
                scrollStatus = "推演耗时 " + formatElapsed(aiLastDurationMillis) + " · 滚轮浏览";
            } else {
                scrollStatus = "滚轮浏览完整记录";
            }
            int metaMaxWidth = Math.max(0, contentW - font.width(aiHeading) - 12);
            String fittedMeta = font.plainSubstrByWidth(scrollStatus, metaMaxWidth);
            if (!fittedMeta.isEmpty()) {
                g.drawString(font, fittedMeta, contentX + contentW - font.width(fittedMeta), panelY + 314,
                        aiBusy ? gold : 0xFF9D91C4, false);
            }
            drawScrollableAiResponse(g, contentX, panelY + 328, contentW, panelY + panelH - 30);
        }
        int feedbackY = panelY + panelH - 17;
        String feedbackLine = serverFeedback == null ? "" : font.plainSubstrByWidth(serverFeedback, contentW);
        if (!feedbackLine.isEmpty()) g.drawString(font, feedbackLine, contentX, feedbackY, 0xFF9DCDE0, false);
        g.drawString(font, Component.literal("⟐"), panelX + panelW - 15, panelY + panelH - 17, gold, false);

        // Paint an arcane skin over the clickable vanilla widgets. Hit boxes and handlers stay
        // native, but the rendered controls share the same engraved metal / ink-glass language.
        renderEngravedButton(g, judgeButton, mouseX, mouseY, violet, "分析交易");
        renderEngravedButton(g, forgeButton, mouseX, mouseY, 0xFF8DE2B2, "缔结契约");
        renderEngravedButton(g, aiButton, mouseX, mouseY, gold, "AI 推演");
        renderEngravedButton(g, clearInputButton, mouseX, mouseY, violet, "清空输入");
        renderEngravedButton(g, clearContractButton, mouseX, mouseY, 0xFFFFA2A2, "解除契约");
        renderEngravedButton(g, backButton, mouseX, mouseY, cyan, aiBusy || waitingForServer ? "返回菜单 · 请求继续" : "返回 SAO Menu");
        renderEngravedButton(g, closeButton, mouseX, mouseY, violet, "×");
    }

    private void renderEngravedButton(GuiGraphics g, Button button, int mouseX, int mouseY, int accent, String label) {
        if (button == null || !button.visible) return;
        int x = button.getX(), y = button.getY(), w = button.getWidth(), h = button.getHeight();
        boolean hovered = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
        int dim = button.active ? (hovered ? 0xFF33294B : 0xFF171629) : 0xFF10111C;
        g.fill(x, y, x + w, y + h, dim);
        g.fill(x, y, x + w, y + 1, button.active ? accent : 0xFF343044);
        g.fill(x, y + h - 1, x + w, y + h, button.active ? 0xFF554477 : 0xFF292638);
        g.fill(x, y, x + 2, y + h, button.active ? 0xFF8E7CC0 : 0xFF343044);
        g.fill(x + w - 2, y, x + w, y + h, button.active ? 0xFF4E426D : 0xFF242333);
        if (hovered && button.active) {
            g.fill(x + 5, y + 3, x + w - 5, y + 4, 0x887FD8FF);
            g.drawString(font, "◇", x + 4, y + (h - 8) / 2, accent, false);
        }
        String fitted = font.plainSubstrByWidth(label, Math.max(12, w - 18));
        g.drawCenteredString(font, fitted, x + w / 2, y + (h - 8) / 2, button.active ? 0xFFF0EDFF : 0xFF77738F);
    }

    private static void drawRitualCorners(GuiGraphics g, int x, int y, int width, int height, int color) {
        int length = 12;
        int secondary = 0xFF3E365D;
        // Four inward-facing etched brackets mark the ritual workspace without adding clutter.
        g.fill(x + 5, y + 5, x + 5 + length, y + 6, color);
        g.fill(x + 5, y + 5, x + 6, y + 5 + length, color);
        g.fill(x + width - 5 - length, y + 5, x + width - 5, y + 6, color);
        g.fill(x + width - 6, y + 5, x + width - 5, y + 5 + length, color);
        g.fill(x + 5, y + height - 6, x + 5 + length, y + height - 5, secondary);
        g.fill(x + 5, y + height - 5 - length, x + 6, y + height - 5, secondary);
        g.fill(x + width - 5 - length, y + height - 6, x + width - 5, y + height - 5, secondary);
        g.fill(x + width - 6, y + height - 5 - length, x + width - 5, y + height - 5, secondary);
        g.drawString(Minecraft.getInstance().font, "◇", x + width / 2 - 4, y + 4, 0xFF8E78C1, false);
    }

    private static void drawOathSigil(GuiGraphics g, int x, int y, int violet, int gold) {
        g.fill(x - 10, y - 1, x - 3, y + 1, violet);
        g.fill(x + 3, y - 1, x + 10, y + 1, violet);
        g.fill(x - 1, y - 10, x + 1, y - 3, violet);
        g.fill(x - 1, y + 3, x + 1, y + 10, violet);
        g.fill(x - 3, y - 3, x + 3, y + 3, gold);
        g.fill(x - 1, y - 5, x + 1, y + 5, 0xFF25203A);
        g.fill(x - 5, y - 1, x + 5, y + 1, 0xFF25203A);
        g.fill(x - 1, y - 1, x + 1, y + 1, gold);
    }

    /** Symmetric pixel-metal bezel inspired by the supplied SAO-style frame reference. */
    private static void drawPixelArcaneFrame(GuiGraphics g, int x, int y, int width, int height) {
        int shadow = 0xFF100C18;
        int bronze = 0xFF61462F;
        int brass = 0xFF9C7749;
        int highlight = 0xFFC7A365;
        int violet = 0xFF8C6AC5;
        int deepViolet = 0xFF45325F;
        // Continuous rails are kept thin; ornament is concentrated at corners and axis points.
        g.fill(x + 4, y, x + width - 4, y + 1, shadow);
        g.fill(x + 18, y + 1, x + width - 18, y + 2, bronze);
        g.fill(x + 20, y + height - 2, x + width - 20, y + height - 1, bronze);
        g.fill(x + 4, y + height - 1, x + width - 4, y + height, shadow);
        g.fill(x, y + 5, x + 1, y + height - 5, shadow);
        g.fill(x + 1, y + 18, x + 2, y + height - 18, bronze);
        g.fill(x + width - 2, y + 18, x + width - 1, y + height - 18, bronze);
        g.fill(x + width - 1, y + 5, x + width, y + height - 5, shadow);
        g.fill(x + 3, y + 3, x + width - 3, y + 4, deepViolet);
        g.fill(x + 3, y + height - 4, x + width - 3, y + height - 3, deepViolet);

        // Top-left and top-right stepped corner armor.
        g.fill(x + 3, y + 5, x + 19, y + 7, bronze);
        g.fill(x + 5, y + 3, x + 7, y + 20, brass);
        g.fill(x + 7, y + 7, x + 17, y + 9, highlight);
        g.fill(x + 7, y + 9, x + 9, y + 17, brass);
        g.fill(x + 10, y + 11, x + 14, y + 13, violet);
        g.fill(x + width - 19, y + 5, x + width - 3, y + 7, bronze);
        g.fill(x + width - 7, y + 3, x + width - 5, y + 20, brass);
        g.fill(x + width - 17, y + 7, x + width - 7, y + 9, highlight);
        g.fill(x + width - 9, y + 9, x + width - 7, y + 17, brass);
        g.fill(x + width - 14, y + 11, x + width - 10, y + 13, violet);

        // Lower corners mirror the upper geometry exactly.
        g.fill(x + 3, y + height - 7, x + 19, y + height - 5, bronze);
        g.fill(x + 5, y + height - 20, x + 7, y + height - 3, brass);
        g.fill(x + 7, y + height - 9, x + 17, y + height - 7, highlight);
        g.fill(x + 7, y + height - 17, x + 9, y + height - 9, brass);
        g.fill(x + 10, y + height - 13, x + 14, y + height - 11, violet);
        g.fill(x + width - 19, y + height - 7, x + width - 3, y + height - 5, bronze);
        g.fill(x + width - 7, y + height - 20, x + width - 5, y + height - 3, brass);
        g.fill(x + width - 17, y + height - 9, x + width - 7, y + height - 7, highlight);
        g.fill(x + width - 9, y + height - 17, x + width - 7, y + height - 9, brass);
        g.fill(x + width - 14, y + height - 13, x + width - 10, y + height - 11, violet);

        // A quiet central crystal and matching side rivets establish the frame's symmetry.
        g.drawString(Minecraft.getInstance().font, "◆", x + width / 2 - 4, y - 3, violet, false);
        g.fill(x + width / 2 - 7, y + 2, x + width / 2 - 3, y + 3, brass);
        g.fill(x + width / 2 + 3, y + 2, x + width / 2 + 7, y + 3, brass);
        g.drawString(Minecraft.getInstance().font, "◆", x + width / 2 - 4, y + height - 8, brass, false);
        g.fill(x + 1, y + height / 2 - 2, x + 3, y + height / 2 + 2, violet);
        g.fill(x + width - 3, y + height / 2 - 2, x + width - 1, y + height / 2 + 2, violet);
    }

    private static void frame(GuiGraphics g, int x, int y, int width, int height, int color) {
        g.fill(x, y, x + width, y + 1, color);
        g.fill(x, y + height - 1, x + width, y + height, color);
        g.fill(x, y, x + 1, y + height, color);
        g.fill(x + width - 1, y, x + width, y + height, color);
    }

    private void drawScrollableAiResponse(GuiGraphics g, int x, int y, int width, int bottom) {
        int lineHeight = 10;
        int textWidth = Math.max(1, width - 12);
        List<FormattedCharSequence> lines = wrappedAiResponse(textWidth);
        int visibleLines = aiVisibleLineCount(y, bottom);
        int maxScroll = Math.max(0, lines.size() - visibleLines);
        aiResponseScroll = Math.max(0, Math.min(maxScroll, aiResponseScroll));

        g.enableScissor(x, y, x + width, bottom);
        int count = Math.min(visibleLines, lines.size() - aiResponseScroll);
        for (int i = 0; i < count; i++) {
            g.drawString(font, lines.get(aiResponseScroll + i), x, y + i * lineHeight, 0xFFD9C9F4, false);
        }
        g.disableScissor();

        if (maxScroll > 0) {
            int trackX = x + width - 4;
            int trackTop = y + 1;
            int trackBottom = bottom - 1;
            int trackHeight = Math.max(1, trackBottom - trackTop);
            int thumbHeight = Math.max(10, trackHeight * visibleLines / Math.max(1, lines.size()));
            thumbHeight = Math.min(trackHeight, thumbHeight);
            int travel = Math.max(0, trackHeight - thumbHeight);
            int thumbY = trackTop + (maxScroll == 0 ? 0 : travel * aiResponseScroll / maxScroll);
            g.fill(trackX, trackTop, trackX + 2, trackBottom, 0x7A6C5A8D);
            g.fill(trackX, thumbY, trackX + 2, thumbY + thumbHeight, aiBusy ? 0xFFD5B879 : 0xFF9C83D4);
        }
    }

    private List<FormattedCharSequence> wrappedAiResponse(int maxWidth) {
        if (aiResponse == null || aiResponse.isBlank()) return List.of();
        return font.split(Component.literal(aiResponse), Math.max(1, maxWidth));
    }

    private int aiVisibleLineCount(int top, int bottom) {
        return Math.max(1, Math.max(0, bottom - top) / 10);
    }

    private static String formatElapsed(long millis) {
        long seconds = Math.max(0L, millis) / 1000L;
        if (seconds < 60L) return seconds + "s";
        return (seconds / 60L) + "m " + (seconds % 60L) + "s";
    }

    private void drawWrapped(GuiGraphics g, String text, int x, int y, int maxWidth, int color, int maxLines) {
        if (text == null || text.isBlank()) return;
        List<FormattedCharSequence> lines = font.split(Component.literal(text), maxWidth);
        for (int i = 0; i < Math.min(maxLines, lines.size()); i++) {
            g.drawString(font, lines.get(i), x, y + i * 10, color, false);
        }
    }

    private static String stripExperienceHitPrefix(String analysis) {
        String text = analysis == null ? "" : analysis.trim();
        String prefix = "本地经验库快速命中：这条相同目标曾获服务端通过；仍会重新进行本地与服务端裁定。";
        while (text.startsWith(prefix)) text = text.substring(prefix.length()).trim();
        return text;
    }

    private static String statusName(BindingContractJudge.Status status) {
        return switch (status) {
            case ACCEPTED -> "通过";
            case UNRECOGNIZED -> "无法识别";
            case UNSUPPORTED -> "属性尚未接入";
            case OUT_OF_BOUNDS -> "超出边界";
            case NO_TRADE -> "不是有效交换";
            case UNBALANCED -> "交易不公平";
        };
    }
}
