package cn.blockforge.outofspec.binding.client;

import cn.blockforge.outofspec.binding.BindingContractJudge;
import cn.blockforge.outofspec.binding.SpellNameResolver;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;

/**
 * A local, persistent casebook for the binding adviser. This is retrieval/cache memory, not model
 * fine-tuning: successful cases can fast-path an exact repeat, and relevant old cases are included
 * as compact examples when asking the model about a new intent. The authoritative judge/server are
 * still consulted before a contract can be applied.
 */
public final class ContractExperienceStore {
    private static final Gson GSON = new GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create();
    private static final int MAX_CASES = 80;
    private static final int MAX_RELEVANT_CASES = 3;
    private static final String SERVER_ACCEPTED = "SERVER_ACCEPTED";
    private static final String SERVER_REJECTED = "SERVER_REJECTED";
    private static final String LOCAL_REJECTED = "LOCAL_REJECTED";

    public record ExperienceCase(String intent, String normalizedIntent, String contractText,
                                 String analysis, String alternative, String outcome,
                                 String detail, String model, long recordedAt) {}

    private ContractExperienceStore() {}

    public static Path path() {
        return FMLPaths.CONFIGDIR.get().resolve("out_of_spec_binding_experience.json");
    }

    public static String normalizeIntent(String text) {
        if (text == null) return "";
        return text.toLowerCase(Locale.ROOT)
                .replaceAll("\\s+", "")
                .replaceAll("[，。；、！？,.!?;:：\\\"'‘’“”()（）\\[\\]{}《》<>]+", "")
                .trim();
    }

    /** Returns a cached contract only if the newest exact-match adjudication was server accepted. */
    public static synchronized Optional<ExperienceCase> exactAccepted(String intent) {
        String key = normalizeIntent(intent);
        if (key.isBlank()) return Optional.empty();
        List<ExperienceCase> cases = loadCases();
        for (int i = cases.size() - 1; i >= 0; i--) {
            ExperienceCase entry = cases.get(i);
            if (key.equals(entry.normalizedIntent())) {
                return SERVER_ACCEPTED.equals(entry.outcome()) && isSafeExactReplay(intent, entry)
                        ? Optional.of(entry) : Optional.empty();
            }
        }
        return Optional.empty();
    }

    /**
     * Do not replay an accepted cache entry if it contains a spell absent from the current intent,
     * fails the current local judge, or changes the mechanics of an already executable request.
     */
    private static boolean isSafeExactReplay(String intent, ExperienceCase entry) {
        BindingContractJudge.Result cached = BindingContractJudge.evaluate(entry.contractText());
        if (!cached.accepted()) return false;
        Set<String> requestedSpells = SpellNameResolver.findSpellIds(intent);
        Set<String> cachedSpells = SpellNameResolver.findSpellIds(entry.contractText());
        if (!requestedSpells.containsAll(cachedSpells)) return false;
        BindingContractJudge.Result requested = BindingContractJudge.evaluate(intent);
        // Fail closed when the current natural-language request is not parseable. Replaying an old
        // accepted candidate in that case can import an earlier spell, cost, amount or duration.
        return requested.accepted()
                && BindingContractJudge.equivalentAcceptedTrade(intent, entry.contractText());
    }

    /** Relevant, confirmed/provisional prior cases for prompt retrieval, newest tie-break first. */
    public static synchronized List<ExperienceCase> relevant(String intent) {
        String query = normalizeIntent(intent);
        if (query.isBlank()) return List.of();
        Set<String> queryTerms = terms(query);
        List<ScoredCase> scored = new ArrayList<>();
        for (ExperienceCase entry : loadCases()) {
            if (entry.normalizedIntent().isBlank() || entry.normalizedIntent().equals(query)) continue;
            if (!SERVER_ACCEPTED.equals(entry.outcome())
                    && !SERVER_REJECTED.equals(entry.outcome())
                    && !LOCAL_REJECTED.equals(entry.outcome())) continue;
            Set<String> candidateTerms = terms(entry.normalizedIntent());
            if (candidateTerms.isEmpty() || queryTerms.isEmpty()) continue;
            int intersection = 0;
            for (String term : queryTerms) if (candidateTerms.contains(term)) intersection++;
            double score = (double) intersection / Math.max(1, queryTerms.size() + candidateTerms.size() - intersection);
            // Favor recently observed cases modestly without allowing recency to dominate relevance.
            long ageDays = Math.max(0, (System.currentTimeMillis() - entry.recordedAt()) / 86_400_000L);
            score += Math.max(0.0, 0.035 - Math.min(35, ageDays) * 0.001);
            if (score >= 0.055) scored.add(new ScoredCase(entry, score));
        }
        scored.sort(Comparator.comparingDouble(ScoredCase::score).reversed()
                .thenComparingLong(s -> -s.entry().recordedAt()));
        return scored.stream().limit(MAX_RELEVANT_CASES).map(ScoredCase::entry).toList();
    }

    public static synchronized void recordServerOutcome(String intent, String contractText,
                                                        String analysis, String alternative,
                                                        boolean accepted, String detail, String model) {
        record(intent, contractText, analysis, alternative,
                accepted ? SERVER_ACCEPTED : SERVER_REJECTED, detail, model);
    }

    public static synchronized void recordLocalRejection(String intent, String contractText,
                                                         String analysis, String alternative,
                                                         String detail, String model) {
        record(intent, contractText, analysis, alternative, LOCAL_REJECTED, detail, model);
    }

    public static synchronized int caseCount() { return loadCases().size(); }

    public static synchronized int verifiedAcceptedCount() {
        return (int) loadCases().stream().filter(c -> SERVER_ACCEPTED.equals(c.outcome())).count();
    }

    private static void record(String intent, String contractText, String analysis, String alternative,
                               String outcome, String detail, String model) {
        String normalized = normalizeIntent(intent);
        if (normalized.isBlank() || contractText == null || contractText.isBlank()) return;
        List<ExperienceCase> cases = loadCases();
        cases.add(new ExperienceCase(
                clamp(intent, 512), normalized, clamp(contractText, 512), clamp(analysis, 260),
                clamp(alternative, 220), outcome, clamp(detail, 260), clamp(model, 100),
                System.currentTimeMillis()));
        if (cases.size() > MAX_CASES) {
            cases = new ArrayList<>(cases.subList(cases.size() - MAX_CASES, cases.size()));
        }
        writeCases(cases);
    }

    private static List<ExperienceCase> loadCases() {
        Path path = path();
        if (!Files.isRegularFile(path)) return new ArrayList<>();
        try {
            JsonElement rootElement = JsonParser.parseString(Files.readString(path, StandardCharsets.UTF_8));
            if (!rootElement.isJsonObject()) return new ArrayList<>();
            JsonArray array = rootElement.getAsJsonObject().getAsJsonArray("cases");
            if (array == null) return new ArrayList<>();
            List<ExperienceCase> result = new ArrayList<>();
            for (JsonElement element : array) {
                if (!element.isJsonObject()) continue;
                JsonObject object = element.getAsJsonObject();
                String intent = string(object, "intent");
                String normalized = string(object, "normalizedIntent");
                if (normalized.isBlank()) normalized = normalizeIntent(intent);
                String contractText = string(object, "contractText");
                String outcome = string(object, "outcome");
                if (intent.isBlank() || contractText.isBlank() || outcome.isBlank()) continue;
                result.add(new ExperienceCase(intent, normalized, contractText, string(object, "analysis"),
                        string(object, "alternative"), outcome, string(object, "detail"), string(object, "model"),
                        object.has("recordedAt") && object.get("recordedAt").isJsonPrimitive()
                                ? safeLong(object.get("recordedAt").getAsString()) : 0L));
            }
            return result;
        } catch (Exception ex) {
            // Preserve a malformed file for manual inspection and start with an empty in-memory book.
            try {
                Path broken = path.resolveSibling(path.getFileName() + ".broken-" + System.currentTimeMillis());
                Files.copy(path, broken, StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException ignored) {}
            return new ArrayList<>();
        }
    }

    private static void writeCases(List<ExperienceCase> cases) {
        Path path = path();
        try {
            Files.createDirectories(path.getParent());
            JsonObject root = new JsonObject();
            root.addProperty("schemaVersion", 1);
            root.addProperty("description", "Local contract case memory; not model training. Server checks remain authoritative.");
            JsonArray array = new JsonArray();
            for (ExperienceCase entry : cases) {
                JsonObject object = new JsonObject();
                object.addProperty("intent", entry.intent());
                object.addProperty("normalizedIntent", entry.normalizedIntent());
                object.addProperty("contractText", entry.contractText());
                object.addProperty("analysis", entry.analysis());
                object.addProperty("alternative", entry.alternative());
                object.addProperty("outcome", entry.outcome());
                object.addProperty("detail", entry.detail());
                object.addProperty("model", entry.model());
                object.addProperty("recordedAt", entry.recordedAt());
                array.add(object);
            }
            root.add("cases", array);
            Path temp = path.resolveSibling(path.getFileName() + ".tmp");
            Files.writeString(temp, GSON.toJson(root), StandardCharsets.UTF_8);
            try {
                Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException noAtomicMove) {
                Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ignored) {
            // Experience memory is an optimization, never a reason to stop binding adjudication.
        }
    }

    private static Set<String> terms(String text) {
        Set<String> result = new LinkedHashSet<>();
        String normalized = normalizeIntent(text);
        int[] chars = normalized.codePoints().toArray();
        for (int i = 0; i + 1 < chars.length; i++) {
            int a = chars[i], b = chars[i + 1];
            if (isCjk(a) || isCjk(b)) result.add(new String(chars, i, 2));
        }
        // Preserve technical tokens (spell IDs, percentages, English aliases) as distinct retrieval terms.
        java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("[a-z0-9:_%-]{2,}").matcher(normalized);
        while (matcher.find()) result.add(matcher.group());
        return result;
    }

    private static boolean isCjk(int codePoint) {
        return (codePoint >= 0x3400 && codePoint <= 0x9FFF)
                || (codePoint >= 0xF900 && codePoint <= 0xFAFF);
    }

    private static String string(JsonObject object, String key) {
        return object.has(key) && object.get(key).isJsonPrimitive()
                ? object.get(key).getAsString() : "";
    }

    private static long safeLong(String text) {
        try { return Long.parseLong(text); } catch (NumberFormatException ignored) { return 0L; }
    }

    private static String clamp(String text, int max) {
        if (text == null) return "";
        String value = text.trim();
        return value.length() > max ? value.substring(0, max) : value;
    }

    private record ScoredCase(ExperienceCase entry, double score) {}
}
