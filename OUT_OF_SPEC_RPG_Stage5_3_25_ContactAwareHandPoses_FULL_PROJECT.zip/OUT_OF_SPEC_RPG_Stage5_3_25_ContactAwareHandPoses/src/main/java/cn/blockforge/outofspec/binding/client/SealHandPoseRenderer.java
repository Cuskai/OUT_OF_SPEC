package cn.blockforge.outofspec.binding.client;

import cn.blockforge.outofspec.spellcraft.model.BasicSeal;
import cn.blockforge.outofspec.binding.client.handpose.HandSealPoseLibrary;
import cn.blockforge.outofspec.binding.client.handpose.HandSealPoseLibrary.ContactConstraint;
import cn.blockforge.outofspec.binding.client.handpose.HandSealPoseLibrary.ContactPoint;
import cn.blockforge.outofspec.binding.client.handpose.HandSealPoseLibrary.DetailStatus;
import cn.blockforge.outofspec.binding.client.handpose.HandSealPoseLibrary.DigitPose;
import cn.blockforge.outofspec.binding.client.handpose.HandSealPoseLibrary.Element;
import cn.blockforge.outofspec.binding.client.handpose.HandSealPoseLibrary.HandPose;
import cn.blockforge.outofspec.binding.client.handpose.HandSealPoseLibrary.PoseProfile;
import cn.blockforge.outofspec.binding.client.handpose.HandSealPoseLibrary.Relation;
import cn.blockforge.outofspec.binding.client.handpose.HandSealPoseLibrary.Side;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.logging.LogUtils;
import org.slf4j.Logger;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;

import java.util.List;

/**
 * Owns and renders OUT OF SPEC's standalone first-person arm/hand rig. It deliberately does not
 * attach to another mod's PlayerModel or inherit another renderer's arm matrices. The outer arm
 * placement follows the stable vanilla first-person transform; the hand's 180-degree anatomical
 * basis is local to hand_basis, and seal profiles animate only wrist/digit child bones.
 */
public final class SealHandPoseRenderer {
    private static final ModelPart DEFAULT_ARMS = bake(createLayer(false));
    private static final ModelPart SLIM_ARMS = bake(createLayer(true));
    private static final float SEAL_CENTER_INSET = 0.57f;
    /** Enlarge only the hand subtree; the forearm geometry stays at its original dimensions. */
    private static final float HAND_MODEL_SCALE = 1.12f;
    private static final int CONTACT_SOLVER_PASSES = 7;
    private static final float MAX_CONTACT_STEP_WORLD = 0.035f;
    private static final float SEAL_ARM_Y_LIFT = 0.08f;
    private static final float NEUTRAL_HAND_AXIS_TWIST_DEGREES = 180.0f;
    private static final Logger LOGGER = LogUtils.getLogger();
    private static boolean loggedFirstBilateralDraw;

    // OUT OF SPEC owns the ordinary bilateral hand draw. Special two-handed item layouts stay vanilla.
    private static boolean handFrameActive;
    private static AbstractClientPlayer handFramePlayer;

    private SealHandPoseRenderer() {}

    public static void beginFirstPersonHandFrame(AbstractClientPlayer player) {
        Minecraft mc = Minecraft.getInstance();
        handFramePlayer = player;
        boolean specialVanillaLayout = false;
        if (player != null) {
            net.minecraft.world.item.ItemStack main = player.getMainHandItem();
            net.minecraft.world.item.ItemStack off = player.getOffhandItem();
            specialVanillaLayout = main.is(net.minecraft.world.item.Items.FILLED_MAP)
                    || off.is(net.minecraft.world.item.Items.FILLED_MAP)
                    || main.is(net.minecraft.world.item.Items.BOW)
                    || off.is(net.minecraft.world.item.Items.BOW)
                    || main.is(net.minecraft.world.item.Items.CROSSBOW)
                    || off.is(net.minecraft.world.item.Items.CROSSBOW)
                    || main.is(net.minecraft.world.item.Items.TRIDENT)
                    || off.is(net.minecraft.world.item.Items.TRIDENT);
        }
        handFrameActive = player != null && player == mc.player && mc.level != null
                && !player.isInvisible() && !player.isSpectator() && !specialVanillaLayout
                && SealInputDebugClient.shouldRenderFirstPersonHands();
    }

    public static boolean isHandFrameActive() {
        return handFrameActive;
    }

    public static AbstractClientPlayer handFramePlayer() {
        return handFramePlayer;
    }

    /**
     * Emits both hands unconditionally after the vanilla hand/item pass. This does not use a per-side
     * rendered flag: those flags only proved that a method was entered, not that custom vertices were
     * visible in the frame. The pair shares the outer camera pose and its submitted vertices are flushed.
     */
    public static void finishFirstPersonHandFrame(PoseStack poseStack, MultiBufferSource.BufferSource buffers,
                                                   int packedLight, AbstractClientPlayer player,
                                                   float partialTicks, float mainEquipProgress,
                                                   float offEquipProgress) {
        if (!handFrameActive) {
            handFramePlayer = null;
            return;
        }
        try {
            Minecraft mc = Minecraft.getInstance();
            if (player == null || player != handFramePlayer || player != mc.player || mc.level == null
                    || poseStack == null || buffers == null || !SealInputDebugClient.shouldRenderFirstPersonHands()) {
                return;
            }

            float swing = player.getAttackAnim(partialTicks);
            float leftEquip = player.getMainArm() == HumanoidArm.LEFT ? mainEquipProgress : offEquipProgress;
            float rightEquip = player.getMainArm() == HumanoidArm.RIGHT ? mainEquipProgress : offEquipProgress;
            boolean sealLatched = SealInputDebugClient.shouldRenderFirstPersonHandSeals();
            float active = sealLatched
                    ? clamp01(SealInputDebugClient.handPoseActivationProgress()) : 0.0f;
            BasicSeal from = SealInputDebugClient.handPosePreviousSeal();
            BasicSeal to = SealInputDebugClient.handPoseCurrentSeal();
            float transition = ease(SealInputDebugClient.handPoseTransitionProgress());

            // Prepare BOTH rigs before solving contacts. The contact solver can therefore measure both
            // hands in the same camera-space coordinate system and move individual digit bones.
            prepareFirstPersonArm(player, HumanoidArm.LEFT, leftEquip, swing, active, from, to, transition);
            prepareFirstPersonArm(player, HumanoidArm.RIGHT, rightEquip, swing, active, from, to, transition);
            if (active > 0.01f) {
                solveAuthoredContacts(poseStack, player, leftEquip, rightEquip, swing,
                        to, active, active * transition);
            }

            renderPreparedFirstPersonArm(poseStack, buffers, packedLight, player,
                    HumanoidArm.LEFT, leftEquip, swing, active);
            renderPreparedFirstPersonArm(poseStack, buffers, packedLight, player,
                    HumanoidArm.RIGHT, rightEquip, swing, active);
            // Vanilla has already flushed its normal hand/item batch by RETURN; flush our submitted pair.
            buffers.endBatch();
            if (!loggedFirstBilateralDraw) {
                LOGGER.info("[OUT OF SPEC] Standalone bilateral first-person hands rendered (left + right); Punchy is not used.");
                loggedFirstBilateralDraw = true;
            }
        } finally {
            handFrameActive = false;
            handFramePlayer = null;
        }
    }

    private static ModelPart bake(LayerDefinition definition) {
        return definition.bakeRoot();
    }

    private static LayerDefinition createLayer(boolean slim) {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        float rightX = slim ? -2.0f : -3.0f;
        float leftX = -1.0f;
        float armWidth = slim ? 3.0f : 4.0f;
        float armY = slim ? 2.5f : 2.0f;

        PartDefinition rightArm = root.addOrReplaceChild("right_arm", CubeListBuilder.create()
                .texOffs(40, 16).addBox(rightX, -2.0f, -2.0f, armWidth, 12.0f, 4.0f),
                PartPose.offset(-5.0f, armY, 0.0f));
        PartDefinition leftArm = root.addOrReplaceChild("left_arm", CubeListBuilder.create()
                .texOffs(32, 48).addBox(leftX, -2.0f, -2.0f, armWidth, 12.0f, 4.0f),
                PartPose.offset(5.0f, armY, 0.0f));

        // Sleeves are separate model parts, as in PlayerModel, and end just before the palm.
        root.addOrReplaceChild("right_sleeve", CubeListBuilder.create()
                .texOffs(40, 32).addBox(rightX, -2.0f, -2.0f, armWidth, 10.0f, 4.0f,
                        new CubeDeformation(0.25f)), PartPose.offset(-5.0f, armY, 0.0f));
        root.addOrReplaceChild("left_sleeve", CubeListBuilder.create()
                .texOffs(48, 48).addBox(leftX, -2.0f, -2.0f, armWidth, 10.0f, 4.0f,
                        new CubeDeformation(0.25f)), PartPose.offset(5.0f, armY, 0.0f));

        // The wrist joint is attached to the actual arm endpoint (y=10), not to the camera.
        // Use the same base-arm atlas regions as PlayerModel and keep the hand in the arm's
        // native local axis. The handedness argument is intentionally opposite to the arm side
        // because the in-game screenshot showed the previous left/right finger direction reversed. The hand starts at the wrist (Y≈9.25), Z remains centered at 0,
        // and its thickness matches the vanilla arm instead of floating on the camera-facing side.
        // The last in-game screenshot confirmed the handedness was reversed: thumb/finger
        // direction must be exchanged while the physical arm positions and skin atlas stay put.
        addHandRig(rightArm, 40, 24, slim, true, slim ? -0.5f : -1.0f);
        addHandRig(leftArm, 32, 56, slim, false, slim ? 0.5f : 1.0f);
        return LayerDefinition.create(mesh, 64, 64);
    }

    private static void addHandRig(PartDefinition arm, int texU, int texV, boolean slim, boolean mirror, float wristCenterX) {
        // Build separate animation responsibilities:
        // native arm -> seal_hand (attachment/wrist pivot) -> hand_basis (host axis conversion)
        // -> wrist_joint (seal animation) -> palm -> independently articulated digits.
        // The host basis is an explicit coordinate-system conversion, not a guessed per-state twist.
        float palmWidth = slim ? 2.65f : 3.45f;
        float palmLength = 1.35f; // visible length after accounting for the 0.75-unit arm overlap
        float palmDepth = palmWidth * (3.75f / 8.0f); // reference palm depth: 3.5-4 / 8
        float wristWidth = palmWidth * (5.5f / 8.0f);  // reference wrist width: 5-6 / 8
        float wristDepth = palmWidth * (4.5f / 8.0f);  // intermediate step between arm and palm
        PartDefinition hand = arm.addOrReplaceChild("seal_hand", CubeListBuilder.create(),
                PartPose.offset(wristCenterX, 9.25f, 0.0f));
        PartDefinition basis = hand.addOrReplaceChild("hand_basis", CubeListBuilder.create(),
                PartPose.offset(0.0f, 0.0f, 0.0f));
        PartDefinition wrist = basis.addOrReplaceChild("wrist_joint", CubeListBuilder.create(),
                PartPose.offset(0.0f, 0.0f, 0.0f));

        // This cuboid is narrower than the palm and slightly deeper, creating a restrained,
        // stepped wrist-to-palm transition. It belongs to the wrist joint so the whole hand pose
        // rotates as a coherent unit, without rotating the outer arm pivot a second time.
        wrist.addOrReplaceChild("wrist_transition", CubeListBuilder.create()
                        .texOffs(texU, texV)
                        .addBox(-wristWidth / 2.0f, 0.0f, -wristDepth / 2.0f,
                                wristWidth, 0.90f, wristDepth),
                PartPose.offset(0.0f, 0.0f, 0.0f));

        // The palm begins at the end of the native arm. Its front/back thickness is proportional
        // to palm width. All digits are children of this palm bone and therefore inherit its pose.
        PartDefinition palm = wrist.addOrReplaceChild("palm", CubeListBuilder.create()
                        .texOffs(texU, texV)
                        .addBox(-palmWidth / 2.0f, 0.0f, -palmDepth / 2.0f,
                                palmWidth, palmLength, palmDepth),
                PartPose.offset(0.0f, 0.75f, 0.0f));

        // The thumb has its own depth plane and stays independently articulated. Use a
        // thinner, scaled depth so it does not read as a second full-width palm block.
        float outside = mirror ? 1.0f : -1.0f;
        float thumbWidth = slim ? 0.72f : 0.90f;
        float thumbDepth = palmWidth * (2.75f / 8.0f); // reference thumb depth: 2.5-3 / 8
        float thumbTipDepth = thumbDepth * 0.90f;
        float thumbBaseZ = palmWidth * 0.045f;
        PartDefinition thumb = palm.addOrReplaceChild("thumb", CubeListBuilder.create()
                        .texOffs(texU + 7, texV + 1)
                        .addBox(-thumbWidth / 2.0f, 0.0f, -thumbDepth / 2.0f,
                                thumbWidth, 1.50f, thumbDepth),
                PartPose.offset(outside * (palmWidth / 2.0f - 0.12f), -0.13f, thumbBaseZ));
        thumb.addOrReplaceChild("tip", CubeListBuilder.create()
                        .texOffs(texU + 7, texV + 1)
                        .addBox(-(thumbWidth - 0.10f) / 2.0f, 0.0f, -thumbTipDepth / 2.0f,
                                thumbWidth - 0.10f, 0.92f, thumbTipDepth),
                PartPose.offset(outside * 0.18f, 1.10f, 0.0f));

        // Four fingers use a normalized 1.4-1.7 / 8 visible-width range and about 1.95 / 8
        // front/back depth. Slight neutral Z offsets give individual fingers a readable depth
        // order before any seal pose is applied. Each segment remains a separate bone/ModelPart.
        float scaleX = slim ? 0.78f : 1.0f;
        float fingerMirror = mirror ? -1.0f : 1.0f;
        float[] fingerX = {fingerMirror * -1.05f * scaleX, fingerMirror * -0.35f * scaleX,
                fingerMirror * 0.35f * scaleX, fingerMirror * 1.05f * scaleX};
        float[] fingerZ = {palmWidth * 0.04f, 0.0f, palmWidth * 0.015f, -palmWidth * 0.04f};
        String[] fingerNames = {"index", "middle", "ring", "pinky"};
        float[] baseWidths = {0.64f, 0.68f, 0.64f, 0.61f};
        // Each segment is ~12% longer than the previous iteration while its depth stays thin.
        // This adds finger length without returning to the bulky, full-depth finger columns.
        float[] fingerLengths = {1.25f, 1.32f, 1.25f, 1.12f};
        float[] middleLengths = {0.82f, 0.88f, 0.83f, 0.74f};
        float[] tipLengths = {0.61f, 0.65f, 0.61f, 0.54f};
        float fingerDepth = palmWidth * (1.95f / 8.0f); // reference finger depth: 1.7-2.1 / 8
        for (int i = 0; i < fingerNames.length; i++) {
            float width = baseWidths[i] * scaleX;
            // Preserve the skin atlas convention while keeping each finger's cuboid proportions
            // separate from the palm depth. Segment depths taper slightly toward the fingertip.
            int digitU = texU + i * 2;
            addFinger(palm, fingerNames[i], fingerX[i], digitU, texV + 1,
                    fingerLengths[i], middleLengths[i], tipLengths[i], width, fingerDepth, fingerZ[i]);
        }
    }

    private static void addFinger(PartDefinition palm, String name, float x, int texU, int texV,
                                  float baseLength, float middleLength, float tipLength,
                                  float baseWidth, float baseDepth, float baseZ) {
        float middleWidth = Math.max(0.36f, baseWidth - 0.06f);
        float middleDepth = baseDepth * 0.92f;
        float tipWidth = Math.max(0.32f, baseWidth - 0.12f);
        float tipDepth = baseDepth * 0.82f;
        PartDefinition finger = palm.addOrReplaceChild(name, CubeListBuilder.create()
                        .texOffs(texU, texV).addBox(-baseWidth / 2.0f, 0.0f, -baseDepth / 2.0f,
                                baseWidth, baseLength, baseDepth),
                PartPose.offset(x, 0.87f, baseZ));
        PartDefinition middle = finger.addOrReplaceChild("middle_joint", CubeListBuilder.create()
                        .texOffs(texU, texV).addBox(-middleWidth / 2.0f, 0.0f, -middleDepth / 2.0f,
                                middleWidth, middleLength, middleDepth),
                PartPose.offset(0.0f, baseLength - 0.025f, 0.0f));
        middle.addOrReplaceChild("tip", CubeListBuilder.create()
                        .texOffs(texU, texV).addBox(-tipWidth / 2.0f, 0.0f, -tipDepth / 2.0f,
                                tipWidth, tipLength, tipDepth),
                PartPose.offset(0.0f, middleLength - 0.025f, 0.0f));
    }

    /**
     * Draws one standalone first-person arm and its articulated hand. The vanilla-requested side uses
     * the current renderPlayerArm PoseStack; a missing empty-hand side or a bilateral seal pose is drawn
     * at renderHandsWithItems frame end from the common base stack. No third-party arm renderer is used,
     * and vanilla held-item rendering remains active.
     */
    public static void renderFirstPersonArm(PoseStack cameraPoseStack, MultiBufferSource buffers, int packedLight,
                                            AbstractClientPlayer player, HumanoidArm arm,
                                            float equipProgress, float swingProgress) {
        if (cameraPoseStack == null || buffers == null || player == null || arm == null) return;
        boolean sealPoseLatched = SealInputDebugClient.shouldRenderFirstPersonHandSeals();
        float active = sealPoseLatched
                ? clamp01(SealInputDebugClient.handPoseActivationProgress()) : 0.0f;
        prepareFirstPersonArm(player, arm, equipProgress, swingProgress, active,
                SealInputDebugClient.handPosePreviousSeal(),
                SealInputDebugClient.handPoseCurrentSeal(),
                ease(SealInputDebugClient.handPoseTransitionProgress()));
        renderPreparedFirstPersonArm(cameraPoseStack, buffers, packedLight, player,
                arm, equipProgress, swingProgress, active);
    }

    private static boolean prepareFirstPersonArm(AbstractClientPlayer player, HumanoidArm arm,
                                                  float equipProgress, float swingProgress, float active,
                                                  BasicSeal from, BasicSeal to, float transition) {
        Minecraft mc = Minecraft.getInstance();
        if (player == null || player != mc.player || player.isInvisible()
                || !SealInputDebugClient.shouldRenderFirstPersonHands()) return false;

        boolean left = arm == HumanoidArm.LEFT;
        boolean slim = "slim".equals(player.getModelName());
        ModelPart rigRoot = slim ? SLIM_ARMS : DEFAULT_ARMS;
        ModelPart armPart = rigRoot.getChild(left ? "left_arm" : "right_arm");
        ModelPart sleevePart = rigRoot.getChild(left ? "left_sleeve" : "right_sleeve");
        ModelPart hand = armPart.getChild("seal_hand");
        Side physicalSide = left ? Side.LEFT : Side.RIGHT;
        applyHandPose(hand, from, to, transition, active, physicalSide, slim,
                NEUTRAL_HAND_AXIS_TWIST_DEGREES);

        armPart.visible = true;
        armPart.skipDraw = false;
        armPart.xRot = armPart.yRot = armPart.zRot = 0.0f;
        armPart.xScale = armPart.yScale = armPart.zScale = 1.0f;
        sleevePart.visible = true;
        sleevePart.skipDraw = false;
        sleevePart.xRot = sleevePart.yRot = sleevePart.zRot = 0.0f;
        sleevePart.xScale = sleevePart.yScale = sleevePart.zScale = 1.0f;
        return true;
    }

    private static void renderPreparedFirstPersonArm(PoseStack cameraPoseStack, MultiBufferSource buffers,
                                                      int packedLight, AbstractClientPlayer player,
                                                      HumanoidArm arm, float equipProgress,
                                                      float swingProgress, float active) {
        Minecraft mc = Minecraft.getInstance();
        if (cameraPoseStack == null || buffers == null || player == null || arm == null
                || player != mc.player || player.isInvisible()
                || !SealInputDebugClient.shouldRenderFirstPersonHands()) return;

        boolean left = arm == HumanoidArm.LEFT;
        boolean slim = "slim".equals(player.getModelName());
        ModelPart rigRoot = slim ? SLIM_ARMS : DEFAULT_ARMS;
        ModelPart armPart = rigRoot.getChild(left ? "left_arm" : "right_arm");
        ModelPart sleevePart = rigRoot.getChild(left ? "left_sleeve" : "right_sleeve");
        cameraPoseStack.pushPose();
        try {
            applyVanillaFirstPersonArmTransform(cameraPoseStack, arm, equipProgress, swingProgress, active);
            VertexConsumer skin = buffers.getBuffer(RenderType.entityTranslucent(player.getSkinTextureLocation()));
            armPart.render(cameraPoseStack, skin, packedLight, OverlayTexture.NO_OVERLAY);
            sleevePart.render(cameraPoseStack, skin, packedLight, OverlayTexture.NO_OVERLAY);
        } finally {
            cameraPoseStack.popPose();
        }
    }

    /**
     * Solve authored touch/near/interlock/wrap/cover/insert relations in camera space before the
     * two models are drawn. This is a small bounded positional solver, not a physics simulation:
     * each pass moves only the involved finger bone (or the wrist for palm/dorsum contacts), keeps
     * the contact metadata's front/back ambiguity intact, and clamps movement to avoid exploding poses.
     */
    private static void solveAuthoredContacts(PoseStack cameraPoseStack, AbstractClientPlayer player,
                                               float leftEquip, float rightEquip, float swing,
                                               BasicSeal seal, float active, float strength) {
        if (strength <= 0.025f) return;
        PoseProfile profile = HandSealPoseLibrary.get(seal);
        boolean slim = "slim".equals(player.getModelName());
        List<ContactConstraint> constraints = profile.contacts();
        if (constraints.isEmpty()) return;

        for (int pass = 0; pass < CONTACT_SOLVER_PASSES; pass++) {
            boolean movedAny = false;
            for (ContactConstraint c : constraints) {
                if (c.relation() == Relation.CROSSES) continue; // crossing needs a known foreground order.

                float quality = c.status() == DetailStatus.SPECIFIED ? 0.62f : 0.28f;
                float gain = clamp01(strength * quality);
                if (gain <= 0.005f) continue;

                HumanoidArm firstArm = c.firstSide() == Side.LEFT ? HumanoidArm.LEFT : HumanoidArm.RIGHT;
                HumanoidArm secondArm = c.secondSide() == Side.LEFT ? HumanoidArm.LEFT : HumanoidArm.RIGHT;
                float firstEquip = firstArm == HumanoidArm.LEFT ? leftEquip : rightEquip;
                float secondEquip = secondArm == HumanoidArm.LEFT ? leftEquip : rightEquip;

                Vector3f firstPoint = contactPointInCamera(cameraPoseStack, player, firstArm, firstEquip, swing,
                        active, slim, c.firstElement(), c.firstPoint());
                Vector3f secondPoint;
                if (c.relation() == Relation.INSERTS_BETWEEN) {
                    // The inserted digit targets the gap between the receiving thumb and index, not the
                    // thumb's center. The receiving pair remains the anchor; only the inserted digit moves.
                    Vector3f thumbBase = contactPointInCamera(cameraPoseStack, player, secondArm, secondEquip,
                            swing, active, slim, Element.THUMB, ContactPoint.BASE_SEGMENT);
                    Vector3f indexBase = contactPointInCamera(cameraPoseStack, player, secondArm, secondEquip,
                            swing, active, slim, Element.INDEX, ContactPoint.BASE_SEGMENT);
                    secondPoint = thumbBase.add(indexBase).mul(0.5f);
                    Vector3f towardGap = secondPoint.sub(firstPoint, new Vector3f());
                    float distance = towardGap.length();
                    if (distance < 0.002f) continue;
                    float step = Math.min(distance * gain, MAX_CONTACT_STEP_WORLD);
                    towardGap.mul(step / distance);
                    moveElementInCameraSpace(cameraPoseStack, player, firstArm, firstEquip, swing,
                            active, slim, c.firstElement(), towardGap);
                    movedAny = true;
                    continue;
                } else {
                    secondPoint = contactPointInCamera(cameraPoseStack, player, secondArm, secondEquip, swing,
                            active, slim, c.secondElement(), c.secondPoint());
                }

                Vector3f towardSecond = secondPoint.sub(firstPoint, new Vector3f());
                float distance = towardSecond.length();
                float gap = contactTargetGap(slim, c);
                if (distance <= gap + 0.0015f) continue;
                towardSecond.mul(1.0f / distance);
                float totalCorrection = Math.min((distance - gap) * gain, MAX_CONTACT_STEP_WORLD * 2.0f);
                Vector3f halfStep = new Vector3f(towardSecond).mul(totalCorrection * 0.5f);
                moveElementInCameraSpace(cameraPoseStack, player, firstArm, firstEquip, swing,
                        active, slim, c.firstElement(), halfStep);
                moveElementInCameraSpace(cameraPoseStack, player, secondArm, secondEquip, swing,
                        active, slim, c.secondElement(), new Vector3f(halfStep).negate());
                movedAny = true;
            }
            if (!movedAny) break;
        }
    }

    private static float contactTargetGap(boolean slim, ContactConstraint c) {
        float radii = contactRadius(slim, c.firstElement(), c.firstPoint())
                + contactRadius(slim, c.secondElement(), c.secondPoint());
        return switch (c.relation()) {
            case NEAR_OR_TOUCH -> radii + 0.012f;
            case INTERLOCKS -> radii + 0.004f;
            case COVERS -> 0.001f;
            default -> radii;
        };
    }

    private static float contactRadius(boolean slim, Element element, ContactPoint point) {
        if (element == Element.PALM || element == Element.DORSUM) return 0.0f;
        float width;
        if (element == Element.THUMB) {
            width = slim ? 0.72f : 0.90f;
            if (point == ContactPoint.TIP || point == ContactPoint.DISTAL_SEGMENT) width -= 0.10f;
        } else {
            float scaleX = slim ? 0.78f : 1.0f;
            float[] widths = {0.64f, 0.68f, 0.64f, 0.61f};
            int idx = switch (element) {
                case INDEX -> 0;
                case MIDDLE -> 1;
                case RING -> 2;
                case PINKY -> 3;
                default -> 0;
            };
            width = widths[idx] * scaleX;
            if (point == ContactPoint.TIP) width = Math.max(0.32f, width - 0.12f);
            else if (point == ContactPoint.DISTAL_SEGMENT || point == ContactPoint.MIDDLE_JOINT) {
                width = Math.max(0.36f, width - 0.06f);
            }
        }
        return width * HAND_MODEL_SCALE / 32.0f;
    }

    private static Vector3f contactPointInCamera(PoseStack poseStack, AbstractClientPlayer player,
                                                  HumanoidArm arm, float equip, float swing, float active,
                                                  boolean slim, Element element, ContactPoint point) {
        ModelPart root = slim ? SLIM_ARMS : DEFAULT_ARMS;
        ModelPart armPart = root.getChild(arm == HumanoidArm.LEFT ? "left_arm" : "right_arm");
        ModelPart hand = armPart.getChild("seal_hand");
        ModelPart basis = hand.getChild("hand_basis");
        ModelPart wrist = basis.getChild("wrist_joint");
        ModelPart palm = wrist.getChild("palm");
        float palmWidth = slim ? 2.65f : 3.45f;
        float palmLength = 1.35f;
        float palmDepth = palmWidth * (3.75f / 8.0f);
        poseStack.pushPose();
        try {
            applyVanillaFirstPersonArmTransform(poseStack, arm, equip, swing, active);
            armPart.translateAndRotate(poseStack);
            hand.translateAndRotate(poseStack);
            basis.translateAndRotate(poseStack);
            wrist.translateAndRotate(poseStack);
            palm.translateAndRotate(poseStack);

            Vector3f pointLocal;
            if (element == Element.PALM || element == Element.DORSUM) {
                float surfaceZ = element == Element.PALM ? palmDepth * 0.5f : -palmDepth * 0.5f;
                pointLocal = new Vector3f(0.0f, palmLength * 0.5f / 16.0f, surfaceZ / 16.0f);
            } else if (element == Element.THUMB) {
                ModelPart thumb = palm.getChild("thumb");
                thumb.translateAndRotate(poseStack);
                if (point == ContactPoint.TIP || point == ContactPoint.DISTAL_SEGMENT) {
                    ModelPart tip = thumb.getChild("tip");
                    tip.translateAndRotate(poseStack);
                    pointLocal = new Vector3f(0.0f, point == ContactPoint.TIP ? 0.92f / 16.0f : 0.46f / 16.0f, 0.0f);
                } else {
                    pointLocal = new Vector3f(0.0f,
                            point == ContactPoint.MIDDLE_JOINT ? 1.10f / 16.0f : 0.75f / 16.0f, 0.0f);
                }
            } else {
                ModelPart digit = palm.getChild(digitName(element));
                digit.translateAndRotate(poseStack);
                float[] baseLengths = {1.25f, 1.32f, 1.25f, 1.12f};
                float[] middleLengths = {0.82f, 0.88f, 0.83f, 0.74f};
                float[] tipLengths = {0.61f, 0.65f, 0.61f, 0.54f};
                int idx = digitIndex(element);
                if (point == ContactPoint.TIP) {
                    digit.getChild("middle_joint").translateAndRotate(poseStack);
                    digit.getChild("middle_joint").getChild("tip").translateAndRotate(poseStack);
                    pointLocal = new Vector3f(0.0f, tipLengths[idx] / 16.0f, 0.0f);
                } else if (point == ContactPoint.DISTAL_SEGMENT) {
                    digit.getChild("middle_joint").translateAndRotate(poseStack);
                    pointLocal = new Vector3f(0.0f, middleLengths[idx] * 0.5f / 16.0f, 0.0f);
                } else if (point == ContactPoint.MIDDLE_JOINT) {
                    pointLocal = new Vector3f(0.0f, baseLengths[idx] / 16.0f, 0.0f);
                } else {
                    pointLocal = new Vector3f(0.0f, baseLengths[idx] * 0.5f / 16.0f, 0.0f);
                }
            }
            return poseStack.last().pose().transformPosition(pointLocal);
        } finally {
            poseStack.popPose();
        }
    }

    private static void moveElementInCameraSpace(PoseStack poseStack, AbstractClientPlayer player,
                                                  HumanoidArm arm, float equip, float swing, float active,
                                                  boolean slim, Element element, Vector3f deltaWorld) {
        if (deltaWorld.lengthSquared() < 1.0e-10f) return;
        ModelPart root = slim ? SLIM_ARMS : DEFAULT_ARMS;
        ModelPart armPart = root.getChild(arm == HumanoidArm.LEFT ? "left_arm" : "right_arm");
        ModelPart hand = armPart.getChild("seal_hand");
        ModelPart basis = hand.getChild("hand_basis");
        ModelPart wrist = basis.getChild("wrist_joint");
        ModelPart palm = wrist.getChild("palm");
        poseStack.pushPose();
        try {
            applyVanillaFirstPersonArmTransform(poseStack, arm, equip, swing, active);
            armPart.translateAndRotate(poseStack);
            hand.translateAndRotate(poseStack);
            basis.translateAndRotate(poseStack);
            ModelPart movedBone;
            if (element == Element.PALM || element == Element.DORSUM) {
                movedBone = wrist;
            } else {
                wrist.translateAndRotate(poseStack);
                palm.translateAndRotate(poseStack);
                movedBone = palm.getChild(element == Element.THUMB ? "thumb" : digitName(element));
            }
            Matrix4f inverseParent = new Matrix4f(poseStack.last().pose()).invert();
            Vector3f localDelta = inverseParent.transformDirection(new Vector3f(deltaWorld));
            movedBone.x += localDelta.x * 16.0f;
            movedBone.y += localDelta.y * 16.0f;
            movedBone.z += localDelta.z * 16.0f;
        } finally {
            poseStack.popPose();
        }
    }

    private static String digitName(Element element) {
        return switch (element) {
            case INDEX -> "index";
            case MIDDLE -> "middle";
            case RING -> "ring";
            case PINKY -> "pinky";
            default -> throw new IllegalArgumentException("Not a finger element: " + element);
        };
    }

    private static int digitIndex(Element element) {
        return switch (element) {
            case INDEX -> 0;
            case MIDDLE -> 1;
            case RING -> 2;
            case PINKY -> 3;
            default -> throw new IllegalArgumentException("Not a finger element: " + element);
        };
    }

    /** A standalone copy of vanilla's stable empty-arm transform, with a seal-only center blend. */
    private static void applyVanillaFirstPersonArmTransform(PoseStack poseStack, HumanoidArm arm,
                                                             float equipProgress, float swingProgress,
                                                             float sealProgress) {
        float side = arm == HumanoidArm.RIGHT ? 1.0f : -1.0f;
        float rootSwing = Mth.sqrt(Math.max(0.0f, swingProgress));
        float swingX = -0.3f * Mth.sin(rootSwing * (float) Math.PI);
        float swingY = 0.4f * Mth.sin(rootSwing * ((float) Math.PI * 2.0f));
        float swingZ = -0.4f * Mth.sin(swingProgress * (float) Math.PI);
        float centerInset = SEAL_CENTER_INSET * clamp01(sealProgress);
        float lift = SEAL_ARM_Y_LIFT * clamp01(sealProgress);

        // The lateral shift is applied in camera space before the authored arm rotations, so left and
        // right arms move symmetrically toward the screen center without rewriting a bone matrix.
        poseStack.translate(side * (swingX + 0.64000005f - centerInset),
                swingY - 0.6f + equipProgress * -0.6f + lift,
                swingZ - 0.71999997f);
        poseStack.mulPose(Axis.YP.rotationDegrees(side * 45.0f));
        float swingZRotation = Mth.sin(swingProgress * swingProgress * (float) Math.PI);
        float swingYaw = Mth.sin(rootSwing * (float) Math.PI);
        poseStack.mulPose(Axis.YP.rotationDegrees(side * swingYaw * 70.0f));
        poseStack.mulPose(Axis.ZP.rotationDegrees(side * swingZRotation * -20.0f));
        poseStack.translate(side * -1.0f, 3.6f, 3.5f);
        poseStack.mulPose(Axis.ZP.rotationDegrees(side * 120.0f));
        poseStack.mulPose(Axis.XP.rotationDegrees(200.0f));
        poseStack.mulPose(Axis.YP.rotationDegrees(side * -135.0f));
        poseStack.translate(side * 5.6f, 0.0f, 0.0f);
        if (sealProgress > 0.0f) {
            // A small seal-only inward turn is local to this arm's render pose; no locomotion or item
            // state ever adds a corrective quarter-turn to the whole model.
            poseStack.mulPose(Axis.YP.rotationDegrees(side * -14.0f * clamp01(sealProgress)));
        }
    }

    private static void applyHandPose(ModelPart hand, BasicSeal from, BasicSeal to, float t, float active,
                                      Side side, boolean slim, float basisTwistDeg) {
        PoseProfile oldProfile = HandSealPoseLibrary.get(from);
        PoseProfile newProfile = HandSealPoseLibrary.get(to);
        HandPose oldPose = oldProfile.hand(side);
        HandPose newPose = newProfile.hand(side);
        boolean physicalLeft = side == Side.LEFT;

        float wristRoll = lerp(oldPose.wristRollDeg(), newPose.wristRollDeg(), t);
        float wristYaw = lerp(oldPose.wristYawDeg(), newPose.wristYawDeg(), t);
        float wristPitch = lerp(oldPose.wristPitchDeg(), newPose.wristPitchDeg(), t);

        // This model owns its render transform. The hand mount only locates the wrist in local model
        // space; no third-party arm matrix or movement-specific correction is inherited.
        float baseWristX = physicalLeft ? (slim ? 0.5f : 1.0f) : (slim ? -0.5f : -1.0f);
        hand.x = baseWristX;
        hand.y = 9.25f;
        hand.z = 0.0f;
        hand.xRot = 0.0f;
        hand.yRot = 0.0f;
        hand.zRot = 0.0f;

        // Fixed anatomical hand conversion lives on its own bone, independently of arm movement.
        // The 180-degree local basis retains the user-confirmed thumb orientation.
        ModelPart basis = hand.getChild("hand_basis");
        basis.xRot = 0.0f;
        basis.yRot = radians(basisTwistDeg);
        basis.zRot = 0.0f;
        basis.xScale = HAND_MODEL_SCALE;
        basis.yScale = HAND_MODEL_SCALE;
        basis.zScale = HAND_MODEL_SCALE;
        basis.x = 0.0f;
        basis.y = 0.0f;
        basis.z = 0.0f;

        // The wrist joint animates inside the anatomical basis. Contact/pose offsets are local to this
        // joint and cannot alter the outer arm transform.
        ModelPart wrist = basis.getChild("wrist_joint");
        wrist.x = lerp(oldPose.offsetX(), newPose.offsetX(), t) * active;
        wrist.y = lerp(oldPose.offsetY(), newPose.offsetY(), t) * active;
        wrist.z = lerp(oldPose.offsetZ(), newPose.offsetZ(), t) * active;
        wrist.zRot = radians(wristRoll * active);
        wrist.yRot = radians(wristYaw * active);
        wrist.xRot = radians((-8.0f + wristPitch) * active);

        ModelPart palm = wrist.getChild("palm");
        DigitPose thumbPose = blend(oldPose.thumb(), newPose.thumb(), t);
        ModelPart thumb = palm.getChild("thumb");
        float palmWidth = slim ? 2.65f : 3.45f;
        float thumbOutside = physicalLeft ? -1.0f : 1.0f;
        float thumbBaseZ = palmWidth * 0.045f;
        thumb.x = thumbOutside * (palmWidth / 2.0f - 0.12f) + thumbPose.offsetX() * active;
        thumb.y = -0.13f + thumbPose.offsetY() * active;
        thumb.z = thumbBaseZ + thumbPose.offsetZ() * active;
        float neutralThumbSign = physicalLeft ? -1.0f : 1.0f;
        thumb.xRot = radians(lerp(4.3f, thumbPose.baseFlexionDeg(), active));
        thumb.yRot = radians(lerp(neutralThumbSign * 20.4f, thumbPose.yawDeg(), active));
        thumb.zRot = radians(lerp(neutralThumbSign * 15.4f, thumbPose.spreadDeg(), active));
        ModelPart thumbTip = thumb.getChild("tip");
        thumbTip.xRot = radians(lerp(4.3f, thumbPose.middleFlexionDeg(), active));
        thumbTip.yRot = radians((thumbPose.yawDeg() - neutralThumbSign * 20.4f) * 0.25f * active);
        thumbTip.zRot = radians(lerp(neutralThumbSign * 7.2f, thumbPose.tipFlexionDeg(), active));

        float scaleX = slim ? 0.78f : 1.0f;
        float fingerMirror = physicalLeft ? 1.0f : -1.0f;
        setFinger(palm.getChild("index"), blend(oldPose.index(), newPose.index(), t), active,
                13.2f, 11.0f, 8.25f, fingerMirror * -1.05f * scaleX, 0.87f, palmWidth * 0.04f);
        setFinger(palm.getChild("middle"), blend(oldPose.middle(), newPose.middle(), t), active,
                12.4f, 10.7f, 8.0f, fingerMirror * -0.35f * scaleX, 0.87f, 0.0f);
        setFinger(palm.getChild("ring"), blend(oldPose.ring(), newPose.ring(), t), active,
                12.4f, 10.7f, 8.0f, fingerMirror * 0.35f * scaleX, 0.87f, palmWidth * 0.015f);
        setFinger(palm.getChild("pinky"), blend(oldPose.pinky(), newPose.pinky(), t), active,
                14.0f, 12.5f, 9.3f, fingerMirror * 1.05f * scaleX, 0.87f, -palmWidth * 0.04f);
    }

    private static void setFinger(ModelPart finger, DigitPose pose, float active,
                                  float neutralBaseDeg, float neutralMiddleDeg, float neutralTipDeg,
                                  float baseX, float baseY, float baseZ) {
        ModelPart middle = finger.getChild("middle_joint");
        ModelPart tip = middle.getChild("tip");

        finger.x = baseX + pose.offsetX() * active;
        finger.y = baseY + pose.offsetY() * active;
        finger.z = baseZ + pose.offsetZ() * active;
        finger.xRot = radians(lerp(neutralBaseDeg, pose.baseFlexionDeg(), active));
        finger.yRot = radians(pose.yawDeg() * active);
        finger.zRot = radians(pose.spreadDeg() * active);
        middle.xRot = radians(lerp(neutralMiddleDeg, pose.middleFlexionDeg(), active));
        middle.yRot = radians(pose.yawDeg() * 0.65f * active);
        middle.zRot = radians(pose.spreadDeg() * 0.65f * active);
        tip.xRot = radians(lerp(neutralTipDeg, pose.tipFlexionDeg(), active));
        tip.yRot = radians(pose.yawDeg() * 0.35f * active);
        tip.zRot = radians(pose.spreadDeg() * 0.35f * active);
    }

    private static DigitPose blend(DigitPose from, DigitPose to, float t) {
        return new DigitPose(
                lerp(from.baseFlexionDeg(), to.baseFlexionDeg(), t),
                lerp(from.middleFlexionDeg(), to.middleFlexionDeg(), t),
                lerp(from.tipFlexionDeg(), to.tipFlexionDeg(), t),
                lerp(from.spreadDeg(), to.spreadDeg(), t),
                lerp(from.yawDeg(), to.yawDeg(), t),
                lerp(from.offsetX(), to.offsetX(), t),
                lerp(from.offsetY(), to.offsetY(), t),
                lerp(from.offsetZ(), to.offsetZ(), t));
    }

    private static float radians(float degrees) { return (float) Math.toRadians(degrees); }

    private static float clamp01(float value) { return Math.max(0.0f, Math.min(1.0f, value)); }

    private static float ease(float t) { return t * t * (3.0f - 2.0f * t); }
    private static float lerp(float from, float to, float t) { return from + (to - from) * t; }
}
