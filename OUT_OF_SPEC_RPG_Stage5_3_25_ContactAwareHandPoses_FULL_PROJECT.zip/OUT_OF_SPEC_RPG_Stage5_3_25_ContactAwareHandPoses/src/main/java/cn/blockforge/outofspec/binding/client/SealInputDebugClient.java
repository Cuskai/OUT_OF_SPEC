package cn.blockforge.outofspec.binding.client;

import cn.blockforge.outofspec.binding.BindingCastingMod;
import cn.blockforge.outofspec.binding.network.SealCastingNetwork;
import cn.blockforge.outofspec.spellcraft.network.SpellGrowthNetwork;
import cn.blockforge.outofspec.spellcraft.client.SpellGrowthClient;
import cn.blockforge.outofspec.spellcraft.model.BasicSeal;
import cn.blockforge.outofspec.spellcraft.model.CastingRecipeRegistry;
import cn.blockforge.outofspec.spellcraft.model.SealInputSession;
import cn.blockforge.outofspec.spellcraft.model.RealSealCastingRecipes;
import cn.blockforge.outofspec.spellcraft.growth.SpellGrowthCatalog;
import cn.blockforge.outofspec.spellcraft.model.SequenceMatch;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Objects;
import java.util.StringJoiner;
import java.util.UUID;

/** In-game seal HUD and client input adapter for server-authoritative real spell casts. */
@Mod.EventBusSubscriber(modid = BindingCastingMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class SealInputDebugClient {
    private static SealInputSession SESSION = new SealInputSession(
            RealSealCastingRecipes.registryForLearnedAdditions(Set.of()), 800L, Set.of());
    private static long sessionCatalogGeneration = Long.MIN_VALUE;
    private static Set<String> sessionLearnedAdditionIds = Set.of();
    private static int snapshotSyncTicks;
    private static boolean initialSnapshotRequested;
    private static final int PANEL = 0xEF0A0B1B;
    private static final int PANEL_INNER = 0xF0151830;
    private static final int TEXT = 0xFFF0EEFF;
    private static final int ACCENT = 0xFF8DE4FF;
    private static final int ARCANE = 0xFFC29BFF;
    private static final int GOOD = 0xFF8DE6A1;
    private static final int WARN = 0xFFFFD17A;
    private static boolean hudVisible = true;
    private static String completedSummary = "暂无完成记录";
    private static String feedback = "刻印已就绪";
    private static long feedbackAtMillis;
    private static UUID pendingRequestId;
    private static String pendingCastSummary = "";
    private static BasicSeal lastHandSeal = BasicSeal.ZI;
    private static BasicSeal previousHandSeal = BasicSeal.ZI;
    private static long handSealChangedAtMillis;
    private static long handPoseActivationAtMillis;
    private static long handPoseDeactivationAtMillis;
    private static boolean handPoseRigLatched;

    private SealInputDebugClient() {}

    /** Keep the client input trie synchronized with the dynamically generated registry directory. */
    private static synchronized void ensureSessionCurrent() {
        long current = SpellGrowthCatalog.generation();
        Set<String> learned = learnedAdditionalSealIds(SpellGrowthClient.snapshot());
        if (current == sessionCatalogGeneration && learned.equals(sessionLearnedAdditionIds)) return;
        SESSION = new SealInputSession(RealSealCastingRecipes.registryForLearnedAdditions(learned), 800L, learned);
        sessionCatalogGeneration = current;
        sessionLearnedAdditionIds = learned;
        pendingRequestId = null;
        pendingCastSummary = "";
        feedback = "术式刻印同步完成";
        feedbackAtMillis = System.currentTimeMillis();
    }

    private static Set<String> learnedAdditionalSealIds(CompoundTag snapshot) {
        Set<String> learned = new LinkedHashSet<>();
        if (snapshot == null) return Set.of();
        ListTag rows = snapshot.getList("additional_seals", Tag.TAG_COMPOUND);
        for (int i = 0; i < rows.size(); i++) {
            CompoundTag row = rows.getCompound(i);
            if (row.getBoolean("learned")) learned.add(row.getString("id"));
        }
        return Set.copyOf(learned);
    }

    public static boolean isAcceptingSeals() {
        ensureSessionCurrent();
        SealInputSession.Phase phase = SESSION.snapshot().phase();
        return phase == SealInputSession.Phase.BASE_INPUT || phase == SealInputSession.Phase.ADDITIONAL_INPUT;
    }


    /**
     * True whenever the local player should see first-person hands. Unlike the seal-pose predicate,
     * this does not depend on the casting state: both hands are part of the persistent first-person rig.
     */
    public static boolean shouldRenderFirstPersonHands() {
        Minecraft mc = Minecraft.getInstance();
        return mc.player != null && mc.level != null && mc.screen == null
                && mc.options.getCameraType().isFirstPerson();
    }

    /**
     * True while accepting seals and for a short ease-out after completion/cancel. This controls only
     * the articulated seal pose, never whether the permanent first-person hands are drawn.
     */
    public static boolean shouldRenderFirstPersonHandSeals() {
        ensureSessionCurrent();
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.screen != null
                || !mc.options.getCameraType().isFirstPerson()) {
            handPoseRigLatched = false;
            handPoseDeactivationAtMillis = 0L;
            return false;
        }

        long now = System.currentTimeMillis();
        if (isAcceptingSeals()) {
            if (!handPoseRigLatched || handPoseDeactivationAtMillis > 0L) {
                handPoseActivationAtMillis = now;
                handPoseDeactivationAtMillis = 0L;
            }
            handPoseRigLatched = true;
            return true;
        }

        if (!handPoseRigLatched) return false;
        if (handPoseDeactivationAtMillis <= 0L) handPoseDeactivationAtMillis = now;
        if (now - handPoseDeactivationAtMillis < 220L) return true;
        handPoseRigLatched = false;
        handPoseDeactivationAtMillis = 0L;
        return false;
    }

    public static BasicSeal handPoseCurrentSeal() {
        return lastHandSeal == null ? BasicSeal.ZI : lastHandSeal;
    }

    public static BasicSeal handPosePreviousSeal() {
        return previousHandSeal == null ? handPoseCurrentSeal() : previousHandSeal;
    }

    /** Smooth transition duration, normalized to [0,1]. */
    public static float handPoseTransitionProgress() {
        if (handSealChangedAtMillis <= 0L) return 1.0f;
        return Math.max(0.0f, Math.min(1.0f, (System.currentTimeMillis() - handSealChangedAtMillis) / 180.0f));
    }

    /** Blend between vanilla arm pose and the centered hand-sign pose, including a short ease-out. */
    public static float handPoseActivationProgress() {
        long now = System.currentTimeMillis();
        if (handPoseDeactivationAtMillis > 0L) {
            float t = Math.max(0.0f, Math.min(1.0f,
                    (now - handPoseDeactivationAtMillis) / 220.0f));
            float eased = t * t * (3.0f - 2.0f * t);
            return 1.0f - eased;
        }
        if (handPoseActivationAtMillis <= 0L) return handPoseRigLatched ? 1.0f : 0.0f;
        float t = Math.max(0.0f, Math.min(1.0f,
                (now - handPoseActivationAtMillis) / 260.0f));
        return t * t * (3.0f - 2.0f * t);
    }

    /** True while the two-hand seal pose owns both hands, including its short release animation. */
    public static boolean shouldBlockHandItemInteractions() {
        ensureSessionCurrent();
        return isAcceptingSeals() || (handPoseRigLatched && handPoseActivationProgress() > 0.01f);
    }

    /** During a bilateral seal, hands cannot attack, use held items, or pick blocks. */
    @SubscribeEvent
    public static void onInteractionKeyMappingTriggered(InputEvent.InteractionKeyMappingTriggered event) {
        if (!shouldBlockHandItemInteractions()) return;
        if (event.isAttack() || event.isUseItem() || event.isPickBlock()) {
            event.setCanceled(true);
        }
    }

    /** Used by the client-only KeyboardHandler mixin to keep seal presses from triggering other mod keybinds. */
    public static boolean shouldSuppressKeyMapping(InputConstants.Key key) {
        return key != null && isAcceptingSeals()
                && SealInputDebugKeyMappings.isSealKeyCode(key.getValue());
    }

    @SubscribeEvent
    public static void onKeyboardInput(InputEvent.Key event) {
        ensureSessionCurrent();
        BasicSeal seal = SealInputDebugKeyMappings.sealForKeyCode(event.getKey());
        if (seal == null) return;

        long now = System.currentTimeMillis();
        // Always release tracked physical-key state, even if the HUD was hidden or a screen opened.
        if (event.getAction() == GLFW.GLFW_RELEASE) {
            if (SESSION.snapshot().physicallyHeldSeals().contains(seal)) {
                SESSION.release(seal, now);
            }
            return;
        }
        if (event.getAction() != GLFW.GLFW_PRESS) return; // OS key-repeat is not a new seal.

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.screen != null || !isAcceptingSeals()) return;
        previousHandSeal = lastHandSeal;
        lastHandSeal = seal;
        handSealChangedAtMillis = now;
        SealInputSession.Result result = SESSION.press(seal, now);
        handleInputResult(result, now);
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        ensureSessionCurrent();
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        long now = System.currentTimeMillis();
        if (mc.player != null && mc.level != null) {
            snapshotSyncTicks++;
            if (!initialSnapshotRequested || snapshotSyncTicks >= 100) {
                initialSnapshotRequested = true;
                snapshotSyncTicks = 0;
                SpellGrowthNetwork.requestSnapshot();
            }
        } else {
            initialSnapshotRequested = false;
            snapshotSyncTicks = 0;
        }

        // Drain controls while a screen is open so a queued press cannot trigger when the screen closes.
        if (mc.screen != null || mc.player == null || mc.level == null) {
            drainControls();
            if ((mc.player == null || mc.level == null) && SESSION.snapshot().phase() != SealInputSession.Phase.IDLE) {
                SESSION.resetAfterDisconnect(now);
                pendingRequestId = null;
                pendingCastSummary = "";
                setFeedback("世界已卸载：客户端输入和待处理回包标识已清理；迟到的旧响应会被忽略。", now);
            }
            return;
        }

        if (shouldBlockHandItemInteractions() && mc.player.isUsingItem()) {
            mc.player.stopUsingItem();
        }

        if (consume(SealInputDebugKeyMappings.TOGGLE_HUD)) hudVisible = !hudVisible;
        if (consume(SealInputDebugKeyMappings.START)) {
            previousHandSeal = BasicSeal.ZI;
            lastHandSeal = BasicSeal.ZI;
            handSealChangedAtMillis = now;
            SealInputSession.Result result = SESSION.start(now);
            if (result.code() == SealInputSession.Code.STARTED) handPoseActivationAtMillis = now;
            handleInputResult(result, now);
        }
        if (consume(SealInputDebugKeyMappings.CONFIRM)) confirmCurrentStage(now);
        if (consume(SealInputDebugKeyMappings.BACKSPACE)) handleInputResult(SESSION.backspace(now), now);
        if (consume(SealInputDebugKeyMappings.CANCEL)) handleInputResult(SESSION.cancel(now), now);
        if (consume(SealInputDebugKeyMappings.SUBMIT)) submitCastPlan(now);

        SealInputSession.Result timeout = SESSION.tick(now);
        if (timeout.code() == SealInputSession.Code.TIMED_OUT) {
            setFeedback("输入超时：未确认的印序列已清除；不会自动施法。", now);
        }
    }

    /** A small occult casting rail replaces the old multi-line debug box that covered the world. */
    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (!hudVisible || mc.player == null || mc.level == null || mc.screen != null) return;
        GuiGraphics graphics = event.getGuiGraphics();
        SealInputSession.Snapshot snapshot = SESSION.snapshot();
        int screenW = mc.getWindow().getGuiScaledWidth();
        int screenH = mc.getWindow().getGuiScaledHeight();
        boolean active = snapshot.phase() != SealInputSession.Phase.IDLE;
        long now = System.currentTimeMillis();
        if (!active && now - feedbackAtMillis > 2400L) return;

        if (!active) {
            String toast = compact(feedback == null ? "刻印已就绪" : feedback, 44);
            int width = Math.max(126, Math.min(310, mc.font.width(toast) + 34));
            int x = (screenW - width) / 2;
            int y = Math.min(28, Math.max(8, screenH - 28));
            drawOccultPanel(graphics, x, y, width, 20, ARCANE);
            graphics.drawString(mc.font, Component.literal("◇"), x + 7, y + 6, ARCANE, false);
            graphics.drawString(mc.font, Component.literal(toast), x + 20, y + 6, feedbackColor(), false);
            return;
        }

        int width = Math.min(314, screenW - 20);
        int height = 40;
        int x = (screenW - width) / 2;
        int y = Math.min(28, Math.max(8, screenH - height - 8));
        drawOccultPanel(graphics, x, y, width, height, snapshot.phase() == SealInputSession.Phase.CASTING ? GOOD : ACCENT);

        String spell = snapshot.selectedRecipeId() == null ? "术式构筑" : RealSealCastingRecipes.spellName(snapshot.selectedRecipeId());
        graphics.drawString(mc.font, Component.literal("✦  " + compact(spell, 22)), x + 10, y + 7, ACCENT, false);
        String phase = phaseShortName(snapshot.phase());
        int phaseW = mc.font.width(phase);
        graphics.drawString(mc.font, Component.literal(phase), x + width - phaseW - 10, y + 7,
                snapshot.phase() == SealInputSession.Phase.CASTING ? GOOD : ARCANE, false);

        String sequence = sequenceName(snapshot.currentSequence());
        String additions = snapshot.selectedAdditionalSealIds().isEmpty() ? "" : "  ·  追加 " + snapshot.selectedAdditionalSealIds().size();
        int maxSequenceWidth = width - 22;
        String line = compact((sequence.equals("（空）") ? "等待基础印" : sequence) + additions, Math.max(12, maxSequenceWidth / 6));
        graphics.drawString(mc.font, Component.literal(line), x + 10, y + 22, TEXT, false);
        // The rail has only two persistent rows. A recent feedback toast is transient and never
        // expands the HUD over the center of the world.
        if (now - feedbackAtMillis <= 1150L && feedback != null && !feedback.isBlank()) {
            String toast = compact(feedback, 44);
            int toastWidth = Math.min(290, mc.font.width(toast) + 24);
            int toastX = (screenW - toastWidth) / 2;
            int toastY = y + height + 5;
            graphics.fill(toastX - 1, toastY - 1, toastX + toastWidth + 1, toastY + 15, 0xA56B4E91);
            graphics.fill(toastX, toastY, toastX + toastWidth, toastY + 14, 0xE6080A18);
            graphics.drawString(mc.font, Component.literal(toast), toastX + 8, toastY + 3,
                    feedbackColor() == WARN ? WARN : MUTED_TONE, false);
        }
    }

    private static final int MUTED_TONE = 0xFFAAA5C6;

    private static void drawOccultPanel(GuiGraphics graphics, int x, int y, int width, int height, int accent) {
        // Compact top-of-screen rail: stepped metal corners, a restrained brass rim and a single
        // inner sigil line. The same ink / violet / antique-gold language is used by the full screens.
        graphics.fill(x - 2, y - 2, x + width + 2, y + height + 2, 0x7A14101F);
        graphics.fill(x, y, x + width, y + height, 0xFF070915);
        graphics.fill(x + 2, y + 2, x + width - 2, y + height - 2, PANEL_INNER);
        graphics.fill(x + 7, y + 1, x + width - 7, y + 2, 0xFF5C4937);
        graphics.fill(x + 12, y + 2, x + width - 12, y + 3, 0xFF9B7A4D);
        graphics.fill(x + 7, y + height - 2, x + width - 7, y + height - 1, 0xFF4B3C32);
        graphics.fill(x + 5, y + 5, x + 6, y + height - 5, 0xFF6E5B91);
        graphics.fill(x + width - 6, y + 5, x + width - 5, y + height - 5, 0xFF6E5B91);
        graphics.fill(x + 12, y + 4, x + width - 12, y + 5, accent & 0x88FFFFFF);
        // Small stair-step corner plates echo a pixel-forged frame without widening the HUD.
        graphics.fill(x + 2, y + 3, x + 9, y + 4, 0xFFC19A61);
        graphics.fill(x + 2, y + 3, x + 4, y + 9, 0xFFC19A61);
        graphics.fill(x + 4, y + 5, x + 8, y + 6, 0xFF75563C);
        graphics.fill(x + width - 9, y + 3, x + width - 2, y + 4, 0xFFC19A61);
        graphics.fill(x + width - 4, y + 3, x + width - 2, y + 9, 0xFFC19A61);
        graphics.fill(x + width - 8, y + 5, x + width - 4, y + 6, 0xFF75563C);
        graphics.fill(x + 2, y + height - 4, x + 9, y + height - 3, 0xFF75563C);
        graphics.fill(x + 2, y + height - 9, x + 4, y + height - 3, 0xFF75563C);
        graphics.fill(x + width - 9, y + height - 4, x + width - 2, y + height - 3, 0xFF75563C);
        graphics.fill(x + width - 4, y + height - 9, x + width - 2, y + height - 3, 0xFF75563C);
        graphics.fill(x + 6, y + 6, x + 7, y + 7, 0xFFE0C17A);
        graphics.fill(x + width - 7, y + 6, x + width - 6, y + 7, 0xFFE0C17A);
    }

    private static void confirmCurrentStage(long now) {
        SealInputSession.Snapshot before = SESSION.snapshot();
        if (before.phase() == SealInputSession.Phase.BASE_INPUT) {
            handleInputResult(SESSION.confirmBase(now), now);
        } else if (before.phase() == SealInputSession.Phase.ADDITIONAL_INPUT) {
            if (before.currentSequence().isEmpty()) {
                setFeedback("追加印阶段：按 Enter 提交到服务端校验并施放；也可以先输入追加印并按 O。", now);
            } else {
                handleInputResult(SESSION.confirmAdditional(now), now);
            }
        } else {
            setFeedback("现在不在可确认的输入阶段。按 K 开始新的测试会话。", now);
        }
    }

    private static void submitCastPlan(long now) {
        SealInputSession.Snapshot before = SESSION.snapshot();
        SealInputSession.Result result = SESSION.submitCast(now);
        if (result.code() != SealInputSession.Code.CAST_REQUEST_READY || result.castRequest() == null) {
            handleInputResult(result, now);
            return;
        }
        pendingRequestId = result.castRequest().requestId();
        String recipeId = before.selectedRecipeId();
        List<String> additions = before.selectedAdditionalSealIds();
        StringJoiner selected = new StringJoiner(" + ");
        for (String additionId : additions) selected.add(RealSealCastingRecipes.additionName(additionId));
        String additionsText = additions.isEmpty() ? "无追加印" : selected.toString();
        pendingCastSummary = RealSealCastingRecipes.spellName(recipeId) + " / " + additionsText;
        try {
            SealCastingNetwork.submit(result.castRequest());
            setFeedback("已提交服务器复核并请求真实起手；等待 Iron's Spells 返回结果。", now);
        } catch (RuntimeException sendFailure) {
            UUID rejectedId = pendingRequestId;
            pendingRequestId = null;
            pendingCastSummary = "";
            handleInputResult(SESSION.onValidationResult(rejectedId, false, true, now), now);
            setFeedback("无法发送施法请求：" + compact(safeMessage(sendFailure), 100), now);
        }
    }

    /** Server response. Stale responses cannot modify a later input session. */
    public static void receiveCastResult(UUID requestId, boolean accepted, boolean recoverable,
                                         boolean terminal, String spellId, String message) {
        if (requestId == null || pendingRequestId == null || !pendingRequestId.equals(requestId)) return;
        SealInputSession.Snapshot snapshot = SESSION.snapshot();
        if (snapshot.pendingRequestId() == null || !snapshot.pendingRequestId().equals(requestId)) return;
        long now = System.currentTimeMillis();
        if (terminal) {
            if (snapshot.phase() != SealInputSession.Phase.CASTING) return;
            SealInputSession.Result ended = SESSION.onCastEnded(requestId, now);
            if (ended.code() == SealInputSession.Code.STALE_CAST_END_IGNORED) return;
            completedSummary = pendingCastSummary + (accepted ? " · 已由真实法术执行器释放" : " · 起手后被中断/取消");
            pendingRequestId = null;
            pendingCastSummary = "";
            setFeedback(message == null || message.isBlank() ? (accepted ? "真实法术已执行。" : "本次施法已结束。") : compact(message, 160), now);
            return;
        }
        if (snapshot.phase() != SealInputSession.Phase.VALIDATING) return;
        SealInputSession.Result validation = SESSION.onValidationResult(requestId, accepted, recoverable, now);
        if (validation.code() == SealInputSession.Code.STALE_VALIDATION_IGNORED) return;
        if (accepted) {
            setFeedback((message == null || message.isBlank() ? "服务器已接受施法方案。" : message)
                    + " 正在等待真实法术的释放/中断结果。", now);
        } else {
            pendingRequestId = null;
            pendingCastSummary = "";
            setFeedback(message == null || message.isBlank() ? "服务器拒绝本次施法方案。" : compact(message, 160), now);
        }
    }

    private static String safeMessage(Throwable throwable) {
        String message = throwable.getMessage();
        if (message == null || message.isBlank()) return throwable.getClass().getSimpleName();
        return message;
    }

    private static void handleInputResult(SealInputSession.Result result, long now) {
        Objects.requireNonNull(result, "result");
        String message = switch (result.code()) {
            case STARTED -> "基础术式输入已开始。请按 Z/X/C/V/B/N/F/G/H/R/T/Y 输入基本印。";
            case BUSY -> "当前已有输入会话；完成、取消或退出世界后再开始。";
            case INPUT_ACCEPTED -> "已记录 " + lastSealName(result.snapshot()) + "。";
            case INPUT_ACCEPTED_AFTER_TIMEOUT_RESET -> "上一段输入已超时；本次按键已作为新序列的第一枚印记录。";
            case UNKNOWN_SEQUENCE -> "未匹配：当前序列已清除。请检查配方和输入顺序。";
            case SEQUENCE_TOO_LONG -> "序列超过安全长度，已清除。";
            case REPEAT_KEYDOWN_IGNORED -> "已忽略同一按键的重复按下事件。";
            case KEY_RELEASED, UNTRACKED_KEYUP_IGNORED -> feedback;
            case IGNORED_WRONG_PHASE -> "当前阶段不接受此操作。";
            case BACKSPACE_APPLIED -> "已退格。";
            case NOTHING_TO_DELETE -> "没有可删除的印或追加印。";
            case BASE_CONFIRMED -> "基础术式已锁定：" + RealSealCastingRecipes.spellName(result.snapshot().selectedRecipeId()) + "。现在可选追加印，或按 Enter 请求真实施法。";
            case NO_EXACT_BASE_MATCH -> "当前印序列尚无完整基础术式匹配；继续输入或修正序列。";
            case NO_BASE_SEQUENCE -> "请先输入基础术式的印序列。";
            case ADDITION_CONFIRMED -> "已添加追加印：" + (result.snapshot().selectedAdditionalSealIds().isEmpty() ? "（读取失败）" : RealSealCastingRecipes.additionName(result.snapshot().selectedAdditionalSealIds().get(result.snapshot().selectedAdditionalSealIds().size() - 1))) + "。";
            case NO_EXACT_ADDITIONAL_MATCH -> "当前序列只是追加印前缀，或没有完整匹配。";
            case NO_ADDITIONAL_SEQUENCE -> "没有待确认的追加印序列。";
            case ADDITION_CONFLICT -> "追加印与当前法术或已选追加印冲突；没有加入该效果。";
            case ADDITION_OCCURRENCE_LIMIT -> "该追加印已达到本次施法的重复次数上限。";
            case CAST_REQUEST_READY -> "施法请求已生成，正准备发送到服务器。";
            case CURRENT_SEQUENCE_NOT_CONFIRMED -> "当前追加印序列尚未确认；按 O 确认或退格修改。";
            case REQUIRED_ADDITION_MISSING -> "缺少必需的追加印，不能提交。";
            case CANCELED -> "未提交的施法草稿已取消；没有施放真实法术。";
            case TOO_LATE_TO_CANCEL -> "请求已提交或施法生命周期已开始，不能仅靠本地取消撤销。";
            case VALIDATION_ACCEPTED -> "服务器已接受施法方案。";
            case VALIDATION_REJECTED_RECOVERABLE -> "服务器拒绝请求，可以修改追加印后重试。";
            case VALIDATION_REJECTED_TERMINAL -> "服务器拒绝请求，输入会话已清空。";
            case STALE_VALIDATION_IGNORED -> "已忽略过期验证响应。";
            case CAST_FINISHED -> "施法会话已结束。";
            case STALE_CAST_END_IGNORED -> "已忽略过期的施法结束事件。";
            case INPUT_RESTARTED_AFTER_TIMEOUT -> "上一段输入已超时，已重启当前序列。";
            case TIMED_OUT -> "输入超时：未确认的印序列已清除；不会自动施法。";
            case NO_TIMEOUT -> feedback;
        };
        setFeedback(message, now);
    }

    private static String lastSealName(SealInputSession.Snapshot snapshot) {
        if (snapshot.currentSequence().isEmpty()) return "基本印";
        return sealName(snapshot.currentSequence().get(snapshot.currentSequence().size() - 1));
    }

    private static List<String> buildHudLines() {
        SealInputSession.Snapshot snapshot = SESSION.snapshot();
        List<String> lines = new ArrayList<>();
        lines.add("OUT OF SPEC · 结印施法 HUD");
        lines.add("状态：" + phaseName(snapshot.phase()) + "    间隔超时：800ms");
        lines.add("操作：" + keyLabel(SealInputDebugKeyMappings.START) + " 开始 | "
                + keyLabel(SealInputDebugKeyMappings.CONFIRM) + " 确认 | "
                + keyLabel(SealInputDebugKeyMappings.SUBMIT) + " 提交/施放 | "
                + keyLabel(SealInputDebugKeyMappings.BACKSPACE) + " 退格 | "
                + keyLabel(SealInputDebugKeyMappings.CANCEL) + " 取消 | "
                + keyLabel(SealInputDebugKeyMappings.TOGGLE_HUD) + " 显示/隐藏");
        StringJoiner sealKeys = new StringJoiner("  ");
        for (BasicSeal seal : BasicSeal.values()) {
            net.minecraft.client.KeyMapping mapping = SealInputDebugKeyMappings.sealMappings().get(seal);
            sealKeys.add(keyLabel(mapping) + sealName(seal));
        }
        lines.add("基本印：" + sealKeys);
        lines.add("当前输入：" + sequenceName(snapshot.currentSequence()));
        lines.add("匹配：" + matchSummary(snapshot));
        if (snapshot.selectedRecipeId() != null) {
            lines.add("已选术式：" + RealSealCastingRecipes.spellName(snapshot.selectedRecipeId()));
        }
        if (!snapshot.selectedAdditionalSealIds().isEmpty()) {
            StringJoiner joiner = new StringJoiner(" + ");
            for (String id : snapshot.selectedAdditionalSealIds()) joiner.add(RealSealCastingRecipes.additionName(id));
            lines.add("已选追加印：" + joiner);
            for (String id : snapshot.selectedAdditionalSealIds()) lines.add("  · " + RealSealCastingRecipes.additionPreview(id));
        }
        lines.add("上次完成：" + completedSummary);
        lines.add("反馈：" + compact(feedback, 100));
        lines.add("当前真实配方：" + RealSealCastingRecipes.registeredRecipeCount() + " 个已启用注册术式；四印码由注册表自动生成。");
        lines.add("追加印：F 法术强度×1.20；FG 高阶法术强度×1.35（二选一）。");
        lines.add("范围/分裂/弹道等效果尚未注册真实执行器，不会显示为可选追加印。");
        return lines;
    }

    private static String matchSummary(SealInputSession.Snapshot snapshot) {
        if (snapshot.phase() == SealInputSession.Phase.IDLE) return "尚未开始，按 K";
        if (snapshot.phase() == SealInputSession.Phase.VALIDATING) return "已提交，等待服务端复核";
        if (snapshot.phase() == SealInputSession.Phase.CASTING) return "服务端已接受，等待真实释放/打断";
        SequenceMatch match = snapshot.currentMatch();
        if (match == null) return snapshot.phase() == SealInputSession.Phase.ADDITIONAL_INPUT
                ? "追加印可选；按 Enter 请求服务端起手" : "输入配方序列";
        List<String> exact = match.exactIds();
        List<String> longer = match.longerPrefixIds();
        String exactName = exact.isEmpty() ? "" : (snapshot.phase() == SealInputSession.Phase.BASE_INPUT
                ? RealSealCastingRecipes.spellName(exact.get(0)) : RealSealCastingRecipes.additionName(exact.get(0)));
        List<String> longerNames = new ArrayList<>();
        for (String id : longer) longerNames.add(snapshot.phase() == SealInputSession.Phase.BASE_INPUT
                ? RealSealCastingRecipes.spellName(id) : RealSealCastingRecipes.additionName(id));
        if (!exactName.isEmpty() && !longerNames.isEmpty()) return exactName + " 已完整匹配；继续输入可选 " + String.join(" / ", longerNames);
        if (!exactName.isEmpty()) return exactName + "（完整匹配）";
        if (!longerNames.isEmpty()) return "序列前缀；继续输入：" + String.join(" / ", longerNames);
        return "无匹配";
    }

    private static String phaseShortName(SealInputSession.Phase phase) {
        return switch (phase) {
            case IDLE -> "待机";
            case BASE_INPUT -> "基础结印";
            case ADDITIONAL_INPUT -> "追加印";
            case VALIDATING -> "裁定中";
            case CASTING -> "术式释放";
        };
    }

    private static String compact(String text, int maxChars) {
        if (text == null || text.isBlank()) return "";
        int max = Math.max(4, maxChars);
        return text.length() <= max ? text : text.substring(0, max - 1) + "…";
    }

    private static String phaseName(SealInputSession.Phase phase) {
        return switch (phase) {
            case IDLE -> "空闲";
            case BASE_INPUT -> "基础术式输入";
            case ADDITIONAL_INPUT -> "追加印输入";
            case VALIDATING -> "等待服务端验证";
            case CASTING -> "真实法术施法中";
        };
    }

    private static String sequenceName(List<BasicSeal> sequence) {
        if (sequence.isEmpty()) return "（空）";
        StringJoiner joiner = new StringJoiner(" → ");
        for (BasicSeal seal : sequence) joiner.add(sealName(seal));
        return joiner.toString();
    }

    private static String sealName(BasicSeal seal) {
        return switch (seal) {
            case ZI -> "子";
            case CHOU -> "丑";
            case YIN -> "寅";
            case MAO -> "卯";
            case CHEN -> "辰";
            case SI -> "巳";
            case WU -> "午";
            case WEI -> "未";
            case SHEN -> "申";
            case YOU -> "酉";
            case XU -> "戌";
            case HAI -> "亥";
        };
    }


    private static int feedbackColor() {
        String current = feedback.toLowerCase(java.util.Locale.ROOT);
        if (current.contains("拒绝") || current.contains("冲突") || current.contains("失败")
                || current.contains("不能") || current.contains("不足") || current.contains("中断")) return WARN;
        if (current.contains("已记录") || current.contains("已锁定") || current.contains("已添加")
                || current.contains("服务器已接受") || current.contains("真实法术已执行")) return GOOD;
        return TEXT;
    }

    private static void setFeedback(String text, long now) {
        feedback = text == null || text.isBlank() ? "无反馈" : text;
        feedbackAtMillis = now;
    }

    private static String keyLabel(net.minecraft.client.KeyMapping mapping) {
        return mapping.getTranslatedKeyMessage().getString();
    }

    private static boolean consume(net.minecraft.client.KeyMapping mapping) {
        boolean consumed = false;
        while (mapping.consumeClick()) consumed = true;
        return consumed;
    }

    private static void drainControls() {
        consume(SealInputDebugKeyMappings.START);
        consume(SealInputDebugKeyMappings.CONFIRM);
        consume(SealInputDebugKeyMappings.SUBMIT);
        consume(SealInputDebugKeyMappings.BACKSPACE);
        consume(SealInputDebugKeyMappings.CANCEL);
        consume(SealInputDebugKeyMappings.TOGGLE_HUD);
    }
}
