package cn.blockforge.outofspec.binding.client;

import cn.blockforge.outofspec.binding.BindingCastingMod;
import cn.blockforge.outofspec.spellcraft.model.BasicSeal;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.api.distmarker.Dist;
import org.lwjgl.glfw.GLFW;

import java.util.EnumMap;
import java.util.Map;

/** Rebindable controls for the in-game seal-casting HUD. */
@Mod.EventBusSubscriber(modid = BindingCastingMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class SealInputDebugKeyMappings {
    private static final String CATEGORY = "key.categories.out_of_spec_binding";

    public static final KeyMapping START = key("seal_start", GLFW.GLFW_KEY_K);
    public static final KeyMapping CONFIRM = key("seal_confirm", GLFW.GLFW_KEY_O);
    public static final KeyMapping SUBMIT = key("seal_submit", GLFW.GLFW_KEY_ENTER);
    public static final KeyMapping BACKSPACE = key("seal_backspace", GLFW.GLFW_KEY_BACKSPACE);
    public static final KeyMapping CANCEL = key("seal_cancel", GLFW.GLFW_KEY_P);
    public static final KeyMapping TOGGLE_HUD = key("seal_toggle_hud", GLFW.GLFW_KEY_F8);
    private static final EnumMap<BasicSeal, KeyMapping> SEALS = new EnumMap<>(BasicSeal.class);

    static {
        for (BasicSeal seal : BasicSeal.values()) {
            SEALS.put(seal, key("seal_" + seal.id(), defaultKey(seal.suggestedDefaultKey())));
        }
    }

    private SealInputDebugKeyMappings() {}

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent event) {
        event.register(START);
        event.register(CONFIRM);
        event.register(SUBMIT);
        event.register(BACKSPACE);
        event.register(CANCEL);
        event.register(TOGGLE_HUD);
        SEALS.values().forEach(event::register);
    }

    public static Map<BasicSeal, KeyMapping> sealMappings() { return Map.copyOf(SEALS); }

    public static BasicSeal sealForKeyCode(int keyCode) {
        for (Map.Entry<BasicSeal, KeyMapping> entry : SEALS.entrySet()) {
            if (!entry.getValue().isUnbound() && entry.getValue().getKey().getValue() == keyCode) return entry.getKey();
        }
        return null;
    }

    public static boolean isSealKeyCode(int keyCode) { return sealForKeyCode(keyCode) != null; }

    private static KeyMapping key(String suffix, int keyCode) {
        return new KeyMapping("key.out_of_spec_binding." + suffix, InputConstants.Type.KEYSYM, keyCode, CATEGORY);
    }

    private static int defaultKey(char key) {
        return switch (key) {
            case 'Z' -> GLFW.GLFW_KEY_Z;
            case 'X' -> GLFW.GLFW_KEY_X;
            case 'C' -> GLFW.GLFW_KEY_C;
            case 'V' -> GLFW.GLFW_KEY_V;
            case 'B' -> GLFW.GLFW_KEY_B;
            case 'N' -> GLFW.GLFW_KEY_N;
            case 'F' -> GLFW.GLFW_KEY_F;
            case 'G' -> GLFW.GLFW_KEY_G;
            case 'H' -> GLFW.GLFW_KEY_H;
            case 'R' -> GLFW.GLFW_KEY_R;
            case 'T' -> GLFW.GLFW_KEY_T;
            case 'Y' -> GLFW.GLFW_KEY_Y;
            default -> GLFW.GLFW_KEY_UNKNOWN;
        };
    }
}
