package cn.blockforge.outofspec.binding.client.handpose;

import cn.blockforge.outofspec.spellcraft.model.BasicSeal;

import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Data-only v1.0 pose library for the twelve Naruto hand seals.
 *
 * <p>All side labels are the caster's anatomical left/right, never the viewer's screen-left/right.
 * Angles are authored in degrees; offsets are local Minecraft model units relative to the neutral
 * rig. Contact constraints document intended relationships for audits and future calibration. They
 * are not a collision solver: the rendered pose still needs in-game visual tuning against the user's
 * front/side/oblique references.</p>
 */
public final class HandSealPoseLibrary {
    private HandSealPoseLibrary() {}

    public enum Side { LEFT, RIGHT }

    /** Anatomical rig elements used by both finger poses and relation metadata. */
    public enum Element { THUMB, INDEX, MIDDLE, RING, PINKY, PALM, DORSUM }

    /** The joint/region at which a relation is intended. */
    public enum ContactPoint { TIP, DISTAL_SEGMENT, MIDDLE_JOINT, BASE_SEGMENT, PALM_SURFACE, DORSAL_SURFACE }

    public enum Relation { TOUCH, NEAR_OR_TOUCH, INSERTS_BETWEEN, WRAPS, COVERS, INTERLOCKS, CROSSES }

    /** SPECIFIED means the user's written description establishes this; otherwise a view is needed. */
    public enum DetailStatus { SPECIFIED, NEEDS_REFERENCE }

    /**
     * One digit's independent three-segment articulation plus local orientation and pivot offset.
     * Flexion is measured around the local X axis; spread around Z; yaw around Y. For the thumb,
     * the three flexion values map to the thumb base X rotation, distal X rotation and distal Z
     * rotation respectively because this rig has two thumb cuboids but three useful rotation axes.
     */
    public record DigitPose(
            float baseFlexionDeg,
            float middleFlexionDeg,
            float tipFlexionDeg,
            float spreadDeg,
            float yawDeg,
            float offsetX,
            float offsetY,
            float offsetZ) {
        public DigitPose {
            finite(baseFlexionDeg, "baseFlexionDeg");
            finite(middleFlexionDeg, "middleFlexionDeg");
            finite(tipFlexionDeg, "tipFlexionDeg");
            finite(spreadDeg, "spreadDeg");
            finite(yawDeg, "yawDeg");
            finite(offsetX, "offsetX");
            finite(offsetY, "offsetY");
            finite(offsetZ, "offsetZ");
        }
    }

    /** Wrist rotations are local to the standalone hand rig and are applied only while a seal pose is active. */
    public record HandPose(
            float wristRollDeg,
            float wristYawDeg,
            float wristPitchDeg,
            float offsetX,
            float offsetY,
            float offsetZ,
            DigitPose thumb,
            DigitPose index,
            DigitPose middle,
            DigitPose ring,
            DigitPose pinky) {
        public HandPose {
            finite(wristRollDeg, "wristRollDeg");
            finite(wristYawDeg, "wristYawDeg");
            finite(wristPitchDeg, "wristPitchDeg");
            finite(offsetX, "hand offsetX");
            finite(offsetY, "hand offsetY");
            finite(offsetZ, "hand offsetZ");
            Objects.requireNonNull(thumb, "thumb");
            Objects.requireNonNull(index, "index");
            Objects.requireNonNull(middle, "middle");
            Objects.requireNonNull(ring, "ring");
            Objects.requireNonNull(pinky, "pinky");
        }

        public DigitPose digit(Element element) {
            return switch (element) {
                case THUMB -> thumb;
                case INDEX -> index;
                case MIDDLE -> middle;
                case RING -> ring;
                case PINKY -> pinky;
                default -> throw new IllegalArgumentException("Element is not a digit: " + element);
            };
        }
    }

    /**
     * A declarative spatial relation between two hand elements. foregroundSide is meaningful for
     * CROSSES and must remain null when the provided specification does not determine the order.
     */
    public record ContactConstraint(
            Side firstSide,
            Element firstElement,
            ContactPoint firstPoint,
            Side secondSide,
            Element secondElement,
            ContactPoint secondPoint,
            Relation relation,
            Side foregroundSide,
            DetailStatus status,
            String note) {
        public ContactConstraint {
            Objects.requireNonNull(firstSide, "firstSide");
            Objects.requireNonNull(firstElement, "firstElement");
            Objects.requireNonNull(firstPoint, "firstPoint");
            Objects.requireNonNull(secondSide, "secondSide");
            Objects.requireNonNull(secondElement, "secondElement");
            Objects.requireNonNull(secondPoint, "secondPoint");
            Objects.requireNonNull(relation, "relation");
            Objects.requireNonNull(status, "status");
            Objects.requireNonNull(note, "note");
            if (relation == Relation.CROSSES && status == DetailStatus.SPECIFIED && foregroundSide == null) {
                throw new IllegalArgumentException("A specified crossover must define its foreground hand");
            }
        }
    }

    public record PoseProfile(
            BasicSeal seal,
            HandPose left,
            HandPose right,
            List<ContactConstraint> contacts,
            String calibrationNote) {
        public PoseProfile {
            Objects.requireNonNull(seal, "seal");
            Objects.requireNonNull(left, "left");
            Objects.requireNonNull(right, "right");
            contacts = List.copyOf(contacts);
            Objects.requireNonNull(calibrationNote, "calibrationNote");
        }

        public HandPose hand(Side side) {
            return side == Side.LEFT ? left : right;
        }
    }

    private static final DigitPose O = d(0, 0, 0, 0, 0, 0, 0, 0);

    /*
     * Pose values below are authored from the written v1.0 specification. Where it only says
     * "natural", "near", "interlock" or explicitly asks for a side reference, the profile remains
     * a provisional block-model approximation and the note names the unresolved geometry.
     */
    private static final Map<BasicSeal, PoseProfile> PROFILES = buildProfiles();

    public static PoseProfile get(BasicSeal seal) {
        Objects.requireNonNull(seal, "seal");
        PoseProfile profile = PROFILES.get(seal);
        if (profile == null) throw new IllegalStateException("No hand-seal profile for " + seal);
        return profile;
    }

    public static Map<BasicSeal, PoseProfile> all() {
        return Collections.unmodifiableMap(PROFILES);
    }

    private static Map<BasicSeal, PoseProfile> buildProfiles() {
        EnumMap<BasicSeal, PoseProfile> p = new EnumMap<>(BasicSeal.class);

        // 01 子 — L1/L2 are the upright pair; the right hand wraps them. Exact right-hand
        // contacting joints were deliberately not invented because the written spec leaves them open.
        put(p, profile(BasicSeal.ZI,
                hand(-2, -3, 0, 0.18f, 0, 0,
                        d(12, 18, 10, -16, -18, -0.05f, 0, 0.02f),
                        d(0, 2, 0, -3, 0, 0, 0, -0.08f),
                        d(0, 2, 0, 3, 0, 0, 0, 0.08f),
                        d(54, 65, 44, 2, 0, 0, -0.05f, 0.10f),
                        d(62, 72, 50, 6, -3, 0, -0.12f, 0.12f)),
                hand(3, 17, -4, -0.20f, 0.04f, 0.18f,
                        d(27, 34, 24, 22, 18, -0.02f, -0.02f, 0.14f),
                        d(27, 39, 27, -12, 7, -0.04f, 0, 0.26f),
                        d(34, 45, 31, -4, 3, -0.02f, 0.02f, -0.22f),
                        d(40, 52, 37, 5, -4, 0.02f, 0.02f, 0.20f),
                        d(45, 56, 40, 12, -7, 0.04f, 0.02f, -0.16f)),
                List.of(
                        contact(Side.RIGHT, Element.PALM, ContactPoint.PALM_SURFACE,
                                Side.LEFT, Element.INDEX, ContactPoint.BASE_SEGMENT,
                                Relation.WRAPS, null, DetailStatus.NEEDS_REFERENCE,
                                "右手包覆左食指；由右手哪根指节接触尚待正面/侧面参考确认"),
                        contact(Side.RIGHT, Element.PALM, ContactPoint.PALM_SURFACE,
                                Side.LEFT, Element.MIDDLE, ContactPoint.BASE_SEGMENT,
                                Relation.WRAPS, null, DetailStatus.NEEDS_REFERENCE,
                                "右手包覆左中指；具体接触指节待参考图确认")),
                "优先锁定左食指/中指竖直并拢；右手具体包覆指节未定。"));

        // 02 丑 — thumbs point outward; only the left middle/ring-to-right-dorsum contacts are explicit.
        put(p, profile(BasicSeal.CHOU,
                hand(-7, -14, 8, 0.24f, 0.02f, 0.12f,
                        d(16, 20, 13, -28, -23, -0.03f, 0, 0),
                        d(24, 34, 22, -4, -2, 0, 0, 0.10f),
                        d(28, 38, 27, 1, 1, 0.04f, 0, 0.20f),
                        d(33, 43, 31, 5, 3, 0.02f, 0, 0.26f),
                        d(38, 48, 35, 10, 5, 0.02f, 0, 0.20f)),
                hand(7, 14, -8, -0.24f, -0.02f, -0.10f,
                        d(16, 20, 13, 28, 23, 0.03f, 0, 0),
                        d(29, 39, 28, 4, 2, 0, 0, -0.10f),
                        d(28, 38, 27, -1, -1, -0.04f, 0, -0.20f),
                        d(33, 43, 31, -5, -3, -0.02f, 0, -0.26f),
                        d(38, 48, 35, -10, -5, -0.02f, 0, -0.20f)),
                List.of(
                        contact(Side.LEFT, Element.MIDDLE, ContactPoint.BASE_SEGMENT,
                                Side.RIGHT, Element.DORSUM, ContactPoint.DORSAL_SURFACE,
                                Relation.TOUCH, null, DetailStatus.SPECIFIED,
                                "左中指基部区域接触右手手背"),
                        contact(Side.LEFT, Element.RING, ContactPoint.BASE_SEGMENT,
                                Side.RIGHT, Element.DORSUM, ContactPoint.DORSAL_SURFACE,
                                Relation.TOUCH, null, DetailStatus.SPECIFIED,
                                "左无名指基部区域接触右手手背")),
                "文字要求前臂交叉；本版只提供腕/手局部姿势，不伪称已实现完整前臂交叉。"));

        // 03 寅 — both index/middle pairs rise; ring/pinky are offset in depth as an interlocking draft.
        put(p, profile(BasicSeal.YIN,
                hand(-8, -16, -6, 0.16f, -0.01f, 0.14f,
                        d(25, 32, 22, -18, -18, -0.02f, 0, 0), O, O,
                        d(38, 50, 34, -4, 2, 0, -0.04f, 0.24f),
                        d(46, 58, 41, 7, 5, 0.02f, -0.06f, -0.24f)),
                hand(8, 16, 6, -0.16f, 0.01f, -0.14f,
                        d(25, 32, 22, 18, 18, 0.02f, 0, 0), O, O,
                        d(42, 52, 37, 4, -2, 0, -0.04f, -0.24f),
                        d(49, 60, 43, -7, -5, -0.02f, -0.06f, 0.24f)),
                List.of(
                        contact(Side.LEFT, Element.RING, ContactPoint.BASE_SEGMENT,
                                Side.RIGHT, Element.RING, ContactPoint.BASE_SEGMENT,
                                Relation.INTERLOCKS, null, DetailStatus.NEEDS_REFERENCE,
                                "无名指参与下方交扣；对应哪一节先后穿过待参考确认"),
                        contact(Side.LEFT, Element.PINKY, ContactPoint.BASE_SEGMENT,
                                Side.RIGHT, Element.PINKY, ContactPoint.BASE_SEGMENT,
                                Relation.INTERLOCKS, null, DetailStatus.NEEDS_REFERENCE,
                                "小指参与下方交扣；前后层级待参考确认")),
                "上方食指/中指先保持伸直；下方交扣目前用Z偏移表达初始层级，仍需斜上方视图校准。"));

        // 04 卯 — left thumb/index define a gap; right pinky is a separate bone entering that gap.
        put(p, profile(BasicSeal.MAO,
                hand(-12, -20, 2, 0.20f, 0, 0.08f,
                        d(9, 14, 8, -32, -24, -0.04f, 0, 0),
                        d(4, 6, 4, -14, -4, 0, 0, 0),
                        d(15, 22, 16, 5, 2, 0, 0, 0),
                        d(37, 48, 34, 5, 1, 0, -0.03f, 0),
                        d(43, 54, 38, 10, 4, 0, -0.06f, 0)),
                hand(13, 24, -4, -0.18f, 0.06f, 0.18f,
                        d(28, 34, 22, 20, 20, 0, 0, 0),
                        d(33, 42, 30, -5, -4, 0, 0, 0.12f),
                        d(40, 52, 37, -1, 0, 0, 0, -0.12f),
                        d(46, 58, 42, 3, 2, 0, 0, 0.10f),
                        d(4, 6, 4, 5, -10, -0.42f, -0.10f, 0.16f)),
                List.of(contact(Side.RIGHT, Element.PINKY, ContactPoint.BASE_SEGMENT,
                        Side.LEFT, Element.THUMB, ContactPoint.BASE_SEGMENT,
                        Relation.INSERTS_BETWEEN, null, DetailStatus.SPECIFIED,
                        "右小指独立骨骼穿入左拇指与左食指之间的间隙；实际接触边界仍需画面校准")),
                "右小指具备独立伸展和三轴偏移；手腕大角度扭转被刻意避免。"));

        // 05 辰 — semi-curled, layered fingers; pinkies approach/touch in the lower region.
        put(p, profile(BasicSeal.CHEN,
                hand(-4, -13, 10, 0.12f, 0.04f, 0.18f,
                        d(18, 25, 16, -15, -10, 0, 0, 0),
                        d(19, 27, 18, -7, -3, 0, 0, 0.15f),
                        d(23, 31, 21, -1, 1, 0, 0, -0.14f),
                        d(28, 39, 27, 5, 4, 0, 0, 0.15f),
                        d(33, 44, 31, 11, 8, 0, 0.14f, 0.08f)),
                hand(4, 13, -10, -0.12f, 0.04f, -0.18f,
                        d(18, 25, 16, 15, 10, 0, 0, 0),
                        d(23, 31, 21, 7, 3, 0, 0, -0.15f),
                        d(19, 27, 18, 1, -1, 0, 0, 0.14f),
                        d(28, 39, 27, -5, -4, 0, 0, -0.15f),
                        d(33, 44, 31, -11, -8, 0, 0.14f, -0.08f)),
                List.of(contact(Side.LEFT, Element.PINKY, ContactPoint.TIP,
                        Side.RIGHT, Element.PINKY, ContactPoint.TIP,
                        Relation.NEAR_OR_TOUCH, null, DetailStatus.NEEDS_REFERENCE,
                        "两只小指在下方接近或接触；究竟接触还是留缝由侧面图确定")),
                "所有手指采用不同的半弯曲值和深度偏移，避免退化成十指完全同角度的团块。"));

        // 06 巳 — all ten fingers curl independently; alternating Z offsets are only a first interlock pass.
        put(p, profile(BasicSeal.SI,
                hand(-10, -15, -5, 0.14f, 0.01f, 0.12f,
                        d(16, 22, 14, -16, -17, 0, 0, 0),
                        d(27, 37, 26, -8, -3, 0, 0, 0.22f),
                        d(29, 39, 27, -2, 0, 0, 0, -0.22f),
                        d(32, 44, 30, 4, 3, 0, 0, 0.22f),
                        d(35, 47, 33, 9, 6, 0, 0, -0.22f)),
                hand(10, 15, 5, -0.14f, 0.01f, -0.12f,
                        d(16, 22, 14, 16, 17, 0, 0, 0),
                        d(30, 40, 28, 8, 3, 0, 0, -0.22f),
                        d(26, 36, 25, 2, 0, 0, 0, 0.22f),
                        d(34, 46, 31, -4, -3, 0, 0, -0.22f),
                        d(37, 49, 34, -9, -6, 0, 0, 0.22f)),
                List.of(),
                "已把每根手指拆成独立根节/中节/指尖数值；十指的准确交扣配对和拇指层级仍需正面、侧面参考。"));

        // 07 午 — only the index fingertips meet; other digits form a curved lower silhouette.
        put(p, profile(BasicSeal.WU,
                hand(5, -12, 0, 0.42f, 0.12f, 0.08f,
                        d(19, 26, 18, -18, -12, 0, 0, 0),
                        d(0, 0, 0, -3, -2, -0.08f, 0.05f, 0),
                        d(7, 12, 8, 4, 2, 0, 0, 0),
                        d(53, 64, 44, 4, 2, 0, 0.06f, 0),
                        d(58, 68, 48, 10, 5, 0, 0.10f, 0)),
                hand(-5, 12, 0, -0.42f, 0.12f, -0.08f,
                        d(19, 26, 18, 18, 12, 0, 0, 0),
                        d(0, 0, 0, 3, 2, 0.08f, 0.05f, 0),
                        d(7, 12, 8, -4, -2, 0, 0, 0),
                        d(53, 64, 44, -4, -2, 0, 0.06f, 0),
                        d(58, 68, 48, -10, -5, 0, 0.10f, 0)),
                List.of(contact(Side.LEFT, Element.INDEX, ContactPoint.TIP,
                        Side.RIGHT, Element.INDEX, ContactPoint.TIP,
                        Relation.TOUCH, null, DetailStatus.SPECIFIED,
                        "两根食指只在指尖接触，不应让整根食指互相穿过")),
                "食指指尖为明确锚点；其余指节遮挡顺序尚未由文字完全确定。"));

        // 08 未 — index/middle pairs upright and close; lower ring/pinky interlocking is provisional.
        put(p, profile(BasicSeal.WEI,
                hand(-7, -15, 2, 0.18f, 0, 0.10f,
                        d(15, 20, 14, -16, -16, 0, 0, 0),
                        d(0, 1, 0, -2, -1, 0, 0, 0),
                        d(0, 1, 0, 2, 1, 0, 0, 0.02f),
                        d(40, 52, 37, 5, 3, 0, 0, 0.22f),
                        d(48, 59, 42, 11, 6, 0, -0.08f, -0.22f)),
                hand(7, 15, -2, -0.18f, 0, -0.10f,
                        d(15, 20, 14, 16, 16, 0, 0, 0),
                        d(0, 1, 0, 2, 1, 0, 0, 0),
                        d(0, 1, 0, -2, -1, 0, 0, -0.02f),
                        d(40, 52, 37, -5, -3, 0, 0, -0.22f),
                        d(48, 59, 42, -11, -6, 0, -0.08f, 0.22f)),
                List.of(
                        contact(Side.LEFT, Element.INDEX, ContactPoint.BASE_SEGMENT,
                                Side.LEFT, Element.MIDDLE, ContactPoint.BASE_SEGMENT,
                                Relation.TOUCH, null, DetailStatus.SPECIFIED,
                                "左手食指、中指靠拢"),
                        contact(Side.RIGHT, Element.INDEX, ContactPoint.BASE_SEGMENT,
                                Side.RIGHT, Element.MIDDLE, ContactPoint.BASE_SEGMENT,
                                Relation.TOUCH, null, DetailStatus.SPECIFIED,
                                "右手食指、中指靠拢"),
                        contact(Side.LEFT, Element.RING, ContactPoint.BASE_SEGMENT,
                                Side.RIGHT, Element.RING, ContactPoint.BASE_SEGMENT,
                                Relation.INTERLOCKS, null, DetailStatus.NEEDS_REFERENCE,
                                "下方无名指交错的配对/前后层级待参考图确认"),
                        contact(Side.LEFT, Element.PINKY, ContactPoint.BASE_SEGMENT,
                                Side.RIGHT, Element.PINKY, ContactPoint.BASE_SEGMENT,
                                Relation.INTERLOCKS, null, DetailStatus.NEEDS_REFERENCE,
                                "下方小指交错的配对/前后层级待参考图确认")),
                "不直接复制寅印；上方双指更紧并拢，下方交错采用独立弯曲和Z层级。"));

        // 09 申 — right pinky enters the same left thumb/index gap, with a different wrist presentation from 卯.
        put(p, profile(BasicSeal.SHEN,
                hand(3, -9, 7, 0.28f, 0.04f, 0.04f,
                        d(8, 12, 7, -34, -20, -0.03f, 0, 0),
                        d(3, 4, 3, -12, -2, 0, 0, 0),
                        d(17, 23, 16, 4, 3, 0, 0, 0),
                        d(34, 45, 31, 4, 1, 0, 0, 0),
                        d(41, 53, 37, 8, 4, 0, -0.04f, 0)),
                hand(-3, 19, -8, -0.25f, -0.02f, -0.18f,
                        d(25, 31, 21, 19, 17, 0, 0, 0),
                        d(30, 40, 29, -4, -3, 0, 0, -0.10f),
                        d(38, 49, 35, 0, 0, 0, 0, 0.10f),
                        d(45, 56, 40, 3, 2, 0, 0, -0.10f),
                        d(2, 4, 2, 2, -12, -0.40f, -0.06f, -0.12f)),
                List.of(contact(Side.RIGHT, Element.PINKY, ContactPoint.BASE_SEGMENT,
                        Side.LEFT, Element.THUMB, ContactPoint.BASE_SEGMENT,
                        Relation.INSERTS_BETWEEN, null, DetailStatus.SPECIFIED,
                        "右小指穿入左拇指/食指间；与卯印分开保存手腕和整手偏移")),
                "卯印与申印共享的是‘穿入’关系，不共享整套姿势参数；本版腕角和手部偏移刻意不同。"));

        // 10 酉 — thumb tips meet; index/ring crossover pairing and foreground order await visual confirmation.
        put(p, profile(BasicSeal.YOU,
                hand(8, -6, -7, 0.34f, 0.03f, 0.18f,
                        d(12, 18, 8, -8, -9, 0.04f, 0.02f, 0),
                        d(17, 24, 17, -8, -2, 0, 0, 0.28f),
                        d(27, 37, 27, -1, 0, 0, 0, -0.10f),
                        d(20, 29, 19, 7, 3, 0, 0, -0.28f),
                        d(34, 44, 31, 12, 7, 0, 0, 0.10f)),
                hand(-8, 6, 7, -0.34f, 0.03f, -0.18f,
                        d(12, 18, 8, 8, 9, -0.04f, 0.02f, 0),
                        d(17, 24, 17, 8, 2, 0, 0, -0.28f),
                        d(27, 37, 27, 1, 0, 0, 0, 0.10f),
                        d(20, 29, 19, -7, -3, 0, 0, 0.28f),
                        d(34, 44, 31, -12, -7, 0, 0, -0.10f)),
                List.of(
                        contact(Side.LEFT, Element.THUMB, ContactPoint.TIP,
                                Side.RIGHT, Element.THUMB, ContactPoint.TIP,
                                Relation.TOUCH, null, DetailStatus.SPECIFIED,
                                "两只拇指的指尖互相接触"),
                        contact(Side.LEFT, Element.INDEX, ContactPoint.BASE_SEGMENT,
                                Side.RIGHT, Element.INDEX, ContactPoint.BASE_SEGMENT,
                                Relation.CROSSES, null, DetailStatus.NEEDS_REFERENCE,
                                "食指交叉的具体对应指和前后顺序待参考图确认"),
                        contact(Side.LEFT, Element.RING, ContactPoint.BASE_SEGMENT,
                                Side.RIGHT, Element.RING, ContactPoint.BASE_SEGMENT,
                                Relation.CROSSES, null, DetailStatus.NEEDS_REFERENCE,
                                "无名指交叉的具体对应指和前后顺序待参考图确认")),
                "先将拇指尖作为锚点；食指/无名指层级是本印的主要待校准项，当前Z偏移只是初始占位。"));

        // 11 戌 — right fist is independent from the left flat, close-set palm covering it.
        put(p, profile(BasicSeal.XU,
                hand(-3, -5, 4, 0.36f, 0.20f, 0.10f,
                        d(24, 31, 21, -15, -14, 0, 0, 0),
                        d(2, 3, 2, -1, 0, 0, 0, 0),
                        d(2, 3, 2, 0, 0, 0, 0, 0),
                        d(2, 3, 2, 1, 0, 0, 0, 0),
                        d(2, 3, 2, 2, 0, 0, 0, 0)),
                hand(2, 7, -3, -0.32f, -0.06f, -0.16f,
                        d(58, 67, 48, 5, 6, 0, 0, 0),
                        d(65, 76, 54, -3, 0, 0, 0, 0),
                        d(68, 78, 57, -1, 0, 0, 0, 0),
                        d(67, 77, 56, 2, 0, 0, 0, 0),
                        d(62, 73, 52, 5, -2, 0, 0, 0)),
                List.of(contact(Side.LEFT, Element.PALM, ContactPoint.PALM_SURFACE,
                        Side.RIGHT, Element.DORSUM, ContactPoint.DORSAL_SURFACE,
                        Relation.COVERS, null, DetailStatus.SPECIFIED,
                        "左手掌面覆盖右拳背；右拇指留在拳头自身结构内，不穿进左掌")),
                "右手为完整握拳轮廓、左手为并拢张掌；两者不可合并成同一团手模型。"));

        // 12 亥 — both hands keep a half-fist silhouette, not the full-fist pose used by 戌.
        put(p, profile(BasicSeal.HAI,
                hand(0, -7, 0, 0.16f, 0.04f, 0.08f,
                        d(37, 44, 29, -14, -14, -0.02f, 0, 0),
                        d(29, 39, 28, -3, -1, 0, 0, 0),
                        d(31, 41, 29, -1, 0, 0, 0, 0),
                        d(34, 44, 31, 2, 1, 0, 0, 0),
                        d(38, 47, 33, 5, 3, 0, 0, 0)),
                hand(0, 7, 0, -0.16f, 0.04f, -0.08f,
                        d(37, 44, 29, 14, 14, 0.02f, 0, 0),
                        d(31, 41, 29, 1, 0, 0, 0, 0),
                        d(29, 39, 28, 3, 1, 0, 0, 0),
                        d(34, 44, 31, -2, -1, 0, 0, 0),
                        d(38, 47, 33, -5, -3, 0, 0, 0)),
                List.of(contact(Side.LEFT, Element.PALM, ContactPoint.PALM_SURFACE,
                        Side.RIGHT, Element.PALM, ContactPoint.PALM_SURFACE,
                        Relation.TOUCH, null, DetailStatus.NEEDS_REFERENCE,
                        "两手掌侧相接；具体接触边线需正面/侧面画面校准")),
                "保留半握拳范围，弯曲幅度显著低于戌印；前臂接近水平的程度还需实机视角校准。"));

        if (p.size() != BasicSeal.values().length) {
            throw new IllegalStateException("Hand seal pose library is incomplete: " + p.size());
        }
        return Collections.unmodifiableMap(p);
    }

    private static DigitPose d(float base, float middle, float tip, float spread, float yaw,
                               float offsetX, float offsetY, float offsetZ) {
        return new DigitPose(base, middle, tip, spread, yaw, offsetX, offsetY, offsetZ);
    }

    private static HandPose hand(float roll, float yaw, float pitch, float x, float y, float z,
                                 DigitPose thumb, DigitPose index, DigitPose middle,
                                 DigitPose ring, DigitPose pinky) {
        return new HandPose(roll, yaw, pitch, x, y, z, thumb, index, middle, ring, pinky);
    }

    private static ContactConstraint contact(Side firstSide, Element firstElement, ContactPoint firstPoint,
                                             Side secondSide, Element secondElement, ContactPoint secondPoint,
                                             Relation relation, Side foregroundSide, DetailStatus status,
                                             String note) {
        return new ContactConstraint(firstSide, firstElement, firstPoint, secondSide, secondElement,
                secondPoint, relation, foregroundSide, status, note);
    }

    private static PoseProfile profile(BasicSeal seal, HandPose left, HandPose right,
                                       List<ContactConstraint> contacts, String note) {
        return new PoseProfile(seal, left, right, contacts, note);
    }

    private static void put(Map<BasicSeal, PoseProfile> map, PoseProfile profile) {
        if (map.put(profile.seal(), profile) != null) {
            throw new IllegalStateException("Duplicate pose profile: " + profile.seal());
        }
    }

    private static void finite(float value, String name) {
        if (!Float.isFinite(value)) throw new IllegalArgumentException(name + " must be finite");
    }
}
