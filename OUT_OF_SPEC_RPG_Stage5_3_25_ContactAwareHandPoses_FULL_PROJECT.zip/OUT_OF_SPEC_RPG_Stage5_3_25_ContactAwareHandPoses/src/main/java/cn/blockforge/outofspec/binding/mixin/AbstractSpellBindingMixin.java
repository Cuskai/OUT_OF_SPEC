package cn.blockforge.outofspec.binding.mixin;

import cn.blockforge.outofspec.binding.BindingCastingState;
import cn.blockforge.outofspec.binding.BindingContract;
import cn.blockforge.outofspec.binding.network.SealCastingNetwork;
import cn.blockforge.outofspec.spellcraft.runtime.SealedCastEffectState;
import cn.blockforge.outofspec.spellcraft.growth.SpellGrowthService;
import cn.blockforge.outofspec.spellcraft.growth.SpellGrowthCatalog;
import cn.blockforge.outofspec.spellcraft.growth.SpellGrowthRuntime;
import io.redspace.ironsspellbooks.api.spells.AbstractSpell;
import io.redspace.ironsspellbooks.api.magic.MagicData;
import io.redspace.ironsspellbooks.api.spells.CastResult;
import io.redspace.ironsspellbooks.api.spells.CastSource;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Applies only the effects that are explicitly understood and accepted by the contract judge. */
@Mixin(value = AbstractSpell.class, remap = false)
public abstract class AbstractSpellBindingMixin {
    @Shadow protected int baseSpellPower;
    @Shadow protected int spellPowerPerLevel;

    @Inject(method = "getEffectiveCastTime", at = @At("RETURN"), cancellable = true, remap = false, require = 1)
    private void outOfSpec$applyCastTimeContract(int spellLevel, LivingEntity caster,
                                                 CallbackInfoReturnable<Integer> cir) {
        if (!(caster instanceof Player player) || player.level().isClientSide) return;
        double multiplier = 1.0;
        for (BindingContract contract : BindingCastingState.getEffectContracts(player)) {
            if (Math.abs(contract.castTimeDeltaPct()) >= 0.001
                    && contract.healthConditionMet(player.getHealth(), player.getMaxHealth())) {
                multiplier *= contract.castTimeMultiplier();
                if (!Double.isFinite(multiplier)) multiplier = Double.MAX_VALUE;
            }
        }
        String currentSpellId = ((AbstractSpell) (Object) this).getSpellId();
        multiplier *= SpellGrowthService.branchCastTimeMultiplier(player, currentSpellId);
        multiplier *= SealedCastEffectState.castTimeMultiplier(player, currentSpellId);
        if (!Double.isFinite(multiplier)) multiplier = Double.MAX_VALUE;
        if (Math.abs(multiplier - 1.0) < 0.001) return;
        int current = Math.max(0, cir.getReturnValue());
        cir.setReturnValue((int) Math.min(Integer.MAX_VALUE, Math.max(0, Math.ceil(current * multiplier))));
    }

    @Inject(method = "getSpellPower", at = @At("RETURN"), cancellable = true, remap = false, require = 1)
    private void outOfSpec$applyPowerContract(int spellLevel, Entity caster,
                                              CallbackInfoReturnable<Float> cir) {
        if (!(caster instanceof Player player) || player.level().isClientSide) return;
        String currentSpellId = ((AbstractSpell) (Object) this).getSpellId();
        double multiplier = 1.0;
        for (BindingContract contract : BindingCastingState.getEffectContracts(player)) {
            if (Math.abs(contract.spellPowerDeltaPct()) < 0.001
                    || !contract.matchesPowerSpell(currentSpellId)
                    || !contract.healthConditionMet(player.getHealth(), player.getMaxHealth())) continue;
            multiplier *= contract.spellPowerMultiplier();
            if (!Double.isFinite(multiplier)) multiplier = Float.MAX_VALUE;
        }
        if (SpellGrowthService.isLearned(player, currentSpellId)) {
            // Normalize the spell-power level contribution to the player's OUT OF SPEC growth
            // level even when the same learned spell is launched through a native Iron's Spells path.
            int growthLevel = SpellGrowthService.level(player, currentSpellId);
            double incomingBase = baseSpellPower + (double) spellPowerPerLevel * (spellLevel - 1);
            double growthBase = baseSpellPower + (double) spellPowerPerLevel * (growthLevel - 1);
            if (incomingBase > 0.0001 && Double.isFinite(growthBase)) {
                multiplier *= Math.max(0.0, growthBase / incomingBase);
            }
        }
        multiplier *= SealedCastEffectState.spellPowerMultiplier(player, currentSpellId);
        multiplier *= SpellGrowthService.branchSpellPowerMultiplier(player, currentSpellId);
        if (!Double.isFinite(multiplier)) multiplier = Float.MAX_VALUE;
        if (Math.abs(multiplier - 1.0) < 0.001) return;
        double adjusted = cir.getReturnValue() * multiplier;
        if (!Double.isFinite(adjusted)) adjusted = Float.MAX_VALUE;
        cir.setReturnValue((float) Math.max(0.0, Math.min(Float.MAX_VALUE, adjusted)));
    }

    /** Begin a synchronous capture of the real projectiles produced by this native spell cast. */
    @Inject(method = "castSpell", at = @At("HEAD"), remap = false, require = 1)
    private void outOfSpec$beginProjectileCapture(Level level, int spellLevel,
                                                  net.minecraft.server.level.ServerPlayer player,
                                                  CastSource castSource, boolean addCooldown,
                                                  org.spongepowered.asm.mixin.injection.callback.CallbackInfo ci) {
        if (player == null || level.isClientSide) return;
        SealedCastEffectState.beginProjectileCapture(player, ((AbstractSpell) (Object) this).getSpellId());
    }

    /** Clear the one-cast modifier after the native release and lay captured projectiles out symmetrically. */
    @Inject(method = "castSpell", at = @At("RETURN"), remap = false, require = 1)
    private void outOfSpec$finishSealedCast(Level level, int spellLevel,
                                             net.minecraft.server.level.ServerPlayer player,
                                             CastSource castSource, boolean addCooldown,
                                             org.spongepowered.asm.mixin.injection.callback.CallbackInfo ci) {
        if (player == null || level.isClientSide) return;
        String spellId = ((AbstractSpell) (Object) this).getSpellId();
        int initialProjectileCount = SealedCastEffectState.capturedProjectileCount(player, spellId);
        int extraReleases = SealedCastEffectState.extraReleaseCount(player, spellId);
        boolean extraReleaseFailed = false;
        if (extraReleases > 0 && initialProjectileCount > 0
                && SealedCastEffectState.supportsMultiReleaseSpell(spellId)) {
            AbstractSpell spell = (AbstractSpell) (Object) this;
            for (int index = 0; index < Math.min(2, extraReleases); index++) {
                try {
                    // Execute the original spell's real onCast path; the spawned Projectile entities
                    // are captured and later placed into a symmetric left/center/right formation.
                    spell.onCast(level, spellLevel, player, castSource, MagicData.getPlayerMagicData(player));
                } catch (RuntimeException releaseFailure) {
                    extraReleaseFailed = true;
                    player.displayClientMessage(Component.literal("追加释放的额外弹体执行失败；原始法术释放不受影响。"), true);
                }
            }
        } else if (extraReleases > 0) {
            extraReleaseFailed = true;
        }
        int capturedAfterReleases = SealedCastEffectState.capturedProjectileCount(player, spellId);
        int expectedProjectileCount = initialProjectileCount * (1 + Math.min(2, extraReleases));
        boolean spawnFormationReady = SealedCastEffectState.hasCompleteSpawnFormation(
                player, spellId, expectedProjectileCount);
        int fallbackArrangedCount = 0;
        boolean fallbackAttempted = extraReleases > 0 && capturedAfterReleases > 1 && !spawnFormationReady;
        if (fallbackAttempted) {
            // Safe fallback when a native spell emits entities outside the synchronous join-event window.
            // The fallback reuses original native velocities so a partially placed projectile is not double-rotated.
            fallbackArrangedCount = SealedCastEffectState.arrangeCapturedProjectilesFallback(player, spellId);
        }
        java.util.List<net.minecraft.world.entity.projectile.Projectile> projectiles =
                SealedCastEffectState.finishProjectileCapture(player, spellId);
        boolean fallbackFormationFailed = fallbackAttempted
                && fallbackArrangedCount < Math.min(2, projectiles.size());
        if (extraReleases > 0 && (initialProjectileCount == 0
                || projectiles.size() < expectedProjectileCount || fallbackFormationFailed)) {
            extraReleaseFailed = true;
            player.displayClientMessage(Component.literal(fallbackFormationFailed
                    ? "未能确认额外弹体已完成左右排布；原版法术仍已保留，未强制伪造缺失弹体。"
                    : "未能捕获全部额外弹体；已保留原版法术发射，未强制伪造缺失弹体。"), true);
        }
        java.util.UUID requestId = SealedCastEffectState.completeSpellExecution(player, spellId);
        if (extraReleases > 0 && !extraReleaseFailed) {
            String releaseName = extraReleases >= 2 ? "三重释放" : "多重释放";
            String layout = extraReleases >= 2 ? "左、中、右分列" : "左、右两侧分列";
            player.displayClientMessage(Component.literal(releaseName + "已执行：捕获并排布 "
                    + projectiles.size() + " 枚原版弹体（" + layout + "）。"), true);
        }
        if (requestId != null) SealCastingNetwork.notifyCastFinished(player, requestId, true,
                extraReleaseFailed
                        ? "原版法术已执行；额外弹体未完全确认，追加印状态已清理。"
                        : extraReleases > 0
                            ? "原版法术已执行；捕获 " + projectiles.size() + " 枚真实弹体并完成侧向编队，追加印状态已清理。"
                            : "原版法术已执行；追加印状态已清理。", spellId);
        SpellGrowthRuntime.onSpellReleased(player, spellId);
    }

    @Inject(method = "canBeCastedBy", at = @At("HEAD"), cancellable = true, remap = false, require = 1)
    private void outOfSpec$checkCombinedManaCost(int spellLevel, CastSource castSource, MagicData magicData,
                                                Player player, CallbackInfoReturnable<CastResult> cir) {
        if (player == null || player.level().isClientSide || magicData == null) return;
        String spellId = ((AbstractSpell) (Object) this).getSpellId();
        // Iron's Spells normally checks the unmodified base cost here. Combine growth branches,
        // this cast's additional seals, and any active binding costs so extra-release seals cannot
        // silently undercharge when a costly contract is active at the same time.
        double growthAndAddition = SpellGrowthService.branchManaCostMultiplier(player, spellId)
                * SealedCastEffectState.manaCostMultiplier(player, spellId);
        double bindingCost = 1.0;
        for (BindingContract contract : BindingCastingState.getEffectContracts(player)) {
            if (Math.abs(contract.manaCostDeltaPct()) < 0.001
                    || !contract.healthConditionMet(player.getHealth(), player.getMaxHealth())) continue;
            bindingCost *= contract.manaCostMultiplier();
            if (!Double.isFinite(bindingCost)) break;
        }
        double combined = growthAndAddition * bindingCost;
        if (!Double.isFinite(combined) || combined > 1.0) {
            int baseCost = Math.max(0, ((AbstractSpell) (Object) this).getManaCost(spellLevel));
            // Event listener order is not guaranteed across modules. Check both sequential-rounding
            // orders and require the larger amount, preventing a one-point shortfall.
            int growthFirst = scaleManaCost(scaleManaCost(baseCost, growthAndAddition), bindingCost);
            int bindingFirst = scaleManaCost(scaleManaCost(baseCost, bindingCost), growthAndAddition);
            int required = Math.max(growthFirst, bindingFirst);
            if (magicData.getMana() + 0.001f < required) {
                cir.setReturnValue(new CastResult(CastResult.Type.FAILURE,
                        Component.literal("当前术式、追加印或生效束缚需要额外魔力：至少需要 " + required + " 点魔力。")));
            }
        }
    }

    private static int scaleManaCost(int baseCost, double multiplier) {
        if (baseCost <= 0) return 0;
        if (!Double.isFinite(multiplier) || multiplier >= (double) Integer.MAX_VALUE / baseCost) {
            return Integer.MAX_VALUE;
        }
        if (multiplier <= 0.0) return 0;
        return (int) Math.min(Integer.MAX_VALUE, Math.ceil(baseCost * multiplier));
    }

    @Redirect(method = "canBeCastedBy", at = @At(value = "INVOKE",
            target = "Lio/redspace/ironsspellbooks/api/spells/AbstractSpell;isLearned(Lnet/minecraft/world/entity/player/Player;)Z",
            remap = false), remap = false, require = 1)
    private boolean outOfSpec$acceptGrowthLearning(AbstractSpell spell, Player player) {
        if (SpellGrowthCatalog.bySpellId(spell.getSpellId()) != null) {
            return SpellGrowthService.isLearned(player, spell.getSpellId());
        }
        return spell.isLearned(player);
    }

    /** The legacy Iron's Spells learned flag cannot bypass research for growth-enabled spells. */
    @Inject(method = "attemptInitiateCast", at = @At("HEAD"), cancellable = true, remap = false, require = 1)
    private void outOfSpec$requireResearchForGrowthSpells(ItemStack itemStack, int spellLevel, Level level,
                                                          Player player, CastSource castSource, boolean trigger,
                                                          String slot, CallbackInfoReturnable<Boolean> cir) {
        String spellId = ((AbstractSpell) (Object) this).getSpellId();
        if (SpellGrowthCatalog.bySpellId(spellId) == null || SpellGrowthService.isLearned(player, spellId)) return;
        if (player != null && !level.isClientSide) {
            player.displayClientMessage(Component.literal("尚未通过 OUT OF SPEC 术式研究：请获得对应卷轴并在研究档案中成功学习。"), true);
        }
        cir.setReturnValue(false);
    }

    /** Permanently sealed spells cannot be initiated again after their one permitted cast. */
    @Inject(method = "attemptInitiateCast", at = @At("HEAD"), cancellable = true, remap = false, require = 1)
    private void outOfSpec$enforcePermanentSingleUse(ItemStack itemStack, int spellLevel, Level level,
                                                      Player player, CastSource castSource, boolean trigger,
                                                      String slot, CallbackInfoReturnable<Boolean> cir) {
        if (player == null || level.isClientSide) return;
        String spellId = ((AbstractSpell) (Object) this).getSpellId();
        int requiredPreparationTicks = BindingCastingState.requiredPreparationTicks(player, spellId);
        if (requiredPreparationTicks > 0) {
            int heldTicks = BindingCastingState.castingPreparationProgressTicks(player);
            if (heldTicks < requiredPreparationTicks) {
                player.displayClientMessage(Component.literal("束缚前置条件未完成：请保持潜行、站在地面且不移动 "
                        + BindingContract.format(requiredPreparationTicks / 20.0) + " 秒。当前已完成 "
                        + BindingContract.format(heldTicks / 20.0) + " 秒。"), true);
                cir.setReturnValue(false);
                return;
            }
        }
        if (BindingCastingState.isSpellPermanentlyBlocked(player, spellId)) {
            player.displayClientMessage(Component.literal("束缚已封存" + spellId + "：此法术的唯一使用次数已耗尽。"), true);
            cir.setReturnValue(false);
        }
    }

    /** A completed hold is consumed only if Iron's Spells really initiates the cast. */
    @Inject(method = "attemptInitiateCast", at = @At("RETURN"), remap = false, require = 1)
    private void outOfSpec$consumePreparationAfterSuccessfulCast(ItemStack itemStack, int spellLevel, Level level,
                                                                  Player player, CastSource castSource, boolean trigger,
                                                                  String slot, CallbackInfoReturnable<Boolean> cir) {
        if (player == null || level.isClientSide || !Boolean.TRUE.equals(cir.getReturnValue())) return;
        String spellId = ((AbstractSpell) (Object) this).getSpellId();
        if (BindingCastingState.requiredPreparationTicks(player, spellId) > 0) {
            BindingCastingState.consumeCastingPreparationProgress(player);
        }
    }
}
