package cn.blockforge.outofspec.binding.mixin;

import cn.blockforge.outofspec.spellcraft.runtime.SealedCastEffectState;
import io.redspace.ironsspellbooks.spells.fire.FireballSpell;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Applies the learned fireball-only radius seal to the real Iron's Spells radius calculation. */
@Mixin(value = FireballSpell.class, remap = false)
public abstract class FireballExpansionMixin {
    @Inject(method = "getRadius", at = @At("RETURN"), cancellable = true, remap = false, require = 1)
    private void outOfSpec$expandSealedFireballRadius(int spellLevel, LivingEntity caster,
                                                       CallbackInfoReturnable<Integer> cir) {
        if (!(caster instanceof Player player) || player.level().isClientSide) return;
        double multiplier = SealedCastEffectState.areaRadiusMultiplier(player, "irons_spellbooks:fireball");
        if (!Double.isFinite(multiplier) || multiplier <= 1.001) return;
        int baseRadius = Math.max(0, cir.getReturnValue());
        int expandedRadius = (int) Math.min(64, Math.ceil(baseRadius * multiplier));
        cir.setReturnValue(Math.max(baseRadius, expandedRadius));
    }
}
