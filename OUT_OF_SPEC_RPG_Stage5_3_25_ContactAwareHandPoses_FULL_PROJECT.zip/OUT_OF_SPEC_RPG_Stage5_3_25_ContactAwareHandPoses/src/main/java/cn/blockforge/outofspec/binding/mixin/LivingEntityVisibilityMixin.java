package cn.blockforge.outofspec.binding.mixin;

import cn.blockforge.outofspec.binding.BindingCastingState;
import cn.blockforge.outofspec.binding.BindingContract;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Applies the actual visibility price/reward only while a validated caster is actively casting. */
@Mixin(LivingEntity.class)
public abstract class LivingEntityVisibilityMixin {
    @Inject(method = "getVisibilityPercent", at = @At("RETURN"), cancellable = true, require = 1)
    private void outOfSpec$applyContractVisibility(Entity lookingEntity, CallbackInfoReturnable<Double> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (!(self instanceof Player player) || player.level().isClientSide) return;
        if (!BindingCastingState.isBoundCasting(player)) return;
        double factor = 1.0;
        for (BindingContract contract : BindingCastingState.getEffectContracts(player)) {
            if (Math.abs(contract.visibilityReductionPct()) < 0.001
                    || !contract.healthConditionMet(player.getHealth(), player.getMaxHealth())) continue;
            factor *= contract.visibilityMultiplier();
            if (!Double.isFinite(factor)) factor = 2.0;
        }
        factor = Mth.clamp(factor, 0.1, 2.0);
        if (Math.abs(factor - 1.0) > 0.001) cir.setReturnValue(cir.getReturnValue() * factor);
    }
}
