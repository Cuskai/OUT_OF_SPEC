package cn.blockforge.outofspec.binding.mixin.client;

import cn.blockforge.outofspec.binding.client.BindingContractScreen;
import cn.blockforge.outofspec.spellcraft.client.SpellGrowthClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Optional SAO Menu bridge: places Binding and Spell Growth terminals in its existing profile/skills submenu. */
@Pseudo
@Mixin(targets = "com.sao.saomenulite.client.SAOMenuScreen", remap = false)
public abstract class SAOSkillBindingMenuMixin {
    private static final String CONTRACT_KEY = "out_of_spec_binding.skill_contract";
    private static final String RESEARCH_KEY = "out_of_spec_binding.spell_research";
    private static final String GROWTH_KEY = "out_of_spec_binding.spell_growth";
    private static final String CODEX_KEY = "out_of_spec_binding.seal_codex";
    private static final String GRIMOIRE_KEY = "out_of_spec_binding.arcane_grimoire";
    private static final String ADDITIONS_KEY = "out_of_spec_binding.additional_seals";
    private static final String[] OOS_MENU_ENTRIES = {
            CONTRACT_KEY, RESEARCH_KEY, GROWTH_KEY, CODEX_KEY, ADDITIONS_KEY, GRIMOIRE_KEY
    };

    @Inject(method = "activeItems", at = @At("RETURN"), cancellable = true, remap = false)
    private void outOfSpec$appendTerminals(int main, CallbackInfoReturnable<Object> cir) {
        if (main != 0 || !(cir.getReturnValue() instanceof Object[] original) || original.length == 0) return;
        try {
            Object root = original[0];
            Class<?> itemClass = root.getClass();
            Method childrenGetter = itemClass.getDeclaredMethod("children");
            Method labelGetter = itemClass.getDeclaredMethod("label");
            Method iconGetter = itemClass.getDeclaredMethod("icon");
            Method actionGetter = itemClass.getDeclaredMethod("action");
            Method stackGetter = itemClass.getDeclaredMethod("stack");
            Method slotGetter = itemClass.getDeclaredMethod("invSlot");
            for (Method m : new Method[]{childrenGetter, labelGetter, iconGetter, actionGetter, stackGetter, slotGetter}) {
                m.setAccessible(true);
            }

            Object childrenObject = childrenGetter.invoke(root);
            if (childrenObject == null || !childrenObject.getClass().isArray()) return;
            Object[] children = (Object[]) childrenObject;
            Set<String> existingLabels = new HashSet<>();
            for (Object child : children) existingLabels.add(String.valueOf(labelGetter.invoke(child)));
            boolean needsEntry = Arrays.stream(OOS_MENU_ENTRIES).anyMatch(key -> !existingLabels.contains(key));
            if (!needsEntry) return;

            Class<?> actionClass = actionGetter.getReturnType();
            Object skillAction = null;
            if (actionClass.isEnum()) {
                @SuppressWarnings({"rawtypes", "unchecked"})
                Object candidate = Enum.valueOf((Class<? extends Enum>) actionClass, "SKILL");
                skillAction = candidate;
            }
            if (skillAction == null) return;

            Class<?> childArrayType = Array.newInstance(itemClass, 0).getClass();
            Constructor<?> ctor = itemClass.getDeclaredConstructor(String.class, String.class, actionClass,
                    childArrayType, ItemStack.class, int.class);
            ctor.setAccessible(true);
            List<Object> mergedChildren = new ArrayList<>(Arrays.asList(children));
            for (String key : OOS_MENU_ENTRIES) {
                if (!existingLabels.contains(key)) {
                    // SAO resolves this label key through its normal localization path.
                    mergedChildren.add(ctor.newInstance(key, "item_config", skillAction, null, ItemStack.EMPTY, -1));
                }
            }

            Object[] newChildren = (Object[]) Array.newInstance(itemClass, mergedChildren.size());
            for (int i = 0; i < mergedChildren.size(); i++) newChildren[i] = mergedChildren.get(i);
            Object newRoot = ctor.newInstance(labelGetter.invoke(root), iconGetter.invoke(root), actionGetter.invoke(root),
                    newChildren, stackGetter.invoke(root), slotGetter.invoke(root));
            Object[] newItems = Arrays.copyOf(original, original.length);
            newItems[0] = newRoot;
            cir.setReturnValue(newItems);
        } catch (ReflectiveOperationException | RuntimeException exception) {
            // Keep SAO Menu untouched if a future version changes its item-record internals.
        }
    }

    @Inject(method = "runAction", at = @At("HEAD"), cancellable = true, remap = false)
    private void outOfSpec$openTerminals(@Coerce Object action, CallbackInfo ci) {
        try {
            java.lang.reflect.Field labelField = this.getClass().getDeclaredField("lastClickedLabel");
            labelField.setAccessible(true);
            Object value = labelField.get(this);
            if (!(value instanceof String label)) return;
            Minecraft mc = Minecraft.getInstance();
            Screen parent = (Screen) (Object) this;
            if (CONTRACT_KEY.equals(label)) {
                BindingContractScreen.openOrResume(parent);
            } else if (RESEARCH_KEY.equals(label)) {
                SpellGrowthClient.openResearch(parent);
            } else if (GROWTH_KEY.equals(label)) {
                SpellGrowthClient.openGrowth(parent);
            } else if (CODEX_KEY.equals(label)) {
                SpellGrowthClient.openCodex(parent);
            } else if (ADDITIONS_KEY.equals(label)) {
                SpellGrowthClient.openAdditionalSeals(parent);
            } else if (GRIMOIRE_KEY.equals(label)) {
                SpellGrowthClient.openGrimoire(parent);
            } else {
                return;
            }
            ci.cancel();
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            // Fail closed: unrelated SAO menu actions must never be intercepted.
        }
    }
}
