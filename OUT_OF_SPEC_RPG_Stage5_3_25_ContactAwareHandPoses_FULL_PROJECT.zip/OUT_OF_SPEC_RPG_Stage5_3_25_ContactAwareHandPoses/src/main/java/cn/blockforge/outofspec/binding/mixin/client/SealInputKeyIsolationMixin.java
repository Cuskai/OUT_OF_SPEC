package cn.blockforge.outofspec.binding.mixin.client;

import cn.blockforge.outofspec.binding.client.SealInputDebugClient;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.KeyboardHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** During the diagnostic seal session, prevent those physical keys from firing other KeyMappings. */
@Mixin(KeyboardHandler.class)
public abstract class SealInputKeyIsolationMixin {
    @Redirect(method = "keyPress", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/KeyMapping;click(Lcom/mojang/blaze3d/platform/InputConstants$Key;)V"), require = 0)
    private void outOfSpec$filterSealKeyClick(InputConstants.Key key) {
        if (!SealInputDebugClient.shouldSuppressKeyMapping(key)) KeyMapping.click(key);
    }

    @Redirect(method = "keyPress", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/KeyMapping;set(Lcom/mojang/blaze3d/platform/InputConstants$Key;Z)V"), require = 0)
    private void outOfSpec$filterSealKeyDownState(InputConstants.Key key, boolean down) {
        if (!SealInputDebugClient.shouldSuppressKeyMapping(key)) KeyMapping.set(key, down);
    }
}
