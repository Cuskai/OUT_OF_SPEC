package cn.blockforge.outofspec.binding.mixin.client;

import cn.blockforge.outofspec.binding.client.SealHandPoseRenderer;
import cn.blockforge.outofspec.binding.client.SealInputDebugClient;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Deterministic standalone bilateral hand renderer.
 *
 * Vanilla/Forge hand selection is allowed to render held items normally, but individual vanilla arm
 * geometry is suppressed while this rig is active. At renderHandsWithItems RETURN the OUT OF SPEC rig
 * always draws LEFT and RIGHT from the same outer camera pose, then flushes the new vertices itself.
 * It therefore does not depend on evaluateWhichHandsToRender, renderArmWithItem, Forge hand hooks, or
 * a per-side "missing hand" guess to decide whether the second hand exists.
 */
@Mixin(ItemInHandRenderer.class)
public abstract class StandaloneFirstPersonHandsMixin {
    @Shadow private float mainHandHeight;
    @Shadow private float oMainHandHeight;
    @Shadow private float offHandHeight;
    @Shadow private float oOffHandHeight;

    @Inject(method = "renderHandsWithItems", at = @At("HEAD"), require = 1)
    private void outOfSpec$beginHandFrame(float partialTicks, PoseStack poseStack,
                                          MultiBufferSource.BufferSource buffers, LocalPlayer player,
                                          int packedLight, CallbackInfo ci) {
        SealHandPoseRenderer.beginFirstPersonHandFrame(player);
    }

    /** Draw both custom sides AFTER vanilla has finished its one-sided/special item path. */
    @Inject(method = "renderHandsWithItems", at = @At("RETURN"), require = 1)
    private void outOfSpec$drawBilateralPairAtReturn(float partialTicks, PoseStack poseStack,
                                                      MultiBufferSource.BufferSource buffers, LocalPlayer player,
                                                      int packedLight, CallbackInfo ci) {
        float mainEquip = 1.0f - Mth.lerp(partialTicks, oMainHandHeight, mainHandHeight);
        float offEquip = 1.0f - Mth.lerp(partialTicks, oOffHandHeight, offHandHeight);
        SealHandPoseRenderer.finishFirstPersonHandFrame(poseStack, buffers, packedLight, player,
                partialTicks, mainEquip, offEquip);
    }

    /** Prevent duplicate vanilla arm geometry; items are still rendered by renderArmWithItem normally. */
    @Inject(method = "renderPlayerArm", at = @At("HEAD"), cancellable = true, require = 1)
    private void outOfSpec$replaceVanillaArm(PoseStack poseStack, MultiBufferSource buffers,
                                              int packedLight, float equipProgress,
                                              float swingProgress, HumanoidArm arm,
                                              CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.level != null && mc.player == SealHandPoseRenderer.handFramePlayer()
                && SealHandPoseRenderer.isHandFrameActive()
                && !mc.player.isInvisible() && !mc.player.isSpectator()
                && SealInputDebugClient.shouldRenderFirstPersonHands()) {
            ci.cancel();
        }
    }
}
