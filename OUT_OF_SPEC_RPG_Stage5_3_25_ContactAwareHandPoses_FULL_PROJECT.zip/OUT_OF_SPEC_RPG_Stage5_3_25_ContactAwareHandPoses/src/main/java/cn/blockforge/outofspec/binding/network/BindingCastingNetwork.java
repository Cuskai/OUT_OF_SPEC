package cn.blockforge.outofspec.binding.network;

import cn.blockforge.outofspec.binding.BindingCastingMod;
import cn.blockforge.outofspec.binding.BindingCastingState;
import cn.blockforge.outofspec.binding.BindingContract;
import cn.blockforge.outofspec.binding.BindingContractJudge;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;
import net.minecraftforge.fml.DistExecutor;

import java.util.Optional;
import java.util.function.Supplier;

/** The server re-evaluates proposal text and compares its canonical contract with the displayed preview. */
public final class BindingCastingNetwork {
    private static final String PROTOCOL = "3";
    private static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(BindingCastingMod.MOD_ID, "channel"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);
    private static boolean registered;

    private BindingCastingNetwork() {}

    public static void register() {
        if (registered) return;
        registered = true;
        CHANNEL.registerMessage(0, SubmitProposalPacket.class, SubmitProposalPacket::encode,
                SubmitProposalPacket::decode, SubmitProposalPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(1, ClearContractPacket.class, ClearContractPacket::encode,
                ClearContractPacket::decode, ClearContractPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(2, QueryContractPacket.class, QueryContractPacket::encode,
                QueryContractPacket::decode, QueryContractPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(3, ContractStatusPacket.class, ContractStatusPacket::encode,
                ContractStatusPacket::decode, ContractStatusPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
    }

    /** Send both the source text and the exact locally displayed canonical contract. */
    public static void sendProposal(String text, BindingContract expectedContract) {
        String safe = text == null ? "" : text.substring(0, Math.min(512, text.length())).trim();
        if (expectedContract == null || safe.isBlank()) return;
        CHANNEL.sendToServer(new SubmitProposalPacket(safe, expectedContract));
    }

    public static void sendClear() { CHANNEL.sendToServer(new ClearContractPacket()); }
    public static void requestCurrentContract() { CHANNEL.sendToServer(new QueryContractPacket()); }

    private static void sendStatus(ServerPlayer player, boolean actionSucceeded, String message) {
        BindingContract contract = BindingCastingState.getContract(player);
        boolean hasAnyBinding = !contract.isEmpty() || BindingCastingState.hasPermanentBurdens(player);
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new ContractStatusPacket(
                actionSucceeded, hasAnyBinding, BindingCastingState.summary(player), message));
    }

    private record SubmitProposalPacket(String text, BindingContract expectedContract) {
        private void encode(FriendlyByteBuf buffer) {
            buffer.writeUtf(text, 512);
            writeContract(buffer, expectedContract);
        }
        private static SubmitProposalPacket decode(FriendlyByteBuf buffer) {
            String text = buffer.readUtf(512);
            return new SubmitProposalPacket(text, readContract(buffer));
        }
        private static void handle(SubmitProposalPacket packet, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> {
                ServerPlayer player = context.getSender();
                if (player == null) return;
                BindingContractJudge.Result result = BindingContractJudge.evaluate(packet.text());
                if (!result.accepted()) {
                    sendStatus(player, false, "服务端复核拒绝：" + result.reason() + " " + result.suggestion());
                    return;
                }
                // The server always uses its own adjudicated object. The wire copy is only a
                // consistency witness for the exact preview shown to the user, never authority.
                if (packet.expectedContract() == null
                        || !packet.text().equals(packet.expectedContract().source())
                        || !result.contract().equals(packet.expectedContract())) {
                    sendStatus(player, false, "服务端复核拒绝：客户端预览的规范契约与服务端重新解析结果不一致。未应用任何效果；请确认客户端与服务端的 OUT OF SPEC 版本一致后重新分析。");
                    return;
                }
                if (!BindingCastingState.canReplaceContract(player)) {
                    sendStatus(player, false, "当前契约包含尚未兑现的一次性收益和不可撤销的永久代价；先触发这次收益，之后才能替换契约。");
                    return;
                }
                {
                    BindingContract candidate = result.contract();
                    if (candidate.permanentSlownessCost() && BindingCastingState.hasPermanentSlowness(player)) {
                        sendStatus(player, false, "服务端复核拒绝：你已经永久承担了缓慢，不能把同一份永久代价重复支付给新收益。请提出新的代价。");
                        return;
                    }
                    if (candidate.permanentInsomniaCost() && BindingCastingState.hasPermanentInsomnia(player)) {
                        sendStatus(player, false, "服务端复核拒绝：你已经永久失去睡眠能力，不能把同一份永久代价重复支付给新收益。");
                        return;
                    }
                    if (candidate.permanentCastMoveSpeedCost() && candidate.moveSpeedDeltaPct() < -0.001) {
                        double previous = BindingCastingState.permanentCastMoveSpeedCostPct(player, candidate.moveSpeedScopeId());
                        if (previous < -0.001 && previous <= candidate.moveSpeedDeltaPct()) {
                            sendStatus(player, false, "服务端复核拒绝：相同法术的永久施法减速代价已经支付过；只有更强的永久代价才可再次作为新交易的付出。");
                            return;
                        }
                    }
                    if ((candidate.singleUseSpellCost() || candidate.immediateSealCost())
                            && BindingCastingState.hasSpellUseCommitment(player, candidate.singleUseSpellId())) {
                        sendStatus(player, false, "服务端复核拒绝：该法术已经被永久封存/承诺过，不能重复把同一使用权当作新代价。");
                        return;
                    }
                    if (!BindingContract.ALL_SPELLS.equals(candidate.delayedSealSpellId())
                            && BindingCastingState.hasSpellUseCommitment(player, candidate.delayedSealSpellId())) {
                        sendStatus(player, false, "服务端复核拒绝：该法术已被永久封存/承诺，不能重复安排期限后封存。");
                        return;
                    }
                    BindingCastingState.setContract(player, candidate);
                    sendStatus(player, true, "服务端复核通过，规范契约一致并正式生效。" + candidate.shortSummary());
                }
            });
            context.setPacketHandled(true);
        }
    }

    private record ClearContractPacket() {
        private void encode(FriendlyByteBuf buffer) {}
        private static ClearContractPacket decode(FriendlyByteBuf buffer) { return new ClearContractPacket(); }
        private static void handle(ClearContractPacket packet, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> {
                ServerPlayer player = context.getSender();
                if (player == null) return;
                if (!BindingCastingState.canManuallyClearContract(player)) {
                    sendStatus(player, false, "这份契约含有不可撤销的永久代价，且一次性收益尚未兑现。先完成对应施法后才能解除当前契约；永久代价本身不会消失。");
                    return;
                }
                BindingCastingState.setContract(player, BindingContract.empty());
                sendStatus(player, true, BindingCastingState.hasPermanentBurdens(player)
                        ? "当前可撤销契约已解除；不可撤销的永久代价仍然保留。"
                        : "当前束缚契约已解除。") ;
            });
            context.setPacketHandled(true);
        }
    }

    private record QueryContractPacket() {
        private void encode(FriendlyByteBuf buffer) {}
        private static QueryContractPacket decode(FriendlyByteBuf buffer) { return new QueryContractPacket(); }
        private static void handle(QueryContractPacket packet, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> {
                ServerPlayer player = context.getSender();
                if (player == null) return;
                BindingContract current = BindingCastingState.getContract(player);
                sendStatus(player, true, current.isEmpty() ? "当前没有生效中的契约。" : "已同步当前生效契约。");
            });
            context.setPacketHandled(true);
        }
    }

    private static void writeContract(FriendlyByteBuf b, BindingContract c) {
        b.writeUtf(c.source(), 512);
        b.writeDouble(c.spellPowerDeltaPct());
        b.writeDouble(c.moveSpeedDeltaPct());
        b.writeDouble(c.castTimeDeltaPct());
        b.writeDouble(c.visibilityReductionPct());
        b.writeDouble(c.manaCostDeltaPct());
        b.writeDouble(c.cooldownDeltaPct());
        b.writeUtf(c.spellScopeId(), 256);
        b.writeUtf(c.singleUseSpellId(), 256);
        b.writeDouble(c.spellDamageMultiplier());
        b.writeUtf(c.damageMode(), 32);
        b.writeBoolean(c.permanentSlownessCost());
        b.writeBoolean(c.singleUseSpellCost());
        b.writeInt(c.durationTicks());
        b.writeBoolean(c.damageRewardSpent());
        b.writeUtf(c.spellPowerScopeId(), 256);
        b.writeUtf(c.moveSpeedScopeId(), 256);
        b.writeBoolean(c.permanentInsomniaCost());
        b.writeDouble(c.healthThresholdPct());
        b.writeDouble(c.damagePerSealedSpellPct());
        b.writeUtf(c.delayedSealSpellId(), 256);
        b.writeBoolean(c.immediateSealCost());
        b.writeBoolean(c.permanentCastMoveSpeedCost());
        b.writeUtf(c.preparationMode(), 32);
        b.writeUtf(c.preparationSpellId(), 256);
        b.writeInt(c.preparationTicks());
    }

    private static BindingContract readContract(FriendlyByteBuf b) {
        return new BindingContract(
                b.readUtf(512),
                b.readDouble(), b.readDouble(), b.readDouble(), b.readDouble(), b.readDouble(), b.readDouble(),
                b.readUtf(256), b.readUtf(256), b.readDouble(), b.readUtf(32),
                b.readBoolean(), b.readBoolean(), b.readInt(), b.readBoolean(),
                b.readUtf(256), b.readUtf(256), b.readBoolean(), b.readDouble(), b.readDouble(),
                b.readUtf(256), b.readBoolean(), b.readBoolean(),
                b.readUtf(32), b.readUtf(256), b.readInt());
    }

    private record ContractStatusPacket(boolean actionSucceeded, boolean hasContract,
                                        String activeSummary, String message) {
        private void encode(FriendlyByteBuf buffer) {
            buffer.writeBoolean(actionSucceeded);
            buffer.writeBoolean(hasContract);
            buffer.writeUtf(activeSummary == null ? "" : activeSummary, 512);
            buffer.writeUtf(message == null ? "" : message, 1024);
        }
        private static ContractStatusPacket decode(FriendlyByteBuf buffer) {
            return new ContractStatusPacket(buffer.readBoolean(), buffer.readBoolean(),
                    buffer.readUtf(512), buffer.readUtf(1024));
        }
        private static void handle(ContractStatusPacket packet, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(net.minecraftforge.api.distmarker.Dist.CLIENT,
                    () -> () -> cn.blockforge.outofspec.binding.client.BindingCastingClient.receiveStatus(
                            packet.actionSucceeded(), packet.hasContract(), packet.activeSummary(), packet.message())));
            context.setPacketHandled(true);
        }
    }
}
