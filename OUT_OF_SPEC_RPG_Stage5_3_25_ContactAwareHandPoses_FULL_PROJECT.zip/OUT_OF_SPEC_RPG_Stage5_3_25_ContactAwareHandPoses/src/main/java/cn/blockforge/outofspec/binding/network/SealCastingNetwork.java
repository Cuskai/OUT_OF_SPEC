package cn.blockforge.outofspec.binding.network;

import cn.blockforge.outofspec.binding.BindingCastingMod;
import cn.blockforge.outofspec.binding.BindingCastingState;
import cn.blockforge.outofspec.binding.BindingContract;
import cn.blockforge.outofspec.spellcraft.model.CastPlanRequest;
import cn.blockforge.outofspec.spellcraft.model.CastPlanResolver;
import cn.blockforge.outofspec.spellcraft.model.CastingRecipeRegistry;
import cn.blockforge.outofspec.spellcraft.model.EffectContribution;
import cn.blockforge.outofspec.spellcraft.model.EffectOperation;
import cn.blockforge.outofspec.spellcraft.model.EffectParameter;
import cn.blockforge.outofspec.spellcraft.model.EffectSource;
import cn.blockforge.outofspec.spellcraft.model.EffectUnit;
import cn.blockforge.outofspec.spellcraft.model.PlanResolution;
import cn.blockforge.outofspec.spellcraft.model.RealSealCastingRecipes;
import cn.blockforge.outofspec.spellcraft.model.ResolvedCastPlan;
import cn.blockforge.outofspec.spellcraft.model.ServerBindingSnapshot;
import cn.blockforge.outofspec.spellcraft.model.ServerCastContext;
import cn.blockforge.outofspec.spellcraft.model.SpellRecipe;
import cn.blockforge.outofspec.spellcraft.runtime.SealedCastEffectState;
import cn.blockforge.outofspec.spellcraft.growth.SpellGrowthService;
import io.redspace.ironsspellbooks.api.magic.MagicData;
import io.redspace.ironsspellbooks.api.registry.SpellRegistry;
import io.redspace.ironsspellbooks.api.spells.AbstractSpell;
import io.redspace.ironsspellbooks.api.spells.CastSource;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;

/** Server-authoritative seal-to-Iron's-Spells casting channel. */
public final class SealCastingNetwork {
    private static final String PROTOCOL = "1";
    private static final int MAX_ADDITIONS = 32;
    private static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(BindingCastingMod.MOD_ID, "seal_cast"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);
    private static final CastPlanResolver RESOLVER = new CastPlanResolver();
    private static final Map<UUID, LinkedHashMap<UUID, Boolean>> SEEN_REQUESTS = new LinkedHashMap<>();
    private static final Map<UUID, PendingTerminal> PENDING_TERMINALS = new LinkedHashMap<>();
    private static boolean registered;

    private SealCastingNetwork() {}

    public static void register() {
        if (registered) return;
        registered = true;
        CHANNEL.registerMessage(0, CastPlanPacket.class, CastPlanPacket::encode,
                CastPlanPacket::decode, CastPlanPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(1, CastPlanStatusPacket.class, CastPlanStatusPacket::encode,
                CastPlanStatusPacket::decode, CastPlanStatusPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
    }

    public static void submit(CastPlanRequest request) {
        if (request == null) return;
        CHANNEL.sendToServer(new CastPlanPacket(request.requestId(), request.recipeId(), request.selectedAdditionalSealIds()));
    }

    /**
     * Clears session-scoped request bookkeeping when a server player logs out.
     * This is public because the Forge lifecycle subscriber lives in the parent
     * {@code cn.blockforge.outofspec.binding} package rather than this network package.
     */
    public static synchronized void forgetPlayer(UUID playerId) {
        SEEN_REQUESTS.remove(playerId);
        PENDING_TERMINALS.values().removeIf(pending -> pending.playerId().equals(playerId));
        // Request IDs are intentionally session-scoped.
    }

    private static synchronized boolean claimRequest(UUID playerId, UUID requestId) {
        LinkedHashMap<UUID, Boolean> seen = SEEN_REQUESTS.computeIfAbsent(playerId, ignored -> new LinkedHashMap<>());
        if (seen.containsKey(requestId)) return false;
        seen.put(requestId, Boolean.TRUE);
        while (seen.size() > 256) seen.remove(seen.keySet().iterator().next());
        return true;
    }

    private static void sendStatus(ServerPlayer player, UUID requestId, boolean accepted,
                                   boolean recoverable, String spellId, String message) {
        sendStatus(player, requestId, accepted, recoverable, false, spellId, message);
    }

    private static void sendStatus(ServerPlayer player, UUID requestId, boolean accepted,
                                   boolean recoverable, boolean terminal, String spellId, String message) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new CastPlanStatusPacket(requestId, accepted, recoverable, terminal,
                        spellId == null ? "" : spellId, message == null ? "" : message));
    }

    /** Called after the actual spell executor returns, or when a submitted cast is interrupted. */
    public static synchronized void notifyCastFinished(ServerPlayer player, UUID requestId, boolean completed,
                                                         String message, String spellId) {
        if (player == null || requestId == null) return;
        // Queue terminal status until END of a server tick. A spell with an immediate/synchronous
        // release must not send its terminal packet before the initial accepted packet.
        PENDING_TERMINALS.put(requestId, new PendingTerminal(player.getUUID(), completed,
                message == null ? "" : message, spellId == null ? "" : spellId));
    }

    public static synchronized void flushPendingCastFinished(ServerPlayer player) {
        if (player == null || PENDING_TERMINALS.isEmpty()) return;
        var iterator = PENDING_TERMINALS.entrySet().iterator();
        while (iterator.hasNext()) {
            var entry = iterator.next();
            PendingTerminal pending = entry.getValue();
            if (!pending.playerId().equals(player.getUUID())) continue;
            iterator.remove();
            sendStatus(player, entry.getKey(), pending.completed(), false, true,
                    pending.spellId(), pending.message());
        }
    }

    private record PendingTerminal(UUID playerId, boolean completed, String message, String spellId) {}

    private static void handleCastRequest(CastPlanPacket packet, ServerPlayer player) {
        if (!claimRequest(player.getUUID(), packet.requestId())) {
            // A duplicate must not send a second response with the same ID: doing so could turn a
            // still-running legitimate client session into a rejection after its first acceptance.
            return;
        }
        if (packet.additionalSealIds().size() > MAX_ADDITIONS) {
            sendStatus(player, packet.requestId(), false, true, "", "追加印数量超过安全限制，未施法。");
            return;
        }
        if (MagicData.getPlayerMagicData(player).isCasting()) {
            sendStatus(player, packet.requestId(), false, true, "", "你正在进行另一场 Iron's Spells 施法；当前结印方案未起手，请等当前施法结束后重试。");
            return;
        }
        if (SealedCastEffectState.hasPending(player)) {
            sendStatus(player, packet.requestId(), false, true, "", "上一笔结印效果仍处于结算状态，服务器拒绝并发施法。");
            return;
        }

        final CastPlanRequest request;
        try {
            request = new CastPlanRequest(packet.requestId(), packet.recipeId(), packet.additionalSealIds());
        } catch (RuntimeException invalidRequest) {
            sendStatus(player, packet.requestId(), false, true, "", "施法请求格式无效：" + safeMessage(invalidRequest));
            return;
        }
        long tick = Math.max(0L, player.level().getGameTime());
        ServerBindingSnapshot bindingSnapshot = buildBindingSnapshot(player);
        CastingRecipeRegistry recipes = RealSealCastingRecipes.registry();
        for (String additionId : packet.additionalSealIds()) {
            if (!SpellGrowthService.isAdditionalSealLearned(player, additionId)) {
                sendStatus(player, packet.requestId(), false, true, "",
                        "尚未掌握这枚追加印：「" + RealSealCastingRecipes.additionName(additionId)
                                + "」。请先在 SAO Menu → 技能 → 追加印研究中学习。未施法，也未消耗资源。");
                return;
            }
        }
        PlanResolution resolution;
        try {
            resolution = RESOLVER.resolve(request, recipes,
                    new ServerCastContext(player.getUUID(), bindingSnapshot, tick));
        } catch (RuntimeException invalidPlan) {
            sendStatus(player, packet.requestId(), false, true, "", "服务端无法解析这份施法方案：" + safeMessage(invalidPlan));
            return;
        }
        if (!resolution.accepted()) {
            sendStatus(player, packet.requestId(), false, true, "", "服务端拒绝施法方案：" + resolution.message());
            return;
        }

        ResolvedCastPlan plan = resolution.plan();
        SpellRecipe recipe = recipes.recipe(plan.recipeId());
        if (recipe == null || !isExecutablePlan(plan)) {
            sendStatus(player, packet.requestId(), false, true, plan.spellId(),
                    "该方案包含尚未接入真实执行器的追加效果；未施法，也未扣除施法资源。");
            return;
        }

        AbstractSpell spell = SpellRegistry.getSpell(plan.spellId());
        if (spell == null || !plan.spellId().equals(spell.getSpellId()) || !spell.isEnabled()) {
            sendStatus(player, packet.requestId(), false, true, plan.spellId(),
                    "注册表中找不到可用的 Iron's Spells 法术 " + plan.spellId() + "；未施法。");
            return;
        }
        if (BindingCastingState.isSpellPermanentlyBlocked(player, plan.spellId())) {
            sendStatus(player, packet.requestId(), false, true, plan.spellId(),
                    "该法术已被生效中的永久束缚封存；没有起手，也没有重复扣费。");
            return;
        }
        // OUT OF SPEC research is the source of truth for every growth-enabled seal recipe.
        // A physical Iron's Spells book is not required, but its legacy learned flag cannot bypass research.
        if (!SpellGrowthService.isLearned(player, plan.spellId())) {
            sendStatus(player, packet.requestId(), false, true, plan.spellId(),
                    "尚未掌握该术式。请获得对应卷轴，在术式研究档案中成功学习后再结印；施法不再要求装备法术书。");
            return;
        }
        int requiredTicks = BindingCastingState.requiredPreparationTicks(player, plan.spellId());
        if (requiredTicks > BindingCastingState.castingPreparationProgressTicks(player)) {
            sendStatus(player, packet.requestId(), false, true, plan.spellId(),
                    "束缚前置条件未完成：请潜行、站在地面上并保持静止 "
                            + BindingContract.format(requiredTicks / 20.0) + " 秒后再提交。");
            return;
        }

        if (!SealedCastEffectState.begin(player, plan)) {
            sendStatus(player, packet.requestId(), false, true, plan.spellId(),
                    "无法建立本次追加印效果状态；没有启动法术。");
            return;
        }
        int spellLevel = SpellGrowthService.level(player, plan.spellId());
        boolean started;
        try {
            // CastSource.SPELLBOOK is used only for Iron's Spells mana/cooldown semantics; no physical
            // spellbook slot is required. The slot token is an OUT OF SPEC virtual source identifier.
            started = spell.attemptInitiateCast(ItemStack.EMPTY, spellLevel, player.serverLevel(), player,
                    CastSource.SPELLBOOK, true, "out_of_spec_growth");
        } catch (RuntimeException castFailure) {
            SealedCastEffectState.clear(player);
            sendStatus(player, packet.requestId(), false, true, plan.spellId(),
                    "Iron's Spells 在正式起手时抛出异常：" + safeMessage(castFailure) + "。已清除本次追加效果状态。");
            return;
        }
        if (!started) {
            SealedCastEffectState.clear(player);
            sendStatus(player, packet.requestId(), false, true, plan.spellId(),
                    "Iron's Spells 拒绝起手。请检查是否已学习法术、魔力、冷却、目标及束缚前置条件；没有应用追加效果。");
            return;
        }
        boolean quickReleaseApplied = plan.effects().stream().anyMatch(applied ->
                applied.contribution().source() == cn.blockforge.outofspec.spellcraft.model.EffectSource.ADDITIONAL_SEAL
                        && applied.contribution().ownerId().equals(RealSealCastingRecipes.QUICK_RELEASE));
        String castTimingFeedback = "";
        if (quickReleaseApplied) {
            int baseTicks = Math.max(0, spell.getCastTime(spellLevel));
            int effectiveTicks = Math.max(0, spell.getEffectiveCastTime(spellLevel, player));
            castTimingFeedback = "【迅捷起印】基础 " + baseTicks + " tick → 本次有效 " + effectiveTicks
                    + " tick（已应用 ×0.50；如果基础时间为 0-1 tick，游戏计时粒度会让缩短不明显）。";
            player.displayClientMessage(Component.literal("迅捷起印已启用：基础 " + baseTicks + " tick → 本次有效 "
                    + effectiveTicks + " tick；持续施法的实际缩短会更明显。"), true);
        }
        sendStatus(player, packet.requestId(), true, false, plan.spellId(),
                "服务端已通过结印方案并成功启动 " + RealSealCastingRecipes.spellName(plan.recipeId())
                        + "。Iron's Spells 负责后续施法时间、资源、冷却和释放。" + castTimingFeedback);
    }

    private static boolean isExecutablePlan(ResolvedCastPlan plan) {
        for (var applied : plan.effects()) {
            EffectContribution effect = applied.contribution();
            if (effect.source() == EffectSource.ADDITIONAL_SEAL
                    && !SealedCastEffectState.isExecutableAdditionalEffect(effect, plan.spellId())) return false;
            // Binding effects are retained in the plan for traceability. Their existing Stage 3.8
            // server Mixin/event executors remain the execution owners; do not apply them twice here.
        }
        return true;
    }

    /** Snapshot real server contract state for plan audit; never supplied by the client. */
    private static ServerBindingSnapshot buildBindingSnapshot(ServerPlayer player) {
        List<String> activeIds = new ArrayList<>();
        List<EffectContribution> effects = new ArrayList<>();
        List<BindingContract> contracts = BindingCastingState.getEffectContracts(player);
        for (int i = 0; i < contracts.size(); i++) {
            BindingContract contract = contracts.get(i);
            String owner = contractOwnerId(contract, i);
            activeIds.add(owner);
            if (!contract.healthConditionMet(player.getHealth(), player.getMaxHealth())) continue;
            addBindingModifier(effects, owner, "spell_power", contract.spellPowerDeltaPct(),
                    contract.spellPowerMultiplier(), contract.spellPowerScopeId(), EffectParameter.SPELL_POWER);
            addBindingModifier(effects, owner, "cast_time", contract.castTimeDeltaPct(),
                    contract.castTimeMultiplier(), "*", EffectParameter.CAST_TIME_TICKS);
            addBindingModifier(effects, owner, "move_speed", contract.moveSpeedDeltaPct(),
                    1.0 + contract.moveSpeedDeltaPct() / 100.0, contract.moveSpeedScopeId(), EffectParameter.CAST_MOVE_SPEED);
            addBindingModifier(effects, owner, "mana_cost", contract.manaCostDeltaPct(),
                    contract.manaCostMultiplier(), "*", EffectParameter.MANA_COST);
            addBindingModifier(effects, owner, "cooldown", contract.cooldownDeltaPct(),
                    contract.cooldownMultiplier(), "*", EffectParameter.COOLDOWN_TICKS);
            // Persistent/timed damage rewards are already executed by the Stage 3.8 SpellDamageEvent
            // hook. Next-cast rewards are event-armed later in Iron's Spells cast lifecycle.
            if (contract.hasDamageReward() && !BindingContract.MODE_NONE.equals(contract.damageMode())
                    && !BindingContract.MODE_NEXT_CAST.equals(contract.damageMode())
                    && contract.spellDamageMultiplier() > 1.000001) {
                effects.add(new EffectContribution("damage_reward", EffectSource.BINDING_REWARD, owner,
                        contract.spellScopeId(), EffectParameter.DAMAGE, EffectOperation.MULTIPLY,
                        EffectUnit.MULTIPLIER, contract.spellDamageMultiplier()));
            }
        }
        return new ServerBindingSnapshot(activeIds, effects);
    }

    private static void addBindingModifier(List<EffectContribution> target, String owner, String suffix,
                                           double deltaPct, double multiplier, String spellScope,
                                           EffectParameter parameter) {
        if (Math.abs(deltaPct) < 0.001) return;
        if (!Double.isFinite(multiplier) || multiplier < 0.0) return; // The legacy executor owns runtime handling.
        EffectSource source = deltaPct > 0
                ? (parameter == EffectParameter.CAST_TIME_TICKS || parameter == EffectParameter.MANA_COST
                   || parameter == EffectParameter.COOLDOWN_TICKS ? EffectSource.BINDING_COST : EffectSource.BINDING_REWARD)
                : (parameter == EffectParameter.CAST_TIME_TICKS || parameter == EffectParameter.MANA_COST
                   || parameter == EffectParameter.COOLDOWN_TICKS ? EffectSource.BINDING_REWARD : EffectSource.BINDING_COST);
        target.add(new EffectContribution(suffix, source, owner, spellScope, parameter,
                EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, multiplier));
    }

    private static String contractOwnerId(BindingContract contract, int index) {
        String canonical = index + "|" + contract.source() + "|" + contract.spellPowerDeltaPct() + "|"
                + contract.moveSpeedDeltaPct() + "|" + contract.castTimeDeltaPct() + "|"
                + contract.manaCostDeltaPct() + "|" + contract.cooldownDeltaPct() + "|"
                + contract.spellScopeId() + "|" + contract.spellPowerScopeId();
        try {
            String hash = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256")
                    .digest(canonical.getBytes(StandardCharsets.UTF_8))).substring(0, 12);
            return "out_of_spec_binding:contract_" + index + "_" + hash;
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException("SHA-256 is required by Java 17", impossible);
        }
    }

    private static String safeMessage(Throwable throwable) {
        String message = throwable.getMessage();
        if (message == null || message.isBlank()) return throwable.getClass().getSimpleName();
        return message.length() > 300 ? message.substring(0, 300) : message;
    }

    private record CastPlanPacket(UUID requestId, String recipeId, List<String> additionalSealIds) {
        private CastPlanPacket {
            if (requestId == null) throw new IllegalArgumentException("requestId is required");
            if (recipeId == null || recipeId.isBlank() || recipeId.length() > 256) throw new IllegalArgumentException("recipeId is invalid");
            additionalSealIds = List.copyOf(additionalSealIds);
            if (additionalSealIds.size() > MAX_ADDITIONS) throw new IllegalArgumentException("too many additional seals");
        }
        private void encode(FriendlyByteBuf buffer) {
            buffer.writeUUID(requestId);
            buffer.writeUtf(recipeId, 256);
            buffer.writeVarInt(additionalSealIds.size());
            for (String id : additionalSealIds) buffer.writeUtf(id, 256);
        }
        private static CastPlanPacket decode(FriendlyByteBuf buffer) {
            UUID requestId = buffer.readUUID();
            String recipeId = buffer.readUtf(256);
            int count = buffer.readVarInt();
            if (count < 0 || count > MAX_ADDITIONS) throw new IllegalArgumentException("additional seal count outside protocol limit");
            List<String> additions = new ArrayList<>(count);
            for (int i = 0; i < count; i++) additions.add(buffer.readUtf(256));
            return new CastPlanPacket(requestId, recipeId, additions);
        }
        private static void handle(CastPlanPacket packet, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> {
                ServerPlayer player = context.getSender();
                if (player != null) handleCastRequest(packet, player);
            });
            context.setPacketHandled(true);
        }
    }

    private record CastPlanStatusPacket(UUID requestId, boolean accepted, boolean recoverable,
                                        boolean terminal, String spellId, String message) {
        private void encode(FriendlyByteBuf buffer) {
            buffer.writeUUID(requestId);
            buffer.writeBoolean(accepted);
            buffer.writeBoolean(recoverable);
            buffer.writeBoolean(terminal);
            buffer.writeUtf(spellId == null ? "" : spellId, 256);
            buffer.writeUtf(message == null ? "" : message, 1024);
        }
        private static CastPlanStatusPacket decode(FriendlyByteBuf buffer) {
            return new CastPlanStatusPacket(buffer.readUUID(), buffer.readBoolean(), buffer.readBoolean(),
                    buffer.readBoolean(), buffer.readUtf(256), buffer.readUtf(1024));
        }
        private static void handle(CastPlanStatusPacket packet, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                    cn.blockforge.outofspec.binding.client.SealInputDebugClient.receiveCastResult(
                            packet.requestId(), packet.accepted(), packet.recoverable(), packet.terminal(),
                            packet.spellId(), packet.message())));
            context.setPacketHandled(true);
        }
    }
}
