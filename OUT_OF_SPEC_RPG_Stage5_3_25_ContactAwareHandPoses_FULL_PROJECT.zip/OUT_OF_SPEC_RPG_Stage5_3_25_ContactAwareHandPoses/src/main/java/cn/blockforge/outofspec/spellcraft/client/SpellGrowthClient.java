package cn.blockforge.outofspec.spellcraft.client;

import cn.blockforge.outofspec.spellcraft.network.SpellGrowthNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;

/** Client display cache only. The server remains the source of truth for every action and progress value. */
public final class SpellGrowthClient {
    private static CompoundTag snapshot = new CompoundTag();
    private static String lastMessage = "尚未执行操作。";
    private static boolean lastActionSucceeded;

    private SpellGrowthClient() {}

    /** Direct item entry point; closing the screen returns to the game. */
    public static void openGrimoire() { open(SpellGrowthScreen.Mode.GRIMOIRE, null); }

    /** SAO Menu entry points preserve the menu as the parent screen, just like the Binding Contract terminal. */
    public static void openResearch(Screen parent) { open(SpellGrowthScreen.Mode.RESEARCH, parent); }
    public static void openGrowth(Screen parent) { open(SpellGrowthScreen.Mode.GROWTH, parent); }
    public static void openCodex(Screen parent) { open(SpellGrowthScreen.Mode.CODEX, parent); }
    public static void openAdditionalSeals(Screen parent) { open(SpellGrowthScreen.Mode.ADDITIONS, parent); }
    public static void openGrimoire(Screen parent) { open(SpellGrowthScreen.Mode.GRIMOIRE, parent); }

    private static void open(SpellGrowthScreen.Mode mode, Screen parent) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        mc.setScreen(new SpellGrowthScreen(mode, parent));
        SpellGrowthNetwork.requestSnapshot();
    }

    public static CompoundTag snapshot() { return snapshot.copy(); }
    public static String lastMessage() { return lastMessage; }
    public static boolean lastActionSucceeded() { return lastActionSucceeded; }

    public static void receiveSnapshot(CompoundTag received) {
        snapshot = received == null ? new CompoundTag() : received.copy();
    }

    public static void receiveAction(boolean success, String message, CompoundTag received) {
        lastActionSucceeded = success;
        lastMessage = message == null ? "" : message;
        if (received != null) snapshot = received.copy();
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(Component.literal(lastMessage), true);
    }
}
