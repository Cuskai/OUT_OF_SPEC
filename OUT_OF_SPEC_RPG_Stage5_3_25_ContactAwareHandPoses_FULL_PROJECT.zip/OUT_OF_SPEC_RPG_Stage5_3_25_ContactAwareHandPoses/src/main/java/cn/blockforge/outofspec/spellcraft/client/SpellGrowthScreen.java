package cn.blockforge.outofspec.spellcraft.client;

import cn.blockforge.outofspec.spellcraft.growth.SpellGrowthBranch;
import cn.blockforge.outofspec.spellcraft.network.SpellGrowthNetwork;
import cn.blockforge.outofspec.spellcraft.item.SpellGrowthItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Three independent information screens plus the optional-grimoire casting panel. */
public final class SpellGrowthScreen extends Screen {
    public enum Mode { RESEARCH, GROWTH, CODEX, GRIMOIRE, ADDITIONS }

    // A dark astral palette: ink-blue panels, cold arcane cyan, violet sigils and antique-gold emphasis.
    private static final int PANEL = 0xF0080A18;
    private static final int PANEL_INNER = 0xE8111428;
    private static final int ACCENT = 0xFF87E1FF;
    private static final int VIOLET = 0xFFC29BFF;
    private static final int GOLD = 0xFFFFD98D;
    private static final int TEXT = 0xFFF3F0FF;
    private static final int MUTED = 0xFFAAA8C8;
    private static final int GOOD = 0xFF8BE0AB;
    private static final int WARN = 0xFFFFC879;
    private static final int BAD = 0xFFFF8888;
    private static final int PANEL_W = 552;
    private static final int PANEL_H = 310;
    private static final ResourceLocation RITUAL_SEAL_TEXTURE = new ResourceLocation(
            "out_of_spec_binding", "textures/gui/ritual_seal.png");
    private final Mode mode;
    private final Screen parent;
    private int selectedIndex;
    private SpellGrowthBranch selectedBranch = SpellGrowthBranch.REFINEMENT;
    private String bookPrimaryId = "";
    private String bookSecondaryId = "";
    private int snapshotRefreshTicks;
    private int listScroll;
    private static final int LIST_ROW_HEIGHT = 30;
    private static final int LIST_VISIBLE_ROWS = 7;

    public SpellGrowthScreen(Mode mode) {
        this(mode, null);
    }

    public SpellGrowthScreen(Mode mode, Screen parent) {
        super(Component.literal(titleFor(mode)));
        this.mode = mode == null ? Mode.RESEARCH : mode;
        this.parent = parent;
    }

    private static String titleFor(Mode mode) {
        if (mode == null) return "术式终端";
        return switch (mode) {
            case RESEARCH -> "术式研究档案";
            case GROWTH -> "术式成长终端";
            case CODEX -> "结印图鉴";
            case GRIMOIRE -> "奥术法术书";
            case ADDITIONS -> "追加印研究";
        };
    }

    @Override
    public void tick() {
        super.tick();
        if ((mode == Mode.RESEARCH || mode == Mode.ADDITIONS || mode == Mode.GROWTH || mode == Mode.GRIMOIRE)
                && ++snapshotRefreshTicks >= 20) {
            snapshotRefreshTicks = 0;
            SpellGrowthNetwork.requestSnapshot();
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        int x = (this.width - PANEL_W) / 2;
        int y = (this.height - PANEL_H) / 2;
        drawAstralFrame(graphics, x, y, PANEL_W, PANEL_H);
        graphics.fill(x + 8, y + 35, x + 158, y + PANEL_H - 34, PANEL_INNER);
        graphics.fill(x + 166, y + 35, x + PANEL_W - 8, y + PANEL_H - 34, PANEL_INNER);
        // The hand-designed transparent sigil is a watermark beneath the spell details, never a full-screen image.
        graphics.blit(RITUAL_SEAL_TEXTURE, x + PANEL_W - 132, y + 72, 108, 108,
                0.0F, 0.0F, 256, 256, 256, 256);
        drawFrame(graphics, x + 8, y + 35, 150, PANEL_H - 69, 0xFF3B335C);
        drawFrame(graphics, x + 166, y + 35, PANEL_W - 174, PANEL_H - 69, 0xFF3B335C);
        graphics.drawString(this.font, Component.literal("⟡  " + titleFor(mode)), x + 14, y + 10, ACCENT, false);
        drawHeaderSigil(graphics, x + PANEL_W / 2, y + 20);
        String seal = switch (mode) {
            case RESEARCH -> "ARCANE ARCHIVE";
            case GROWTH -> "PATH OF ASCENSION";
            case CODEX -> "SEAL CODEX";
            case GRIMOIRE -> "GRIMOIRE BINDING";
            case ADDITIONS -> "ADVANCED SIGILS";
        };
        graphics.drawString(this.font, Component.literal(seal), x + PANEL_W - this.font.width(seal) - 34,
                y + 12, VIOLET, false);
        graphics.drawString(this.font, Component.literal("⟐"), x + PANEL_W - 22, y + 8, GOLD, false);
        graphics.drawString(this.font, Component.literal(mode == Mode.ADDITIONS ? "已知纹章" : "术式铭录"), x + 15, y + 39, GOLD, false);
        graphics.fill(x + 15, y + 50, x + 151, y + 51, 0xFF38314F);
        graphics.fill(x + 175, y + 50, x + PANEL_W - 20, y + 51, 0xFF38314F);

        List<CompoundTag> rows = visibleRows();
        ensureSelectionVisible(rows);
        int end = Math.min(rows.size(), listScroll + LIST_VISIBLE_ROWS);
        for (int i = listScroll; i < end; i++) {
            CompoundTag row = rows.get(i);
            int rowY = y + 54 + (i - listScroll) * LIST_ROW_HEIGHT;
            boolean selected = i == selectedIndex;
            if (selected) {
                graphics.fill(x + 12, rowY - 4, x + 154, rowY + 24, 0xD52C244A);
                graphics.fill(x + 12, rowY - 4, x + 14, rowY + 24, VIOLET);
                graphics.fill(x + 14, rowY + 23, x + 153, rowY + 24, 0xFF66518B);
            }
            int tierColor = mode == Mode.ADDITIONS ? (row.getBoolean("learned") ? GOLD : VIOLET)
                    : "下阶".equals(row.getString("tier")) ? MUTED
                    : "中阶".equals(row.getString("tier")) ? ACCENT
                    : "上阶".equals(row.getString("tier")) ? VIOLET : GOLD;
            graphics.drawString(this.font, Component.literal("◇"), x + 17, rowY + 1, selected ? GOLD : tierColor, false);
            graphics.drawString(this.font, Component.literal(fitLabel(displayName(row), 111)), x + 29, rowY, selected ? TEXT : MUTED, false);
            String status = mode == Mode.ADDITIONS ? (row.getBoolean("learned") ? "已掌握" : "待研究")
                    : !row.getBoolean("available") ? "服务器已禁用" : mode == Mode.RESEARCH
                    ? (row.getBoolean("learned") ? "已掌握" : row.getBoolean("discovered") ? "待研究" : "未发现")
                    : "Lv." + Math.max(1, row.getInt("level"));
            graphics.drawString(this.font, Component.literal(row.getString("tier") + "  /  " + status), x + 29, rowY + 12,
                    mode == Mode.RESEARCH && !row.getBoolean("discovered") ? MUTED : tierColor, false);
        }
        if (rows.isEmpty()) {
            String emptyMessage = switch (mode) {
                case RESEARCH -> "尚未发现术式。获得任意已启用注册术式的卷轴并放入物品栏后，会自动记录术式发现。";
                case GROWTH -> "尚无已掌握法术。先在研究档案中学习术式。";
                case CODEX -> "尚无已掌握法术的结印记录。";
                case GRIMOIRE -> "尚无已掌握法术可编入法术书。";
                case ADDITIONS -> "追加印不是默认能力。先掌握基础术式，再投入奥术核心与紫水晶，完成纹章研究。";
            };
            drawWrapped(graphics, emptyMessage, x + 18, y + 68, 124, MUTED, 10);
        }
        CompoundTag selected = rows.isEmpty() ? null : rows.get(selectedIndex);
        renderDetails(graphics, selected, x, y);
        renderFooter(graphics, x, y);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    private void renderDetails(GuiGraphics graphics, CompoundTag row, int x, int y) {
        int left = x + 178;
        int width = PANEL_W - 194;
        if (row == null) {
            if (mode == Mode.RESEARCH) {
                drawWrapped(graphics, "研究档案自动索引 Iron's Spells 注册表中当前启用的法术，包含全部原版法术及向同一注册表添加术式的兼容扩展。", left, y + 48, width, TEXT, 12);
                drawWrapped(graphics, "任何匹配术式 ID 的原版卷轴或 OUT OF SPEC 卷轴都能进入研究流程；法术书不是学习前置。", left, y + 105, width, ACCENT, 12);
                drawWrapped(graphics, "放入背包后会自动发现；空白卷轴或没有对应法术数据的容器不会被误判。若未出现，可执行 /oosgrowth scan 或 /oosgrowth diagnose。", left, y + 162, width, MUTED, 12);
            } else {
                drawWrapped(graphics, "选择左侧术式查看详细信息。", left, y + 48, width, MUTED, 12);
            }
            return;
        }
        graphics.drawString(this.font, Component.literal(displayName(row)), left, y + 41, TEXT, false);
        graphics.drawString(this.font, Component.literal("术式阶级：" + row.getString("tier")), left, y + 57, ACCENT, false);
        drawWrapped(graphics, row.getString("role"), left, y + 75, width, MUTED, 11);
        if (mode != Mode.ADDITIONS && !row.getBoolean("available") && mode != Mode.RESEARCH) {
            drawWrapped(graphics, "该术式仍保留在角色档案中，但当前服务端配置已禁用它。你可以继续查看记录，不能升级、编入法术书或施放。", left, y + 111, width, WARN, 11);
            return;
        }

        switch (mode) {
            case RESEARCH -> renderResearchDetails(graphics, row, left, width, y);
            case GROWTH -> renderGrowthDetails(graphics, row, left, width, y);
            case CODEX -> renderCodexDetails(graphics, row, left, width, y);
            case GRIMOIRE -> renderGrimoireDetails(graphics, row, left, width, y);
            case ADDITIONS -> renderAdditionalSealDetails(graphics, row, left, width, y);
        }
        renderButtons(graphics, row, x, y);
    }

    private void renderResearchDetails(GuiGraphics graphics, CompoundTag row, int left, int width, int y) {
        if (!row.getBoolean("available")) {
            drawWrapped(graphics, "这个术式存在于注册目录，但当前服务器配置将它禁用。发现记录可以保留；研究和结印施放会被服务器拒绝。", left, y + 111, width, WARN, 11);
            graphics.drawString(this.font, Component.literal("匹配卷轴库存：" + row.getInt("scroll_count")), left, y + 164, TEXT, false);
            return;
        }
        String state = row.getBoolean("learned") ? "已掌握：学习记录永久保留。"
                : row.getBoolean("discovered") ? "已发现：仍需消耗卷轴尝试研究。"
                : "未发现：获得对应卷轴后会自动记录术式。";
        drawWrapped(graphics, state, left, y + 111, width, row.getBoolean("learned") ? GOOD : TEXT, 11);
        graphics.drawString(this.font, Component.literal("卷轴库存：" + row.getInt("scroll_count")), left, y + 143, TEXT, false);
        graphics.drawString(this.font, Component.literal("基础成功率：" + row.getInt("chance") + "%"), left + 118, y + 143, WARN, false);
        graphics.drawString(this.font, Component.literal("奥术核心辅助：" + row.getInt("chance_core") + "%（消耗 1 核心）"), left, y + 160, MUTED, false);
        drawWrapped(graphics, "确认学习后卷轴会消耗；失败仍保留发现记录，但必须重新获得卷轴才能再试。", left, y + 179, width, WARN, 11);
    }

    private void renderGrowthDetails(GuiGraphics graphics, CompoundTag row, int left, int width, int y) {
        if (!row.getBoolean("learned")) {
            drawWrapped(graphics, "先在术式研究档案中成功学习这个术式。", left, y + 112, width, WARN, 11);
            return;
        }
        int level = Math.max(1, row.getInt("level"));
        int proficiency = row.getInt("proficiency");
        int needed = row.getInt("next_required");
        graphics.drawString(this.font, Component.literal("当前等级：Lv." + level + " / " + row.getInt("max_level")), left, y + 111, TEXT, false);
        graphics.drawString(this.font, Component.literal("熟练度：" + proficiency + (needed > 0 ? " / " + needed : "（已满级）")), left, y + 128, TEXT, false);
        if (needed > 0) {
            int barW = Math.min(width - 2, 260);
            graphics.fill(left, y + 145, left + barW, y + 152, 0xFF26384C);
            int fillW = (int) (barW * Math.min(1.0, (double) proficiency / needed));
            if (fillW > 0) graphics.fill(left, y + 145, left + fillW, y + 152, ACCENT);
        }
        graphics.drawString(this.font, Component.literal("已选分支：" + row.getString("branch_name")), left, y + 160, ACCENT, false);
        graphics.drawString(this.font, Component.literal("实战试炼：成功释放或命中 " + row.getInt("challenge_hits") + " / " + row.getInt("challenge_required") + " 次"), left, y + 177, MUTED, false);
        if (level == 3) drawWrapped(graphics, "突破要求熟练度 " + needed + "、成功释放法术或命中目标 " + row.getInt("challenge_required")
                + " 次、奥术核心 ×1、紫水晶碎片 ×" + row.getInt("breakthrough_shard_cost") + "。", left, y + 193, width, WARN, 10);
        else if (level < row.getInt("max_level")) drawWrapped(graphics, "普通升级必须由你主动确认；下一级需要紫水晶碎片 ×" + row.getInt("level_material_cost") + "。", left, y + 193, width, MUTED, 10);
        else drawWrapped(graphics, "当前术式已达到本版本成长上限。", left, y + 193, width, GOOD, 10);
    }

    private void renderCodexDetails(GuiGraphics graphics, CompoundTag row, int left, int width, int y) {
        graphics.drawString(this.font, Component.literal("基础纹章序列"), left, y + 110, GOLD, false);
        drawWrapped(graphics, row.getString("seals"), left, y + 127, width, TEXT, 14);
        graphics.fill(left, y + 149, left + width - 4, y + 150, 0xFF38314F);
        drawWrapped(graphics, "此处记录已经掌握的基础术式。追加印属于可研究的高级技能，请从技能菜单进入「追加印研究」逐枚解锁。", left, y + 162, width, MUTED, 12);
        graphics.drawString(this.font, Component.literal("铭文原则"), left, y + 207, VIOLET, false);
        drawWrapped(graphics, "基础印决定术式；追加印改变本次释放。未掌握的追加印不会进入输入匹配，也不会被服务器接受。", left, y + 222, width, TEXT, 11);
    }

    private void renderAdditionalSealDetails(GuiGraphics graphics, CompoundTag row, int left, int width, int y) {
        graphics.drawString(this.font, Component.literal("✦  " + row.getString("name")), left, y + 108, GOLD, false);
        graphics.drawString(this.font, Component.literal("纹章阶层：" + row.getString("tier")), left, y + 127, VIOLET, false);
        graphics.drawString(this.font, Component.literal("印序：" + row.getString("sequence")), left, y + 146, ACCENT, false);
        graphics.drawString(this.font, Component.literal("效果：" + row.getString("effect")), left, y + 164, GOOD, false);
        graphics.drawString(this.font, Component.literal(fitLabel(row.getString("description"), width)), left, y + 184, TEXT, false);
        graphics.fill(left, y + 198, left + width - 4, y + 199, 0xFF38314F);
        String state = row.getBoolean("learned") ? "✧ 已掌握 · 已刻入个人术式档案"
                : row.getBoolean("can_learn") ? "◇ 条件满足 · 可开始纹章研究"
                : "◇ 尚未掌握 · 前置或媒介不足";
        graphics.drawString(this.font, Component.literal(fitLabel(state, width)), left, y + 207,
                row.getBoolean("learned") ? GOOD : WARN, false);
        graphics.drawString(this.font, Component.literal(fitLabel(row.getString("requirements"), width)), left, y + 224, MUTED, false);
    }

    private void renderGrimoireDetails(GuiGraphics graphics, CompoundTag row, int left, int width, int y) {
        graphics.drawString(this.font, Component.literal("当前选择：" + row.getString("name")), left, y + 112, TEXT, false);
        drawWrapped(graphics, "第一层：" + displaySpellName(bookPrimaryId), left, y + 132, width, ACCENT, 11);
        drawWrapped(graphics, "第二层：" + displaySpellName(bookSecondaryId), left, y + 148, width, ACCENT, 11);
        boolean held = isGrimoireHeld();
        drawWrapped(graphics, held ? "法术书已手持：可使用自动施法或连续叠施。" : "请先手持奥术法术书；普通结印施法不受影响。", left, y + 169, width, held ? GOOD : WARN, 11);
        drawWrapped(graphics, "当前叠加施法为序列式：第一层真实释放后，再尝试第二层；不会伪装成同时融合两个投射物。", left, y + 188, width, MUTED, 10);
    }

    private void renderButtons(GuiGraphics graphics, CompoundTag row, int x, int y) {
        if (mode == Mode.RESEARCH) {
            boolean hasScroll = row.getInt("scroll_count") > 0;
            boolean available = row.getBoolean("available");
            button(graphics, x + 176, y + 245, 143, 24,
                    !available ? "服务器已禁用" : hasScroll ? "开始学习 · " + row.getInt("chance") + "%" : "缺少对应卷轴",
                    available && hasScroll && !row.getBoolean("learned"));
            button(graphics, x + 326, y + 245, 202, 24,
                    "核心辅助学习 · " + row.getInt("chance_core") + "%",
                    available && hasScroll && row.getBoolean("has_core") && !row.getBoolean("learned"));
        } else if (mode == Mode.GROWTH) {
            if (row.getBoolean("available") && row.getInt("level") == 3 && row.getBoolean("learned")) {
                optionButton(graphics, x + 176, y + 219, 111, 20, "精炼型", selectedBranch == SpellGrowthBranch.REFINEMENT);
                optionButton(graphics, x + 292, y + 219, 111, 20, "爆发型", selectedBranch == SpellGrowthBranch.BURST);
                optionButton(graphics, x + 408, y + 219, 120, 20, "操控型", selectedBranch == SpellGrowthBranch.CONTROL);
                button(graphics, x + 176, y + 245, 352, 24, "确认关键突破（需要实战命中与媒介）", row.getBoolean("can_breakthrough"));
            } else {
                button(graphics, x + 176, y + 245, 202, 24, "主动提升等级",
                        row.getBoolean("available") && row.getBoolean("can_level") && row.getBoolean("learned") && row.getInt("level") < row.getInt("max_level"));
            }
        } else if (mode == Mode.ADDITIONS) {
            button(graphics, x + 176, y + 245, 352, 24,
                    row.getBoolean("learned") ? "已掌握 · 已刻入术式档案" : row.getBoolean("can_learn") ? "研究并掌握此追加印" : "前置或媒介不足",
                    row.getBoolean("can_learn") && !row.getBoolean("learned"));
        } else if (mode == Mode.GRIMOIRE) {
            button(graphics, x + 176, y + 217, 169, 20, "设为第一层", row.getBoolean("available") && row.getBoolean("learned"));
            button(graphics, x + 352, y + 217, 176, 20, "设为第二层", row.getBoolean("available") && row.getBoolean("learned"));
            button(graphics, x + 176, y + 243, 169, 26, "自动施法", isGrimoireHeld() && !bookPrimaryId.isBlank());
            button(graphics, x + 352, y + 243, 176, 26, "连续叠施", isGrimoireHeld() && !bookPrimaryId.isBlank() && !bookSecondaryId.isBlank());
        }
    }

    private void renderFooter(GuiGraphics graphics, int x, int y) {
        String message = SpellGrowthClient.lastMessage();
        int color = SpellGrowthClient.lastActionSucceeded() ? GOOD : WARN;
        if (message != null && !message.isBlank()) {
            String clipped = this.font.plainSubstrByWidth(message, PANEL_W - 28);
            graphics.drawString(this.font, Component.literal(clipped), x + 12, y + PANEL_H - 16, color, false);
        } else {
            graphics.drawString(this.font, Component.literal("Esc 关闭 · ↑/↓ 或滚轮翻阅术式 · 状态由服务器确认"), x + 12, y + PANEL_H - 16, MUTED, false);
        }
        List<CompoundTag> rows = visibleRows();
        if (rows.size() > LIST_VISIBLE_ROWS) {
            String page = (listScroll + 1) + "-" + Math.min(rows.size(), listScroll + LIST_VISIBLE_ROWS) + " / " + rows.size();
            graphics.drawString(this.font, Component.literal(page), x + 16, y + PANEL_H - 47, MUTED, false);
        }
    }

    private void button(GuiGraphics graphics, int x, int y, int width, int height, String label, boolean enabled) {
        int background = enabled ? 0xFF25213E : 0xFF151724;
        graphics.fill(x, y, x + width, y + height, background);
        graphics.fill(x, y, x + width, y + 1, enabled ? VIOLET : 0xFF343047);
        graphics.fill(x, y + height - 1, x + width, y + height, enabled ? 0xFF62528C : 0xFF292638);
        graphics.fill(x, y + 2, x + 2, y + height - 2, enabled ? ACCENT : 0xFF343047);
        int textColor = enabled ? TEXT : MUTED;
        int labelWidth = this.font.width(label);
        graphics.drawString(this.font, Component.literal(label), x + Math.max(4, (width - labelWidth) / 2),
                y + (height - 8) / 2, textColor, false);
    }

    private void optionButton(GuiGraphics graphics, int x, int y, int width, int height, String label, boolean selected) {
        int background = selected ? 0xFF393052 : 0xFF151724;
        graphics.fill(x, y, x + width, y + height, background);
        graphics.fill(x, y, x + width, y + 2, selected ? GOLD : 0xFF343047);
        graphics.fill(x, y + height - 1, x + width, y + height, selected ? VIOLET : 0xFF292638);
        int labelWidth = this.font.width(label);
        graphics.drawString(this.font, Component.literal(label), x + Math.max(4, (width - labelWidth) / 2),
                y + (height - 8) / 2, TEXT, false);
    }

    private static void drawAstralFrame(GuiGraphics g, int x, int y, int width, int height) {
        g.fill(x - 4, y - 4, x + width + 4, y + height + 4, 0x8C48352B);
        g.fill(x - 2, y - 2, x + width + 2, y + height + 2, 0xF0060711);
        g.fill(x, y, x + width, y + height, PANEL);
        // Pixel-forged bezel: the corners carry the weight; the rails remain restrained.
        g.fill(x + 4, y, x + width - 4, y + 1, 0xFF211A22);
        g.fill(x + 18, y + 1, x + width - 18, y + 2, 0xFF745539);
        g.fill(x + 20, y + 2, x + width - 20, y + 3, 0xFFB18B55);
        g.fill(x + 20, y + height - 3, x + width - 20, y + height - 2, 0xFF745539);
        g.fill(x + 4, y + height - 1, x + width - 4, y + height, 0xFF211A22);
        g.fill(x, y + 5, x + 1, y + height - 5, 0xFF211A22);
        g.fill(x + 1, y + 18, x + 2, y + height - 18, 0xFF745539);
        g.fill(x + width - 2, y + 18, x + width - 1, y + height - 18, 0xFF745539);
        g.fill(x + width - 1, y + 5, x + width, y + height - 5, 0xFF211A22);
        g.fill(x + 4, y + 4, x + width - 4, y + 5, 0xFF49365B);
        g.fill(x + 4, y + height - 5, x + width - 4, y + height - 4, 0xFF49365B);

        int bronze = 0xFF63472F;
        int brass = 0xFFA7824C;
        int gold = 0xFFD1AC69;
        int violet = 0xFF8D6AC4;
        // Identical stepped corner plates keep all five terminal modes visually coherent.
        g.fill(x + 3, y + 5, x + 18, y + 7, bronze);
        g.fill(x + 5, y + 3, x + 7, y + 18, brass);
        g.fill(x + 7, y + 7, x + 16, y + 9, gold);
        g.fill(x + 7, y + 9, x + 9, y + 16, brass);
        g.fill(x + 10, y + 11, x + 13, y + 13, violet);
        g.fill(x + width - 18, y + 5, x + width - 3, y + 7, bronze);
        g.fill(x + width - 7, y + 3, x + width - 5, y + 18, brass);
        g.fill(x + width - 16, y + 7, x + width - 7, y + 9, gold);
        g.fill(x + width - 9, y + 9, x + width - 7, y + 16, brass);
        g.fill(x + width - 13, y + 11, x + width - 10, y + 13, violet);
        g.fill(x + 3, y + height - 7, x + 18, y + height - 5, bronze);
        g.fill(x + 5, y + height - 18, x + 7, y + height - 3, brass);
        g.fill(x + 7, y + height - 9, x + 16, y + height - 7, gold);
        g.fill(x + 7, y + height - 16, x + 9, y + height - 9, brass);
        g.fill(x + 10, y + height - 13, x + 13, y + height - 11, violet);
        g.fill(x + width - 18, y + height - 7, x + width - 3, y + height - 5, bronze);
        g.fill(x + width - 7, y + height - 18, x + width - 5, y + height - 3, brass);
        g.fill(x + width - 16, y + height - 9, x + width - 7, y + height - 7, gold);
        g.fill(x + width - 9, y + height - 16, x + width - 7, y + height - 9, brass);
        g.fill(x + width - 13, y + height - 13, x + width - 10, y + height - 11, violet);
        g.drawString(net.minecraft.client.Minecraft.getInstance().font, Component.literal("◆"), x + width / 2 - 4, y - 3, VIOLET, false);
        g.fill(x + width / 2 - 14, y + 2, x + width / 2 - 7, y + 3, brass);
        g.fill(x + width / 2 + 7, y + 2, x + width / 2 + 14, y + 3, brass);
        g.drawString(net.minecraft.client.Minecraft.getInstance().font, Component.literal("◆"), x + width / 2 - 4, y + height - 8, GOLD, false);
    }

    private static void drawFrame(GuiGraphics g, int x, int y, int width, int height, int color) {
        g.fill(x, y, x + width, y + 1, color);
        g.fill(x, y + height - 1, x + width, y + height, color);
        g.fill(x, y, x + 1, y + height, color);
        g.fill(x + width - 1, y, x + width, y + height, color);
    }

    /** Small fixed-width ritual mark: architectural line work, not emoji or a generic rounded card. */
    private static void drawHeaderSigil(GuiGraphics g, int cx, int cy) {
        int silver = 0xFF76789A;
        int violet = 0xFF8264B3;
        g.fill(cx - 13, cy, cx - 5, cy + 1, silver);
        g.fill(cx + 5, cy, cx + 13, cy + 1, silver);
        g.fill(cx - 1, cy - 7, cx + 1, cy - 3, violet);
        g.fill(cx - 1, cy + 3, cx + 1, cy + 7, violet);
        g.fill(cx - 3, cy - 1, cx + 3, cy + 1, GOLD);
        g.fill(cx - 1, cy - 3, cx + 1, cy + 3, GOLD);
        g.fill(cx - 10, cy - 4, cx - 7, cy - 3, violet);
        g.fill(cx + 7, cy + 3, cx + 10, cy + 4, violet);
    }

    private void drawWrapped(GuiGraphics graphics, String text, int x, int y, int width, int color, int lineHeight) {
        if (text == null || text.isBlank()) return;
        List<net.minecraft.util.FormattedCharSequence> lines = this.font.split(Component.literal(text), Math.max(20, width));
        int limit = Math.min(lines.size(), 5);
        for (int i = 0; i < limit; i++) graphics.drawString(this.font, lines.get(i), x, y + i * lineHeight, color, false);
    }

    private void ensureSelectionVisible(List<CompoundTag> rows) {
        if (rows.isEmpty()) { selectedIndex = 0; listScroll = 0; return; }
        selectedIndex = Math.max(0, Math.min(selectedIndex, rows.size() - 1));
        int maxScroll = Math.max(0, rows.size() - LIST_VISIBLE_ROWS);
        if (selectedIndex < listScroll) listScroll = selectedIndex;
        if (selectedIndex >= listScroll + LIST_VISIBLE_ROWS) listScroll = selectedIndex - LIST_VISIBLE_ROWS + 1;
        listScroll = Math.max(0, Math.min(listScroll, maxScroll));
    }

    private void scrollSelection(int delta) {
        List<CompoundTag> rows = visibleRows();
        if (rows.isEmpty()) return;
        selectedIndex = Math.max(0, Math.min(rows.size() - 1, selectedIndex + delta));
        ensureSelectionVisible(rows);
    }

    private String fitLabel(String value, int maxWidth) {
        if (value == null) return "";
        if (this.font.width(value) <= maxWidth) return value;
        String suffix = "…";
        return this.font.plainSubstrByWidth(value, Math.max(8, maxWidth - this.font.width(suffix))) + suffix;
    }

    private String displayName(CompoundTag row) {
        String key = row.getString("name_key");
        if (!key.isBlank()) {
            String translated = Component.translatable(key).getString();
            if (translated != null && !translated.isBlank() && !translated.equals(key)) return translated;
        }
        return row.getString("name");
    }

    private List<CompoundTag> visibleRows() {
        CompoundTag snapshot = SpellGrowthClient.snapshot();
        ListTag tags = snapshot.getList(mode == Mode.ADDITIONS ? "additional_seals" : "spells", Tag.TAG_COMPOUND);
        List<CompoundTag> rows = new ArrayList<>();
        for (int i = 0; i < tags.size(); i++) {
            CompoundTag row = tags.getCompound(i);
            if (mode == Mode.ADDITIONS) {
                rows.add(row);
            } else if (mode == Mode.RESEARCH) {
                // Unknown spell names are not revealed until a scroll is found/held.
                if (row.getBoolean("discovered") || row.getBoolean("learned") || row.getInt("scroll_count") > 0) rows.add(row);
            } else if (row.getBoolean("learned")) {
                rows.add(row);
            }
        }
        return rows;
    }

    private CompoundTag selectedRow() {
        List<CompoundTag> rows = visibleRows();
        if (rows.isEmpty()) return null;
        return rows.get(Math.max(0, Math.min(selectedIndex, rows.size() - 1)));
    }

    private String displaySpellName(String spellId) {
        if (spellId == null || spellId.isBlank()) return "未指定";
        for (CompoundTag row : visibleRows()) if (spellId.equals(row.getString("id"))) return displayName(row);
        return spellId;
    }

    private boolean isGrimoireHeld() {
        Minecraft mc = Minecraft.getInstance();
        return mc.player != null && (mc.player.getMainHandItem().is(SpellGrowthItems.ARCANE_GRIMOIRE.get())
                || mc.player.getOffhandItem().is(SpellGrowthItems.ARCANE_GRIMOIRE.get()));
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int x = (this.width - PANEL_W) / 2;
        int y = (this.height - PANEL_H) / 2;
        if (mouseX >= x + PANEL_W - 26 && mouseX <= x + PANEL_W && mouseY >= y && mouseY <= y + 30) {
            this.onClose();
            return true;
        }
        if (mouseX >= x + 12 && mouseX <= x + 154 && mouseY >= y + 51
                && mouseY < y + 51 + LIST_VISIBLE_ROWS * LIST_ROW_HEIGHT) {
            int visibleIndex = (int) ((mouseY - (y + 51)) / LIST_ROW_HEIGHT);
            int index = listScroll + visibleIndex;
            if (visibleIndex >= 0 && visibleIndex < LIST_VISIBLE_ROWS && index < visibleRows().size()) selectedIndex = index;
            return true;
        }
        CompoundTag row = selectedRow();
        if (row == null) return super.mouseClicked(mouseX, mouseY, button);
        String id = row.getString("id");
        if (mode == Mode.ADDITIONS && mouseY >= y + 243 && mouseY <= y + 271
                && mouseX >= x + 176 && mouseX < x + 530) {
            if (row.getBoolean("can_learn") && !row.getBoolean("learned")) SpellGrowthNetwork.learnAdditionalSeal(id);
            return true;
        }
        if (mode == Mode.RESEARCH && mouseY >= y + 243 && mouseY <= y + 271) {
            if (!row.getBoolean("available") || row.getBoolean("learned") || row.getInt("scroll_count") <= 0) return true;
            if (mouseX >= x + 176 && mouseX < x + 322) SpellGrowthNetwork.research(id, false);
            else if (mouseX >= x + 326 && mouseX < x + 530 && row.getBoolean("has_core")) SpellGrowthNetwork.research(id, true);
            return true;
        }
        if (mode == Mode.GROWTH && row.getInt("level") == 3 && row.getBoolean("learned")) {
            if (mouseY >= y + 217 && mouseY <= y + 241) {
                if (mouseX >= x + 176 && mouseX < x + 287) selectedBranch = SpellGrowthBranch.REFINEMENT;
                else if (mouseX >= x + 292 && mouseX < x + 403) selectedBranch = SpellGrowthBranch.BURST;
                else if (mouseX >= x + 408 && mouseX < x + 530) selectedBranch = SpellGrowthBranch.CONTROL;
                return true;
            }
            if (mouseY >= y + 243 && mouseY <= y + 271) {
                SpellGrowthNetwork.breakthrough(id, selectedBranch.name());
                return true;
            }
        } else if (mode == Mode.GROWTH && mouseY >= y + 243 && mouseY <= y + 271
                && mouseX >= x + 176 && mouseX < x + 378) {
            SpellGrowthNetwork.levelUp(id);
            return true;
        }
        if (mode == Mode.GRIMOIRE) {
            if (mouseY >= y + 215 && mouseY <= y + 239) {
                if (mouseX >= x + 176 && mouseX < x + 345) bookPrimaryId = id;
                else if (mouseX >= x + 352 && mouseX < x + 528) bookSecondaryId = id;
                return true;
            }
            if (mouseY >= y + 241 && mouseY <= y + 274) {
                if (mouseX >= x + 176 && mouseX < x + 345 && !bookPrimaryId.isBlank()) {
                    SpellGrowthNetwork.grimoireCast(bookPrimaryId, "");
                } else if (mouseX >= x + 352 && mouseX < x + 528 && !bookPrimaryId.isBlank() && !bookSecondaryId.isBlank()) {
                    SpellGrowthNetwork.grimoireCast(bookPrimaryId, bookSecondaryId);
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        int x = (this.width - PANEL_W) / 2;
        int y = (this.height - PANEL_H) / 2;
        if (mouseX >= x + 8 && mouseX <= x + 160 && mouseY >= y + 49 && mouseY <= y + PANEL_H - 43) {
            List<CompoundTag> rows = visibleRows();
            if (rows.size() > LIST_VISIBLE_ROWS && delta != 0) {
                listScroll = Math.max(0, Math.min(Math.max(0, rows.size() - LIST_VISIBLE_ROWS),
                        listScroll + (delta < 0 ? 1 : -1)));
                selectedIndex = Math.max(listScroll, Math.min(selectedIndex, listScroll + LIST_VISIBLE_ROWS - 1));
                ensureSelectionVisible(rows);
            }
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_UP) { scrollSelection(-1); return true; }
        if (keyCode == GLFW.GLFW_KEY_DOWN) { scrollSelection(1); return true; }
        if (keyCode == GLFW.GLFW_KEY_PAGE_UP) { scrollSelection(-LIST_VISIBLE_ROWS); return true; }
        if (keyCode == GLFW.GLFW_KEY_PAGE_DOWN) { scrollSelection(LIST_VISIBLE_ROWS); return true; }
        if (keyCode == GLFW.GLFW_KEY_HOME) { selectedIndex = 0; ensureSelectionVisible(visibleRows()); return true; }
        if (keyCode == GLFW.GLFW_KEY_END) { selectedIndex = Math.max(0, visibleRows().size() - 1); ensureSelectionVisible(visibleRows()); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void onClose() {
        if (minecraft != null && parent != null) minecraft.setScreen(parent);
        else super.onClose();
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public boolean shouldCloseOnEsc() { return true; }
}
