package cn.blockforge.outofspec.spellcraft.growth;

/** Small, mutually-exclusive breakthrough specializations. Values are intentionally modest. */
public enum SpellGrowthBranch {
    NONE("尚未选择", ""),
    REFINEMENT("精炼型", "spell_growth.out_of_spec.refinement"),
    BURST("爆发型", "spell_growth.out_of_spec.burst"),
    CONTROL("操控型", "spell_growth.out_of_spec.control");

    private final String displayName;
    private final String key;

    SpellGrowthBranch(String displayName, String key) {
        this.displayName = displayName;
        this.key = key;
    }

    public String displayName() { return displayName; }
    public String key() { return key; }

    public static SpellGrowthBranch byId(String id) {
        if (id == null || id.isBlank()) return NONE;
        for (SpellGrowthBranch branch : values()) {
            if (branch.name().equalsIgnoreCase(id)) return branch;
        }
        return NONE;
    }
}
