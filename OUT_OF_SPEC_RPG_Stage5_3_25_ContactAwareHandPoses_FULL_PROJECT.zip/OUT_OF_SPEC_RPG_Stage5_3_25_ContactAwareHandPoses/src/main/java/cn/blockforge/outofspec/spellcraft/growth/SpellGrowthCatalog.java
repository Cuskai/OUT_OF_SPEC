package cn.blockforge.outofspec.spellcraft.growth;

import cn.blockforge.outofspec.spellcraft.model.BasicSeal;
import cn.blockforge.outofspec.spellcraft.model.SealSequence;
import cn.blockforge.outofspec.spellcraft.model.SpellSealSequenceGenerator;
import io.redspace.ironsspellbooks.api.registry.SpellRegistry;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import io.redspace.ironsspellbooks.api.spells.AbstractSpell;
import net.minecraft.resources.ResourceLocation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Single source of truth for every enabled spell registered in Iron's Spells' spell registry.
 * Four long-tested spells keep their curated names, tiers and short seal sequences; all additional
 * registry spells receive stable metadata and unique four-seal recipes at bootstrap.
 */
public final class SpellGrowthCatalog {
    private static final List<SpellGrowthProfile> CURATED_PROFILES = List.of(
            new SpellGrowthProfile("firebolt", "irons_spellbooks:firebolt", "火焰箭",
                    SpellTier.LOWER, 5, "子 → 丑 → 寅", "低成本、快速、适合稳定连续施放"),
            new SpellGrowthProfile("magic_arrow", "irons_spellbooks:magic_arrow", "魔法箭",
                    SpellTier.MIDDLE, 5, "子 → 丑", "基础奥术投射物，成长与资源效率兼顾"),
            new SpellGrowthProfile("fireball", "irons_spellbooks:fireball", "火球术",
                    SpellTier.MIDDLE, 5, "丑 → 巳 → 亥", "范围与战术价值高于单体基础投射物"),
            new SpellGrowthProfile("lightning_lance", "irons_spellbooks:lightning_lance", "雷鸣长枪",
                    SpellTier.UPPER, 5, "寅 → 卯 → 辰", "高威力雷系攻击，需要更高研究准备")
    );
    private static final Map<String, SealSequence> CURATED_SEQUENCES = Map.of(
            "irons_spellbooks:magic_arrow", SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU),
            "irons_spellbooks:firebolt", SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU, BasicSeal.YIN),
            "irons_spellbooks:lightning_lance", SealSequence.of(BasicSeal.YIN, BasicSeal.MAO, BasicSeal.CHEN),
            "irons_spellbooks:fireball", SealSequence.of(BasicSeal.CHOU, BasicSeal.SI, BasicSeal.HAI)
    );

    private static volatile Map<String, SpellGrowthProfile> BY_ID;
    private static volatile Map<String, SpellGrowthProfile> BY_KEY;
    private static volatile Map<String, SealSequence> SEQUENCES;
    private static volatile List<SpellGrowthProfile> PROFILES;
    private static volatile long generation;
    private static volatile int registrySpellCount;

    static {
        publish(CURATED_PROFILES, CURATED_SEQUENCES, false);
    }

    private SpellGrowthCatalog() {}

    /**
     * Called on FMLCommonSetup after mod registries have been populated, then again on server start
     * as a defensive reconciliation pass for spell add-ons that register late.
     * @return number of eligible registered spells in the final growth directory
     */
    public static void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> {
            refreshFromRegistry();
            cn.blockforge.outofspec.spellcraft.model.RealSealCastingRecipes.refresh();
        });
    }

    public static synchronized int refreshFromRegistry() {
        Collection<AbstractSpell> registered;
        try {
            registered = SpellRegistry.REGISTRY.get().getValues();
        } catch (RuntimeException | LinkageError unavailableBeforeRegistry) {
            return PROFILES.size();
        }

        Map<String, AbstractSpell> byId = new LinkedHashMap<>();
        for (AbstractSpell spell : registered) {
            if (spell == null) continue;
            ResourceLocation resource;
            String spellId;
            try {
                resource = spell.getSpellResource();
                spellId = spell.getSpellId();
            } catch (RuntimeException failure) {
                continue;
            }
            if (resource == null || spellId == null || spellId.isBlank()) continue;
            if ("none".equals(resource.getPath()) || "irons_spellbooks:none".equals(spellId)) continue;
            // Include registered spells even when the current config disables them. This keeps
            // client/server generated seal codes identical; availability is exposed separately in
            // the UI and the server remains responsible for refusing disabled spells.
            byId.put(spellId, spell);
        }

        List<String> dynamicIds = byId.keySet().stream()
                .filter(id -> !CURATED_SEQUENCES.containsKey(id))
                .sorted()
                .toList();
        Map<String, SealSequence> generated = SpellSealSequenceGenerator.generate(dynamicIds, CURATED_SEQUENCES.values());
        Map<String, SealSequence> sequences = new LinkedHashMap<>(CURATED_SEQUENCES);
        sequences.putAll(generated);

        List<SpellGrowthProfile> profiles = new ArrayList<>(CURATED_PROFILES);
        for (String id : dynamicIds) {
            AbstractSpell spell = byId.get(id);
            ResourceLocation resource = spell.getSpellResource();
            String key = stableKey(id);
            String displayName = readableName(resource.getPath());
            SpellTier tier = classifyTier(spell, resource.getPath());
            String schoolName = "魔法";
            try {
                if (spell.getSchoolType() != null) {
                    String value = spell.getSchoolType().getDisplayName().getString();
                    if (value != null && !value.isBlank()) schoolName = value;
                }
            } catch (RuntimeException ignored) {
                // School metadata is presentation-only; the spell remains eligible.
            }
            String role = "原版/注册扩展术式 · " + schoolName + "领域 · 阶级按效果规格与施法成本初步估算";
            profiles.add(new SpellGrowthProfile(key, id, displayName, tier, 5,
                    SpellSealSequenceGenerator.display(generated.get(id)), role));
        }
        profiles.sort(Comparator.comparingInt((SpellGrowthProfile p) -> CURATED_SEQUENCES.containsKey(p.spellId()) ? 0 : 1)
                .thenComparing(SpellGrowthProfile::spellId));
        registrySpellCount = dynamicIds.size() + (int) CURATED_PROFILES.stream()
                .filter(p -> !dynamicIds.contains(p.spellId()) && byId.containsKey(p.spellId())).count();
        publish(profiles, sequences, true);
        return PROFILES.size();
    }

    private static synchronized void publish(Collection<SpellGrowthProfile> profiles,
                                             Map<String, SealSequence> sequences,
                                             boolean incrementGeneration) {
        Map<String, SpellGrowthProfile> ids = new LinkedHashMap<>();
        Map<String, SpellGrowthProfile> keys = new LinkedHashMap<>();
        List<SpellGrowthProfile> stable = List.copyOf(profiles);
        for (SpellGrowthProfile profile : stable) {
            SpellGrowthProfile oldId = ids.put(profile.spellId(), profile);
            if (oldId != null) throw new IllegalStateException("duplicate spell ID in growth catalog: " + profile.spellId());
            SpellGrowthProfile oldKey = keys.put(profile.key(), profile);
            if (oldKey != null) throw new IllegalStateException("duplicate key in growth catalog: " + profile.key());
        }
        for (SpellGrowthProfile profile : stable) {
            if (!sequences.containsKey(profile.spellId())) {
                throw new IllegalStateException("growth spell has no seal recipe: " + profile.spellId());
            }
        }
        BY_ID = Map.copyOf(ids);
        BY_KEY = Map.copyOf(keys);
        SEQUENCES = Map.copyOf(sequences);
        PROFILES = stable;
        if (incrementGeneration) generation++;
    }

    public static Collection<SpellGrowthProfile> profiles() { return PROFILES; }
    public static SpellGrowthProfile bySpellId(String spellId) { return spellId == null ? null : BY_ID.get(spellId); }
    public static SpellGrowthProfile byKey(String key) { return key == null ? null : BY_KEY.get(key); }
    public static SealSequence sealSequence(String spellId) { return spellId == null ? null : SEQUENCES.get(spellId); }
    public static long generation() { return generation; }
    public static int registeredDynamicSpellCount() { return registrySpellCount; }

    /** The current spell's native translation key is evaluated on the client so language packs work. */
    public static String translationKey(String spellId) {
        if (spellId == null) return "";
        try {
            AbstractSpell spell = SpellRegistry.getSpell(spellId);
            if (spell != null && spellId.equals(spell.getSpellId())) return spell.getComponentId();
        } catch (RuntimeException ignored) { }
        return "";
    }

    /** Proficiency required to request the next normal level. No automatic level-up occurs. */
    public static int requiredProficiency(SpellGrowthProfile profile, int currentLevel) {
        if (profile == null || currentLevel >= profile.maxLevel()) return 0;
        int base = switch (profile.tier()) {
            case LOWER -> 80;
            case MIDDLE -> 100;
            case UPPER -> 140;
            case SUPER -> 180;
        };
        return base + Math.max(0, currentLevel - 1) * 60;
    }

    /** The first key breakthrough happens at Lv.3 -> Lv.4 and needs real spell use. */
    public static boolean isBreakthroughLevel(int currentLevel) { return currentLevel == 3; }

    public static int breakthroughCombatHitsRequired(SpellGrowthProfile profile) {
        if (profile == null) return 5;
        return switch (profile.tier()) {
            case LOWER -> 4;
            case MIDDLE -> 5;
            case UPPER -> 7;
            case SUPER -> 10;
        };
    }

    public static int materialCostForLevel(SpellGrowthProfile profile, int currentLevel) {
        if (profile == null) return Integer.MAX_VALUE;
        return profile.tier().materialCost() + (currentLevel >= 4 ? 1 : 0);
    }

    private static String stableKey(String spellId) {
        // An injective key encoding avoids ambiguous flattening of namespace/path separators.
        // It also remains stable across restarts and does not depend on registry iteration order.
        byte[] bytes = spellId.toLowerCase(Locale.ROOT).getBytes(java.nio.charset.StandardCharsets.UTF_8);
        StringBuilder key = new StringBuilder("spell_");
        for (byte value : bytes) key.append(String.format(Locale.ROOT, "%02x", value & 0xff));
        return key.toString();
    }

    private static String readableName(String path) {
        String[] chunks = path.replace('-', '_').split("_");
        StringBuilder name = new StringBuilder();
        for (String chunk : chunks) {
            if (chunk.isBlank()) continue;
            if (name.length() > 0) name.append(' ');
            name.append(Character.toUpperCase(chunk.charAt(0))).append(chunk.substring(1));
        }
        return name.isEmpty() ? path : name.toString();
    }

    private static SpellTier classifyTier(AbstractSpell spell, String path) {
        String id = path.toLowerCase(Locale.ROOT);
        // Space/dimensional/large-scale effects are graded by strategic scope, not damage alone.
        if (containsAny(id, "portal", "pocket_dimension", "black_hole", "starfall", "planar_sight", "raise_hell")) {
            return SpellTier.SUPER;
        }
        if (containsAny(id, "teleport", "recall", "counterspell", "invisibility", "angel_wings",
                "time", "dimension", "blood_step", "summon_ender_chest")) {
            return SpellTier.UPPER;
        }
        int mana = 0;
        int castTicks = 0;
        try { mana = Math.max(0, spell.getManaCost(1)); } catch (RuntimeException ignored) { }
        try { castTicks = Math.max(0, spell.getCastTime(1)); } catch (RuntimeException ignored) { }
        if (mana >= 70 || castTicks >= 80) return SpellTier.UPPER;
        if (mana >= 32 || castTicks >= 30 || containsAny(id, "healing_circle", "cloud_of_regeneration", "summon", "shield")) {
            return SpellTier.MIDDLE;
        }
        return SpellTier.LOWER;
    }

    private static boolean containsAny(String value, String... parts) {
        for (String part : parts) if (value.contains(part)) return true;
        return false;
    }
}
