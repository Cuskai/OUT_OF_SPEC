package cn.blockforge.outofspec.spellcraft.growth;

import cn.blockforge.outofspec.spellcraft.item.SpellGrowthItems;
import cn.blockforge.outofspec.spellcraft.item.SpellScrollResolver;
import io.redspace.ironsspellbooks.api.events.SpellDamageEvent;
import io.redspace.ironsspellbooks.api.events.SpellOnCastEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import cn.blockforge.outofspec.spellcraft.model.RealSealCastingRecipes;
import cn.blockforge.outofspec.spellcraft.runtime.SealedCastEffectState;

/** World hooks for scroll discoveries, rare field finds, spell practice, and persistent growth. */
public final class SpellGrowthEvents {
    public static final String BUILD_MARKER = "OUT_OF_SPEC_STAGE_5_3_25.0.6.34";
    private SpellGrowthEvents() {}

    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent event) {
        SpellGrowthCatalog.refreshFromRegistry();
        RealSealCastingRecipes.refresh();
        // Idempotent reconciliation catches registries that acquired spell add-ons after CommonSetup.
    }

    /** Immediate discovery for either a custom scroll or a native Iron's Spells scroll. */
    @SubscribeEvent
    public static void onSpellScrollPickup(PlayerEvent.ItemPickupEvent event) {
        Player player = event.getEntity();
        if (player == null || player.level().isClientSide) return;
        // The event's stack can vary by pickup route; check both that stack and the now-updated inventory.
        SpellGrowthService.discoverFromStack(player, event.getStack());
        SpellGrowthService.discoverInventoryScrolls(player);
    }

    /**
     * Inventory reconciliation protects creative /give, login, inventory transfers, and any
     * pickup route that does not emit the expected item event. One scan per second is cheap
     * (the player inventory has only a few dozen slots) and is server-authoritative.
     */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide) return;
        if (event.player.tickCount % 20 != 0) return;
        SpellGrowthService.discoverInventoryScrolls(event.player);
    }

    @SubscribeEvent
    public static void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        Player player = event.getEntity();
        if (player != null && !player.level().isClientSide) {
            player.displayClientMessage(Component.literal("[OUT OF SPEC] " + BUILD_MARKER + " 已加载；已登记 " + SpellGrowthCatalog.profiles().size() + " 个术式成长档案。"), false);
            SpellGrowthService.discoverInventoryScrolls(player);
        }
    }

    /**
     * Player-accessible read-only diagnostic: /oosgrowth diagnose. It prints exactly what the server sees in the
     * inventory, embedded native-scroll IDs, catalog counts and persisted discovery state.
     */
    @SubscribeEvent
    public static void onRegisterGrowthCommands(RegisterCommandsEvent event) {
        // Read-only diagnostics concern only the executing player's own inventory and progression,
        // so they are intentionally available without OP permission. A permission gate makes the
        // command appear nonexistent to ordinary players, exactly the failure we want to avoid.
        event.getDispatcher().register(Commands.literal("oosgrowth")
                .executes(context -> {
                    context.getSource().sendSuccess(() -> Component.literal("[OUT OF SPEC] " + BUILD_MARKER
                            + " 已加载。命令：/oosgrowth version、/oosgrowth scan、/oosgrowth diagnose"), false);
                    return 1;
                })
                .then(Commands.literal("help").executes(context -> {
                    context.getSource().sendSuccess(() -> Component.literal("/oosgrowth version：检查已加载版本；"+
                            "/oosgrowth scan：重新扫描背包并登记发现；/oosgrowth diagnose：输出卷轴 ID、内嵌术式 ID、目录支持状态和发现/掌握状态。"), false);
                    return 1;
                }))
                .then(Commands.literal("version").executes(context -> {
                    context.getSource().sendSuccess(() -> Component.literal("[OUT OF SPEC] build=" + BUILD_MARKER
                            + " | registrySpells=" + SpellGrowthCatalog.registeredDynamicSpellCount() + " | sealRecipes=" + RealSealCastingRecipes.registeredRecipeCount() + " | eventRegistration=active | scrollResolver=API+NBT-fallback | diagnostics=player-accessible"), false);
                    return 1;
                }))
                .then(Commands.literal("scan").executes(context -> {
                    ServerPlayer player = context.getSource().getPlayerOrException();
                    SpellGrowthService.discoverInventoryScrolls(player);
                    int supportedStacks = 0;
                    int supportedItems = 0;
                    for (ItemStack stack : player.getInventory().items) {
                        String id = SpellScrollResolver.supportedSpellId(stack);
                        if (id != null) { supportedStacks++; supportedItems += stack.getCount(); }
                    }
                    for (ItemStack stack : player.getInventory().offhand) {
                        String id = SpellScrollResolver.supportedSpellId(stack);
                        if (id != null) { supportedStacks++; supportedItems += stack.getCount(); }
                    }
                    final int stackCount = supportedStacks;
                    final int itemCount = supportedItems;
                    context.getSource().sendSuccess(() -> Component.literal("[OUT OF SPEC] 扫描完成：成长目录含 " + SpellGrowthCatalog.profiles().size() + " 个术式；背包内发现 "
                            + stackCount + " 组受支持卷轴，共 " + itemCount + " 张。请打开 SAO Menu → 技能 → 术式研究档案查看。"), false);
                    return 1;
                }))
                .then(Commands.literal("diagnose").executes(context -> {
                    ServerPlayer player = context.getSource().getPlayerOrException();
                    SpellGrowthService.discoverInventoryScrolls(player);
                    context.getSource().sendSuccess(() -> Component.literal("[OUT OF SPEC] " + BUILD_MARKER
                            + "；诊断开始。若你安装的新包已经加载，此处必须显示该版本标记。"), false);
                    boolean foundStack = false;
                    for (ItemStack stack : player.getInventory().items) {
                        foundStack |= sendScrollDiagnostic(context.getSource(), stack);
                    }
                    for (ItemStack stack : player.getInventory().armor) {
                        foundStack |= sendScrollDiagnostic(context.getSource(), stack);
                    }
                    for (ItemStack stack : player.getInventory().offhand) {
                        foundStack |= sendScrollDiagnostic(context.getSource(), stack);
                    }
                    if (!foundStack) context.getSource().sendSuccess(() -> Component.literal(
                            "没有找到卷轴候选。请把火焰箭卷轴放在普通背包或副手，再运行 /oosgrowth diagnose。"), false);
                    int discoveredCount = 0;
                    int learnedCount = 0;
                    for (SpellGrowthProfile profile : SpellGrowthCatalog.profiles()) {
                        int count = SpellGrowthService.countScrolls(player, profile.spellId());
                        boolean discovered = SpellGrowthService.isDiscovered(player, profile.spellId());
                        boolean learned = SpellGrowthService.isLearned(player, profile.spellId());
                        if (discovered) discoveredCount++;
                        if (learned) learnedCount++;
                        if (count > 0 || discovered || learned) {
                            context.getSource().sendSuccess(() -> Component.literal(profile.spellId()
                                    + " | matchingScrolls=" + count + " | discovered=" + discovered
                                    + " | learned=" + learned), false);
                        }
                    }
                    final int totalDiscovered = discoveredCount;
                    final int totalLearned = learnedCount;
                    context.getSource().sendSuccess(() -> Component.literal("目录合计：" + SpellGrowthCatalog.profiles().size()
                            + " 个已启用注册术式；当前角色已发现 " + totalDiscovered + " 个、已掌握 " + totalLearned + " 个；"
                            + "结印配方 " + RealSealCastingRecipes.registeredRecipeCount() + " 个。"), false);
                    return 1;
                })));
    }

    private static boolean sendScrollDiagnostic(net.minecraft.commands.CommandSourceStack source, ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        String rawSpellId = SpellScrollResolver.spellId(stack);
        var key = ForgeRegistries.ITEMS.getKey(stack.getItem());
        String itemId = key == null ? "<unregistered>" : key.toString();
        if (!SpellScrollResolver.isScrollCandidate(stack)) return false;
        String supported = SpellScrollResolver.supportedSpellId(stack);
        source.sendSuccess(() -> Component.literal("卷轴候选：" + itemId + " x" + stack.getCount()
                + " | class=" + stack.getItem().getClass().getSimpleName()
                + " | embeddedSpell=" + (rawSpellId == null ? "<无术式数据>" : rawSpellId)
                + " | supported=" + (supported == null ? "否" : supported)), false);
        return true;
    }

    @SubscribeEvent
    public static void onPlayerClone(PlayerEvent.Clone event) {
        // Growth knowledge and chosen branches survive death/respawn, like other persistent character progression.
        SpellGrowthService.copyOnClone(event);
    }

    @SubscribeEvent
    public static void onSpellCastStarting(SpellOnCastEvent event) {
        Player player = event.getEntity();
        if (player == null || player.level().isClientSide) return;
        String spellId = event.getSpellId();
        if (SpellGrowthCatalog.bySpellId(spellId) == null) return;
        // Growth-enabled spells are trained through OUT OF SPEC research. Legacy Iron's
        // learned flag is intentionally not imported; otherwise the scroll study UI is bypassed.
        if (!SpellGrowthService.isLearned(player, spellId)) return;
        double manaMultiplier = SpellGrowthService.branchManaCostMultiplier(player, spellId)
                * SealedCastEffectState.manaCostMultiplier(player, spellId);
        if (Double.isFinite(manaMultiplier) && manaMultiplier > 0.0 && Math.abs(manaMultiplier - 1.0) > 0.001) {
            event.setManaCost(Math.max(0, (int) Math.ceil(event.getManaCost() * manaMultiplier)));
        }
        // SpellOnCastEvent is posted at the start of AbstractSpell.castSpell, before the
        // spell executor runs. Proficiency is awarded only by the AbstractSpell.castSpell RETURN
        // hook after the real executor finishes, to avoid progress for interrupted/failed effects.
    }

    @SubscribeEvent
    public static void onSpellDamage(SpellDamageEvent event) {
        if (event == null || event.getAmount() <= 0.0f || event.getEntity().level().isClientSide) return;
        String spellId = event.getSpellDamageSource().spell() == null
                ? "" : event.getSpellDamageSource().spell().getSpellId();
        if (SpellGrowthCatalog.bySpellId(spellId) == null) return;
        if (!(event.getSpellDamageSource().getEntity() instanceof Player caster)) return;
        if (caster.getUUID().equals(event.getEntity().getUUID())) return;
        SpellGrowthService.recordCombatHit(caster, spellId);
    }

    @SubscribeEvent
    public static void onMonsterDrops(LivingDropsEvent event) {
        if (event.getEntity().level().isClientSide || !(event.getEntity() instanceof Monster)) return;
        if (!(event.getSource().getEntity() instanceof ServerPlayer player)) return;
        // Most finds are the lower-tier Firebolt scroll. Higher tiers are deliberately rare.
        float roll = event.getEntity().getRandom().nextFloat();
        if (roll >= 0.12f) return;
        float tierRoll = event.getEntity().getRandom().nextFloat();
        var item = tierRoll < 0.72f ? SpellGrowthItems.FIREBOLT_SCROLL.get()
                : tierRoll < 0.90f ? SpellGrowthItems.MAGIC_ARROW_SCROLL.get()
                : tierRoll < 0.99f ? SpellGrowthItems.FIREBALL_SCROLL.get()
                : SpellGrowthItems.LIGHTNING_LANCE_SCROLL.get();
        ItemEntity drop = new ItemEntity(player.serverLevel(), event.getEntity().getX(),
                event.getEntity().getY(), event.getEntity().getZ(), new ItemStack(item));
        event.getDrops().add(drop);
    }

    /** A once-per-villager master-librarian inheritance exchange creates a legitimate high-tier source. */
    @SubscribeEvent
    public static void onMentorInheritance(PlayerInteractEvent.EntityInteract event) {
        if (event.getLevel().isClientSide || !(event.getTarget() instanceof Villager villager)) return;
        if (villager.getVillagerData().getProfession() != VillagerProfession.LIBRARIAN
                || villager.getVillagerData().getLevel() < 5) return;
        Player player = event.getEntity();
        if (!player.isCrouching()) return;
        if (villager.getPersistentData().getBoolean("out_of_spec_inheritance_claimed")) {
            player.displayClientMessage(net.minecraft.network.chat.Component.literal("这位大图书管理员已经完成过一次术式传承。"), true);
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);
            return;
        }
        ItemStack held = player.getItemInHand(event.getHand());
        if (!held.is(SpellGrowthItems.ARCANE_CORE.get())) return;
        held.shrink(1);
        ItemStack scroll = new ItemStack(SpellGrowthItems.LIGHTNING_LANCE_SCROLL.get());
        if (!player.getInventory().add(scroll)) {
            if (!player.level().isClientSide) {
                net.minecraft.world.entity.item.ItemEntity drop = new net.minecraft.world.entity.item.ItemEntity(
                        player.level(), player.getX(), player.getY(), player.getZ(), scroll);
                player.level().addFreshEntity(drop);
            }
        }
        villager.getPersistentData().putBoolean("out_of_spec_inheritance_claimed", true);
        player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                "你以一枚奥术核心换得「雷鸣长枪」上阶术式传承卷轴。卷轴仍需研究学习。"), false);
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
    }
}
