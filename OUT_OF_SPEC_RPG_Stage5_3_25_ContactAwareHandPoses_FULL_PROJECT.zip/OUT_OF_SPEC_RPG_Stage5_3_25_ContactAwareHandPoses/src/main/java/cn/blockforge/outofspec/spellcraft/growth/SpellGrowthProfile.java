package cn.blockforge.outofspec.spellcraft.growth;

import java.util.Objects;

/** Immutable design data. Tier and growable player level deliberately remain separate. */
public record SpellGrowthProfile(
        String key,
        String spellId,
        String displayName,
        SpellTier tier,
        int maxLevel,
        String sealSequence,
        String roleSummary) {
    public SpellGrowthProfile {
        if (key == null || key.isBlank()) throw new IllegalArgumentException("key is required");
        if (spellId == null || spellId.isBlank()) throw new IllegalArgumentException("spellId is required");
        if (displayName == null || displayName.isBlank()) throw new IllegalArgumentException("displayName is required");
        Objects.requireNonNull(tier, "tier");
        if (maxLevel < 2 || maxLevel > 20) throw new IllegalArgumentException("maxLevel must be in 2..20");
        sealSequence = Objects.requireNonNullElse(sealSequence, "待录入");
        roleSummary = Objects.requireNonNullElse(roleSummary, "");
    }
}
