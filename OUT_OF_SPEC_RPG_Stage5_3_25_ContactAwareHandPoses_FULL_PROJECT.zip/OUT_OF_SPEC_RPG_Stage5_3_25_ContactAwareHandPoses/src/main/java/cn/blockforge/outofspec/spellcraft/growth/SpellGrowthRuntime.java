package cn.blockforge.outofspec.spellcraft.growth;

import cn.blockforge.outofspec.spellcraft.network.SpellGrowthNetwork;
import io.redspace.ironsspellbooks.api.magic.MagicData;
import io.redspace.ironsspellbooks.api.registry.SpellRegistry;
import io.redspace.ironsspellbooks.api.spells.AbstractSpell;
import io.redspace.ironsspellbooks.api.spells.CastSource;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import cn.blockforge.outofspec.binding.BindingCastingMod;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Optional grimoire second-layer cast queue. V1 is chained execution, not concurrent projectile merging. */
@Mod.EventBusSubscriber(modid = BindingCastingMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class SpellGrowthRuntime {
    private static final Map<UUID, QueuedCast> QUEUED = new ConcurrentHashMap<>();

    private SpellGrowthRuntime() {}

    public static boolean queueFollowup(ServerPlayer player, String primarySpellId, String secondSpellId) {
        if (player == null || primarySpellId == null || secondSpellId == null || secondSpellId.isBlank()) return true;
        QueuedCast cast = new QueuedCast(primarySpellId, secondSpellId, player.level().getGameTime(), -1L);
        return QUEUED.putIfAbsent(player.getUUID(), cast) == null;
    }

    public static void cancelQueued(ServerPlayer player) {
        if (player != null) QUEUED.remove(player.getUUID());
    }

    /** Called after Iron's Spells reaches AbstractSpell.castSpell RETURN. */
    public static void onSpellReleased(ServerPlayer player, String completedSpellId) {
        if (player == null || completedSpellId == null) return;
        // Count a successful real release as progress for every spell family, including heal,
        // movement, shield, summon and utility spells that may never emit SpellDamageEvent.
        SpellGrowthService.recordRealCast(player, completedSpellId);
        SpellGrowthService.recordSuccessfulRelease(player, completedSpellId);
        QUEUED.computeIfPresent(player.getUUID(), (uuid, pending) -> {
            if (!pending.primarySpellId().equals(completedSpellId) || pending.readyAtTick() >= 0) return pending;
            return new QueuedCast(pending.primarySpellId(), pending.nextSpellId(), pending.queuedAtTick(),
                    player.level().getGameTime() + 1L);
        });
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || QUEUED.isEmpty()) return;
        for (Map.Entry<UUID, QueuedCast> item : QUEUED.entrySet()) {
            UUID playerId = item.getKey();
            QueuedCast queued = item.getValue();
            ServerPlayer player = event.getServer().getPlayerList().getPlayer(playerId);
            if (player == null) {
                QUEUED.remove(playerId, queued);
                continue;
            }
            long now = player.level().getGameTime();
            if (now - queued.queuedAtTick() > 1200L) {
                if (QUEUED.remove(playerId, queued)) {
                    player.displayClientMessage(net.minecraft.network.chat.Component.literal("法术书的第二层施法已超时取消。"), true);
                }
                continue;
            }
            if (queued.readyAtTick() < 0 || now < queued.readyAtTick()
                    || MagicData.getPlayerMagicData(player).isCasting()) continue;
            if (!QUEUED.remove(playerId, queued)) continue;
            AbstractSpell spell = SpellRegistry.getSpell(queued.nextSpellId());
            if (spell == null || !spell.isEnabled() || !SpellGrowthService.isLearned(player, queued.nextSpellId())) {
                player.displayClientMessage(net.minecraft.network.chat.Component.literal("法术书第二层施法失败：后续术式已不可用或尚未掌握。"), true);
                continue;
            }
            try {
                boolean started = spell.attemptInitiateCast(ItemStack.EMPTY,
                        SpellGrowthService.level(player, queued.nextSpellId()), player.serverLevel(), player,
                        CastSource.SPELLBOOK, true, "out_of_spec_grimoire_layer_2");
                if (!started) player.displayClientMessage(net.minecraft.network.chat.Component.literal("法术书第二层施法被 Iron's Spells 拒绝；请检查魔力、冷却和束缚条件。"), true);
            } catch (RuntimeException failure) {
                player.displayClientMessage(net.minecraft.network.chat.Component.literal("法术书第二层施法失败：" + safeMessage(failure)), true);
            }
        }
    }

    @SubscribeEvent
    public static void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() != null) QUEUED.remove(event.getEntity().getUUID());
    }

    private static String safeMessage(Throwable throwable) {
        if (throwable == null || throwable.getMessage() == null || throwable.getMessage().isBlank()) return "未知错误";
        String value = throwable.getMessage().replace('\n', ' ').replace('\r', ' ');
        return value.length() > 120 ? value.substring(0, 120) : value;
    }

    private record QueuedCast(String primarySpellId, String nextSpellId, long queuedAtTick, long readyAtTick) {}
}
