package cn.blockforge.outofspec.spellcraft.growth;

import cn.blockforge.outofspec.spellcraft.item.SpellGrowthItems;
import cn.blockforge.outofspec.spellcraft.item.SpellScrollResolver;
import cn.blockforge.outofspec.spellcraft.model.RealSealCastingRecipes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import io.redspace.ironsspellbooks.api.registry.SpellRegistry;
import io.redspace.ironsspellbooks.api.spells.AbstractSpell;
import net.minecraftforge.event.entity.player.PlayerEvent;

import java.util.List;
import java.util.Locale;

/** Server-authoritative per-player discovery, learning, proficiency, level, and breakthrough state. */
public final class SpellGrowthService {
    public static final String ROOT_KEY = "out_of_spec_spell_growth";
    private static final String ENTRIES_KEY = "entries";
    private static final int MAX_PROFICIENCY = 100_000;

    private SpellGrowthService() {}

    private static CompoundTag root(Player player) {
        CompoundTag persistent = player.getPersistentData();
        if (!persistent.contains(ROOT_KEY, Tag.TAG_COMPOUND)) persistent.put(ROOT_KEY, new CompoundTag());
        return persistent.getCompound(ROOT_KEY);
    }

    private static CompoundTag entry(Player player, SpellGrowthProfile profile, boolean create) {
        CompoundTag entries = root(player).getCompound(ENTRIES_KEY);
        if (!root(player).contains(ENTRIES_KEY, Tag.TAG_COMPOUND)) {
            root(player).put(ENTRIES_KEY, entries);
        }
        if (!entries.contains(profile.key(), Tag.TAG_COMPOUND) && create) {
            CompoundTag fresh = new CompoundTag();
            fresh.putBoolean("discovered", false);
            fresh.putBoolean("learned", false);
            fresh.putInt("level", 0);
            fresh.putInt("proficiency", 0);
            fresh.putInt("challenge_hits", 0);
            fresh.putInt("challenge_uses", 0);
            fresh.putString("branch", SpellGrowthBranch.NONE.name());
            entries.put(profile.key(), fresh);
        }
        return entries.getCompound(profile.key());
    }

    public static boolean discover(Player player, String spellId) {
        SpellGrowthProfile profile = SpellGrowthCatalog.bySpellId(spellId);
        if (player == null || profile == null || player.level().isClientSide) return false;
        CompoundTag state = entry(player, profile, true);
        boolean wasDiscovered = state.getBoolean("discovered");
        if (!wasDiscovered) state.putBoolean("discovered", true);
        return !wasDiscovered;
    }

    /**
     * Fallback reconciliation for scrolls already present in the inventory (creative give,
     * inventory transfer, or a pickup event missed before this handler was registered).
     * This is server-only and idempotent because discover() only changes a new record once.
     */
    public static void discoverInventoryScrolls(Player player) {
        if (player == null || player.level().isClientSide) return;
        // Reconcile actual stacks rather than only querying our custom item registry. Iron's
        // native scroll item is shared by every spell and carries its individual spell ID in NBT.
        for (ItemStack stack : player.getInventory().items) discoverFromStack(player, stack);
        for (ItemStack stack : player.getInventory().armor) discoverFromStack(player, stack);
        for (ItemStack stack : player.getInventory().offhand) discoverFromStack(player, stack);
    }

    public static void discoverFromStack(Player player, ItemStack stack) {
        if (player == null || player.level().isClientSide) return;
        String spellId = SpellScrollResolver.supportedSpellId(stack);
        if (spellId == null) return;
        SpellGrowthProfile profile = SpellGrowthCatalog.bySpellId(spellId);
        if (profile != null && discover(player, spellId)) {
            player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                    "发现新术式：「" + profile.displayName() + "」。请打开术式研究档案尝试学习。"), true);
        }
    }


    private static CompoundTag additionalSealStates(Player player) {
        CompoundTag data = root(player);
        if (!data.contains("additional_seals", Tag.TAG_COMPOUND)) data.put("additional_seals", new CompoundTag());
        return data.getCompound("additional_seals");
    }

    /** Additional seals are learned abilities, not globally available input shortcuts. */
    public static boolean isAdditionalSealLearned(Player player, String additionId) {
        if (player == null || additionId == null || additionId.isBlank()) return false;
        return additionalSealStates(player).getBoolean(additionId);
    }

    public static ActionResult learnAdditionalSeal(Player player, String additionId) {
        if (!(player instanceof ServerPlayer) || !RealSealCastingRecipes.isKnownAdditionalSeal(additionId)) {
            return ActionResult.failure("无法识别这枚追加印。");
        }
        if (isAdditionalSealLearned(player, additionId)) return ActionResult.failure("你已经掌握这枚追加印。");
        if (!additionalSealPrerequisitesMet(player, additionId)) {
            return ActionResult.failure("尚未满足「" + RealSealCastingRecipes.additionName(additionId) + "」的前置条件："
                    + RealSealCastingRecipes.additionPrerequisiteText(additionId).split("；奥术核心")[0] + "。");
        }
        int coreCost = RealSealCastingRecipes.additionCoreCost(additionId);
        int shardCost = RealSealCastingRecipes.additionShardCost(additionId);
        if (countItem(player, SpellGrowthItems.ARCANE_CORE.get()) < coreCost) {
            return ActionResult.failure("研究追加印需要奥术核心 ×" + coreCost + "。");
        }
        if (countItem(player, Items.AMETHYST_SHARD) < shardCost) {
            return ActionResult.failure("研究追加印需要紫水晶碎片 ×" + shardCost + "。");
        }
        consumeItem(player, SpellGrowthItems.ARCANE_CORE.get(), coreCost);
        consumeItem(player, Items.AMETHYST_SHARD, shardCost);
        additionalSealStates(player).putBoolean(additionId, true);
        return ActionResult.success("追加印已掌握：「" + RealSealCastingRecipes.additionName(additionId)
                + "」。已写入个人术式档案，可在结印时输入对应的追加印序列。");
    }

    /** One source of truth for both the learning request and the research UI's prerequisite state. */
    public static boolean additionalSealPrerequisitesMet(Player player, String additionId) {
        if (player == null || !RealSealCastingRecipes.isKnownAdditionalSeal(additionId)) return false;
        if (learnedSpellCount(player) <= 0) return false;
        int highestLevel = highestLearnedSpellLevel(player);
        return switch (additionId) {
            case RealSealCastingRecipes.POWER_FOCUS, RealSealCastingRecipes.QUICK_RELEASE -> true;
            case RealSealCastingRecipes.POWER_FOCUS_STRONG -> isAdditionalSealLearned(player, RealSealCastingRecipes.POWER_FOCUS)
                    && highestLevel >= 3;
            case RealSealCastingRecipes.MULTI_RELEASE -> highestLevel >= 2;
            case RealSealCastingRecipes.TRIUNE_RELEASE -> isAdditionalSealLearned(player, RealSealCastingRecipes.MULTI_RELEASE)
                    && highestLevel >= 3;
            case RealSealCastingRecipes.FIREBALL_EXPANSION -> isLearned(player, "irons_spellbooks:fireball")
                    && level(player, "irons_spellbooks:fireball") >= 2;
            default -> false;
        };
    }

    private static int learnedSpellCount(Player player) {
        int total = 0;
        for (SpellGrowthProfile profile : SpellGrowthCatalog.profiles()) if (isLearned(player, profile.spellId())) total++;
        return total;
    }

    private static int highestLearnedSpellLevel(Player player) {
        int highest = 0;
        for (SpellGrowthProfile profile : SpellGrowthCatalog.profiles()) {
            if (isLearned(player, profile.spellId())) highest = Math.max(highest, level(player, profile.spellId()));
        }
        return highest;
    }

    private static ListTag createAdditionalSealSnapshot(ServerPlayer player) {
        ListTag rows = new ListTag();
        for (String id : RealSealCastingRecipes.additionalSealIds()) {
            boolean learned = isAdditionalSealLearned(player, id);
            int coreCost = RealSealCastingRecipes.additionCoreCost(id);
            int shardCost = RealSealCastingRecipes.additionShardCost(id);
            boolean prerequisites = additionalSealPrerequisitesMet(player, id);
            CompoundTag row = new CompoundTag();
            row.putString("id", id);
            row.putString("name", RealSealCastingRecipes.additionName(id));
            row.putString("tier", RealSealCastingRecipes.additionTierName(id));
            row.putString("sequence", RealSealCastingRecipes.additionSequence(id));
            row.putString("effect", RealSealCastingRecipes.additionPreview(id));
            row.putString("description", RealSealCastingRecipes.additionDescription(id));
            row.putString("requirements", RealSealCastingRecipes.additionPrerequisiteText(id));
            row.putBoolean("learned", learned);
            row.putBoolean("can_learn", !learned && prerequisites
                    && countItem(player, SpellGrowthItems.ARCANE_CORE.get()) >= coreCost
                    && countItem(player, Items.AMETHYST_SHARD) >= shardCost);
            row.putInt("core_cost", coreCost);
            row.putInt("shard_cost", shardCost);
            row.putBoolean("has_prerequisites", prerequisites);
            row.putBoolean("has_core", countItem(player, SpellGrowthItems.ARCANE_CORE.get()) >= coreCost);
            row.putBoolean("has_shards", countItem(player, Items.AMETHYST_SHARD) >= shardCost);
            rows.add(row);
        }
        return rows;
    }

    public static boolean isDiscovered(Player player, String spellId) {
        SpellGrowthProfile profile = SpellGrowthCatalog.bySpellId(spellId);
        return player != null && profile != null && entry(player, profile, false).getBoolean("discovered");
    }

    public static boolean isLearned(Player player, String spellId) {
        SpellGrowthProfile profile = SpellGrowthCatalog.bySpellId(spellId);
        return player != null && profile != null && entry(player, profile, false).getBoolean("learned");
    }

    public static boolean markLearned(Player player, String spellId) {
        SpellGrowthProfile profile = SpellGrowthCatalog.bySpellId(spellId);
        if (player == null || profile == null || player.level().isClientSide) return false;
        CompoundTag state = entry(player, profile, true);
        boolean fresh = !state.getBoolean("learned");
        state.putBoolean("discovered", true);
        state.putBoolean("learned", true);
        if (state.getInt("level") < 1) state.putInt("level", 1);
        return fresh;
    }

    public static int level(Player player, String spellId) {
        SpellGrowthProfile profile = SpellGrowthCatalog.bySpellId(spellId);
        if (player == null || profile == null) return 1;
        CompoundTag state = entry(player, profile, false);
        if (!state.getBoolean("learned")) return 1;
        return Math.max(1, Math.min(profile.maxLevel(), state.getInt("level")));
    }

    public static int proficiency(Player player, String spellId) {
        SpellGrowthProfile profile = SpellGrowthCatalog.bySpellId(spellId);
        return player == null || profile == null ? 0 : Math.max(0, entry(player, profile, false).getInt("proficiency"));
    }

    public static void recordRealCast(Player player, String spellId) {
        SpellGrowthProfile profile = SpellGrowthCatalog.bySpellId(spellId);
        if (player == null || profile == null || player.level().isClientSide) return;
        if (!isLearned(player, spellId)) return;
        CompoundTag state = entry(player, profile, true);
        int award = switch (profile.tier()) {
            case LOWER -> 8;
            case MIDDLE -> 10;
            case UPPER -> 12;
            case SUPER -> 15;
        };
        state.putInt("proficiency", Math.min(MAX_PROFICIENCY, state.getInt("proficiency") + award));
    }

    /**
     * Successful cast completion progress for the key breakthrough. This deliberately covers
     * healing, movement, shield, summon, utility and spatial spells that never deal damage.
     * Attack spells may also accumulate hit events; breakthrough uses the greater of the two
     * progress sources so one hit-heavy spell does not double count the same activity.
     */
    public static void recordSuccessfulRelease(Player player, String spellId) {
        SpellGrowthProfile profile = SpellGrowthCatalog.bySpellId(spellId);
        if (player == null || profile == null || player.level().isClientSide || !isLearned(player, spellId)) return;
        CompoundTag state = entry(player, profile, true);
        state.putInt("challenge_uses", Math.min(100_000, state.getInt("challenge_uses") + 1));
    }

    /** Counts real spell-damage events for the Lv.3 -> Lv.4 breakthrough challenge. */
    public static void recordCombatHit(Player player, String spellId) {
        SpellGrowthProfile profile = SpellGrowthCatalog.bySpellId(spellId);
        if (player == null || profile == null || player.level().isClientSide || !isLearned(player, spellId)) return;
        CompoundTag state = entry(player, profile, true);
        state.putInt("challenge_hits", Math.min(100_000, state.getInt("challenge_hits") + 1));
    }

    public static ActionResult research(Player player, String spellId, boolean useCore) {
        SpellGrowthProfile profile = SpellGrowthCatalog.bySpellId(spellId);
        if (!(player instanceof ServerPlayer) || profile == null) return ActionResult.failure("无法识别这份术式档案。");
        if (isLearned(player, spellId)) return ActionResult.failure("你已经掌握这个术式，无需重复学习。");
        AbstractSpell registeredSpell = SpellRegistry.getSpell(spellId);
        if (!isSpellAvailable(spellId, registeredSpell)) {
            discover(player, spellId);
            return ActionResult.failure("该术式当前未在 Iron's Spells 注册表中启用。发现记录保留，但不能研究或施放被服务器禁用的法术。");
        }
        if (countScrolls(player, spellId) <= 0) {
            return ActionResult.failure("物品栏中没有「" + profile.displayName() + "」对应的卷轴。支持 OUT OF SPEC 卷轴，以及内含该术式数据的 Iron's Spells 原版卷轴。");
        }
        if (useCore && countItem(player, SpellGrowthItems.ARCANE_CORE.get()) < 1) {
            return ActionResult.failure("没有奥术核心；未开始学习，也没有消耗卷轴。");
        }

        // A committed attempt consumes one matching spell scroll regardless of its source.
        // Native Iron's Spells scrolls all use the same Item type, so consume by embedded spell ID.
        if (!consumeScroll(player, spellId, 1)) {
            return ActionResult.failure("确认学习时没有找到对应卷轴；未消耗材料，请重新打开研究档案同步库存。");
        }
        if (useCore) consumeItem(player, SpellGrowthItems.ARCANE_CORE.get(), 1);
        discover(player, spellId);
        double chance = researchChance(profile, useCore);
        boolean success = player.getRandom().nextDouble() < chance;
        if (success) {
            markLearned(player, spellId);
            return ActionResult.success("研究成功：已掌握「" + profile.displayName() + "」Lv.1。卷轴已消耗，术式记录已写入你的成长档案。");
        }
        String catalystNote = useCore ? "，奥术核心也已消耗" : "";
        return ActionResult.failure("研究失败：" + profile.displayName() + "尚未掌握。卷轴已消耗" + catalystNote + "；术式发现记录保留，可重新寻找卷轴后再试。成功率 " + percent(chance) + "%。");
    }

    public static ActionResult levelUp(Player player, String spellId) {
        SpellGrowthProfile profile = SpellGrowthCatalog.bySpellId(spellId);
        if (!(player instanceof ServerPlayer) || profile == null || !isLearned(player, spellId)) {
            return ActionResult.failure("必须先发现并学会这个术式，才能提升等级。");
        }
        if (!isSpellAvailable(spellId, SpellRegistry.getSpell(spellId))) {
            return ActionResult.failure("该术式当前被服务器禁用，不能提升等级。");
        }
        CompoundTag state = entry(player, profile, true);
        int currentLevel = level(player, spellId);
        if (currentLevel >= profile.maxLevel()) return ActionResult.failure("该术式已达到当前成长上限。");
        if (SpellGrowthCatalog.isBreakthroughLevel(currentLevel)) {
            return ActionResult.failure("Lv.3 → Lv.4 属于关键突破，必须完成实战试炼并选择成长分支。");
        }
        int needed = SpellGrowthCatalog.requiredProficiency(profile, currentLevel);
        if (state.getInt("proficiency") < needed) {
            return ActionResult.failure("熟练度不足：需要 " + needed + "，当前 " + state.getInt("proficiency") + "。");
        }
        int materialCost = SpellGrowthCatalog.materialCostForLevel(profile, currentLevel);
        if (countItem(player, Items.AMETHYST_SHARD) < materialCost) {
            return ActionResult.failure("媒介不足：需要紫水晶碎片 ×" + materialCost + "。");
        }
        consumeItem(player, Items.AMETHYST_SHARD, materialCost);
        state.putInt("proficiency", state.getInt("proficiency") - needed);
        state.putInt("level", currentLevel + 1);
        return ActionResult.success("术式成长完成：「" + profile.displayName() + "」升至 Lv." + (currentLevel + 1) + "。已消耗紫水晶碎片 ×" + materialCost + "。");
    }

    public static ActionResult breakthrough(Player player, String spellId, String branchId) {
        SpellGrowthProfile profile = SpellGrowthCatalog.bySpellId(spellId);
        SpellGrowthBranch branch = SpellGrowthBranch.byId(branchId);
        if (!(player instanceof ServerPlayer) || profile == null || !isLearned(player, spellId)) {
            return ActionResult.failure("必须先掌握该术式，才能尝试突破。");
        }
        if (!isSpellAvailable(spellId, SpellRegistry.getSpell(spellId))) {
            return ActionResult.failure("该术式当前被服务器禁用，不能突破。");
        }
        if (branch == SpellGrowthBranch.NONE) return ActionResult.failure("必须选择一个成长分支。");
        CompoundTag state = entry(player, profile, true);
        int currentLevel = level(player, spellId);
        if (currentLevel != 3) return ActionResult.failure("当前版本的关键突破发生在 Lv.3 → Lv.4。");
        int needed = SpellGrowthCatalog.requiredProficiency(profile, currentLevel);
        int hitsNeeded = SpellGrowthCatalog.breakthroughCombatHitsRequired(profile);
        if (state.getInt("proficiency") < needed) return ActionResult.failure("熟练度不足：突破需要 " + needed + "，当前 " + state.getInt("proficiency") + "。");
        int challengeProgress = challengeProgress(state);
        if (challengeProgress < hitsNeeded) {
            return ActionResult.failure("术式试炼尚未完成：成功释放该法术或命中目标共需 " + hitsNeeded
                    + " 次，当前 " + challengeProgress + " 次。治疗、位移、护盾、召唤等非伤害法术按成功释放计数。");
        }
        if (countItem(player, SpellGrowthItems.ARCANE_CORE.get()) < 1) return ActionResult.failure("突破需要奥术核心 ×1。");
        int shards = 3 + profile.tier().materialCost();
        if (countItem(player, Items.AMETHYST_SHARD) < shards) return ActionResult.failure("突破需要紫水晶碎片 ×" + shards + "。");

        consumeItem(player, SpellGrowthItems.ARCANE_CORE.get(), 1);
        consumeItem(player, Items.AMETHYST_SHARD, shards);
        state.putInt("proficiency", state.getInt("proficiency") - needed);
        state.putInt("level", 4);
        state.putString("branch", branch.name());
        state.putInt("challenge_hits", 0);
        state.putInt("challenge_uses", 0);
        return ActionResult.success("关键突破成功：「" + profile.displayName() + "」升至 Lv.4，成长路线确定为「" + branch.displayName() + "」。");
    }

    public static double branchSpellPowerMultiplier(Player player, String spellId) {
        SpellGrowthBranch branch = branch(player, spellId);
        return switch (branch) {
            case REFINEMENT -> 1.05;
            case BURST -> 1.12;
            case CONTROL -> 1.03;
            case NONE -> 1.0;
        };
    }

    public static double branchCastTimeMultiplier(Player player, String spellId) {
        return branch(player, spellId) == SpellGrowthBranch.CONTROL ? 0.85 : 1.0;
    }

    public static double branchManaCostMultiplier(Player player, String spellId) {
        return switch (branch(player, spellId)) {
            case REFINEMENT -> 0.90;
            case BURST -> 1.12;
            default -> 1.0;
        };
    }

    public static SpellGrowthBranch branch(Player player, String spellId) {
        SpellGrowthProfile profile = SpellGrowthCatalog.bySpellId(spellId);
        if (player == null || profile == null) return SpellGrowthBranch.NONE;
        return SpellGrowthBranch.byId(entry(player, profile, false).getString("branch"));
    }

    private static boolean isSpellAvailable(String spellId, AbstractSpell spell) {
        if (spell == null || spellId == null) return false;
        try { return spellId.equals(spell.getSpellId()) && spell.isEnabled(); }
        catch (RuntimeException unavailable) { return false; }
    }

    public static CompoundTag createSnapshot(ServerPlayer player) {
        CompoundTag snapshot = new CompoundTag();
        snapshot.putString("version", "stage4-growth-3-additional-seal-catalog-6");
        ListTag rows = new ListTag();
        for (SpellGrowthProfile profile : SpellGrowthCatalog.profiles()) {
            CompoundTag state = entry(player, profile, false);
            CompoundTag row = new CompoundTag();
            row.putString("id", profile.spellId());
            row.putString("key", profile.key());
            row.putString("name", profile.displayName());
            row.putString("tier", profile.tier().displayName());
            row.putString("role", profile.roleSummary());
            row.putString("seals", profile.sealSequence());
            row.putBoolean("discovered", state.getBoolean("discovered"));
            row.putBoolean("learned", state.getBoolean("learned"));
            row.putInt("level", state.getBoolean("learned") ? Math.max(1, state.getInt("level")) : 0);
            row.putInt("max_level", profile.maxLevel());
            row.putInt("proficiency", state.getInt("proficiency"));
            int current = state.getBoolean("learned") ? Math.max(1, state.getInt("level")) : 1;
            row.putInt("next_required", current >= profile.maxLevel()
                    ? 0 : SpellGrowthCatalog.requiredProficiency(profile, current));
            row.putInt("scroll_count", countScrolls(player, profile.spellId()));
            row.putInt("chance", (int) Math.round(researchChance(profile, false) * 100));
            row.putInt("chance_core", (int) Math.round(researchChance(profile, true) * 100));
            row.putString("branch", state.getString("branch"));
            row.putString("branch_name", SpellGrowthBranch.byId(state.getString("branch")).displayName());
            row.putInt("challenge_hits", challengeProgress(state));
            row.putInt("challenge_damage_hits", state.getInt("challenge_hits"));
            row.putInt("challenge_successful_casts", state.getInt("challenge_uses"));
            row.putInt("challenge_required", SpellGrowthCatalog.breakthroughCombatHitsRequired(profile));
            row.putString("name_key", SpellGrowthCatalog.translationKey(profile.spellId()));
            AbstractSpell nativeSpell = SpellRegistry.getSpell(profile.spellId());
            row.putBoolean("available", isSpellAvailable(profile.spellId(), nativeSpell));
            row.putInt("level_material_cost", SpellGrowthCatalog.materialCostForLevel(profile, current));
            row.putBoolean("has_core", countItem(player, SpellGrowthItems.ARCANE_CORE.get()) > 0);
            row.putBoolean("has_shards", countItem(player, Items.AMETHYST_SHARD) >= 1);
            row.putBoolean("can_level", state.getBoolean("learned") && current < profile.maxLevel()
                    && !SpellGrowthCatalog.isBreakthroughLevel(current)
                    && state.getInt("proficiency") >= SpellGrowthCatalog.requiredProficiency(profile, current)
                    && countItem(player, Items.AMETHYST_SHARD) >= SpellGrowthCatalog.materialCostForLevel(profile, current));
            int breakthroughShards = 3 + profile.tier().materialCost();
            row.putBoolean("can_breakthrough", state.getBoolean("learned") && current == 3
                    && state.getInt("proficiency") >= SpellGrowthCatalog.requiredProficiency(profile, current)
                    && challengeProgress(state) >= SpellGrowthCatalog.breakthroughCombatHitsRequired(profile)
                    && countItem(player, SpellGrowthItems.ARCANE_CORE.get()) >= 1
                    && countItem(player, Items.AMETHYST_SHARD) >= breakthroughShards);
            row.putInt("breakthrough_shard_cost", breakthroughShards);
            rows.add(row);
        }
        snapshot.put("spells", rows);
        snapshot.put("additional_seals", createAdditionalSealSnapshot(player));
        return snapshot;
    }

    private static int challengeProgress(CompoundTag state) {
        return Math.max(0, Math.max(state.getInt("challenge_hits"), state.getInt("challenge_uses")));
    }

    public static double researchChance(SpellGrowthProfile profile, boolean useCore) {
        if (profile == null) return 0.0;
        return Math.max(0.05, Math.min(0.95, profile.tier().baseResearchChance() + (useCore ? 0.20 : 0.0)));
    }

    public static void copyOnClone(PlayerEvent.Clone event) {
        if (event == null || event.getOriginal() == null || event.getEntity() == null) return;
        CompoundTag previous = event.getOriginal().getPersistentData();
        if (previous.contains(ROOT_KEY, Tag.TAG_COMPOUND)) {
            event.getEntity().getPersistentData().put(ROOT_KEY, previous.getCompound(ROOT_KEY).copy());
        }
    }

    public static int countScrolls(Player player, String spellId) {
        if (player == null || spellId == null) return 0;
        int count = 0;
        for (ItemStack stack : player.getInventory().items) {
            if (SpellScrollResolver.matches(stack, spellId)) count += stack.getCount();
        }
        for (ItemStack stack : player.getInventory().offhand) {
            if (SpellScrollResolver.matches(stack, spellId)) count += stack.getCount();
        }
        return count;
    }

    private static boolean consumeScroll(Player player, String spellId, int amount) {
        if (player == null || amount <= 0 || countScrolls(player, spellId) < amount) return false;
        int remaining = amount;
        for (ItemStack stack : player.getInventory().items) {
            if (remaining <= 0) break;
            if (!SpellScrollResolver.matches(stack, spellId)) continue;
            int taken = Math.min(remaining, stack.getCount());
            stack.shrink(taken);
            remaining -= taken;
        }
        for (ItemStack stack : player.getInventory().offhand) {
            if (remaining <= 0) break;
            if (!SpellScrollResolver.matches(stack, spellId)) continue;
            int taken = Math.min(remaining, stack.getCount());
            stack.shrink(taken);
            remaining -= taken;
        }
        if (remaining == 0) {
            player.getInventory().setChanged();
            return true;
        }
        return false;
    }

    private static int countItem(Player player, Item item) {
        if (player == null || item == null) return 0;
        int count = 0;
        for (ItemStack stack : player.getInventory().items) if (stack.is(item)) count += stack.getCount();
        for (ItemStack stack : player.getInventory().offhand) if (stack.is(item)) count += stack.getCount();
        return count;
    }

    private static boolean consumeItem(Player player, Item item, int amount) {
        if (player == null || item == null || amount <= 0 || countItem(player, item) < amount) return false;
        int remaining = amount;
        for (ItemStack stack : player.getInventory().items) {
            if (remaining <= 0) break;
            if (!stack.is(item)) continue;
            int taken = Math.min(remaining, stack.getCount());
            stack.shrink(taken);
            remaining -= taken;
        }
        for (ItemStack stack : player.getInventory().offhand) {
            if (remaining <= 0) break;
            if (!stack.is(item)) continue;
            int taken = Math.min(remaining, stack.getCount());
            stack.shrink(taken);
            remaining -= taken;
        }
        return remaining == 0;
    }

    private static String percent(double chance) { return String.format(Locale.ROOT, "%.0f", chance * 100); }
    public record ActionResult(boolean success, String message) {
        public static ActionResult success(String message) { return new ActionResult(true, message); }
        public static ActionResult failure(String message) { return new ActionResult(false, message); }
    }
}
