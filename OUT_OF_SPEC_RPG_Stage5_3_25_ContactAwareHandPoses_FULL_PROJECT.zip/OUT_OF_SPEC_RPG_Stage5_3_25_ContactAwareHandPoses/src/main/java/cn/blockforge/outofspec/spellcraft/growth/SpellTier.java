package cn.blockforge.outofspec.spellcraft.growth;

/** The tier classifies a spell's designed scope and complexity; it is not the player's spell level. */
public enum SpellTier {
    LOWER("下阶", 0.82, 1),
    MIDDLE("中阶", 0.60, 2),
    UPPER("上阶", 0.28, 3),
    SUPER("超阶", 0.10, 4);

    private final String displayName;
    private final double baseResearchChance;
    private final int materialCost;

    SpellTier(String displayName, double baseResearchChance, int materialCost) {
        this.displayName = displayName;
        this.baseResearchChance = baseResearchChance;
        this.materialCost = materialCost;
    }

    public String displayName() { return displayName; }
    public double baseResearchChance() { return baseResearchChance; }
    public int materialCost() { return materialCost; }
}
