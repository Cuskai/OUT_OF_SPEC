package cn.blockforge.outofspec.spellcraft.item;

import cn.blockforge.outofspec.spellcraft.client.SpellGrowthClient;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;

/** Optional equipment for the automated / queued-cast modes; it is never required for seal casting. */
public final class ArcaneGrimoireItem extends Item {
    public ArcaneGrimoireItem(Properties properties) { super(properties); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> SpellGrowthClient.openGrimoire());
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
