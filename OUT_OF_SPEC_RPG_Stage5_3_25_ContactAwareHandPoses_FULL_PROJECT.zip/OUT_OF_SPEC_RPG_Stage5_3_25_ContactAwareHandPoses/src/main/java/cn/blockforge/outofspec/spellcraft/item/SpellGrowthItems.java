package cn.blockforge.outofspec.spellcraft.item;

import cn.blockforge.outofspec.binding.BindingCastingMod;
import cn.blockforge.outofspec.spellcraft.growth.SpellGrowthCatalog;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class SpellGrowthItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, BindingCastingMod.MOD_ID);

    public static final RegistryObject<Item> FIREBOLT_SCROLL = ITEMS.register("scroll_firebolt",
            () -> new SpellScrollItem(SpellGrowthCatalog.byKey("firebolt"), new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> MAGIC_ARROW_SCROLL = ITEMS.register("scroll_magic_arrow",
            () -> new SpellScrollItem(SpellGrowthCatalog.byKey("magic_arrow"), new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> FIREBALL_SCROLL = ITEMS.register("scroll_fireball",
            () -> new SpellScrollItem(SpellGrowthCatalog.byKey("fireball"), new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> LIGHTNING_LANCE_SCROLL = ITEMS.register("scroll_lightning_lance",
            () -> new SpellScrollItem(SpellGrowthCatalog.byKey("lightning_lance"), new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> ARCANE_CORE = ITEMS.register("arcane_core",
            () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> ARCANE_GRIMOIRE = ITEMS.register("arcane_grimoire",
            () -> new ArcaneGrimoireItem(new Item.Properties().stacksTo(1)));

    private SpellGrowthItems() {}

    public static RegistryObject<Item> scrollForSpell(String spellId) {
        if (SpellGrowthCatalog.bySpellId(spellId) == null) return null;
        return switch (SpellGrowthCatalog.bySpellId(spellId).key()) {
            case "firebolt" -> FIREBOLT_SCROLL;
            case "magic_arrow" -> MAGIC_ARROW_SCROLL;
            case "fireball" -> FIREBALL_SCROLL;
            case "lightning_lance" -> LIGHTNING_LANCE_SCROLL;
            default -> null;
        };
    }

    public static void addCreativeContents(BuildCreativeModeTabContentsEvent event) {
        if (!event.getTabKey().equals(CreativeModeTabs.TOOLS_AND_UTILITIES)) return;
        event.accept(FIREBOLT_SCROLL);
        event.accept(MAGIC_ARROW_SCROLL);
        event.accept(FIREBALL_SCROLL);
        event.accept(LIGHTNING_LANCE_SCROLL);
        event.accept(ARCANE_CORE);
        event.accept(ARCANE_GRIMOIRE);
    }
}
