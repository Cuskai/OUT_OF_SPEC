package cn.blockforge.outofspec.spellcraft.item;

import cn.blockforge.outofspec.binding.BindingCastingMod;
import cn.blockforge.outofspec.spellcraft.growth.SpellGrowthProfile;
import cn.blockforge.outofspec.spellcraft.growth.SpellGrowthService;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.List;

/** Scroll acquisition records discovery immediately; learning still requires a separate study attempt. */
public final class SpellScrollItem extends Item {
    private final String spellId;
    private final String spellName;

    public SpellScrollItem(SpellGrowthProfile profile, Properties properties) {
        super(properties);
        if (profile == null) throw new IllegalArgumentException("Spell scroll needs a known growth profile");
        this.spellId = profile.spellId();
        this.spellName = profile.displayName();
    }

    public String spellId() { return spellId; }
    public String displaySpellName() { return spellName; }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slotId, boolean selected) {
        super.inventoryTick(stack, level, entity, slotId, selected);
        if (level.isClientSide || !(entity instanceof Player player)) return;
        if (SpellGrowthService.discover(player, spellId)) {
            player.displayClientMessage(Component.literal("发现新术式：「" + spellName + "」。请打开术式研究档案尝试学习。"), true);
        }
    }

    @Override
    @OnlyIn(Dist.CLIENT)
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.out_of_spec_binding.scroll_discover"));
        tooltip.add(Component.translatable("tooltip.out_of_spec_binding.scroll_research"));
        tooltip.add(Component.translatable("tooltip.out_of_spec_binding.scroll_failure"));
    }
}
