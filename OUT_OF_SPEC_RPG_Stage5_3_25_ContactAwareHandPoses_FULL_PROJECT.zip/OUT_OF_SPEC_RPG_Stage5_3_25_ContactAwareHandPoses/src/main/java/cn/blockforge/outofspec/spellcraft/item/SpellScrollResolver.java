package cn.blockforge.outofspec.spellcraft.item;

import cn.blockforge.outofspec.spellcraft.growth.SpellGrowthCatalog;
import io.redspace.ironsspellbooks.api.spells.ISpellContainer;
import io.redspace.ironsspellbooks.api.spells.SpellData;
import io.redspace.ironsspellbooks.item.Scroll;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Locale;

/**
 * Robustly resolves both OUT OF SPEC research scrolls and native Iron's Spells scrolls.
 * A native scroll uses one registry item ID and stores the actual spell ID in its SpellContainer.
 */
public final class SpellScrollResolver {
    private static final String[] CONTAINER_KEYS = {"irons_spellbooks:spell_container", "ISB_Spells"};
    private static final String[] SPELL_ID_KEYS = {"id", "spell", "spellId", "spell_id"};

    private SpellScrollResolver() {}

    /** Returns the embedded spell ID for a recognized scroll, even if this spell is not in the growth catalog. */
    public static String spellId(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return null;
        if (stack.getItem() instanceof SpellScrollItem custom) return normalizeSpellId(custom.spellId());
        if (!looksLikeNativeScroll(stack)) return null;

        // Preferred path: use Iron's public API and its legacy NBT compatibility support.
        try {
            if (ISpellContainer.isSpellContainer(stack)) {
                ISpellContainer container = ISpellContainer.get(stack);
                if (container != null && !container.isEmpty()) {
                    SpellData data = container.getSpellAtIndex(0);
                    if (data != null && data.getSpell() != null) {
                        String resolved = normalizeSpellId(data.getSpell().getSpellId());
                        if (resolved != null && SpellGrowthCatalog.bySpellId(resolved) != null) return resolved;
                        // Keep unsupported but valid native spell IDs available to the diagnostic command.
                        if (resolved != null && !"irons_spellbooks:none".equals(resolved)) return resolved;
                    }
                }
            }
        } catch (RuntimeException ignored) {
            // Fall through to a defensive NBT parse. A malformed scroll must not break player ticking.
        }

        // Fallback for legacy / imported stacks that have a valid raw container but fail API decoding.
        return spellIdFromRawTag(stack);
    }

    private static boolean looksLikeNativeScroll(ItemStack stack) {
        if (stack.getItem() instanceof Scroll) return true;
        var key = ForgeRegistries.ITEMS.getKey(stack.getItem());
        return key != null && "irons_spellbooks".equals(key.getNamespace()) && "scroll".equals(key.getPath());
    }

    private static String spellIdFromRawTag(ItemStack stack) {
        try {
            CompoundTag root = stack.getTag();
            if (root == null) return null;
            for (String containerKey : CONTAINER_KEYS) {
                if (!root.contains(containerKey, Tag.TAG_COMPOUND)) continue;
                CompoundTag container = root.getCompound(containerKey);
                if (!container.contains("data", Tag.TAG_LIST)) continue;
                ListTag data = container.getList("data", Tag.TAG_COMPOUND);
                for (int i = 0; i < data.size(); i++) {
                    CompoundTag spell = data.getCompound(i);
                    for (String idKey : SPELL_ID_KEYS) {
                        if (!spell.contains(idKey, Tag.TAG_STRING)) continue;
                        String normalized = normalizeSpellId(spell.getString(idKey));
                        if (normalized != null && !"irons_spellbooks:none".equals(normalized)) return normalized;
                    }
                }
            }
        } catch (RuntimeException ignored) {
            // This is a best-effort fallback only; never crash inventory scanning.
        }
        return null;
    }

    private static String normalizeSpellId(String raw) {
        if (raw == null || raw.isBlank()) return null;
        String value = raw.trim();
        if (!value.contains(":")) value = "irons_spellbooks:" + value;
        ResourceLocation id = ResourceLocation.tryParse(value.toLowerCase(Locale.ROOT));
        return id == null ? null : id.toString();
    }

    /** Returns the spell ID only when this build implements that spell in the growth catalog. */
    public static String supportedSpellId(ItemStack stack) {
        String spellId = spellId(stack);
        return spellId != null && SpellGrowthCatalog.bySpellId(spellId) != null ? spellId : null;
    }

    public static boolean matches(ItemStack stack, String spellId) {
        String resolved = supportedSpellId(stack);
        return resolved != null && resolved.equals(spellId);
    }

    /** True when the held stack is a scroll-like item for diagnostics, whether or not its data is valid. */
    public static boolean isScrollCandidate(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        if (stack.getItem() instanceof SpellScrollItem || looksLikeNativeScroll(stack)) return true;
        var key = ForgeRegistries.ITEMS.getKey(stack.getItem());
        String itemId = key == null ? "" : key.toString().toLowerCase(Locale.ROOT);
        String name = stack.getHoverName().getString().toLowerCase(Locale.ROOT);
        String description = stack.getItem().getDescriptionId().toLowerCase(Locale.ROOT);
        return itemId.contains("scroll") || name.contains("scroll") || name.contains("卷轴")
                || name.contains("firebolt") || name.contains("火焰箭")
                || description.contains("scroll") || description.contains("firebolt");
    }
}
