package cn.blockforge.outofspec.spellcraft.model;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

/** One independently selectable additional-seal unit. */
public record AdditionalSealDefinition(
        String id,
        SealSequence sequence,
        long interSealTimeoutMillis,
        Set<String> compatibleRecipeIds,
        Set<String> requiredAdditionalSealIds,
        Set<String> incompatibleAdditionalSealIds,
        int maxOccurrencesPerCast,
        AdditionalSealTier tier,
        CompositionMode compositionMode,
        String executorId,
        List<EffectContribution> effects) {

    public AdditionalSealDefinition {
        id = ModelIds.requireId(id, "additionalSealId");
        Objects.requireNonNull(sequence, "sequence");
        if (interSealTimeoutMillis < 100 || interSealTimeoutMillis > 5_000) {
            throw new IllegalArgumentException("inter-seal timeout must be between 100 and 5000 ms");
        }
        compatibleRecipeIds = stableIds(compatibleRecipeIds, "compatibleRecipeIds");
        requiredAdditionalSealIds = stableIds(requiredAdditionalSealIds, "requiredAdditionalSealIds");
        incompatibleAdditionalSealIds = stableIds(incompatibleAdditionalSealIds, "incompatibleAdditionalSealIds");
        if (compatibleRecipeIds.isEmpty()) throw new IllegalArgumentException("additional seal needs at least one compatible recipe");
        if (requiredAdditionalSealIds.contains(id)) throw new IllegalArgumentException("additional seal cannot require itself");
        if (incompatibleAdditionalSealIds.contains(id)) throw new IllegalArgumentException("additional seal cannot conflict with itself");
        if (maxOccurrencesPerCast < 1 || maxOccurrencesPerCast > 32) {
            throw new IllegalArgumentException("maxOccurrencesPerCast must be 1..32 (input safety bound)");
        }
        Objects.requireNonNull(tier, "tier");
        Objects.requireNonNull(compositionMode, "compositionMode");
        if (compositionMode == CompositionMode.SPECIAL_EXECUTOR) {
            executorId = ModelIds.requireId(executorId, "executorId");
        } else if (executorId != null && !executorId.isBlank()) {
            throw new IllegalArgumentException("independent-effect seal must not declare a special executor");
        } else {
            executorId = "";
        }
        Objects.requireNonNull(effects, "effects");
        effects = List.copyOf(effects);
        for (EffectContribution effect : effects) {
            Objects.requireNonNull(effect, "effect");
            if (effect.source() != EffectSource.ADDITIONAL_SEAL || !effect.ownerId().equals(id)) {
                throw new IllegalArgumentException("additional-seal effects must be owned by this definition");
            }
        }
        Set<String> effectIds = new TreeSet<>();
        for (EffectContribution effect : effects) {
            if (!effectIds.add(effect.contributionId())) {
                throw new IllegalArgumentException("duplicate contribution ID inside additional seal: " + effect.contributionId());
            }
        }
    }

    private static Set<String> stableIds(Set<String> input, String field) {
        Objects.requireNonNull(input, field);
        TreeSet<String> sorted = new TreeSet<>();
        for (String id : input) sorted.add(ModelIds.requireId(id, field));
        return Collections.unmodifiableSet(sorted);
    }
}
