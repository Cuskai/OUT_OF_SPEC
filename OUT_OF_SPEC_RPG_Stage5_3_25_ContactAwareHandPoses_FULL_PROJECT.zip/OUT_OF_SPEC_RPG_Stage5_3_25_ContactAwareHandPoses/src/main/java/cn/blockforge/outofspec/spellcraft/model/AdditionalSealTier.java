package cn.blockforge.outofspec.spellcraft.model;

public enum AdditionalSealTier {
    BASIC,
    ADVANCED,
    SPECIAL
}
