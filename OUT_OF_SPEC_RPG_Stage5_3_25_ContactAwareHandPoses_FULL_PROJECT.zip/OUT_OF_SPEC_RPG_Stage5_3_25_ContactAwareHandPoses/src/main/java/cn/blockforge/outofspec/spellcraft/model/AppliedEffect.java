package cn.blockforge.outofspec.spellcraft.model;

import java.util.Objects;

/** A modifier bound to one concrete cast-plan application site. */
public record AppliedEffect(String applicationId, String resolvedSpellId, EffectContribution contribution, int occurrenceIndex) {
    public AppliedEffect {
        if (applicationId == null || applicationId.isBlank()) throw new IllegalArgumentException("applicationId is required");
        resolvedSpellId = ModelIds.requireId(resolvedSpellId, "resolvedSpellId");
        Objects.requireNonNull(contribution, "contribution");
        if (occurrenceIndex < 0) throw new IllegalArgumentException("occurrenceIndex cannot be negative");
        if (!"*".equals(contribution.targetSpellId()) && !contribution.targetSpellId().equals(resolvedSpellId)) {
            throw new IllegalArgumentException("effect is not applicable to resolved spell");
        }
    }
}
