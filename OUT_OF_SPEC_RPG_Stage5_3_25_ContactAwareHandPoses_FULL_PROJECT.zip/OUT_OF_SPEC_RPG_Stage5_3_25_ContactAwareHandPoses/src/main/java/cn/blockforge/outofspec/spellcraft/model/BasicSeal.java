package cn.blockforge.outofspec.spellcraft.model;

import java.util.Arrays;
import java.util.Locale;
import java.util.Optional;

/** The twelve input tokens. Keyboard bindings are deliberately stored elsewhere. */
public enum BasicSeal {
    ZI("zi", 'Z'),
    CHOU("chou", 'X'),
    YIN("yin", 'C'),
    MAO("mao", 'V'),
    CHEN("chen", 'B'),
    SI("si", 'N'),
    WU("wu", 'F'),
    WEI("wei", 'G'),
    SHEN("shen", 'H'),
    YOU("you", 'R'),
    XU("xu", 'T'),
    HAI("hai", 'Y');

    private final String id;
    private final char suggestedDefaultKey;

    BasicSeal(String id, char suggestedDefaultKey) {
        this.id = id;
        this.suggestedDefaultKey = suggestedDefaultKey;
    }

    public String id() { return id; }

    /** A suggestion only; runtime key mappings must remain rebindable. */
    public char suggestedDefaultKey() { return suggestedDefaultKey; }

    public static Optional<BasicSeal> byId(String value) {
        if (value == null) return Optional.empty();
        String normalized = value.trim().toLowerCase(Locale.ROOT);
        return Arrays.stream(values()).filter(seal -> seal.id.equals(normalized)).findFirst();
    }
}
