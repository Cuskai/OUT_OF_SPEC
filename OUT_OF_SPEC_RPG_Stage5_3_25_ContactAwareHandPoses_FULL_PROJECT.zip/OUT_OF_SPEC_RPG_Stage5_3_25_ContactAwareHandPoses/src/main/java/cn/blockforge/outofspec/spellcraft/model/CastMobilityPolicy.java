package cn.blockforge.outofspec.spellcraft.model;

/** Declarative baseline policy; an actual game adapter must enforce it. */
public enum CastMobilityPolicy {
    FREE,
    REDUCED_MOBILITY,
    STATIONARY,
    SNEAK_AND_STATIONARY
}
