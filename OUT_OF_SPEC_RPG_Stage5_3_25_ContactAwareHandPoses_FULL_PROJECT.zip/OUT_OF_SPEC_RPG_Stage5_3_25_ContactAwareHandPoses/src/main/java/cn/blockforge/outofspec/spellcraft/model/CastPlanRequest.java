package cn.blockforge.outofspec.spellcraft.model;

import java.util.List;
import java.util.Objects;
import java.util.UUID;

/** Untrusted selection request. Caster identity, active contracts and effect values are server-derived. */
public record CastPlanRequest(
        UUID requestId,
        String recipeId,
        List<String> selectedAdditionalSealIds) {

    public CastPlanRequest {
        Objects.requireNonNull(requestId, "requestId");
        recipeId = ModelIds.requireId(recipeId, "recipeId");
        Objects.requireNonNull(selectedAdditionalSealIds, "selectedAdditionalSealIds");
        if (selectedAdditionalSealIds.size() > 64) {
            throw new IllegalArgumentException("selectedAdditionalSealIds exceeds protocol safety limit");
        }
        selectedAdditionalSealIds = selectedAdditionalSealIds.stream()
                .map(id -> ModelIds.requireId(id, "selectedAdditionalSealIds"))
                .toList();
    }
}
