package cn.blockforge.outofspec.spellcraft.model;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Pure resolver. Caller must supply binding effects obtained from trusted server contract state. */
public final class CastPlanResolver {
    public static final String MODEL_VERSION = "2.6";
    private static final int MAX_ADDITIONAL_SELECTIONS = 32;

    public PlanResolution resolve(CastPlanRequest request, CastingRecipeRegistry registry,
                                  ServerCastContext serverContext) {
        if (registry == null || !registry.isFrozen()) {
            return PlanResolution.reject(PlanResolution.RejectionCode.REGISTRY_NOT_FROZEN,
                    "casting recipe registry is not frozen");
        }
        if (request == null || serverContext == null) {
            throw new IllegalArgumentException("request and trusted server context are required");
        }
        ServerBindingSnapshot serverBindingSnapshot = serverContext.bindingSnapshot();
        long serverTick = serverContext.serverTick();
        if (request.selectedAdditionalSealIds().size() > MAX_ADDITIONAL_SELECTIONS) {
            return PlanResolution.reject(PlanResolution.RejectionCode.OCCURRENCE_LIMIT_EXCEEDED,
                    "too many additional-seal selections in one cast plan");
        }
        SpellRecipe recipe = registry.recipe(request.recipeId());
        if (recipe == null) return PlanResolution.reject(PlanResolution.RejectionCode.UNKNOWN_RECIPE, "unknown base spell recipe");

        Map<String, Integer> occurrences = new HashMap<>();
        List<AdditionalSealDefinition> selected = new ArrayList<>();
        for (String id : request.selectedAdditionalSealIds()) {
            AdditionalSealDefinition definition = registry.additionalSeal(id);
            if (definition == null) return PlanResolution.reject(PlanResolution.RejectionCode.UNKNOWN_ADDITIONAL_SEAL,
                    "unknown additional seal: " + id);
            if (!definition.compatibleRecipeIds().contains(recipe.recipeId())) {
                return PlanResolution.reject(PlanResolution.RejectionCode.INCOMPATIBLE_ADDITIONAL_SEAL,
                        "additional seal is not registered for recipe " + recipe.recipeId() + ": " + id);
            }
            int count = occurrences.merge(id, 1, Integer::sum);
            if (count > definition.maxOccurrencesPerCast()) {
                return PlanResolution.reject(PlanResolution.RejectionCode.OCCURRENCE_LIMIT_EXCEEDED,
                        "additional seal occurrence limit exceeded: " + id);
            }
            selected.add(definition);
        }

        Set<String> selectedIds = occurrences.keySet();
        for (AdditionalSealDefinition definition : selected) {
            for (String requiredId : definition.requiredAdditionalSealIds()) {
                if (!selectedIds.contains(requiredId)) {
                    return PlanResolution.reject(PlanResolution.RejectionCode.REQUIRED_ADDITIONAL_SEAL_MISSING,
                            definition.id() + " requires " + requiredId);
                }
            }
            for (String incompatibleId : definition.incompatibleAdditionalSealIds()) {
                if (selectedIds.contains(incompatibleId)) {
                    return PlanResolution.reject(PlanResolution.RejectionCode.CONFLICTING_ADDITIONAL_SEALS,
                            definition.id() + " conflicts with " + incompatibleId);
                }
            }
        }

        List<AppliedEffect> applied = new ArrayList<>();
        for (int selectionIndex = 0; selectionIndex < selected.size(); selectionIndex++) {
            AdditionalSealDefinition definition = selected.get(selectionIndex);
            int occurrenceIndex = occurrenceIndex(request.selectedAdditionalSealIds(), selectionIndex, definition.id());
            for (EffectContribution contribution : definition.effects()) {
                if (!"*".equals(contribution.targetSpellId()) && !contribution.targetSpellId().equals(recipe.spellId())) {
                    return PlanResolution.reject(PlanResolution.RejectionCode.INCOMPATIBLE_ADDITIONAL_SEAL,
                            "additional-seal effect target does not match the resolved spell");
                }
                applied.add(new AppliedEffect(request.requestId() + "/additional/" + selectionIndex + "/" + contribution.contributionId(),
                        recipe.spellId(), contribution, occurrenceIndex));
            }
        }

        List<EffectContribution> sortedBindingEffects = new ArrayList<>(serverBindingSnapshot.effects());
        sortedBindingEffects.sort(Comparator.comparing(EffectContribution::ownerId)
                .thenComparing(EffectContribution::contributionId)
                .thenComparing(e -> e.source().name())
                .thenComparing(e -> e.parameter().name()));
        Set<String> seenBindingContributionKeys = new HashSet<>();
        for (EffectContribution contribution : sortedBindingEffects) {
            if (contribution.source() != EffectSource.BINDING_COST && contribution.source() != EffectSource.BINDING_REWARD) {
                return PlanResolution.reject(PlanResolution.RejectionCode.INVALID_BINDING_EFFECT,
                        "binding contribution has a non-binding source");
            }
            if (!serverBindingSnapshot.activeContractIds().contains(contribution.ownerId())) {
                return PlanResolution.reject(PlanResolution.RejectionCode.INVALID_BINDING_EFFECT,
                        "binding effect owner is not in the server active-contract snapshot");
            }
            String uniqueKey = contribution.ownerId() + "|" + contribution.contributionId();
            if (!seenBindingContributionKeys.add(uniqueKey)) {
                return PlanResolution.reject(PlanResolution.RejectionCode.DUPLICATE_BINDING_CONTRIBUTION,
                        "duplicate binding contribution in server snapshot: " + contribution.contributionId());
            }
            if (!"*".equals(contribution.targetSpellId()) && !contribution.targetSpellId().equals(recipe.spellId())) {
                continue; // Valid active contract, but its spell-scoped effect does not apply to this spell.
            }
            applied.add(new AppliedEffect(request.requestId() + "/binding/" + contribution.source().name().toLowerCase(java.util.Locale.ROOT)
                    + "/" + contribution.ownerId() + "/" + contribution.contributionId(),
                    recipe.spellId(), contribution, 0));
        }

        ResolvedCastPlan plan = ResolvedCastPlan.create(MODEL_VERSION, request.requestId(), serverContext.casterId(),
                recipe.recipeId(), recipe.spellId(), request.selectedAdditionalSealIds(),
                serverBindingSnapshot.activeContractIds(), applied, serverTick);
        return PlanResolution.accept(plan);
    }

    private static int occurrenceIndex(List<String> selections, int currentIndex, String id) {
        int occurrence = 0;
        for (int i = 0; i <= currentIndex; i++) if (selections.get(i).equals(id)) occurrence++;
        return occurrence - 1;
    }
}
