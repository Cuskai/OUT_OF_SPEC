package cn.blockforge.outofspec.spellcraft.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

/** Mutable during bootstrap, immutable after freeze. No Minecraft dependencies. */
public final class CastingRecipeRegistry {
    private final Map<String, SpellRecipe> recipes = new LinkedHashMap<>();
    private final Map<String, AdditionalSealDefinition> additions = new LinkedHashMap<>();
    private boolean frozen;

    public void registerSpellRecipe(SpellRecipe recipe) {
        ensureMutable();
        Objects.requireNonNull(recipe, "recipe");
        if (recipes.containsKey(recipe.recipeId())) {
            throw new IllegalArgumentException("duplicate spell recipe ID: " + recipe.recipeId());
        }
        for (SpellRecipe other : recipes.values()) {
            if (other.sequence().equals(recipe.sequence())) {
                throw new IllegalArgumentException("ambiguous base-seal sequence " + recipe.sequence().canonicalKey()
                        + " for recipes " + other.recipeId() + " and " + recipe.recipeId());
            }
        }
        recipes.put(recipe.recipeId(), recipe);
    }

    public void registerAdditionalSeal(AdditionalSealDefinition definition) {
        ensureMutable();
        Objects.requireNonNull(definition, "definition");
        if (additions.putIfAbsent(definition.id(), definition) != null) {
            throw new IllegalArgumentException("duplicate additional-seal ID: " + definition.id());
        }
    }

    /**
     * Freeze after the real adapter supplies IDs of concrete SPECIAL_EXECUTOR implementations.
     * Merely naming an executor is not treated as implementing it.
     */
    public void freeze(Set<String> registeredSpecialExecutors) {
        ensureMutable();
        Objects.requireNonNull(registeredSpecialExecutors, "registeredSpecialExecutors");
        Set<String> executorIds = new TreeSet<>();
        for (String id : registeredSpecialExecutors) executorIds.add(ModelIds.requireId(id, "executorId"));

        for (AdditionalSealDefinition addition : additions.values()) {
            for (String recipeId : addition.compatibleRecipeIds()) {
                if (!recipes.containsKey(recipeId)) throw new IllegalArgumentException("unknown compatible recipe " + recipeId + " in " + addition.id());
            }
            for (String requiredId : addition.requiredAdditionalSealIds()) {
                AdditionalSealDefinition required = additions.get(requiredId);
                if (required == null) throw new IllegalArgumentException("unknown required additional seal " + requiredId + " in " + addition.id());
                if (!required.compatibleRecipeIds().containsAll(addition.compatibleRecipeIds())) {
                    throw new IllegalArgumentException("required additional seal " + requiredId
                            + " is not compatible with every recipe supported by " + addition.id());
                }
                if (addition.incompatibleAdditionalSealIds().contains(requiredId)
                        || required.incompatibleAdditionalSealIds().contains(addition.id())) {
                    throw new IllegalArgumentException("contradictory requires/conflicts rules between " + addition.id() + " and " + requiredId);
                }
            }
            for (String incompatibleId : addition.incompatibleAdditionalSealIds()) {
                if (!additions.containsKey(incompatibleId)) throw new IllegalArgumentException("unknown incompatible additional seal " + incompatibleId + " in " + addition.id());
            }
            if (addition.compositionMode() == CompositionMode.SPECIAL_EXECUTOR && !executorIds.contains(addition.executorId())) {
                throw new IllegalArgumentException("special executor is not registered: " + addition.executorId());
            }
            for (EffectContribution effect : addition.effects()) {
                if (!"*".equals(effect.targetSpellId())) {
                    for (String recipeId : addition.compatibleRecipeIds()) {
                        SpellRecipe recipe = recipes.get(recipeId);
                        if (!effect.targetSpellId().equals(recipe.spellId())) {
                            throw new IllegalArgumentException("effect target " + effect.targetSpellId()
                                    + " conflicts with compatible recipe " + recipeId);
                        }
                    }
                }
            }
        }

        List<AdditionalSealDefinition> defs = new ArrayList<>(additions.values());
        for (int i = 0; i < defs.size(); i++) {
            AdditionalSealDefinition a = defs.get(i);
            for (int j = i + 1; j < defs.size(); j++) {
                AdditionalSealDefinition b = defs.get(j);
                Set<String> commonRecipes = new TreeSet<>(a.compatibleRecipeIds());
                commonRecipes.retainAll(b.compatibleRecipeIds());
                if (!commonRecipes.isEmpty() && a.sequence().equals(b.sequence())) {
                    throw new IllegalArgumentException("ambiguous additional-seal sequence " + a.sequence().canonicalKey()
                            + " for same recipe context: " + a.id() + " and " + b.id());
                }
            }
        }
        this.frozen = true;
    }

    public SequenceMatch matchBase(SealSequence input) {
        ensureFrozen();
        List<String> exact = new ArrayList<>();
        List<String> longer = new ArrayList<>();
        for (SpellRecipe recipe : recipes.values()) {
            if (recipe.sequence().equals(input)) exact.add(recipe.recipeId());
            else if (input.isStrictPrefixOf(recipe.sequence())) longer.add(recipe.recipeId());
        }
        Collections.sort(exact);
        Collections.sort(longer);
        return matchResult(exact, longer);
    }

    public SequenceMatch matchAdditional(String recipeId, SealSequence input) {
        ensureFrozen();
        if (!recipes.containsKey(recipeId)) throw new IllegalArgumentException("unknown recipe: " + recipeId);
        List<String> exact = new ArrayList<>();
        List<String> longer = new ArrayList<>();
        for (AdditionalSealDefinition definition : additions.values()) {
            if (!definition.compatibleRecipeIds().contains(recipeId)) continue;
            if (definition.sequence().equals(input)) exact.add(definition.id());
            else if (input.isStrictPrefixOf(definition.sequence())) longer.add(definition.id());
        }
        Collections.sort(exact);
        Collections.sort(longer);
        return matchResult(exact, longer);
    }

    private static SequenceMatch matchResult(List<String> exact, List<String> longer) {
        SequenceMatch.Status status = exact.isEmpty()
                ? (longer.isEmpty() ? SequenceMatch.Status.NONE : SequenceMatch.Status.PREFIX_ONLY)
                : (longer.isEmpty() ? SequenceMatch.Status.EXACT : SequenceMatch.Status.EXACT_AND_PREFIX);
        return new SequenceMatch(status, exact, longer);
    }

    public SpellRecipe recipe(String id) { ensureFrozen(); return recipes.get(id); }
    public AdditionalSealDefinition additionalSeal(String id) { ensureFrozen(); return additions.get(id); }
    public Map<String, SpellRecipe> spellRecipes() { ensureFrozen(); return Collections.unmodifiableMap(recipes); }
    public Map<String, AdditionalSealDefinition> additionalSeals() { ensureFrozen(); return Collections.unmodifiableMap(additions); }
    public boolean isFrozen() { return frozen; }

    private void ensureMutable() {
        if (frozen) throw new IllegalStateException("casting recipe registry is frozen");
    }
    private void ensureFrozen() {
        if (!frozen) throw new IllegalStateException("casting recipe registry must be frozen before resolution");
    }
}
