package cn.blockforge.outofspec.spellcraft.model;

/** SPECIAL_EXECUTOR requires a concrete executor registered by the game adapter. */
public enum CompositionMode {
    INDEPENDENT_EFFECTS,
    SPECIAL_EXECUTOR
}
