package cn.blockforge.outofspec.spellcraft.model;

import java.util.Objects;

/** Immutable, sourced modifier. This model records intent; game code must still execute it. */
public record EffectContribution(
        String contributionId,
        EffectSource source,
        String ownerId,
        String targetSpellId,
        EffectParameter parameter,
        EffectOperation operation,
        EffectUnit unit,
        double value) {

    public EffectContribution {
        contributionId = ModelIds.requireId(contributionId, "contributionId");
        Objects.requireNonNull(source, "source");
        ownerId = ModelIds.requireId(ownerId, "ownerId");
        targetSpellId = ModelIds.requireScope(targetSpellId, "targetSpellId");
        Objects.requireNonNull(parameter, "parameter");
        Objects.requireNonNull(operation, "operation");
        Objects.requireNonNull(unit, "unit");
        if (!Double.isFinite(value) || Math.abs(value) > 1_000_000_000d) {
            throw new IllegalArgumentException("effect value must be finite and safely representable");
        }
        if (!unitAndOperationMatch(parameter, operation, unit)) {
            throw new IllegalArgumentException("unit/operation does not match parameter: "
                    + parameter + " / " + operation + " / " + unit);
        }
        if (operation == EffectOperation.MULTIPLY && value < 0d) {
            throw new IllegalArgumentException("multipliers cannot be negative; zero remains valid for full suppression");
        }
        if (operation == EffectOperation.REPLACE && value < 0d) {
            throw new IllegalArgumentException("replacement values cannot be negative");
        }
        if ((unit == EffectUnit.COUNT || unit == EffectUnit.TICKS) && value != Math.rint(value)) {
            throw new IllegalArgumentException("count/tick values must be whole numbers");
        }
    }

    private static boolean unitAndOperationMatch(EffectParameter p, EffectOperation op, EffectUnit u) {
        return switch (p) {
            case DAMAGE, SPELL_POWER -> op == EffectOperation.MULTIPLY && u == EffectUnit.MULTIPLIER;
            case AREA_RADIUS -> (op == EffectOperation.MULTIPLY && u == EffectUnit.MULTIPLIER)
                    || (op == EffectOperation.ADD && u == EffectUnit.BLOCKS)
                    || (op == EffectOperation.REPLACE && (u == EffectUnit.MULTIPLIER || u == EffectUnit.BLOCKS));
            case PROJECTILE_COUNT, PIERCING_COUNT -> (op == EffectOperation.ADD || op == EffectOperation.REPLACE)
                    && u == EffectUnit.COUNT;
            case FLIGHT_SPEED, CAST_MOVE_SPEED -> op == EffectOperation.MULTIPLY && u == EffectUnit.MULTIPLIER;
            case DURATION_TICKS, COOLDOWN_TICKS, CAST_TIME_TICKS ->
                    (op == EffectOperation.MULTIPLY && u == EffectUnit.MULTIPLIER)
                    || ((op == EffectOperation.ADD || op == EffectOperation.REPLACE) && u == EffectUnit.TICKS);
            case MANA_COST -> (op == EffectOperation.MULTIPLY && u == EffectUnit.MULTIPLIER)
                    || ((op == EffectOperation.ADD || op == EffectOperation.REPLACE) && u == EffectUnit.RESOURCE_POINTS);
        };
    }
}
