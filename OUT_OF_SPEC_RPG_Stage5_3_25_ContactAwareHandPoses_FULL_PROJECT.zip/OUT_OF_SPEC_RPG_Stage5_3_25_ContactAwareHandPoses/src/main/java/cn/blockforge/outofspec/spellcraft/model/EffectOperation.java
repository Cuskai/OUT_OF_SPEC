package cn.blockforge.outofspec.spellcraft.model;

public enum EffectOperation {
    ADD,
    MULTIPLY,
    REPLACE
}
