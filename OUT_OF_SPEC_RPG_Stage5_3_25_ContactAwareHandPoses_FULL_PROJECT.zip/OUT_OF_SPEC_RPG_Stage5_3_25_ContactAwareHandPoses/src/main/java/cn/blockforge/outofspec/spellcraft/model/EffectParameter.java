package cn.blockforge.outofspec.spellcraft.model;

/** Typed effect slots. Registration of a slot does not itself promise a game executor exists. */
public enum EffectParameter {
    DAMAGE,
    SPELL_POWER,
    AREA_RADIUS,
    PROJECTILE_COUNT,
    FLIGHT_SPEED,
    CAST_MOVE_SPEED,
    DURATION_TICKS,
    PIERCING_COUNT,
    MANA_COST,
    COOLDOWN_TICKS,
    CAST_TIME_TICKS
}
