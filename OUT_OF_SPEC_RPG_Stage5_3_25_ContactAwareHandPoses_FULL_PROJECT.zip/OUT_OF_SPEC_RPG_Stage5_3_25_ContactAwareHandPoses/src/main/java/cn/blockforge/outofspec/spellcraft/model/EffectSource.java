package cn.blockforge.outofspec.spellcraft.model;

/** Provenance of an effect; provenance is part of validation and accounting. */
public enum EffectSource {
    ADDITIONAL_SEAL,
    BINDING_REWARD,
    BINDING_COST
}
