package cn.blockforge.outofspec.spellcraft.model;

/** Explicit units stop percentages, ticks, counts and dimensions being confused. */
public enum EffectUnit {
    MULTIPLIER,
    BLOCKS,
    COUNT,
    TICKS,
    RESOURCE_POINTS
}
