package cn.blockforge.outofspec.spellcraft.model;

import java.util.regex.Pattern;

/** Shared stable-ID validation for the composable casting model. */
final class ModelIds {
    private static final Pattern NAMESPACED = Pattern.compile("[a-z0-9_.-]+:[a-z0-9_./-]+");

    private ModelIds() {}

    static String requireId(String value, String field) {
        if (value == null || !NAMESPACED.matcher(value).matches()) {
            throw new IllegalArgumentException(field + " must be a stable namespaced ID: " + value);
        }
        return value;
    }

    static String requireScope(String value, String field) {
        if ("*".equals(value)) return value;
        return requireId(value, field);
    }
}
