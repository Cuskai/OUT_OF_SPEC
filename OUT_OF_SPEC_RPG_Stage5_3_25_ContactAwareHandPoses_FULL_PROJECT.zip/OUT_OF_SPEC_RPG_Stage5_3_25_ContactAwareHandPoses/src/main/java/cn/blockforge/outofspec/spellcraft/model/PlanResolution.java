package cn.blockforge.outofspec.spellcraft.model;

import java.util.Objects;
import java.util.Optional;

public record PlanResolution(RejectionCode code, String message, ResolvedCastPlan plan) {
    public enum RejectionCode {
        ACCEPTED,
        REGISTRY_NOT_FROZEN,
        UNKNOWN_RECIPE,
        UNKNOWN_ADDITIONAL_SEAL,
        INCOMPATIBLE_ADDITIONAL_SEAL,
        OCCURRENCE_LIMIT_EXCEEDED,
        REQUIRED_ADDITIONAL_SEAL_MISSING,
        CONFLICTING_ADDITIONAL_SEALS,
        INVALID_BINDING_EFFECT,
        DUPLICATE_BINDING_CONTRIBUTION
    }

    public PlanResolution {
        Objects.requireNonNull(code, "code");
        if (message == null || message.isBlank()) throw new IllegalArgumentException("message is required");
        if ((code == RejectionCode.ACCEPTED) != (plan != null)) {
            throw new IllegalArgumentException("accepted resolution must have a plan and rejection must not");
        }
    }

    public boolean accepted() { return code == RejectionCode.ACCEPTED; }
    public Optional<ResolvedCastPlan> optionalPlan() { return Optional.ofNullable(plan); }

    public static PlanResolution accept(ResolvedCastPlan plan) {
        return new PlanResolution(RejectionCode.ACCEPTED, "server-resolved cast plan", Objects.requireNonNull(plan));
    }
    public static PlanResolution reject(RejectionCode code, String message) {
        if (code == RejectionCode.ACCEPTED) throw new IllegalArgumentException("use accept() for accepted result");
        return new PlanResolution(code, message, null);
    }
}
