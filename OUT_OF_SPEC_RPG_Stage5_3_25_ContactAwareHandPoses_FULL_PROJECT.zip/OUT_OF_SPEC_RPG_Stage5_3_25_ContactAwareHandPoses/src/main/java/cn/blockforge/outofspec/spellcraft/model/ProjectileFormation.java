package cn.blockforge.outofspec.spellcraft.model;

import java.util.ArrayList;
import java.util.List;

/** Pure, deterministic lateral spread used by the server-side native-projectile executor. */
public final class ProjectileFormation {
    public static final double BLOCK_SPACING = 0.72;
    public static final double DEGREES_PER_SLOT = 10.0;
    public static final int MAX_SUPPORTED_PROJECTILES = 64;

    public record Slot(int index, int total, double lateralOffsetBlocks, double yawOffsetDegrees) {}

    private ProjectileFormation() {}

    /** Centered, left-to-right distribution; even counts straddle the center and odd counts include it. */
    public static List<Slot> distribute(int totalProjectiles) {
        if (totalProjectiles < 0 || totalProjectiles > MAX_SUPPORTED_PROJECTILES) {
            throw new IllegalArgumentException("projectile count is outside the supported formation domain");
        }
        if (totalProjectiles == 0) return List.of();
        List<Slot> slots = new ArrayList<>(totalProjectiles);
        double center = (totalProjectiles - 1) / 2.0;
        for (int index = 0; index < totalProjectiles; index++) {
            double lateralIndex = index - center;
            slots.add(new Slot(index, totalProjectiles,
                    lateralIndex * BLOCK_SPACING, lateralIndex * DEGREES_PER_SLOT));
        }
        return List.copyOf(slots);
    }
}
