package cn.blockforge.outofspec.spellcraft.model;

import cn.blockforge.outofspec.spellcraft.growth.SpellGrowthCatalog;
import cn.blockforge.outofspec.spellcraft.growth.SpellGrowthProfile;
import cn.blockforge.outofspec.spellcraft.growth.SpellTier;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Server/client view of the same generated spell recipes. The four legacy recipes retain their
 * tested IDs and short sequences; every additional enabled registry spell receives a stable recipe
 * ID and unique four-seal sequence. Rebuilds when SpellGrowthCatalog's registry generation changes.
 */
public final class RealSealCastingRecipes {
    public static final String MAGIC_ARROW = "out_of_spec_binding:recipe_magic_arrow";
    public static final String FIREBOLT = "out_of_spec_binding:recipe_firebolt";
    public static final String LIGHTNING_LANCE = "out_of_spec_binding:recipe_lightning_lance";
    public static final String FIREBALL = "out_of_spec_binding:recipe_fireball";

    public static final String POWER_FOCUS = "out_of_spec_binding:power_focus";
    public static final String POWER_FOCUS_STRONG = "out_of_spec_binding:power_focus_strong";
    public static final String QUICK_RELEASE = "out_of_spec_binding:quick_release";
    public static final String MULTI_RELEASE = "out_of_spec_binding:multi_release";
    public static final String TRIUNE_RELEASE = "out_of_spec_binding:triune_release";
    public static final String FIREBALL_EXPANSION = "out_of_spec_binding:fireball_expansion";

    private static final List<String> ADDITIONAL_SEAL_IDS = List.of(
            POWER_FOCUS, POWER_FOCUS_STRONG, QUICK_RELEASE,
            MULTI_RELEASE, TRIUNE_RELEASE, FIREBALL_EXPANSION);
    private static final Set<String> MULTI_RELEASE_RECIPE_IDS = Set.of(
            MAGIC_ARROW, FIREBOLT, LIGHTNING_LANCE, FIREBALL);

    private static volatile CastingRecipeRegistry registry;
    private static volatile long builtCatalogGeneration = Long.MIN_VALUE;

    private RealSealCastingRecipes() {}

    public static synchronized CastingRecipeRegistry registry() {
        long generation = SpellGrowthCatalog.generation();
        if (registry == null || builtCatalogGeneration != generation) rebuild();
        return registry;
    }

    /** Called after Forge's spell registry has been populated; safe to call more than once. */
    public static synchronized void refresh() { rebuild(); }

    /**
     * Input sessions keep the complete immutable registry so prerequisite/conflict references
     * remain valid. SealInputSession independently filters matched additions by the player's
     * learned IDs; removing unlearned definitions here would invalidate those cross-references.
     */
    public static synchronized CastingRecipeRegistry registryForLearnedAdditions(Set<String> learnedAdditionIds) {
        return registry();
    }

    private static void rebuild() {
        List<SpellGrowthProfile> profiles = new ArrayList<>(SpellGrowthCatalog.profiles());
        profiles.sort(Comparator.comparing(SpellGrowthProfile::spellId));
        CastingRecipeRegistry next = new CastingRecipeRegistry();
        Set<String> allRecipeIds = new LinkedHashSet<>();
        for (SpellGrowthProfile profile : profiles) {
            String recipeId = recipeIdForSpell(profile.spellId());
            SealSequence sequence = SpellGrowthCatalog.sealSequence(profile.spellId());
            if (sequence == null) {
                throw new IllegalStateException("growth spell lacks a seal sequence: " + profile.spellId());
            }
            next.registerSpellRecipe(new SpellRecipe(recipeId, profile.spellId(), sequence, 800L, CastMobilityPolicy.FREE));
            allRecipeIds.add(recipeId);
        }

        EffectContribution normalPower = effect(POWER_FOCUS, "spell_power", "*", EffectParameter.SPELL_POWER,
                EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 1.20);
        EffectContribution strongPower = effect(POWER_FOCUS_STRONG, "spell_power", "*", EffectParameter.SPELL_POWER,
                EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 1.35);
        EffectContribution quickCast = effect(QUICK_RELEASE, "cast_time", "*", EffectParameter.CAST_TIME_TICKS,
                EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 0.50);
        EffectContribution multiProjectiles = effect(MULTI_RELEASE, "projectile_count", "*", EffectParameter.PROJECTILE_COUNT,
                EffectOperation.ADD, EffectUnit.COUNT, 1);
        EffectContribution multiMana = effect(MULTI_RELEASE, "mana_cost", "*", EffectParameter.MANA_COST,
                EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 1.40);
        EffectContribution triuneProjectiles = effect(TRIUNE_RELEASE, "projectile_count", "*", EffectParameter.PROJECTILE_COUNT,
                EffectOperation.ADD, EffectUnit.COUNT, 2);
        EffectContribution triuneMana = effect(TRIUNE_RELEASE, "mana_cost", "*", EffectParameter.MANA_COST,
                EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 1.85);
        EffectContribution fireballRadius = effect(FIREBALL_EXPANSION, "area_radius", "irons_spellbooks:fireball",
                EffectParameter.AREA_RADIUS, EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 1.35);
        EffectContribution fireballMana = effect(FIREBALL_EXPANSION, "mana_cost", "irons_spellbooks:fireball",
                EffectParameter.MANA_COST, EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 1.25);

        next.registerAdditionalSeal(new AdditionalSealDefinition(POWER_FOCUS,
                SealSequence.of(BasicSeal.WU), 800L, allRecipeIds, Set.of(), Set.of(POWER_FOCUS_STRONG),
                1, AdditionalSealTier.BASIC, CompositionMode.INDEPENDENT_EFFECTS, "", List.of(normalPower)));
        next.registerAdditionalSeal(new AdditionalSealDefinition(POWER_FOCUS_STRONG,
                SealSequence.of(BasicSeal.WU, BasicSeal.WEI), 800L, allRecipeIds, Set.of(), Set.of(POWER_FOCUS),
                1, AdditionalSealTier.ADVANCED, CompositionMode.INDEPENDENT_EFFECTS, "", List.of(strongPower)));
        next.registerAdditionalSeal(new AdditionalSealDefinition(QUICK_RELEASE,
                SealSequence.of(BasicSeal.ZI, BasicSeal.HAI), 800L, allRecipeIds, Set.of(), Set.of(),
                1, AdditionalSealTier.BASIC, CompositionMode.INDEPENDENT_EFFECTS, "", List.of(quickCast)));
        next.registerAdditionalSeal(new AdditionalSealDefinition(MULTI_RELEASE,
                SealSequence.of(BasicSeal.SHEN, BasicSeal.XU), 800L, MULTI_RELEASE_RECIPE_IDS, Set.of(), Set.of(TRIUNE_RELEASE),
                1, AdditionalSealTier.ADVANCED, CompositionMode.INDEPENDENT_EFFECTS, "", List.of(multiProjectiles, multiMana)));
        next.registerAdditionalSeal(new AdditionalSealDefinition(TRIUNE_RELEASE,
                SealSequence.of(BasicSeal.SHEN, BasicSeal.YOU, BasicSeal.XU), 800L, MULTI_RELEASE_RECIPE_IDS, Set.of(), Set.of(MULTI_RELEASE),
                1, AdditionalSealTier.SPECIAL, CompositionMode.INDEPENDENT_EFFECTS, "", List.of(triuneProjectiles, triuneMana)));
        next.registerAdditionalSeal(new AdditionalSealDefinition(FIREBALL_EXPANSION,
                SealSequence.of(BasicSeal.MAO, BasicSeal.YOU), 800L, Set.of(FIREBALL), Set.of(), Set.of(),
                1, AdditionalSealTier.ADVANCED, CompositionMode.INDEPENDENT_EFFECTS, "", List.of(fireballRadius, fireballMana)));
        next.freeze(Set.of());
        registry = next;
        builtCatalogGeneration = SpellGrowthCatalog.generation();
    }

    private static EffectContribution effect(String owner, String suffix, String targetSpellId,
                                             EffectParameter parameter, EffectOperation operation,
                                             EffectUnit unit, double value) {
        return new EffectContribution(owner + "/" + suffix, EffectSource.ADDITIONAL_SEAL, owner,
                targetSpellId, parameter, operation, unit, value);
    }

    public static String recipeIdForSpell(String spellId) {
        if ("irons_spellbooks:magic_arrow".equals(spellId)) return MAGIC_ARROW;
        if ("irons_spellbooks:firebolt".equals(spellId)) return FIREBOLT;
        if ("irons_spellbooks:lightning_lance".equals(spellId)) return LIGHTNING_LANCE;
        if ("irons_spellbooks:fireball".equals(spellId)) return FIREBALL;
        if (spellId == null || spellId.isBlank()) throw new IllegalArgumentException("spellId is required");
        int separator = spellId.indexOf(':');
        if (separator <= 0 || separator == spellId.length() - 1 || spellId.indexOf(':', separator + 1) >= 0) {
            throw new IllegalArgumentException("spellId must be namespaced: " + spellId);
        }
        String namespace = spellId.substring(0, separator).toLowerCase(java.util.Locale.ROOT);
        String path = spellId.substring(separator + 1).toLowerCase(java.util.Locale.ROOT);
        // Preserve the namespace/path boundary in the generated recipe path; this is injective.
        return "out_of_spec_binding:recipe/" + namespace + "/" + path;
    }

    public static String spellName(String recipeId) {
        String spellId = spellId(recipeId);
        SpellGrowthProfile profile = SpellGrowthCatalog.bySpellId(spellId);
        if (profile != null) return profile.displayName();
        return "未知术式 (" + recipeId + ")";
    }

    public static String spellId(String recipeId) {
        if (recipeId == null) return "";
        SpellRecipe recipe = registry().recipe(recipeId);
        return recipe == null ? "" : recipe.spellId();
    }

    public static List<String> additionalSealIds() { return ADDITIONAL_SEAL_IDS; }

    public static boolean isKnownAdditionalSeal(String additionId) {
        return additionId != null && ADDITIONAL_SEAL_IDS.contains(additionId);
    }

    public static int additionCoreCost(String additionId) {
        return switch (additionId == null ? "" : additionId) {
            case POWER_FOCUS, QUICK_RELEASE -> 1;
            case POWER_FOCUS_STRONG, MULTI_RELEASE, FIREBALL_EXPANSION -> 2;
            case TRIUNE_RELEASE -> 3;
            default -> 0;
        };
    }

    public static int additionShardCost(String additionId) {
        return switch (additionId == null ? "" : additionId) {
            case POWER_FOCUS -> 2;
            case POWER_FOCUS_STRONG -> 6;
            case QUICK_RELEASE -> 3;
            case MULTI_RELEASE -> 4;
            case FIREBALL_EXPANSION -> 5;
            case TRIUNE_RELEASE -> 8;
            default -> 0;
        };
    }

    public static String additionName(String additionId) {
        return switch (additionId == null ? "" : additionId) {
            case POWER_FOCUS -> "法术强度聚焦";
            case POWER_FOCUS_STRONG -> "高阶法术强度聚焦";
            case QUICK_RELEASE -> "迅捷起印";
            case MULTI_RELEASE -> "多重释放";
            case TRIUNE_RELEASE -> "三重释放";
            case FIREBALL_EXPANSION -> "炽域扩张";
            default -> "未知追加印 (" + additionId + ")";
        };
    }

    public static String additionTierName(String additionId) {
        return switch (additionId == null ? "" : additionId) {
            case POWER_FOCUS, QUICK_RELEASE -> "基础";
            case POWER_FOCUS_STRONG, MULTI_RELEASE, FIREBALL_EXPANSION -> "进阶";
            case TRIUNE_RELEASE -> "高阶";
            default -> "未登记";
        };
    }

    public static String additionSequence(String additionId) {
        return switch (additionId == null ? "" : additionId) {
            case POWER_FOCUS -> "午";
            case POWER_FOCUS_STRONG -> "午 → 未";
            case QUICK_RELEASE -> "子 → 亥";
            case MULTI_RELEASE -> "申 → 戌";
            case TRIUNE_RELEASE -> "申 → 酉 → 戌";
            case FIREBALL_EXPANSION -> "卯 → 酉";
            default -> "未登记";
        };
    }

    public static String additionPreview(String additionId) {
        return switch (additionId == null ? "" : additionId) {
            case POWER_FOCUS -> "本次施法的 Iron's Spells 法术强度计算值 ×1.20";
            case POWER_FOCUS_STRONG -> "本次施法的 Iron's Spells 法术强度计算值 ×1.35";
            case QUICK_RELEASE -> "本次有效吟唱时间减半（×0.50）；瞬发法术不受影响";
            case MULTI_RELEASE -> "原版弹体与额外弹体左右分列同时发射；魔力消耗 ×1.40";
            case TRIUNE_RELEASE -> "原版弹体与两枚额外弹体按左／中／右同时发射；魔力消耗 ×1.85";
            case FIREBALL_EXPANSION -> "仅对火球术生效：爆炸半径 ×1.35；魔力消耗 ×1.25";
            default -> "此追加印没有已注册的真实执行器";
        };
    }

    public static String additionDescription(String additionId) {
        return switch (additionId == null ? "" : additionId) {
            case POWER_FOCUS -> "基础术式完成后追加午印，强化本次法术强度。";
            case POWER_FOCUS_STRONG -> "追加午、未两印强化法术强度；与普通强度聚焦互斥。";
            case QUICK_RELEASE -> "基础术式完成后追加子、亥两印，压缩本次有效吟唱时间。";
            case MULTI_RELEASE -> "对魔法箭、火焰箭、雷鸣长枪、火球术同时从左右分列释放两枚弹体；与三重释放互斥。";
            case TRIUNE_RELEASE -> "对已接入的四种投射术式同时形成左／中／右三路弹体；与多重释放互斥。";
            case FIREBALL_EXPANSION -> "仅对火球术扩大爆炸半径；可与其他不冲突的追加印组合。";
            default -> "此追加印没有已注册的真实执行器";
        };
    }

    public static String additionPrerequisiteText(String additionId) {
        String prerequisite = switch (additionId == null ? "" : additionId) {
            case POWER_FOCUS -> "至少掌握一个术式";
            case POWER_FOCUS_STRONG -> "先掌握法术强度聚焦；至少一个术式达到 Lv.3";
            case QUICK_RELEASE -> "至少掌握一个术式";
            case MULTI_RELEASE -> "至少一个已掌握术式达到 Lv.2";
            case TRIUNE_RELEASE -> "先掌握多重释放；至少一个已掌握术式达到 Lv.3";
            case FIREBALL_EXPANSION -> "先掌握火球术，且火球术达到 Lv.2";
            default -> "无有效学习路径";
        };
        return prerequisite + "；奥术核心 ×" + additionCoreCost(additionId)
                + "；紫水晶碎片 ×" + additionShardCost(additionId);
    }

    public static int registeredRecipeCount() { return registry().spellRecipes().size(); }

    public static SpellTier tierForRecipe(String recipeId) {
        SpellGrowthProfile profile = SpellGrowthCatalog.bySpellId(spellId(recipeId));
        return profile == null ? null : profile.tier();
    }
}
