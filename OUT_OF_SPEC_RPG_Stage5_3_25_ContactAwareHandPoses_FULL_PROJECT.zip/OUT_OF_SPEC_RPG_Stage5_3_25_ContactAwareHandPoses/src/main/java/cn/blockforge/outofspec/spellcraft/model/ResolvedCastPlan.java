package cn.blockforge.outofspec.spellcraft.model;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.List;
import java.util.Objects;
import java.util.TreeSet;
import java.util.UUID;

/** Immutable server-resolved plan. It is a model object, not an executor by itself. */
public record ResolvedCastPlan(
        String modelVersion,
        UUID requestId,
        UUID casterId,
        String recipeId,
        String spellId,
        List<String> selectedAdditionalSealIds,
        List<String> activeBindingContractIds,
        List<AppliedEffect> effects,
        long resolvedAtServerTick,
        String fingerprint) {

    public ResolvedCastPlan {
        if (modelVersion == null || modelVersion.isBlank()) throw new IllegalArgumentException("modelVersion is required");
        Objects.requireNonNull(requestId, "requestId");
        Objects.requireNonNull(casterId, "casterId");
        recipeId = ModelIds.requireId(recipeId, "recipeId");
        spellId = ModelIds.requireId(spellId, "spellId");
        selectedAdditionalSealIds = List.copyOf(selectedAdditionalSealIds);
        List<String> providedBindingIds = List.copyOf(activeBindingContractIds);
        if (new TreeSet<>(providedBindingIds).size() != providedBindingIds.size()) {
            throw new IllegalArgumentException("resolved plan contains duplicate active contract IDs");
        }
        activeBindingContractIds = List.copyOf(new TreeSet<>(providedBindingIds));
        effects = List.copyOf(effects);
        java.util.Set<String> applicationIds = new java.util.HashSet<>();
        for (AppliedEffect effect : effects) {
            Objects.requireNonNull(effect, "effect");
            if (!applicationIds.add(effect.applicationId())) {
                throw new IllegalArgumentException("duplicate effect application ID: " + effect.applicationId());
            }
        }
        if (resolvedAtServerTick < 0) throw new IllegalArgumentException("server tick cannot be negative");
        for (String id : selectedAdditionalSealIds) ModelIds.requireId(id, "selectedAdditionalSealIds");
        for (String id : activeBindingContractIds) ModelIds.requireId(id, "activeBindingContractIds");
        String computed = calculateFingerprint(modelVersion, requestId, casterId, recipeId, spellId,
                selectedAdditionalSealIds, activeBindingContractIds, effects);
        if (fingerprint == null || fingerprint.isBlank()) fingerprint = computed;
        else if (!fingerprint.equals(computed)) throw new IllegalArgumentException("provided fingerprint does not match plan contents");
    }

    public static ResolvedCastPlan create(String modelVersion, UUID requestId, UUID casterId,
                                          String recipeId, String spellId, List<String> additions,
                                          List<String> bindingIds, List<AppliedEffect> effects,
                                          long serverTick) {
        return new ResolvedCastPlan(modelVersion, requestId, casterId, recipeId, spellId,
                additions, List.copyOf(new TreeSet<>(bindingIds)), effects, serverTick, "");
    }

    private static String calculateFingerprint(String modelVersion, UUID requestId, UUID casterId,
                                               String recipeId, String spellId, List<String> additions,
                                               List<String> bindingIds, List<AppliedEffect> effects) {
        StringBuilder canonical = new StringBuilder();
        canonical.append(modelVersion).append('\n').append(requestId).append('\n').append(casterId).append('\n')
                .append(recipeId).append('\n').append(spellId).append('\n');
        additions.forEach(id -> canonical.append("A:").append(id).append('\n'));
        new TreeSet<>(bindingIds).forEach(id -> canonical.append("B:").append(id).append('\n'));
        for (AppliedEffect effect : effects) {
            EffectContribution c = effect.contribution();
            canonical.append("E:").append(effect.applicationId()).append('|').append(effect.resolvedSpellId()).append('|')
                    .append(c.contributionId()).append('|').append(c.source()).append('|').append(c.ownerId()).append('|')
                    .append(c.targetSpellId()).append('|').append(c.parameter()).append('|').append(c.operation()).append('|')
                    .append(c.unit()).append('|').append(Double.toString(c.value())).append('|')
                    .append(effect.occurrenceIndex()).append('\n');
        }
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(canonical.toString().getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException("SHA-256 is required by the Java runtime", impossible);
        }
    }
}
