package cn.blockforge.outofspec.spellcraft.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

/**
 * Platform-independent input state machine for the twelve basic seals.
 * A Forge/client adapter is responsible for forwarding physical key-down and key-up edges.
 * This class intentionally does not cast spells, charge resources, or trust client effects.
 */
public final class SealInputSession {
    public enum Phase { IDLE, BASE_INPUT, ADDITIONAL_INPUT, VALIDATING, CASTING }

    public enum Code {
        STARTED,
        BUSY,
        INPUT_ACCEPTED,
        INPUT_ACCEPTED_AFTER_TIMEOUT_RESET,
        UNKNOWN_SEQUENCE,
        INPUT_RESTARTED_AFTER_TIMEOUT,
        SEQUENCE_TOO_LONG,
        REPEAT_KEYDOWN_IGNORED,
        KEY_RELEASED,
        UNTRACKED_KEYUP_IGNORED,
        IGNORED_WRONG_PHASE,
        TIMED_OUT,
        NO_TIMEOUT,
        BACKSPACE_APPLIED,
        NOTHING_TO_DELETE,
        BASE_CONFIRMED,
        NO_EXACT_BASE_MATCH,
        NO_BASE_SEQUENCE,
        ADDITION_CONFIRMED,
        NO_EXACT_ADDITIONAL_MATCH,
        NO_ADDITIONAL_SEQUENCE,
        ADDITION_CONFLICT,
        ADDITION_OCCURRENCE_LIMIT,
        CAST_REQUEST_READY,
        CURRENT_SEQUENCE_NOT_CONFIRMED,
        REQUIRED_ADDITION_MISSING,
        CANCELED,
        TOO_LATE_TO_CANCEL,
        VALIDATION_ACCEPTED,
        VALIDATION_REJECTED_RECOVERABLE,
        VALIDATION_REJECTED_TERMINAL,
        STALE_VALIDATION_IGNORED,
        CAST_FINISHED,
        STALE_CAST_END_IGNORED
    }

    /** match is null when the current sequence is empty. */
    public record Snapshot(
            Phase phase,
            List<BasicSeal> currentSequence,
            SequenceMatch currentMatch,
            String selectedRecipeId,
            List<String> selectedAdditionalSealIds,
            UUID pendingRequestId,
            Set<BasicSeal> physicallyHeldSeals,
            long lastSealPressedAtMillis) {
        public Snapshot {
            Objects.requireNonNull(phase, "phase");
            currentSequence = List.copyOf(currentSequence);
            selectedAdditionalSealIds = List.copyOf(selectedAdditionalSealIds);
            physicallyHeldSeals = Collections.unmodifiableSet(EnumSet.copyOf(
                    physicallyHeldSeals.isEmpty() ? EnumSet.noneOf(BasicSeal.class) : physicallyHeldSeals));
        }
    }

    public record Result(Code code, String message, Snapshot snapshot, CastPlanRequest castRequest) {
        public Result {
            Objects.requireNonNull(code, "code");
            if (message == null || message.isBlank()) throw new IllegalArgumentException("message is required");
            Objects.requireNonNull(snapshot, "snapshot");
            if ((code == Code.CAST_REQUEST_READY) != (castRequest != null)) {
                throw new IllegalArgumentException("only CAST_REQUEST_READY may contain a cast request");
            }
        }
    }

    private final CastingRecipeRegistry registry;
    private final Set<String> learnedAdditionalSealIds;
    private final long defaultInterSealTimeoutMillis;
    private final ArrayList<BasicSeal> currentSequence = new ArrayList<>();
    private final ArrayList<Long> currentSequenceTimes = new ArrayList<>();
    private final ArrayList<String> selectedAdditionalSealIds = new ArrayList<>();
    private final EnumSet<BasicSeal> physicallyHeldSeals = EnumSet.noneOf(BasicSeal.class);
    private Phase phase = Phase.IDLE;
    private SequenceMatch currentMatch;
    private String selectedRecipeId;
    private UUID pendingRequestId;
    private long lastSealPressedAtMillis = -1L;
    private long lastObservedTimeMillis = -1L;

    public SealInputSession(CastingRecipeRegistry registry) {
        this(registry, 800L);
    }

    public SealInputSession(CastingRecipeRegistry registry, long defaultInterSealTimeoutMillis) {
        this(registry, defaultInterSealTimeoutMillis, defaultLearnedAdditions(registry));
    }

    private static Set<String> defaultLearnedAdditions(CastingRecipeRegistry registry) {
        if (registry == null) return Set.of();
        if (!registry.isFrozen()) {
            throw new IllegalArgumentException("casting registry must be frozen before input sessions are created");
        }
        return Set.copyOf(registry.additionalSeals().keySet());
    }

    public SealInputSession(CastingRecipeRegistry registry, long defaultInterSealTimeoutMillis, Set<String> learnedAdditionalSealIds) {
        this.registry = Objects.requireNonNull(registry, "registry");
        if (!registry.isFrozen()) throw new IllegalArgumentException("casting registry must be frozen before input sessions are created");
        if (defaultInterSealTimeoutMillis < 100L || defaultInterSealTimeoutMillis > 5_000L) {
            throw new IllegalArgumentException("default timeout must be between 100 and 5000 ms");
        }
        this.defaultInterSealTimeoutMillis = defaultInterSealTimeoutMillis;
        this.learnedAdditionalSealIds = Set.copyOf(Objects.requireNonNull(learnedAdditionalSealIds, "learnedAdditionalSealIds"));
    }

    public Result start(long nowMillis) {
        observeTime(nowMillis);
        if (phase != Phase.IDLE) return result(Code.BUSY, "an input/cast session is already active");
        clearSessionKeepingPhysicalKeys();
        phase = Phase.BASE_INPUT;
        return result(Code.STARTED, "base-seal input started");
    }

    /** Call on a real key-down edge. Repeated key-down while held is ignored. */
    public Result press(BasicSeal seal, long nowMillis) {
        Objects.requireNonNull(seal, "seal");
        observeTime(nowMillis);
        if (!physicallyHeldSeals.add(seal)) {
            return result(Code.REPEAT_KEYDOWN_IGNORED, "held key did not create a second seal");
        }
        if (phase != Phase.BASE_INPUT && phase != Phase.ADDITIONAL_INPUT) {
            return result(Code.IGNORED_WRONG_PHASE, "basic-seal input is not active in this phase");
        }

        boolean timedOut = false;
        if (!currentSequence.isEmpty() && nowMillis - lastSealPressedAtMillis > effectiveTimeoutMillis()) {
            clearCurrentSequence();
            timedOut = true;
        }
        if (currentSequence.size() >= SealSequence.MAX_LENGTH) {
            clearCurrentSequence();
            return result(Code.SEQUENCE_TOO_LONG, "seal sequence exceeded the input safety length");
        }
        currentSequence.add(seal);
        currentSequenceTimes.add(nowMillis);
        lastSealPressedAtMillis = nowMillis;
        SequenceMatch match = resolveCurrentSequence();
        if (match.status() == SequenceMatch.Status.NONE) {
            clearCurrentSequence();
            return result(Code.UNKNOWN_SEQUENCE, "no registered recipe matches this sequence or its prefix");
        }
        currentMatch = match;
        if (timedOut) {
            return result(Code.INPUT_ACCEPTED_AFTER_TIMEOUT_RESET, "previous partial sequence timed out; this seal started a new sequence");
        }
        return result(Code.INPUT_ACCEPTED, "seal recorded; inspect match status before confirming");
    }

    /** Call on a real key-up edge so the same physically-held key can be pressed again later. */
    public Result release(BasicSeal seal, long nowMillis) {
        Objects.requireNonNull(seal, "seal");
        observeTime(nowMillis);
        if (physicallyHeldSeals.remove(seal)) return result(Code.KEY_RELEASED, "physical key released");
        return result(Code.UNTRACKED_KEYUP_IGNORED, "key-up had no tracked key-down");
    }

    /** Clears only the current unconfirmed sequence when its configured inter-seal timeout expires. */
    public Result tick(long nowMillis) {
        observeTime(nowMillis);
        if ((phase == Phase.BASE_INPUT || phase == Phase.ADDITIONAL_INPUT)
                && !currentSequence.isEmpty()
                && nowMillis - lastSealPressedAtMillis > effectiveTimeoutMillis()) {
            clearCurrentSequence();
            return result(Code.TIMED_OUT, "unconfirmed seal sequence expired; no cast was triggered");
        }
        return result(Code.NO_TIMEOUT, "no input timeout action was needed");
    }

    /** Explicitly confirms the unique exact base recipe, even if the sequence is also a prefix of a longer recipe. */
    public Result confirmBase(long nowMillis) {
        observeTime(nowMillis);
        if (phase != Phase.BASE_INPUT) return result(Code.IGNORED_WRONG_PHASE, "not in base input phase");
        if (currentSequence.isEmpty()) return result(Code.NO_BASE_SEQUENCE, "enter a base-seal sequence first");
        if (currentMatch == null || currentMatch.exactIds().isEmpty()) {
            return result(Code.NO_EXACT_BASE_MATCH, "the current sequence is only a prefix or has no exact recipe");
        }
        selectedRecipeId = currentMatch.exactIds().get(0);
        selectedAdditionalSealIds.clear();
        clearCurrentSequence();
        phase = Phase.ADDITIONAL_INPUT;
        return result(Code.BASE_CONFIRMED, "base recipe selected; optional additional-seal input is active");
    }

    /** Explicitly adds the unique exact additional-seal definition to this cast, without submitting the cast. */
    public Result confirmAdditional(long nowMillis) {
        observeTime(nowMillis);
        if (phase != Phase.ADDITIONAL_INPUT) return result(Code.IGNORED_WRONG_PHASE, "not in additional-seal input phase");
        if (currentSequence.isEmpty()) return result(Code.NO_ADDITIONAL_SEQUENCE, "enter an additional-seal sequence first");
        if (currentMatch == null || currentMatch.exactIds().isEmpty()) {
            return result(Code.NO_EXACT_ADDITIONAL_MATCH, "the current sequence is only a prefix or has no exact addition");
        }
        String additionId = currentMatch.exactIds().get(0);
        AdditionalSealDefinition addition = registry.additionalSeal(additionId);
        if (addition == null || !addition.compatibleRecipeIds().contains(selectedRecipeId)) {
            clearCurrentSequence();
            return result(Code.ADDITION_CONFLICT, "additional seal is not compatible with selected recipe");
        }
        long existingOccurrences = selectedAdditionalSealIds.stream().filter(additionId::equals).count();
        if (existingOccurrences >= addition.maxOccurrencesPerCast()) {
            clearCurrentSequence();
            return result(Code.ADDITION_OCCURRENCE_LIMIT, "additional seal occurrence limit reached");
        }
        for (String selectedId : selectedAdditionalSealIds) {
            AdditionalSealDefinition selected = registry.additionalSeal(selectedId);
            if (addition.incompatibleAdditionalSealIds().contains(selectedId)
                    || selected.incompatibleAdditionalSealIds().contains(additionId)) {
                clearCurrentSequence();
                return result(Code.ADDITION_CONFLICT, "selected additions have a registered conflict");
            }
        }
        selectedAdditionalSealIds.add(additionId);
        clearCurrentSequence();
        return result(Code.ADDITION_CONFIRMED, "additional seal added to the draft cast plan");
    }

    /**
     * Submit an immutable selection-only request. The server still resolves effects and active contracts.
     * Requirements are checked locally for feedback and must be rechecked by the server resolver.
     */
    public Result submitCast(long nowMillis) {
        observeTime(nowMillis);
        if (phase != Phase.ADDITIONAL_INPUT) return result(Code.IGNORED_WRONG_PHASE, "cast cannot be submitted in this phase");
        if (!currentSequence.isEmpty()) return result(Code.CURRENT_SEQUENCE_NOT_CONFIRMED, "confirm or clear the current additional-seal sequence first");
        Map<String, Boolean> selected = new HashMap<>();
        for (String id : selectedAdditionalSealIds) selected.put(id, true);
        for (String id : selectedAdditionalSealIds) {
            AdditionalSealDefinition addition = registry.additionalSeal(id);
            if (addition == null) return result(Code.ADDITION_CONFLICT, "draft refers to an unknown additional seal");
            for (String requiredId : addition.requiredAdditionalSealIds()) {
                if (!selected.containsKey(requiredId)) {
                    return result(Code.REQUIRED_ADDITION_MISSING, "additional seal " + id + " requires " + requiredId);
                }
            }
        }
        pendingRequestId = UUID.randomUUID();
        CastPlanRequest request = new CastPlanRequest(pendingRequestId, selectedRecipeId, selectedAdditionalSealIds);
        phase = Phase.VALIDATING;
        return new Result(Code.CAST_REQUEST_READY, "selection request is ready for server validation", snapshot(), request);
    }

    /** An async/packet response is accepted only if it matches the current pending request. */
    public Result onValidationResult(UUID requestId, boolean accepted, boolean recoverable, long nowMillis) {
        observeTime(nowMillis);
        if (phase != Phase.VALIDATING || pendingRequestId == null || !pendingRequestId.equals(requestId)) {
            return result(Code.STALE_VALIDATION_IGNORED, "validation response is stale or belongs to another request");
        }
        if (accepted) {
            phase = Phase.CASTING;
            return result(Code.VALIDATION_ACCEPTED, "server accepted this request; cast execution may proceed");
        }
        pendingRequestId = null;
        if (recoverable) {
            phase = Phase.ADDITIONAL_INPUT;
            clearCurrentSequence();
            return result(Code.VALIDATION_REJECTED_RECOVERABLE, "server rejected the draft; confirmed selections are retained for correction");
        }
        clearSessionKeepingPhysicalKeys();
        phase = Phase.IDLE;
        return result(Code.VALIDATION_REJECTED_TERMINAL, "server rejected the request; session was cleared");
    }

    public Result onCastEnded(UUID requestId, long nowMillis) {
        observeTime(nowMillis);
        if (phase != Phase.CASTING || pendingRequestId == null || !pendingRequestId.equals(requestId)) {
            return result(Code.STALE_CAST_END_IGNORED, "cast-end event is stale or belongs to another request");
        }
        clearSessionKeepingPhysicalKeys();
        phase = Phase.IDLE;
        return result(Code.CAST_FINISHED, "cast session finished; transient input state cleared");
    }

    /** Hard local reset when the client disconnects/unloads its world; later packets are stale by request ID. */
    public void resetAfterDisconnect(long nowMillis) {
        observeTime(nowMillis);
        clearSessionKeepingPhysicalKeys();
        physicallyHeldSeals.clear();
        phase = Phase.IDLE;
    }

    /** Cancellation is local-only before submit; it cannot undo a submitted server request or active cast. */
    public Result cancel(long nowMillis) {
        observeTime(nowMillis);
        if (phase == Phase.VALIDATING || phase == Phase.CASTING) {
            return result(Code.TOO_LATE_TO_CANCEL, "submitted/active cast must be resolved by the server lifecycle");
        }
        if (phase == Phase.IDLE) return result(Code.IGNORED_WRONG_PHASE, "there is no active input session");
        clearSessionKeepingPhysicalKeys();
        phase = Phase.IDLE;
        return result(Code.CANCELED, "unsubmitted cast draft canceled; no resources or binding triggers were applied");
    }

    /** Removes the final seal in the current sequence, or the most recently confirmed addition if empty. */
    public Result backspace(long nowMillis) {
        observeTime(nowMillis);
        if (phase != Phase.BASE_INPUT && phase != Phase.ADDITIONAL_INPUT) {
            return result(Code.IGNORED_WRONG_PHASE, "backspace is not available in this phase");
        }
        if (!currentSequence.isEmpty()) {
            currentSequence.remove(currentSequence.size() - 1);
            currentSequenceTimes.remove(currentSequenceTimes.size() - 1);
            if (currentSequence.isEmpty()) {
                currentMatch = null;
                lastSealPressedAtMillis = -1L;
            } else {
                currentMatch = resolveCurrentSequence();
                lastSealPressedAtMillis = currentSequenceTimes.get(currentSequenceTimes.size() - 1);
            }
            return result(Code.BACKSPACE_APPLIED, "last unconfirmed seal removed");
        }
        if (phase == Phase.ADDITIONAL_INPUT && !selectedAdditionalSealIds.isEmpty()) {
            selectedAdditionalSealIds.remove(selectedAdditionalSealIds.size() - 1);
            return result(Code.BACKSPACE_APPLIED, "last confirmed additional seal removed from the draft");
        }
        return result(Code.NOTHING_TO_DELETE, "there is no unconfirmed seal or selected addition to remove");
    }

    public Snapshot snapshot() {
        return new Snapshot(phase, currentSequence, currentMatch, selectedRecipeId,
                selectedAdditionalSealIds, pendingRequestId, physicallyHeldSeals, lastSealPressedAtMillis);
    }

    private SequenceMatch resolveCurrentSequence() {
        SealSequence sequence = new SealSequence(currentSequence);
        if (phase == Phase.BASE_INPUT) return registry.matchBase(sequence);
        SequenceMatch raw = registry.matchAdditional(selectedRecipeId, sequence);
        List<String> exact = raw.exactIds().stream().filter(learnedAdditionalSealIds::contains).toList();
        List<String> longer = raw.longerPrefixIds().stream().filter(learnedAdditionalSealIds::contains).toList();
        SequenceMatch.Status status = exact.isEmpty()
                ? (longer.isEmpty() ? SequenceMatch.Status.NONE : SequenceMatch.Status.PREFIX_ONLY)
                : (longer.isEmpty() ? SequenceMatch.Status.EXACT : SequenceMatch.Status.EXACT_AND_PREFIX);
        return new SequenceMatch(status, exact, longer);
    }

    private long effectiveTimeoutMillis() {
        if (currentMatch == null) return defaultInterSealTimeoutMillis;
        long timeout = Long.MAX_VALUE;
        List<String> candidates = new ArrayList<>(currentMatch.exactIds());
        candidates.addAll(currentMatch.longerPrefixIds());
        if (phase == Phase.BASE_INPUT) {
            for (String id : candidates) timeout = Math.min(timeout, registry.recipe(id).interSealTimeoutMillis());
        } else if (phase == Phase.ADDITIONAL_INPUT) {
            for (String id : candidates) timeout = Math.min(timeout, registry.additionalSeal(id).interSealTimeoutMillis());
        }
        return timeout == Long.MAX_VALUE ? defaultInterSealTimeoutMillis : timeout;
    }

    private void clearCurrentSequence() {
        currentSequence.clear();
        currentSequenceTimes.clear();
        currentMatch = null;
        lastSealPressedAtMillis = -1L;
    }

    private void clearSessionKeepingPhysicalKeys() {
        clearCurrentSequence();
        selectedRecipeId = null;
        selectedAdditionalSealIds.clear();
        pendingRequestId = null;
    }

    private Result result(Code code, String message) {
        return new Result(code, message, snapshot(), null);
    }

    private void observeTime(long nowMillis) {
        if (nowMillis < 0L) throw new IllegalArgumentException("time must be non-negative");
        if (lastObservedTimeMillis >= 0L && nowMillis < lastObservedTimeMillis) {
            throw new IllegalArgumentException("session time must be monotonic");
        }
        lastObservedTimeMillis = nowMillis;
    }
}
