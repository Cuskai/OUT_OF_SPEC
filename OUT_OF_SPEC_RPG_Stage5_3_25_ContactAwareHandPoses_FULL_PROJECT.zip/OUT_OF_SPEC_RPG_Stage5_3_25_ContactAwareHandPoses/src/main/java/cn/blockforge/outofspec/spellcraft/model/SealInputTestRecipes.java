package cn.blockforge.outofspec.spellcraft.model;

import java.util.List;
import java.util.Set;

/**
 * Explicitly test-only seal recipes used by the in-game diagnostic HUD.
 * These IDs are not real Iron's Spells spell IDs and must never be passed to a real cast executor.
 */
public final class SealInputTestRecipes {
    public static final String BLUE_BOLT = "out_of_spec_binding:debug_blue_bolt";
    public static final String BLUE_BURST = "out_of_spec_binding:debug_blue_burst";
    public static final String IMPACT_RING = "out_of_spec_binding:debug_impact_ring";
    public static final String PRISM_RAY = "out_of_spec_binding:debug_prism_ray";

    public static final String RANGE_SMALL = "out_of_spec_binding:debug_range_small";
    public static final String RANGE_LARGE = "out_of_spec_binding:debug_range_large";
    public static final String SPLIT = "out_of_spec_binding:debug_split";
    public static final String SPEED = "out_of_spec_binding:debug_speed";
    public static final String DURATION = "out_of_spec_binding:debug_duration";

    private static final CastingRecipeRegistry REGISTRY = buildRegistry();

    private SealInputTestRecipes() {}

    public static CastingRecipeRegistry registry() { return REGISTRY; }

    public static String spellName(String recipeId) {
        if (BLUE_BOLT.equals(recipeId)) return "诊断术式·青焰弹";
        if (BLUE_BURST.equals(recipeId)) return "诊断术式·青焰爆发";
        if (IMPACT_RING.equals(recipeId)) return "诊断术式·震荡环";
        if (PRISM_RAY.equals(recipeId)) return "诊断术式·裂光矢";
        return "未知诊断术式 (" + recipeId + ")";
    }

    public static String additionName(String additionId) {
        if (RANGE_SMALL.equals(additionId)) return "范围微调";
        if (RANGE_LARGE.equals(additionId)) return "范围扩展";
        if (SPLIT.equals(additionId)) return "分裂结构";
        if (SPEED.equals(additionId)) return "弹道加速";
        if (DURATION.equals(additionId)) return "持续时间延长";
        return "未知追加印 (" + additionId + ")";
    }

    public static String additionPreview(String additionId) {
        if (RANGE_SMALL.equals(additionId)) return "范围参数 ×1.25（仅诊断预览）";
        if (RANGE_LARGE.equals(additionId)) return "范围参数 ×1.75（仅诊断预览）";
        if (SPLIT.equals(additionId)) return "投射物数量 +2（仅诊断预览）";
        if (SPEED.equals(additionId)) return "弹道速度 ×1.25（仅诊断预览）";
        if (DURATION.equals(additionId)) return "持续时间 ×1.5（仅诊断预览）";
        return "无预览数据";
    }

    private static CastingRecipeRegistry buildRegistry() {
        CastingRecipeRegistry r = new CastingRecipeRegistry();
        r.registerSpellRecipe(new SpellRecipe(BLUE_BOLT, BLUE_BOLT,
                SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU), 800L, CastMobilityPolicy.FREE));
        // Intentionally shares the ZX prefix with BLUE_BOLT to test explicit disambiguation.
        r.registerSpellRecipe(new SpellRecipe(BLUE_BURST, BLUE_BURST,
                SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU, BasicSeal.YIN), 800L, CastMobilityPolicy.FREE));
        r.registerSpellRecipe(new SpellRecipe(IMPACT_RING, IMPACT_RING,
                SealSequence.of(BasicSeal.YIN, BasicSeal.MAO, BasicSeal.CHEN), 800L, CastMobilityPolicy.FREE));
        r.registerSpellRecipe(new SpellRecipe(PRISM_RAY, PRISM_RAY,
                SealSequence.of(BasicSeal.CHOU, BasicSeal.SI, BasicSeal.HAI), 800L, CastMobilityPolicy.FREE));

        Set<String> all = Set.of(BLUE_BOLT, BLUE_BURST, IMPACT_RING, PRISM_RAY);
        Set<String> projectile = Set.of(BLUE_BOLT, BLUE_BURST, PRISM_RAY);
        Set<String> ringAndBurst = Set.of(BLUE_BURST, IMPACT_RING);
        r.registerAdditionalSeal(addition(RANGE_SMALL, SealSequence.of(BasicSeal.WU), all,
                Set.of(RANGE_LARGE), EffectParameter.AREA_RADIUS, EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 1.25));
        // Intentionally shares the F prefix with RANGE_SMALL to test additional-seal disambiguation.
        r.registerAdditionalSeal(addition(RANGE_LARGE, SealSequence.of(BasicSeal.WU, BasicSeal.WEI), all,
                Set.of(RANGE_SMALL), EffectParameter.AREA_RADIUS, EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 1.75));
        r.registerAdditionalSeal(addition(SPLIT, SealSequence.of(BasicSeal.SHEN, BasicSeal.YOU), projectile,
                Set.of(), EffectParameter.PROJECTILE_COUNT, EffectOperation.ADD, EffectUnit.COUNT, 2));
        r.registerAdditionalSeal(addition(SPEED, SealSequence.of(BasicSeal.XU, BasicSeal.HAI), projectile,
                Set.of(), EffectParameter.FLIGHT_SPEED, EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 1.25));
        r.registerAdditionalSeal(addition(DURATION, SealSequence.of(BasicSeal.YOU, BasicSeal.XU), ringAndBurst,
                Set.of(), EffectParameter.DURATION_TICKS, EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 1.5));
        r.freeze(Set.of());
        return r;
    }

    private static AdditionalSealDefinition addition(String id, SealSequence sequence, Set<String> compatible,
                                                      Set<String> conflicts, EffectParameter parameter,
                                                      EffectOperation operation, EffectUnit unit, double value) {
        EffectContribution effect = new EffectContribution(id + "/preview", EffectSource.ADDITIONAL_SEAL,
                id, "*", parameter, operation, unit, value);
        return new AdditionalSealDefinition(id, sequence, 800L, compatible, Set.of(), conflicts,
                1, AdditionalSealTier.BASIC, CompositionMode.INDEPENDENT_EFFECTS, "", List.of(effect));
    }
}
