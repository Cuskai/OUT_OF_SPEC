package cn.blockforge.outofspec.spellcraft.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/** Immutable ordered sequence of basic seals. It has no keyboard or UI dependency. */
public record SealSequence(List<BasicSeal> seals) {
    public static final int MAX_LENGTH = 32;

    public SealSequence {
        Objects.requireNonNull(seals, "seals");
        if (seals.isEmpty() || seals.size() > MAX_LENGTH) {
            throw new IllegalArgumentException("seal sequence length must be 1.." + MAX_LENGTH);
        }
        if (seals.stream().anyMatch(Objects::isNull)) {
            throw new IllegalArgumentException("seal sequence cannot contain null");
        }
        seals = List.copyOf(seals);
    }

    public static SealSequence of(BasicSeal... seals) {
        Objects.requireNonNull(seals, "seals");
        return new SealSequence(List.of(seals));
    }

    public boolean isPrefixOf(SealSequence other) {
        Objects.requireNonNull(other, "other");
        if (seals.size() > other.seals.size()) return false;
        for (int i = 0; i < seals.size(); i++) {
            if (seals.get(i) != other.seals.get(i)) return false;
        }
        return true;
    }

    public boolean isStrictPrefixOf(SealSequence other) {
        return seals.size() < other.seals.size() && isPrefixOf(other);
    }

    /** Stable serialization key independent of keybindings and localized labels. */
    public String canonicalKey() {
        return seals.stream().map(BasicSeal::id).collect(Collectors.joining("."));
    }

    public SealSequence append(BasicSeal seal) {
        Objects.requireNonNull(seal, "seal");
        if (seals.size() >= MAX_LENGTH) throw new IllegalStateException("seal sequence capacity reached");
        List<BasicSeal> next = new ArrayList<>(seals);
        next.add(seal);
        return new SealSequence(next);
    }
}
