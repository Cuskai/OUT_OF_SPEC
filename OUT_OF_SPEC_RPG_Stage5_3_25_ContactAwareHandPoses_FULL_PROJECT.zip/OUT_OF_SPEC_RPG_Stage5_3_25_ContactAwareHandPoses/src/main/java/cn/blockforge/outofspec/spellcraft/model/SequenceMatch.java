package cn.blockforge.outofspec.spellcraft.model;

import java.util.List;

/** Resolution result distinguishes exact matches from longer recipes sharing the prefix. */
public record SequenceMatch(Status status, List<String> exactIds, List<String> longerPrefixIds) {
    public enum Status { NONE, PREFIX_ONLY, EXACT, EXACT_AND_PREFIX }

    public SequenceMatch {
        if (status == null) throw new IllegalArgumentException("status is required");
        exactIds = List.copyOf(exactIds);
        longerPrefixIds = List.copyOf(longerPrefixIds);
        if (exactIds.size() > 1) throw new IllegalArgumentException("exact sequence cannot be ambiguous");
        Status expected = exactIds.isEmpty()
                ? (longerPrefixIds.isEmpty() ? Status.NONE : Status.PREFIX_ONLY)
                : (longerPrefixIds.isEmpty() ? Status.EXACT : Status.EXACT_AND_PREFIX);
        if (status != expected) throw new IllegalArgumentException("match status does not match candidate lists");
    }
}
