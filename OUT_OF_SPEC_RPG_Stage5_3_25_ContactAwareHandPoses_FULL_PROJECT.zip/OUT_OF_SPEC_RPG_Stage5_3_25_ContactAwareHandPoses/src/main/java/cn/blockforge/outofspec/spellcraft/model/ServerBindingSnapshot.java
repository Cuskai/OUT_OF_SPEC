package cn.blockforge.outofspec.spellcraft.model;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

/**
 * Internal server-side snapshot of the caster's active contracts and their structured effects.
 * It must be constructed from persisted/validated server state, never deserialized from a client packet.
 */
public record ServerBindingSnapshot(List<String> activeContractIds, List<EffectContribution> effects) {
    public ServerBindingSnapshot {
        Objects.requireNonNull(activeContractIds, "activeContractIds");
        Objects.requireNonNull(effects, "effects");
        if (activeContractIds.size() > 128) throw new IllegalArgumentException("too many active contracts in snapshot");
        activeContractIds = activeContractIds.stream().map(id -> ModelIds.requireId(id, "activeContractIds")).toList();
        Set<String> unique = new TreeSet<>(activeContractIds);
        if (unique.size() != activeContractIds.size()) throw new IllegalArgumentException("server snapshot contains duplicate active contract IDs");
        effects = List.copyOf(effects);
    }
}
