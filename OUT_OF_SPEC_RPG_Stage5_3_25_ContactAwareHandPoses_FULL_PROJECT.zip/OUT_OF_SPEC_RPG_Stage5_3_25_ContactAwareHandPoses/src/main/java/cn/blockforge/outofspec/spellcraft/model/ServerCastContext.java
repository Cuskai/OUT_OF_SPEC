package cn.blockforge.outofspec.spellcraft.model;

import java.util.Objects;
import java.util.UUID;

/** Trusted cast context created by the server packet handler from the actual sender and server state. */
public record ServerCastContext(UUID casterId, ServerBindingSnapshot bindingSnapshot, long serverTick) {
    public ServerCastContext {
        Objects.requireNonNull(casterId, "casterId");
        Objects.requireNonNull(bindingSnapshot, "bindingSnapshot");
        if (serverTick < 0) throw new IllegalArgumentException("server tick cannot be negative");
    }
}
