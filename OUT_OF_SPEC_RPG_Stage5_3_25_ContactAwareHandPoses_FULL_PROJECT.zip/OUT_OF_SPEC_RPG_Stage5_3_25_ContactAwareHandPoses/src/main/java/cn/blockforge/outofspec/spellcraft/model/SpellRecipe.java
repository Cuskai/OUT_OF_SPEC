package cn.blockforge.outofspec.spellcraft.model;

import java.util.Objects;

/** A registered base-seal recipe for one real spell ID. */
public record SpellRecipe(
        String recipeId,
        String spellId,
        SealSequence sequence,
        long interSealTimeoutMillis,
        CastMobilityPolicy mobilityPolicy) {

    public SpellRecipe {
        recipeId = ModelIds.requireId(recipeId, "recipeId");
        spellId = ModelIds.requireId(spellId, "spellId");
        Objects.requireNonNull(sequence, "sequence");
        Objects.requireNonNull(mobilityPolicy, "mobilityPolicy");
        if (interSealTimeoutMillis < 100 || interSealTimeoutMillis > 5_000) {
            throw new IllegalArgumentException("inter-seal timeout must be between 100 and 5000 ms");
        }
    }
}
