package cn.blockforge.outofspec.spellcraft.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

/**
 * Generates deterministic, collision-free four-seal recipes for registered spells that do not
 * have a curated sequence. Curated recipes keep their existing sequences; generated codes never
 * extend or prefix-collide with those recipes, so adding spells cannot steal common short inputs.
 *
 * Four seals provide 12^4 codes, far more than the base spell registry needs. IDs are sorted so
 * client and server produce identical assignments regardless of registry iteration order.
 */
public final class SpellSealSequenceGenerator {
    public static final int GENERATED_LENGTH = 4;
    private static final BasicSeal[] ALPHABET = BasicSeal.values();

    private SpellSealSequenceGenerator() {}

    public static Map<String, SealSequence> generate(Collection<String> spellIds,
                                                       Collection<SealSequence> reservedSequences) {
        Objects.requireNonNull(spellIds, "spellIds");
        Objects.requireNonNull(reservedSequences, "reservedSequences");
        List<String> sortedIds = spellIds.stream()
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(value -> !value.isEmpty())
                .distinct()
                .sorted(Comparator.naturalOrder())
                .toList();
        List<SealSequence> reserved = List.copyOf(reservedSequences);
        Map<String, SealSequence> result = new LinkedHashMap<>();
        Set<String> assigned = new TreeSet<>();
        int candidateCount = 1;
        for (int i = 0; i < GENERATED_LENGTH; i++) candidateCount = Math.multiplyExact(candidateCount, ALPHABET.length);
        int cursor = 0;
        for (String spellId : sortedIds) {
            SealSequence selected = null;
            while (cursor < candidateCount) {
                SealSequence candidate = decode(cursor++);
                if (hasAdjacentRepeat(candidate) || conflicts(candidate, reserved)) continue;
                if (!assigned.add(candidate.canonicalKey())) continue;
                selected = candidate;
                break;
            }
            if (selected == null) {
                throw new IllegalStateException("four-seal namespace exhausted while assigning " + spellId
                        + "; registered spells=" + sortedIds.size());
            }
            result.put(spellId, selected);
        }
        return Map.copyOf(result);
    }

    public static String display(SealSequence sequence) {
        if (sequence == null) return "待生成";
        List<String> glyphs = new ArrayList<>(sequence.seals().size());
        for (BasicSeal seal : sequence.seals()) glyphs.add(glyph(seal));
        return String.join(" → ", glyphs);
    }

    private static SealSequence decode(int index) {
        BasicSeal[] seals = new BasicSeal[GENERATED_LENGTH];
        int value = index;
        for (int i = GENERATED_LENGTH - 1; i >= 0; i--) {
            seals[i] = ALPHABET[value % ALPHABET.length];
            value /= ALPHABET.length;
        }
        return new SealSequence(List.of(seals));
    }

    private static boolean hasAdjacentRepeat(SealSequence sequence) {
        for (int i = 1; i < sequence.seals().size(); i++) {
            if (sequence.seals().get(i) == sequence.seals().get(i - 1)) return true;
        }
        return false;
    }

    private static boolean conflicts(SealSequence candidate, List<SealSequence> reserved) {
        for (SealSequence existing : reserved) {
            if (candidate.isPrefixOf(existing) || existing.isPrefixOf(candidate)) return true;
        }
        return false;
    }

    private static String glyph(BasicSeal seal) {
        return switch (seal) {
            case ZI -> "子";
            case CHOU -> "丑";
            case YIN -> "寅";
            case MAO -> "卯";
            case CHEN -> "辰";
            case SI -> "巳";
            case WU -> "午";
            case WEI -> "未";
            case SHEN -> "申";
            case YOU -> "酉";
            case XU -> "戌";
            case HAI -> "亥";
        };
    }
}
