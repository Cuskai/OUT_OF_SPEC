package cn.blockforge.outofspec.spellcraft.network;

import cn.blockforge.outofspec.binding.BindingCastingMod;
import cn.blockforge.outofspec.spellcraft.growth.SpellGrowthCatalog;
import cn.blockforge.outofspec.spellcraft.growth.SpellGrowthRuntime;
import cn.blockforge.outofspec.spellcraft.growth.SpellGrowthService;
import cn.blockforge.outofspec.spellcraft.item.SpellGrowthItems;
import cn.blockforge.outofspec.spellcraft.runtime.SealedCastEffectState;
import io.redspace.ironsspellbooks.api.magic.MagicData;
import io.redspace.ironsspellbooks.api.registry.SpellRegistry;
import io.redspace.ironsspellbooks.api.spells.AbstractSpell;
import io.redspace.ironsspellbooks.api.spells.CastSource;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.Optional;
import java.util.function.Supplier;

/** All learning and growth mutations are calculated on the server; the client sends only a spell ID and a chosen action. */
public final class SpellGrowthNetwork {
    private static final String PROTOCOL = "1";
    private static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(BindingCastingMod.MOD_ID, "spell_growth"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);
    private static boolean registered;

    private SpellGrowthNetwork() {}

    public static void register() {
        if (registered) return;
        registered = true;
        CHANNEL.registerMessage(0, SnapshotRequest.class, SnapshotRequest::encode,
                SnapshotRequest::decode, SnapshotRequest::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(1, SnapshotPacket.class, SnapshotPacket::encode,
                SnapshotPacket::decode, SnapshotPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(2, ResearchRequest.class, ResearchRequest::encode,
                ResearchRequest::decode, ResearchRequest::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(3, LevelUpRequest.class, LevelUpRequest::encode,
                LevelUpRequest::decode, LevelUpRequest::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(4, BreakthroughRequest.class, BreakthroughRequest::encode,
                BreakthroughRequest::decode, BreakthroughRequest::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(5, ActionPacket.class, ActionPacket::encode,
                ActionPacket::decode, ActionPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(6, GrimoireCastRequest.class, GrimoireCastRequest::encode,
                GrimoireCastRequest::decode, GrimoireCastRequest::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(7, LearnAdditionalSealRequest.class, LearnAdditionalSealRequest::encode,
                LearnAdditionalSealRequest::decode, LearnAdditionalSealRequest::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
    }

    public static void requestSnapshot() { CHANNEL.sendToServer(new SnapshotRequest()); }
    public static void research(String spellId, boolean useCore) {
        CHANNEL.sendToServer(new ResearchRequest(safeId(spellId), useCore));
    }
    public static void levelUp(String spellId) { CHANNEL.sendToServer(new LevelUpRequest(safeId(spellId))); }
    public static void breakthrough(String spellId, String branchId) {
        CHANNEL.sendToServer(new BreakthroughRequest(safeId(spellId), safeId(branchId)));
    }
    public static void grimoireCast(String firstSpellId, String secondSpellId) {
        CHANNEL.sendToServer(new GrimoireCastRequest(safeId(firstSpellId), safeId(secondSpellId)));
    }
    public static void learnAdditionalSeal(String additionId) {
        CHANNEL.sendToServer(new LearnAdditionalSealRequest(safeId(additionId)));
    }

    private static String safeId(String value) {
        if (value == null) return "";
        String safe = value.trim();
        return safe.length() > 128 ? safe.substring(0, 128) : safe;
    }

    private static void sendSnapshot(ServerPlayer player) {
        // The snapshot request also reconciles held scrolls with the discovery record.
        // This makes research usable even if acquisition happened before the UI was opened.
        SpellGrowthService.discoverInventoryScrolls(player);
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new SnapshotPacket(SpellGrowthService.createSnapshot(player)));
    }

    private static void sendAction(ServerPlayer player, boolean success, String message) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new ActionPacket(success, message == null ? "" : message, SpellGrowthService.createSnapshot(player)));
    }

    private static String validateCastPreconditions(ServerPlayer player, String spellId) {
        if (SpellGrowthCatalog.bySpellId(spellId) == null) return "这个术式尚未接入 OUT OF SPEC 成长系统。";
        if (!SpellGrowthService.isLearned(player, spellId)) return "尚未掌握该术式。请获得对应卷轴，并在术式研究档案中完成学习。";
        if (SpellGrowthService.isLearned(player, spellId)
                && cn.blockforge.outofspec.binding.BindingCastingState.isSpellPermanentlyBlocked(player, spellId)) {
            return "该术式已被生效中的永久束缚封存。";
        }
        AbstractSpell spell = SpellRegistry.getSpell(spellId);
        if (spell == null || !spell.isEnabled()) return "Iron's Spells 注册表中没有可用的术式 " + spellId + "。";
        int requiredTicks = cn.blockforge.outofspec.binding.BindingCastingState.requiredPreparationTicks(player, spellId);
        if (requiredTicks > cn.blockforge.outofspec.binding.BindingCastingState.castingPreparationProgressTicks(player)) {
            return "束缚前置条件未完成：请潜行、站在地面并保持静止 "
                    + cn.blockforge.outofspec.binding.BindingContract.format(requiredTicks / 20.0) + " 秒后再施法。";
        }
        return "";
    }

    private static boolean startBooklessSpell(ServerPlayer player, String spellId) {
        AbstractSpell spell = SpellRegistry.getSpell(spellId);
        if (spell == null || !spell.isEnabled()) return false;
        return spell.attemptInitiateCast(ItemStack.EMPTY, SpellGrowthService.level(player, spellId),
                player.serverLevel(), player, CastSource.SPELLBOOK, true, "out_of_spec_growth");
    }

    private static void handleGrimoireCast(ServerPlayer player, GrimoireCastRequest packet) {
        if (player == null) return;
        boolean hasGrimoire = player.getMainHandItem().is(SpellGrowthItems.ARCANE_GRIMOIRE.get())
                || player.getOffhandItem().is(SpellGrowthItems.ARCANE_GRIMOIRE.get());
        if (!hasGrimoire) {
            sendAction(player, false, "自动施法与叠加施法需要手持奥术法术书；普通结印施法不需要法术书。");
            return;
        }
        if (MagicData.getPlayerMagicData(player).isCasting() || SealedCastEffectState.hasPending(player)) {
            sendAction(player, false, "当前已有施法或结印效果正在结算，不能启动新的法术书序列。");
            return;
        }
        String firstError = validateCastPreconditions(player, packet.firstSpellId);
        if (!firstError.isBlank()) { sendAction(player, false, firstError); return; }
        String secondId = packet.secondSpellId;
        if (!secondId.isBlank()) {
            String secondError = validateCastPreconditions(player, secondId);
            if (!secondError.isBlank()) { sendAction(player, false, "叠加序列第二层未通过检查：" + secondError); return; }
        }
        boolean queued = false;
        if (!secondId.isBlank()) {
            queued = SpellGrowthRuntime.queueFollowup(player, packet.firstSpellId, secondId);
            if (!queued) { sendAction(player, false, "当前已有法术书后续施法等待执行，请先完成当前序列。"); return; }
        }
        boolean started;
        try {
            started = startBooklessSpell(player, packet.firstSpellId);
        } catch (RuntimeException failure) {
            started = false;
            if (queued) SpellGrowthRuntime.cancelQueued(player);
            sendAction(player, false, "法术书自动施法失败：" + safeMessage(failure));
            return;
        }
        if (!started) {
            if (queued) SpellGrowthRuntime.cancelQueued(player);
            sendAction(player, false, "Iron's Spells 拒绝起手。请检查魔力、冷却和束缚条件；法术书没有跳过这些规则。");
            return;
        }
        sendAction(player, true, secondId.isBlank()
                ? "法术书已自动执行「" + SpellGrowthCatalog.bySpellId(packet.firstSpellId).displayName() + "」。"
                : "法术书已启动双层序列：第一层「" + SpellGrowthCatalog.bySpellId(packet.firstSpellId).displayName()
                    + "」，第二层将在第一层真实释放后排队执行。当前实现是连续叠施，并非两个投射物同一刻融合。"
        );
    }

    private static String safeMessage(Throwable throwable) {
        if (throwable == null || throwable.getMessage() == null || throwable.getMessage().isBlank()) return "未知错误";
        String text = throwable.getMessage().replace('\n', ' ').replace('\r', ' ');
        return text.length() > 140 ? text.substring(0, 140) : text;
    }

    private static final class SnapshotRequest {
        private static void encode(SnapshotRequest value, FriendlyByteBuf buffer) {}
        private static SnapshotRequest decode(FriendlyByteBuf buffer) { return new SnapshotRequest(); }
        private static void handle(SnapshotRequest packet, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> { if (context.getSender() != null) sendSnapshot(context.getSender()); });
            context.setPacketHandled(true);
        }
    }

    private static final class SnapshotPacket {
        private final CompoundTag snapshot;
        private SnapshotPacket(CompoundTag snapshot) { this.snapshot = snapshot == null ? new CompoundTag() : snapshot.copy(); }
        private static void encode(SnapshotPacket value, FriendlyByteBuf buffer) { buffer.writeNbt(value.snapshot); }
        private static SnapshotPacket decode(FriendlyByteBuf buffer) {
            CompoundTag value = buffer.readNbt();
            return new SnapshotPacket(value == null ? new CompoundTag() : value);
        }
        private static void handle(SnapshotPacket packet, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                    () -> () -> cn.blockforge.outofspec.spellcraft.client.SpellGrowthClient.receiveSnapshot(packet.snapshot)));
            context.setPacketHandled(true);
        }
    }

    private static final class ResearchRequest {
        private final String spellId;
        private final boolean useCore;
        private ResearchRequest(String spellId, boolean useCore) { this.spellId = spellId; this.useCore = useCore; }
        private static void encode(ResearchRequest value, FriendlyByteBuf buffer) { buffer.writeUtf(value.spellId, 128); buffer.writeBoolean(value.useCore); }
        private static ResearchRequest decode(FriendlyByteBuf buffer) { return new ResearchRequest(buffer.readUtf(128), buffer.readBoolean()); }
        private static void handle(ResearchRequest packet, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> {
                ServerPlayer player = context.getSender();
                if (player == null) return;
                SpellGrowthService.ActionResult result = SpellGrowthService.research(player, packet.spellId, packet.useCore);
                sendAction(player, result.success(), result.message());
            });
            context.setPacketHandled(true);
        }
    }

    private static final class LevelUpRequest {
        private final String spellId;
        private LevelUpRequest(String spellId) { this.spellId = spellId; }
        private static void encode(LevelUpRequest value, FriendlyByteBuf buffer) { buffer.writeUtf(value.spellId, 128); }
        private static LevelUpRequest decode(FriendlyByteBuf buffer) { return new LevelUpRequest(buffer.readUtf(128)); }
        private static void handle(LevelUpRequest packet, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> {
                ServerPlayer player = context.getSender();
                if (player == null) return;
                SpellGrowthService.ActionResult result = SpellGrowthService.levelUp(player, packet.spellId);
                sendAction(player, result.success(), result.message());
            });
            context.setPacketHandled(true);
        }
    }

    private static final class BreakthroughRequest {
        private final String spellId;
        private final String branchId;
        private BreakthroughRequest(String spellId, String branchId) { this.spellId = spellId; this.branchId = branchId; }
        private static void encode(BreakthroughRequest value, FriendlyByteBuf buffer) { buffer.writeUtf(value.spellId, 128); buffer.writeUtf(value.branchId, 128); }
        private static BreakthroughRequest decode(FriendlyByteBuf buffer) { return new BreakthroughRequest(buffer.readUtf(128), buffer.readUtf(128)); }
        private static void handle(BreakthroughRequest packet, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> {
                ServerPlayer player = context.getSender();
                if (player == null) return;
                SpellGrowthService.ActionResult result = SpellGrowthService.breakthrough(player, packet.spellId, packet.branchId);
                sendAction(player, result.success(), result.message());
            });
            context.setPacketHandled(true);
        }
    }

    private static final class ActionPacket {
        private final boolean success;
        private final String message;
        private final CompoundTag snapshot;
        private ActionPacket(boolean success, String message, CompoundTag snapshot) {
            this.success = success;
            this.message = message == null ? "" : message;
            this.snapshot = snapshot == null ? new CompoundTag() : snapshot.copy();
        }
        private static void encode(ActionPacket value, FriendlyByteBuf buffer) {
            buffer.writeBoolean(value.success); buffer.writeUtf(value.message, 1024); buffer.writeNbt(value.snapshot);
        }
        private static ActionPacket decode(FriendlyByteBuf buffer) {
            return new ActionPacket(buffer.readBoolean(), buffer.readUtf(1024), buffer.readNbt());
        }
        private static void handle(ActionPacket packet, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                    () -> () -> cn.blockforge.outofspec.spellcraft.client.SpellGrowthClient.receiveAction(
                            packet.success, packet.message, packet.snapshot)));
            context.setPacketHandled(true);
        }
    }

    private static final class LearnAdditionalSealRequest {
        private final String additionId;
        private LearnAdditionalSealRequest(String additionId) { this.additionId = additionId; }
        private static void encode(LearnAdditionalSealRequest value, FriendlyByteBuf buffer) { buffer.writeUtf(value.additionId, 128); }
        private static LearnAdditionalSealRequest decode(FriendlyByteBuf buffer) { return new LearnAdditionalSealRequest(buffer.readUtf(128)); }
        private static void handle(LearnAdditionalSealRequest packet, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> {
                ServerPlayer player = context.getSender();
                if (player == null) return;
                SpellGrowthService.ActionResult result = SpellGrowthService.learnAdditionalSeal(player, packet.additionId);
                sendAction(player, result.success(), result.message());
            });
            context.setPacketHandled(true);
        }
    }

    private static final class GrimoireCastRequest {
        private final String firstSpellId;
        private final String secondSpellId;
        private GrimoireCastRequest(String firstSpellId, String secondSpellId) {
            this.firstSpellId = firstSpellId; this.secondSpellId = secondSpellId;
        }
        private static void encode(GrimoireCastRequest value, FriendlyByteBuf buffer) {
            buffer.writeUtf(value.firstSpellId, 128); buffer.writeUtf(value.secondSpellId, 128);
        }
        private static GrimoireCastRequest decode(FriendlyByteBuf buffer) {
            return new GrimoireCastRequest(buffer.readUtf(128), buffer.readUtf(128));
        }
        private static void handle(GrimoireCastRequest packet, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> handleGrimoireCast(context.getSender(), packet));
            context.setPacketHandled(true);
        }
    }
}
