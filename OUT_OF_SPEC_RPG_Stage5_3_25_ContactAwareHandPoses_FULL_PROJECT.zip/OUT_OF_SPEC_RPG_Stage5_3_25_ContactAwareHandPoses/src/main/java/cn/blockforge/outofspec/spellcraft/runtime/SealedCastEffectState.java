package cn.blockforge.outofspec.spellcraft.runtime;

import cn.blockforge.outofspec.spellcraft.model.EffectContribution;
import cn.blockforge.outofspec.spellcraft.model.EffectOperation;
import cn.blockforge.outofspec.spellcraft.model.EffectParameter;
import cn.blockforge.outofspec.spellcraft.model.EffectSource;
import cn.blockforge.outofspec.spellcraft.model.EffectUnit;
import cn.blockforge.outofspec.spellcraft.model.ProjectileFormation;
import cn.blockforge.outofspec.spellcraft.model.ResolvedCastPlan;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.Vec3;

import java.util.Set;
import java.util.UUID;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Server-owned, cast-local effect state. Only registered additional-seal effects with concrete
 * game hooks are installed here. Iron's Spells still owns initiation, cast timing, mana payment,
 * cooldown and the original release.
 */
public final class SealedCastEffectState {
    private static final Set<String> MULTI_RELEASE_SPELLS = Set.of(
            "irons_spellbooks:magic_arrow",
            "irons_spellbooks:firebolt",
            "irons_spellbooks:lightning_lance",
            "irons_spellbooks:fireball");
    private static final ConcurrentMap<UUID, ActiveCast> ACTIVE = new ConcurrentHashMap<>();
    /** Synchronous cast-spawn capture; only projectiles owned by the casting player are tracked. */
    private static final ThreadLocal<ProjectileCapture> PROJECTILE_CAPTURE = new ThreadLocal<>();

    private SealedCastEffectState() {}

    /** Begin tracking projectiles emitted by the original native cast and any additional releases. */
    public static void beginProjectileCapture(ServerPlayer player, String spellId) {
        if (player == null || spellId == null || spellId.isBlank() || player.level().isClientSide) {
            PROJECTILE_CAPTURE.remove();
            return;
        }
        int extra = supportsMultiReleaseSpell(spellId) ? extraReleaseCount(player, spellId) : 0;
        PROJECTILE_CAPTURE.set(new ProjectileCapture(player, spellId, 1 + Math.max(0, extra)));
    }

    /** Called synchronously by EntityJoinLevelEvent. Unrelated entities and other owners are ignored. */
    public static void captureSpawnedEntity(Entity entity) {
        ProjectileCapture capture = PROJECTILE_CAPTURE.get();
        if (capture == null || entity == null || entity.level().isClientSide || !(entity instanceof Projectile projectile)) return;
        if (projectile.getOwner() != capture.player) return;
        capture.originalVelocities.put(projectile, projectile.getDeltaMovement());
        int index = capture.projectiles.size();
        capture.projectiles.add(projectile);
        // Position each native projectile while it is joining the level, before the server sends
        // its initial entity-spawn packet to clients. This is the key difference from the old
        // post-spawn-only layout, which could make two shots look like a single central projectile.
        if (capture.expectedProjectileCount > 1 && index < capture.expectedProjectileCount) {
            if (capture.center == null) {
                capture.center = projectile.position();
                Vec3 look = capture.player.getLookAngle().normalize();
                Vec3 right = new Vec3(-look.z, 0.0, look.x);
                capture.right = right.lengthSqr() < 1.0E-6 ? new Vec3(1, 0, 0) : right.normalize();
            }
            applyFormationSlot(capture, projectile, index, capture.expectedProjectileCount);
            capture.prearrangedCount++;
        }
    }

    public static int capturedProjectileCount(ServerPlayer player, String spellId) {
        ProjectileCapture capture = PROJECTILE_CAPTURE.get();
        return capture != null && capture.player == player && capture.spellId.equals(spellId)
                ? capture.projectiles.size() : 0;
    }

    /** Ends capture even on partial failure and returns an immutable list of this cast's projectiles. */
    public static java.util.List<Projectile> finishProjectileCapture(ServerPlayer player, String spellId) {
        ProjectileCapture capture = PROJECTILE_CAPTURE.get();
        if (capture == null) return java.util.List.of();
        PROJECTILE_CAPTURE.remove();
        if (capture.player != player || !capture.spellId.equals(spellId)) return java.util.List.of();
        return java.util.List.copyOf(capture.projectiles);
    }

    /**
     * Repositions every projectile from one native cast family into a symmetric lateral spread.
     * Two total shots are placed left/right; three total shots use left/center/right. The original
     * launch point is retained as the center and each velocity is rotated slightly outward.
     */
    public static int arrangeBilateralProjectiles(Player caster, java.util.List<Projectile> projectiles) {
        if (caster == null || projectiles == null || projectiles.size() < 2 || caster.level().isClientSide) return 0;
        java.util.List<Projectile> valid = projectiles.stream()
                .filter(p -> p != null && p.isAlive() && p.level() == caster.level())
                .toList();
        int count = valid.size();
        if (count < 2) return 0;
        Vec3 center = null;
        Vec3 right = null;
        ProjectileCapture capture = PROJECTILE_CAPTURE.get();
        if (capture != null && capture.player == caster && !capture.projectiles.isEmpty()) {
            center = capture.center;
            right = capture.right;
        }
        if (center == null) {
            double x = 0, y = 0, z = 0;
            for (Projectile projectile : valid) {
                Vec3 pos = projectile.position(); x += pos.x; y += pos.y; z += pos.z;
            }
            center = new Vec3(x / count, y / count, z / count);
        }
        if (right == null) right = rightVector(caster);
        java.util.List<ProjectileFormation.Slot> formation = ProjectileFormation.distribute(count);
        for (int i = 0; i < count; i++) {
            Projectile projectile = valid.get(i);
            Vec3 nativeVelocity = capture == null ? projectile.getDeltaMovement()
                    : capture.originalVelocities.getOrDefault(projectile, projectile.getDeltaMovement());
            placeProjectile(projectile, center, right, nativeVelocity, formation.get(i));
        }
        return count;
    }

    /** Use the active capture's original motion to repair a partial spawn-time formation. */
    public static int arrangeCapturedProjectilesFallback(ServerPlayer player, String spellId) {
        ProjectileCapture capture = PROJECTILE_CAPTURE.get();
        if (capture == null || capture.player != player || !capture.spellId.equals(spellId)) return 0;
        return arrangeBilateralProjectiles(player, java.util.List.copyOf(capture.projectiles));
    }

    public static boolean hasCompleteSpawnFormation(ServerPlayer player, String spellId, int expectedCount) {
        ProjectileCapture capture = PROJECTILE_CAPTURE.get();
        return capture != null && capture.player == player && capture.spellId.equals(spellId)
                && expectedCount > 1 && capture.expectedProjectileCount == expectedCount
                && capture.projectiles.size() == expectedCount && capture.prearrangedCount == expectedCount;
    }

    private static Vec3 rightVector(Player caster) {
        Vec3 look = caster.getLookAngle().normalize();
        Vec3 right = new Vec3(-look.z, 0.0, look.x);
        return right.lengthSqr() < 1.0E-6 ? new Vec3(1, 0, 0) : right.normalize();
    }

    private static void applyFormationSlot(ProjectileCapture capture, Projectile projectile, int index, int total) {
        java.util.List<ProjectileFormation.Slot> slots = ProjectileFormation.distribute(total);
        placeProjectile(projectile, capture.center, capture.right,
                capture.originalVelocities.getOrDefault(projectile, projectile.getDeltaMovement()), slots.get(index));
    }

    private static void placeProjectile(Projectile projectile, Vec3 center, Vec3 right, Vec3 nativeVelocity,
                                        ProjectileFormation.Slot slot) {
        double offset = slot.lateralOffsetBlocks();
        float divergence = (float) slot.yawOffsetDegrees();
        projectile.setPos(center.x + right.x * offset, center.y, center.z + right.z * offset);
        Vec3 velocity = nativeVelocity == null ? Vec3.ZERO : nativeVelocity;
        if (velocity.lengthSqr() > 1.0E-8) projectile.setDeltaMovement(velocity.yRot((float) Math.toRadians(divergence)));
        projectile.setYRot(projectile.getYRot() + divergence);
    }

    public static boolean supportsMultiReleaseSpell(String spellId) {
        return spellId != null && MULTI_RELEASE_SPELLS.contains(spellId);
    }

    /**
     * Explicit allowlist for additional effects. Registration alone is never considered proof
     * that an effect has an executor. These constraints are mirrored by the server plan gate.
     */
    public static boolean isExecutableAdditionalEffect(EffectContribution effect, String spellId) {
        if (effect == null || effect.source() != EffectSource.ADDITIONAL_SEAL || spellId == null) return false;
        return switch (effect.parameter()) {
            case SPELL_POWER -> effect.operation() == EffectOperation.MULTIPLY
                    && effect.unit() == EffectUnit.MULTIPLIER
                    && effect.value() >= 0.0 && effect.value() <= 100.0;
            case CAST_TIME_TICKS -> effect.operation() == EffectOperation.MULTIPLY
                    && effect.unit() == EffectUnit.MULTIPLIER
                    && effect.value() > 0.0 && effect.value() <= 4.0;
            case AREA_RADIUS -> spellId.equals("irons_spellbooks:fireball")
                    && effect.operation() == EffectOperation.MULTIPLY
                    && effect.unit() == EffectUnit.MULTIPLIER
                    && effect.value() > 0.0 && effect.value() <= 3.0;
            case MANA_COST -> effect.operation() == EffectOperation.MULTIPLY
                    && effect.unit() == EffectUnit.MULTIPLIER
                    && effect.value() >= 1.0 && effect.value() <= 4.0;
            // This runtime interprets the contribution as additional projectiles after the native
            // one has already spawned, so only ADD is meaningful. REPLACE would need a different
            // executor that suppresses or alters the original projectile count.
            case PROJECTILE_COUNT -> supportsMultiReleaseSpell(spellId)
                    && effect.operation() == EffectOperation.ADD
                    && effect.unit() == EffectUnit.COUNT
                    && effect.value() >= 0.0 && effect.value() <= 2.0
                    && effect.value() == Math.rint(effect.value());
            default -> false;
        };
    }

    /**
     * Arms one cast-local effect state before attemptInitiateCast, so time/cost/power hooks can
     * observe it while Iron's Spells performs its real validation and release. Returns false if
     * a previous sealed cast is still pending or any effect lacks an executable hook.
     */
    public static boolean begin(ServerPlayer player, ResolvedCastPlan plan) {
        if (player == null || plan == null || !player.getUUID().equals(plan.casterId())) return false;
        double spellPowerMultiplier = 1.0;
        double castTimeMultiplier = 1.0;
        double areaRadiusMultiplier = 1.0;
        double manaCostMultiplier = 1.0;
        int extraReleaseCount = 0;
        for (var applied : plan.effects()) {
            EffectContribution effect = applied.contribution();
            if (effect.source() != EffectSource.ADDITIONAL_SEAL) continue;
            if (!isExecutableAdditionalEffect(effect, plan.spellId())) return false;
            switch (effect.parameter()) {
                case SPELL_POWER -> spellPowerMultiplier *= effect.value();
                case CAST_TIME_TICKS -> castTimeMultiplier *= effect.value();
                case AREA_RADIUS -> areaRadiusMultiplier *= effect.value();
                case MANA_COST -> manaCostMultiplier *= effect.value();
                case PROJECTILE_COUNT -> {
                    if (effect.operation() == EffectOperation.ADD) extraReleaseCount += (int) effect.value();
                    else extraReleaseCount = (int) effect.value();
                }
                default -> { return false; }
            }
        }
        if (!Double.isFinite(spellPowerMultiplier) || spellPowerMultiplier < 0.0 || spellPowerMultiplier > 100.0) return false;
        if (!Double.isFinite(castTimeMultiplier) || castTimeMultiplier <= 0.0 || castTimeMultiplier > 4.0) return false;
        if (!Double.isFinite(areaRadiusMultiplier) || areaRadiusMultiplier <= 0.0 || areaRadiusMultiplier > 3.0) return false;
        if (!Double.isFinite(manaCostMultiplier) || manaCostMultiplier < 1.0 || manaCostMultiplier > 16.0) return false;
        if (extraReleaseCount < 0 || extraReleaseCount > 2) return false;
        ActiveCast candidate = new ActiveCast(plan.requestId(), plan.spellId(), spellPowerMultiplier,
                castTimeMultiplier, areaRadiusMultiplier, manaCostMultiplier, extraReleaseCount,
                player.level().getGameTime());
        return ACTIVE.putIfAbsent(player.getUUID(), candidate) == null;
    }

    public static double spellPowerMultiplier(Player player, String spellId) {
        ActiveCast active = activeFor(player, spellId);
        return active == null ? 1.0 : active.spellPowerMultiplier();
    }

    public static double castTimeMultiplier(Player player, String spellId) {
        ActiveCast active = activeFor(player, spellId);
        return active == null ? 1.0 : active.castTimeMultiplier();
    }

    public static double areaRadiusMultiplier(Player player, String spellId) {
        ActiveCast active = activeFor(player, spellId);
        return active == null ? 1.0 : active.areaRadiusMultiplier();
    }

    public static double manaCostMultiplier(Player player, String spellId) {
        ActiveCast active = activeFor(player, spellId);
        return active == null ? 1.0 : active.manaCostMultiplier();
    }

    public static int extraReleaseCount(Player player, String spellId) {
        ActiveCast active = activeFor(player, spellId);
        return active == null ? 0 : active.extraReleaseCount();
    }

    private static ActiveCast activeFor(Player player, String spellId) {
        if (player == null || player.level().isClientSide || spellId == null) return null;
        ActiveCast active = ACTIVE.get(player.getUUID());
        return active != null && active.spellId().equals(spellId) ? active : null;
    }

    /** Called from AbstractSpell.castSpell RETURN, after the spell has consumed its cast-local values. */
    public static UUID completeSpellExecution(Player player, String spellId) {
        if (player == null || spellId == null) return null;
        ActiveCast active = ACTIVE.get(player.getUUID());
        if (active == null || !active.spellId().equals(spellId)) return null;
        return ACTIVE.remove(player.getUUID(), active) ? active.requestId() : null;
    }

    /** Remove cast-local modifiers when a cast is canceled before reaching AbstractSpell.castSpell. */
    public static UUID cleanupIfNoLongerCasting(ServerPlayer player) {
        if (player == null) return null;
        ActiveCast active = ACTIVE.get(player.getUUID());
        if (active == null) return null;
        // Do not race the packet handler in the same world tick that armed the state.
        if (player.level().getGameTime() <= active.armedAtWorldTick()) return null;
        if (!io.redspace.ironsspellbooks.api.magic.MagicData.getPlayerMagicData(player).isCasting()) {
            return ACTIVE.remove(player.getUUID(), active) ? active.requestId() : null;
        }
        return null;
    }

    public static void clear(ServerPlayer player) {
        if (player != null) {
            ACTIVE.remove(player.getUUID());
            ProjectileCapture capture = PROJECTILE_CAPTURE.get();
            if (capture != null && capture.player == player) PROJECTILE_CAPTURE.remove();
        }
    }

    public static boolean hasPending(ServerPlayer player) {
        return player != null && ACTIVE.containsKey(player.getUUID());
    }

    private static final class ProjectileCapture {
        private final ServerPlayer player;
        private final String spellId;
        private final int expectedProjectileCount;
        private final java.util.ArrayList<Projectile> projectiles = new java.util.ArrayList<>();
        private final Map<Projectile, Vec3> originalVelocities = new IdentityHashMap<>();
        private Vec3 center;
        private Vec3 right;
        private int prearrangedCount;
        private ProjectileCapture(ServerPlayer player, String spellId, int expectedProjectileCount) {
            this.player = player;
            this.spellId = spellId;
            this.expectedProjectileCount = expectedProjectileCount;
        }
    }

    private record ActiveCast(UUID requestId, String spellId, double spellPowerMultiplier,
                              double castTimeMultiplier, double areaRadiusMultiplier,
                              double manaCostMultiplier, int extraReleaseCount, long armedAtWorldTick) {}
}
