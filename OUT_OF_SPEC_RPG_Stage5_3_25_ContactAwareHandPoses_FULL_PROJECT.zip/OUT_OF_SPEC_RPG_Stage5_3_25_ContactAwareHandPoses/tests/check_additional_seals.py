from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
def read(path):
    return (ROOT / path).read_text(encoding='utf-8')

recipes = read('src/main/java/cn/blockforge/outofspec/spellcraft/model/RealSealCastingRecipes.java')
state = read('src/main/java/cn/blockforge/outofspec/spellcraft/runtime/SealedCastEffectState.java')
growth = read('src/main/java/cn/blockforge/outofspec/spellcraft/growth/SpellGrowthService.java')
spell_mixin = read('src/main/java/cn/blockforge/outofspec/binding/mixin/AbstractSpellBindingMixin.java')
fireball_mixin = read('src/main/java/cn/blockforge/outofspec/binding/mixin/FireballExpansionMixin.java')
events = read('src/main/java/cn/blockforge/outofspec/spellcraft/growth/SpellGrowthEvents.java')
config = json.loads((ROOT / 'src/main/resources/out_of_spec_binding.mixins.json').read_text(encoding='utf-8'))
model_tests = read('tests/java/RealSealCastingRecipesHarness.java')
future_design = read('DESIGN_SPELL_INSTABILITY_AFFINITY_INNATE_MAGIC.md')

ids = ('POWER_FOCUS', 'POWER_FOCUS_STRONG', 'QUICK_RELEASE', 'MULTI_RELEASE', 'TRIUNE_RELEASE', 'FIREBALL_EXPANSION')
for item in ids:
    assert f'public static final String {item} =' in recipes, f'missing additional seal definition: {item}'
assert 'List.of(\n            POWER_FOCUS, POWER_FOCUS_STRONG, QUICK_RELEASE,\n            MULTI_RELEASE, TRIUNE_RELEASE, FIREBALL_EXPANSION)' in recipes
for name in ('迅捷起印', '多重释放', '三重释放', '炽域扩张'):
    assert name in recipes, f'missing Chinese name for {name}'
for token in ('EffectParameter.CAST_TIME_TICKS', 'EffectParameter.PROJECTILE_COUNT', 'EffectParameter.AREA_RADIUS', 'EffectParameter.MANA_COST'):
    assert token in recipes, f"addition does not declare the expected typed effect: {token}"
assert 'EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 0.50' in recipes and '有效吟唱时间减半' in recipes
assert 'EffectOperation.ADD, EffectUnit.COUNT, 1' in recipes
assert 'EffectOperation.ADD, EffectUnit.COUNT, 2' in recipes
assert 'EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 1.40' in recipes
assert 'EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 1.85' in recipes
assert 'EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 1.35' in recipes
assert 'Set.of(FIREBALL)' in recipes, 'fireball expansion must only target the real fireball recipe'
assert 'Set.of(POWER_FOCUS_STRONG)' in recipes and 'Set.of(POWER_FOCUS)' in recipes
assert 'Set.of(TRIUNE_RELEASE)' in recipes and 'Set.of(MULTI_RELEASE)' in recipes
assert 'case RealSealCastingRecipes.MULTI_RELEASE -> highestLevel >= 2' in growth
assert 'isAdditionalSealLearned(player, RealSealCastingRecipes.MULTI_RELEASE)' in growth
assert 'level(player, "irons_spellbooks:fireball") >= 2' in growth
for token in ('case SPELL_POWER', 'case CAST_TIME_TICKS', 'case AREA_RADIUS', 'case MANA_COST', 'case PROJECTILE_COUNT'):
    assert token in state, f'no cast-local runtime aggregation for {token}'
for spell_id in ('irons_spellbooks:magic_arrow', 'irons_spellbooks:firebolt', 'irons_spellbooks:lightning_lance', 'irons_spellbooks:fireball'):
    assert spell_id in state and spell_id in recipes, f'multi-release executor allowlist missing {spell_id}'
assert 'SealedCastEffectState.castTimeMultiplier(player, currentSpellId)' in spell_mixin
assert 'SealedCastEffectState.manaCostMultiplier(player, spellId)' in spell_mixin
assert 'BindingCastingState.getEffectContracts(player)' in spell_mixin and 'scaleManaCost' in spell_mixin, 'combined extra-seal/contract mana cost must be checked before casting'
assert 'SealedCastEffectState.extraReleaseCount(player, spellId)' in spell_mixin
assert 'effect.operation() == EffectOperation.ADD' in state and 'effect.operation() == EffectOperation.REPLACE' not in state, 'projectile-count executor must fail closed for unsupported replacement semantics'
assert 'spell.onCast(level, spellLevel, player, castSource, MagicData.getPlayerMagicData(player))' in spell_mixin
assert 'Math.min(2, extraReleases)' in spell_mixin and 'SealedCastEffectState.beginProjectileCapture' in spell_mixin
assert 'SealedCastEffectState.arrangeCapturedProjectilesFallback(player, spellId)' in spell_mixin
assert 'SealedCastEffectState.hasCompleteSpawnFormation' in spell_mixin
assert 'fallbackFormationFailed' in spell_mixin and 'fallbackArrangedCount < Math.min(2, projectiles.size())' in spell_mixin, 'fallback must not report a bilateral layout as successful unless at least two native projectiles were actually arranged'
assert 'player.setYRot(originalYaw)' not in spell_mixin, "multi-release must not manipulate the player yaw"
assert 'EntityJoinLevelEvent' in read('src/main/java/cn/blockforge/outofspec/binding/SealCastingLifecycleEvents.java')
assert 'PROJECTILE_CAPTURE' in state and 'projectile.getOwner() != capture.player' in state
formation = read('src/main/java/cn/blockforge/outofspec/spellcraft/model/ProjectileFormation.java')
assert 'ProjectileFormation.distribute(count)' in state and 'lateralOffsetBlocks()' in state
assert 'lateralIndex * BLOCK_SPACING' in formation and 'lateralIndex * DEGREES_PER_SLOT' in formation
assert 'Position each native projectile while it is joining the level' in state
assert 'capture.prearrangedCount++' in state
assert 'BLOCK_SPACING = 0.72' in formation and 'DEGREES_PER_SLOT = 10.0' in formation
formation_harness = read('tests/java/ProjectileFormationHarness.java')
assert 'two-shot offsets are symmetric' in formation_harness and 'three-shot offsets are symmetric' in formation_harness
assert 'SealedCastEffectState.manaCostMultiplier(player, spellId)' in events
assert 'getRadius' in fireball_mixin and 'Math.ceil(baseRadius * multiplier)' in fireball_mixin
assert 'FireballExpansionMixin' in config['mixins']
for token in ('弹体', 'proficiency', '未实现', '偏差', '类型共鸣', '生得魔法'):
    assert token.lower() in future_design.lower(), f'future design document missing distinction/term: {token}'
for token in ('QUICK_RELEASE', 'MULTI_RELEASE', 'TRIUNE_RELEASE', 'FIREBALL_EXPANSION', 'multi-release is rejected', 'unintended projectile count'):
    assert token.lower() in model_tests.lower(), f'model regression fixture is missing {token}'
hand = read('src/main/java/cn/blockforge/outofspec/binding/client/SealHandPoseRenderer.java')
pose_library = read('src/main/java/cn/blockforge/outofspec/binding/client/handpose/HandSealPoseLibrary.java')
input_client = read('src/main/java/cn/blockforge/outofspec/binding/client/SealInputDebugClient.java')
hand_mixin = read('src/main/java/cn/blockforge/outofspec/binding/mixin/client/StandaloneFirstPersonHandsMixin.java')
client_mixins = json.loads(read('src/main/resources/out_of_spec_binding.client.mixins.json'))
assert 'StandaloneFirstPersonHandsMixin' in client_mixins['client']
assert '@Mixin(ItemInHandRenderer.class)' in hand_mixin
assert '@Inject(method = "renderPlayerArm", at = @At("HEAD"), cancellable = true, require = 1)' in hand_mixin
assert 'method = "renderPlayerArm"' in hand_mixin and 'ci.cancel()' in hand_mixin
assert 'outOfSpec$drawBilateralPairAtReturn' in hand_mixin and 'finishFirstPersonHandFrame(' in hand_mixin
assert 'HumanoidArm.LEFT' in hand and 'HumanoidArm.RIGHT' in hand and 'buffers.endBatch();' in hand
assert 'renderPlayerArm' in hand and 'attachAndPoseHand' not in hand
assert 'getChild(left ? "left_arm" : "right_arm")' in hand
assert 'PartPose.offset(wristCenterX, 9.25f, 0.0f)' in hand and 'slim ? -0.5f : -1.0f' in hand and 'slim ? 0.5f : 1.0f' in hand
assert 'String[] fingerNames = {"index", "middle", "ring", "pinky"};' in hand and 'addFinger(palm, fingerNames[i]' in hand
assert 'PartDefinition thumb = palm.addOrReplaceChild("thumb"' in hand and 'thumb.addOrReplaceChild("tip"' in hand
assert 'middle_joint' in hand and 'HandSealPoseLibrary.get(from)' in hand and 'HandSealPoseLibrary.get(to)' in hand
assert 'public record DigitPose(' in pose_library and 'public record ContactConstraint(' in pose_library
assert all(f'profile(BasicSeal.{name}' in pose_library for name in ('ZI','CHOU','YIN','MAO','CHEN','SI','WU','WEI','SHEN','YOU','XU','HAI'))
assert 'shouldRenderFirstPersonHands()' in input_client and 'mc.options.getCameraType().isFirstPerson()' in input_client
assert 'PunchyArmHandsMixin' not in client_mixins['client'] and 'ModelPartChildrenAccessor' not in client_mixins['client']
assert 'method = "renderHandsWithItems"' in hand_mixin and 'finishFirstPersonHandFrame(' in hand_mixin, 'custom rig must explicitly complete both arms after vanilla hand selection'
assert 'PunchyFirstPersonHandRigAdapter' not in hand and 'PunchyArmRenderer' not in hand
assert 'renderPlayerArm' in hand_mixin and 'RenderArmEvent' not in hand and 'RenderHandEvent' not in hand
advisor = read('src/main/java/cn/blockforge/outofspec/binding/client/BindingAIAdvisor.java')
assert 'requestRepair' in advisor and 'isSafeModelProposal' in advisor and 'hasExplicitTransaction' in advisor
assert '当前尚不支持改变作用范围' in advisor and '第二轮修订候选已通过本地复核' in advisor
assert 'num_predict", 700' in advisor and 'max_tokens", 700' in advisor
assert 'localFallbackAdvice' in advisor and '本地规则备用候选' in advisor and 'isOpenEndedIntent' in advisor
assert 'SpellNameResolver.findPositiveSpellIds(intent)' in advisor and 'changesExplicitSpellScope(intent, candidate)' in advisor
assert '模型候选未通过本地裁定' in advisor and '永久承受缓慢效果' in advisor
assert '模型候选改变了已指定法术' in advisor and 'boolean changedExplicitScope' in advisor
assert '瞬移|传送|治疗|回血|恢复生命|召唤|护盾' in advisor, 'offline fallback must not overwrite unsupported explicit mechanics'
assert 'boolean asksCooldown' in advisor and 'boolean asksMobility' in advisor, 'offline fallback must choose supported trades by requested stat'
assert '该想法提到了特定法术' in advisor, 'single-spell scopes for global-only stats must remain explicit failures'
assert '迅捷起印已启用：基础 ' in read('src/main/java/cn/blockforge/outofspec/binding/network/SealCastingNetwork.java') and 'getEffectiveCastTime(spellLevel, player)' in read('src/main/java/cn/blockforge/outofspec/binding/network/SealCastingNetwork.java')
seal_network = read('src/main/java/cn/blockforge/outofspec/binding/network/SealCastingNetwork.java')
assert 'import net.minecraft.network.chat.Component;' in seal_network, 'quick-release action-bar feedback must import Component'
assert 'int spellLevel = SpellGrowthService.level(player, plan.spellId());\n        boolean started;\n        try {' in seal_network, 'current spell level must remain in scope for cast initiation and timing feedback'
assert seal_network.count('int spellLevel = SpellGrowthService.level(player, plan.spellId());') == 1, 'spell level must be resolved once for the current initiation'
assert '捕获并排布 ' in spell_mixin and '多重释放' in spell_mixin and '三重释放' in spell_mixin
assert '只有开放式请求' not in advisor # intent-specific fallback is gated in code, not claimed by the prompt
print('PASS carried-forward source audit: bilateral/triune native-projectile formation, half-time quick release, standalone articulated first-person hand rig, and locally adjudicated/repaired Binding AI proposals.')
