from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
MODEL = ROOT / "src/main/java/cn/blockforge/outofspec/spellcraft/model"
files = {p.name: p.read_text(encoding="utf-8") for p in MODEL.glob("*.java")}
required = {
    "BasicSeal.java", "SealSequence.java", "SpellRecipe.java", "AdditionalSealDefinition.java",
    "CastingRecipeRegistry.java", "EffectContribution.java", "CastPlanRequest.java",
    "ResolvedCastPlan.java", "CastPlanResolver.java", "PlanResolution.java", "AppliedEffect.java", "ServerBindingSnapshot.java", "ServerCastContext.java", "RealSealCastingRecipes.java"
}
missing = required - set(files)
assert not missing, f"missing Stage 2.6 model files: {sorted(missing)}"
assert "ZI(\"zi\", 'Z')" in files["BasicSeal.java"] and "HAI(\"hai\", 'Y')" in files["BasicSeal.java"]
seal_block = files["BasicSeal.java"].split("public enum BasicSeal {", 1)[1].split(";", 1)[0]
seal_constants = [line.strip() for line in seal_block.splitlines() if re.match(r"^[A-Z]+\(", line.strip())]
assert len(seal_constants) == 12, f"expected 12 basic seal constants, found {len(seal_constants)}"
assert "recipes.put(recipe.recipeId(), recipe);" in files["CastingRecipeRegistry.java"]
assert "ensureFrozen();" in files["CastingRecipeRegistry.java"]
assert "ambiguous base-seal sequence" in files["CastingRecipeRegistry.java"]
assert "registeredSpecialExecutors" in files["CastingRecipeRegistry.java"]
assert "request.selectedAdditionalSealIds()" in files["CastPlanResolver.java"]
assert "serverBindingSnapshot.effects()" in files["CastPlanResolver.java"]
assert "owner is not in the server active-contract snapshot" in files["CastPlanResolver.java"]
assert "DUPLICATE_BINDING_CONTRIBUTION" in files["CastPlanResolver.java"]
assert "MessageDigest.getInstance(\"SHA-256\")" in files["ResolvedCastPlan.java"]
assert "Untrusted selection request" in files["CastPlanRequest.java"]
assert "never deserialized from a client packet" in files["ServerBindingSnapshot.java"]
assert "actual sender" in files["ServerCastContext.java"]
assert "serverContext.casterId()" in files["CastPlanResolver.java"]
assert "request.activeBindingContractIds()" not in files["CastPlanResolver.java"]
assert "import net.minecraft" not in "\n".join(files.values()), "pure model must not depend on Minecraft APIs"
assert "EffectSource.ADDITIONAL_SEAL" in files["AdditionalSealDefinition.java"]
assert "MAX_LENGTH = 32" in files["SealSequence.java"]
print("PASS Stage 2.6 source audit: stable IDs, 12 basic seals, immutable sequences, recipe prefix states, frozen registry, per-recipe additional-seal scope, typed effect provenance/units, server-derived binding contributions, and deterministic plan fingerprint.")
print("NOTE Stage 2.6: the model itself remains platform-independent; Stage 2.9 adds separate Forge network and spell-execution adapters without putting Minecraft imports into the model package.")
