from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]
def read(path): return (ROOT / path).read_text(encoding="utf-8")
def require(value, message): assert value, message

renderer = read("src/main/java/cn/blockforge/outofspec/binding/client/SealHandPoseRenderer.java")
pose_library = read("src/main/java/cn/blockforge/outofspec/binding/client/handpose/HandSealPoseLibrary.java")
input_client = read("src/main/java/cn/blockforge/outofspec/binding/client/SealInputDebugClient.java")
arm_mixin = read("src/main/java/cn/blockforge/outofspec/binding/mixin/client/StandaloneFirstPersonHandsMixin.java")
config = json.loads(read("src/main/resources/out_of_spec_binding.client.mixins.json"))
build = read("build.gradle")
mods = read("src/main/resources/META-INF/mods.toml")

# Standalone rendering hook: replace the exact vanilla arm render call, not the full frame.
require('@Mixin(ItemInHandRenderer.class)' in arm_mixin, "standalone arm integration must target vanilla ItemInHandRenderer")
require('method = "renderHandsWithItems"' in arm_mixin and '@At("RETURN")' in arm_mixin,
        "bilateral pair must be emitted at the actual end of ItemInHandRenderer.renderHandsWithItems")
require('outOfSpec$drawBilateralPairAtReturn' in arm_mixin and 'finishFirstPersonHandFrame(' in arm_mixin,
        "end-of-frame bilateral drawing injection missing")
require('@Inject(method = "renderPlayerArm", at = @At("HEAD"), cancellable = true, require = 1)' in arm_mixin,
        "arm replacement must happen at renderPlayerArm so current held-item/use transforms are inherited")
for token in ("PoseStack poseStack", "MultiBufferSource buffers", "int packedLight", "float equipProgress",
              "float swingProgress", "HumanoidArm arm", "SealHandPoseRenderer.isHandFrameActive()", "ci.cancel()"):
    require(token in arm_mixin, f"standalone render hook missing {token}")
require("StandaloneFirstPersonHandsMixin" in config["client"], "standalone arm mixin not registered")
require(all("Punchy" not in name and "punchy" not in name for name in config["client"]), "Punchy mixin remains active")
require("StandaloneFirstPersonPlayerRendererMixin" not in config["client"], "obsolete duplicate-arm suppression mixin remains active")
require('modId="punchy"' not in mods and 'version="2.8f"' not in mods, "Punchy must not be registered as a bundled mod")
require("compileOnly files('libs/punchy-2.8f-forge-1.20.1.jar')" not in build and "PunchyJarEmbedder" not in build,
        "build must have no Punchy compile or embedding dependency")

# There must be no live Punchy source dependency or bundled binary in the current project.
java_root = ROOT / "src/main/java"
for path in java_root.rglob("*.java"):
    text = path.read_text(encoding="utf-8")
    require("punchy." not in text.lower() and "PunchyArmRenderer" not in text,
            f"runtime Java source still depends on Punchy: {path.relative_to(ROOT)}")
require(not (ROOT / "libs/punchy-2.8f-forge-1.20.1.jar").exists(), "Punchy binary should not ship in the standalone project")
require(not (ROOT / "tools/PunchyJarEmbedder.java").exists(), "obsolete Punchy embedder remains in project")

# Both hands stay persistent in first person; seal state only affects articulation and center placement.
require("shouldRenderFirstPersonHands()" in input_client and "getCameraType().isFirstPerson()" in input_client,
        "hands must be gated to the local first-person view")
require("public static void renderFirstPersonArm(" in renderer, "standalone arm renderer entrypoint missing")
require("beginFirstPersonHandFrame" in renderer and "finishFirstPersonHandFrame" in renderer,
        "standalone rig must guarantee bilateral hand visibility even when vanilla omits an empty off-hand")
require("prepareFirstPersonArm(player, HumanoidArm.LEFT" in renderer
        and "prepareFirstPersonArm(player, HumanoidArm.RIGHT" in renderer
        and "renderPreparedFirstPersonArm(poseStack, buffers, packedLight, player,\n                    HumanoidArm.LEFT" in renderer
        and "renderPreparedFirstPersonArm(poseStack, buffers, packedLight, player,\n                    HumanoidArm.RIGHT" in renderer,
        "the frame completion must prepare and render both sides before solving hand contacts")
require("buffers.endBatch();" in renderer,
        "bilateral vertices submitted after vanilla's original flush must be explicitly flushed")
require("Standalone bilateral first-person hands rendered (left + right)" in renderer,
        "runtime diagnostic must prove the end-of-frame pair render path executed")
require("RenderType.entityTranslucent(player.getSkinTextureLocation())" in renderer,
        "custom arms must use the player's skin texture")
require("applyVanillaFirstPersonArmTransform(cameraPoseStack, arm, equipProgress, swingProgress, active)" in renderer,
        "standalone rig must reproduce vanilla arm pose before drawing its geometry")
require("SEAL_CENTER_INSET = 0.57f" in renderer and "SEAL_ARM_Y_LIFT = 0.08f" in renderer,
        "seal-specific center/lift transform must remain isolated from idle/held poses")
require("HAND_MODEL_SCALE = 1.12f" in renderer and "basis.xScale = HAND_MODEL_SCALE" in renderer
        and "basis.yScale = HAND_MODEL_SCALE" in renderer and "basis.zScale = HAND_MODEL_SCALE" in renderer,
        "the palm and finger subtree must be enlarged by 12% without scaling the forearm")
require("solveAuthoredContacts(" in renderer and "profile.contacts()" in renderer
        and "contactPointInCamera(" in renderer and "moveElementInCameraSpace(" in renderer,
        "authored finger contact/interlock relations must actually affect the rendered pose")
require("NEUTRAL_HAND_AXIS_TWIST_DEGREES = 180.0f" in renderer and "basis.yRot = radians(basisTwistDeg);" in renderer,
        "user-approved anatomical hand basis must remain on its own local bone")
require("hand.xRot = 0.0f;" in renderer and "hand.yRot = 0.0f;" in renderer and "hand.zRot = 0.0f;" in renderer,
        "mount must not receive whole-arm pose rotations")
require("wrist.yRot = radians(wristYaw * active);" in renderer, "seal-only wrist yaw missing")

# Geometry remains thickness-layered and each digit has three separate links (thumb has two).
require("float palmWidth = slim ? 2.65f : 3.45f;" in renderer, "Classic/Slim palm width profiles missing")
require("float palmDepth = palmWidth * (3.75f / 8.0f);" in renderer, "palm thickness ratio regressed")
require("float wristWidth = palmWidth * (5.5f / 8.0f);" in renderer and '"wrist_transition"' in renderer,
        "stepped wrist transition missing")
require("float wristDepth = palmWidth * (4.5f / 8.0f);" in renderer, "wrist thickness ratio regressed")
require("float fingerDepth = palmWidth * (1.95f / 8.0f);" in renderer, "thin fingers ratio regressed")
require("float thumbDepth = palmWidth * (2.75f / 8.0f);" in renderer, "thumb depth plane missing")
require("float[] fingerLengths = {1.25f, 1.32f, 1.25f, 1.12f};" in renderer, "lengthened finger geometry regressed")
require('addFinger(palm, fingerNames[i]' in renderer and '"middle_joint"' in renderer and '"tip"' in renderer,
        "finger segments must remain independently articulated")
require('PartDefinition basis = hand.addOrReplaceChild("hand_basis"' in renderer
        and 'PartDefinition wrist = basis.addOrReplaceChild("wrist_joint"' in renderer
        and 'PartDefinition palm = wrist.addOrReplaceChild("palm"' in renderer,
        "hand basis/wrist/palm hierarchy is incomplete")
# UV footprints must fit inside each 16x8 vanilla arm atlas region.
for width, height, depth, label in [
    (3.45, 1.35, 3.45 * 3.75 / 8.0, "classic palm"),
    (2.65, 1.35, 2.65 * 3.75 / 8.0, "slim palm"),
    (3.45 * 5.5 / 8.0, 0.90, 3.45 * 4.5 / 8.0, "wrist transition"),
    (0.68, 1.18, 3.45 * 1.95 / 8.0, "finger base"),
    (0.90, 1.50, 3.45 * 2.75 / 8.0, "thumb base"),
]:
    uv_w = 2 * width + 2 * depth
    uv_h = height + depth
    require(uv_w <= 16.0 and uv_h <= 8.0,
            f"{label} UV footprint spills outside the base-arm atlas region ({uv_w:.2f}x{uv_h:.2f})")
for token in ("baseFlexionDeg()", "middleFlexionDeg()", "tipFlexionDeg()", "pose.offsetX() * active",
              "pose.offsetY() * active", "pose.offsetZ() * active"):
    require(token in renderer, f"per-joint hand pose control missing {token}")
for seal in ("ZI", "CHOU", "YIN", "MAO", "CHEN", "SI", "WU", "WEI", "SHEN", "YOU", "XU", "HAI"):
    require(seal in pose_library, f"pose library missing {seal}")

properties = read("gradle.properties")
settings = read("settings.gradle")
events = read("src/main/java/cn/blockforge/outofspec/spellcraft/growth/SpellGrowthEvents.java")
require("mod_version=0.6.34" in properties, "project version is stale")
require("OUT_OF_SPEC_BindingContracts_Stage5_3_25_ContactAwareHandPoses" in settings,
        "standalone project identity is stale")
require('BUILD_MARKER = "OUT_OF_SPEC_STAGE_5_3_25.0.6.34"' in events, "runtime version marker is stale")
print("PASS standalone first-person rig audit: vanilla arm-render hook, no Punchy runtime/binary dependency, retained 180-degree local anatomical basis, seal-only centering, thickness-layered articulated fingers, twelve pose profiles, and project identity audited.")
