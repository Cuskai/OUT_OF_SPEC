from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
def read(path): return (ROOT / path).read_text(encoding="utf-8")
def require(value, message): assert value, message

renderer = read("src/main/java/cn/blockforge/outofspec/binding/client/SealHandPoseRenderer.java")
input_client = read("src/main/java/cn/blockforge/outofspec/binding/client/SealInputDebugClient.java")
pose_library = read("src/main/java/cn/blockforge/outofspec/binding/client/handpose/HandSealPoseLibrary.java")
props = read("gradle.properties")
events = read("src/main/java/cn/blockforge/outofspec/spellcraft/growth/SpellGrowthEvents.java")

# Size: scale only hand_basis so the model/forearm proportion is preserved.
require("HAND_MODEL_SCALE = 1.12f" in renderer, "hand model scale must be 1.12x")
require(renderer.count("= HAND_MODEL_SCALE;") >= 3, "all three basis scale axes must use the explicit scale")
require("armPart.xScale = armPart.yScale = armPart.zScale = 1.0f;" in renderer, "forearm scale must remain unchanged")

# Contact constraints must move animated parts, not remain documentation-only metadata.
for token in ("solveAuthoredContacts(", "profile.contacts()", "CONTACT_SOLVER_PASSES",
              "contactPointInCamera(", "contactTargetGap(", "moveElementInCameraSpace(",
              "Relation.INSERTS_BETWEEN", "Relation.CROSSES"):
    require(token in renderer, f"contact solver missing {token}")
for token in ("ContactConstraint", "Relation.TOUCH", "Relation.INTERLOCKS", "Relation.INSERTS_BETWEEN", "Relation.COVERS"):
    require(token in pose_library, f"authored pose relations missing {token}")
require("prepareFirstPersonArm(player, HumanoidArm.LEFT" in renderer
        and "prepareFirstPersonArm(player, HumanoidArm.RIGHT" in renderer
        and "solveAuthoredContacts(poseStack" in renderer,
        "both rigs must be prepared before bilateral contacts are solved")

# Two-hand lock: cancel attack/use/pick-block and stop ongoing item use during a seal.
require("shouldBlockHandItemInteractions()" in input_client, "item interaction lock predicate missing")
require("InputEvent.InteractionKeyMappingTriggered" in input_client, "Forge click/use event hook missing")
require("event.isAttack() || event.isUseItem() || event.isPickBlock()" in input_client,
        "attack, item-use and pick-block actions must be blocked during bilateral seals")
require("event.setCanceled(true);" in input_client, "blocked item interactions must be canceled")
require("mc.player.isUsingItem()" in input_client and "mc.player.stopUsingItem();" in input_client,
        "an item-use action already in progress must end when the seal owns both hands")
require("mod_version=0.6.34" in props and 'BUILD_MARKER = "OUT_OF_SPEC_STAGE_5_3_25.0.6.34"' in events,
        "hand contact/occupancy iteration version markers are stale")
print("PASS hand iteration audit: 1.12x hand-only scale, runtime contact-constraint solver, and two-hand item-interaction lock.")
