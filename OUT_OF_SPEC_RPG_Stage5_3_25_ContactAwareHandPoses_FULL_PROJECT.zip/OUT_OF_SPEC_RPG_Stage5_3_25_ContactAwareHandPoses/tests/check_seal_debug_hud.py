import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
client = (ROOT / 'src/main/java/cn/blockforge/outofspec/binding/client/SealInputDebugClient.java').read_text(encoding='utf-8')
keys = (ROOT / 'src/main/java/cn/blockforge/outofspec/binding/client/SealInputDebugKeyMappings.java').read_text(encoding='utf-8')
recipes = (ROOT / 'src/main/java/cn/blockforge/outofspec/spellcraft/model/RealSealCastingRecipes.java').read_text(encoding='utf-8')
network = (ROOT / 'src/main/java/cn/blockforge/outofspec/binding/network/SealCastingNetwork.java').read_text(encoding='utf-8')
runtime = (ROOT / 'src/main/java/cn/blockforge/outofspec/spellcraft/runtime/SealedCastEffectState.java').read_text(encoding='utf-8')
mixin = (ROOT / 'src/main/java/cn/blockforge/outofspec/binding/mixin/client/SealInputKeyIsolationMixin.java').read_text(encoding='utf-8')
spell_mixin = (ROOT / 'src/main/java/cn/blockforge/outofspec/binding/mixin/AbstractSpellBindingMixin.java').read_text(encoding='utf-8')
config = json.loads((ROOT / 'src/main/resources/out_of_spec_binding.client.mixins.json').read_text(encoding='utf-8'))
zh = json.loads((ROOT / 'src/main/resources/assets/out_of_spec_binding/lang/zh_cn.json').read_text(encoding='utf-8'))
en = json.loads((ROOT / 'src/main/resources/assets/out_of_spec_binding/lang/en_us.json').read_text(encoding='utf-8'))

for token in ('RenderGuiEvent.Post', '当前输入：', '匹配：', '反馈：', '800ms', '等待服务端复核', 'SealCastingNetwork.submit', 'receiveCastResult'):
    assert token in client, f'live HUD/real-request feature missing: {token}'
assert 'SealInputTestRecipes' not in client, 'live HUD must not use diagnostic-only recipe registry'
for token in ('RegisterKeyMappingsEvent', 'GLFW_KEY_K', 'GLFW_KEY_O', 'GLFW_KEY_ENTER', 'sealMappings()', 'getTranslatedKeyMessage'):
    assert token in keys or token in client, f'key-mapping requirement missing: {token}'
for token in ('irons_spellbooks:magic_arrow', 'irons_spellbooks:firebolt', 'irons_spellbooks:lightning_lance', 'irons_spellbooks:fireball'):
    assert token in recipes, f'real Iron\'s Spells recipe missing: {token}'
for token in ('POWER_FOCUS', 'POWER_FOCUS_STRONG', 'SPELL_POWER', '1.20', '1.35'):
    assert token in recipes, f'executable additional seal missing: {token}'
for token in ('SpellRegistry.getSpell', 'attemptInitiateCast', 'SpellGrowthService.isLearned', 'SpellGrowthService.level', 'CastSource.SPELLBOOK', 'isExecutablePlan', 'claimRequest', 'PENDING_TERMINALS', 'flushPendingCastFinished'):
    assert token in network, f'server-authoritative casting guard missing: {token}'
assert '尚未掌握该术式' in network and '不再要求装备法术书' in network, 'growth learning must gate seal casting without requiring physical spellbook equipment'
lifecycle = (ROOT / 'src/main/java/cn/blockforge/outofspec/binding/SealCastingLifecycleEvents.java').read_text(encoding='utf-8')
assert 'public static synchronized void forgetPlayer(UUID playerId)' in network, 'cross-package logout cleanup must be public'
assert 'SealCastingNetwork.forgetPlayer(player.getUUID())' in lifecycle, 'logout handler must clear session request bookkeeping'
for token in ('EffectSource.ADDITIONAL_SEAL', 'case SPELL_POWER', 'completeSpellExecution', 'cleanupIfNoLongerCasting', 'PROJECTILE_COUNT', 'manaCostMultiplier', 'castTimeMultiplier'):
    assert token in runtime, f'cast-local runtime lifecycle missing: {token}'
for token in ('SealedCastEffectState.spellPowerMultiplier', 'getSpellPower', 'castSpell', 'completeSpellExecution', 'SealedCastEffectState.extraReleaseCount', 'SealedCastEffectState.castTimeMultiplier'):
    assert token in spell_mixin, f'spell-power execution hook missing: {token}'
assert 'shouldSuppressKeyMapping' in mixin and 'KeyMapping;click' in mixin and 'KeyMapping;set' in mixin
assert 'SealInputKeyIsolationMixin' in config['client']
for key in ['key.out_of_spec_binding.seal_start', 'key.out_of_spec_binding.seal_confirm', 'key.out_of_spec_binding.seal_submit', 'key.out_of_spec_binding.seal_backspace', 'key.out_of_spec_binding.seal_cancel', 'key.out_of_spec_binding.seal_toggle_hud']:
    assert key in zh and key in en, f'key translation missing: {key}'
for seal in ('zi','chou','yin','mao','chen','si','wu','wei','shen','you','xu','hai'):
    key = 'key.out_of_spec_binding.seal_' + seal
    assert key in zh and key in en, f'seal translation missing: {key}'
mods = (ROOT / 'src/main/resources/META-INF/mods.toml').read_text(encoding='utf-8')
assert 'diagnostic-only' not in mods and 'does not cast real spells' not in mods
assert 'int width = Math.min(314, screenW - 20)' in client and 'int height = 40' in client, 'active seal HUD must remain a compact two-line rail'
assert 'int y = Math.min(28, Math.max(8, screenH - height - 8))' in client, 'active seal HUD should render at the top of the gameplay view'
assert 'int toastY = y + height + 5' in client, 'feedback toast should sit below the top HUD'
assert 'drawPixelArcaneFrame' in (ROOT / 'src/main/java/cn/blockforge/outofspec/binding/client/BindingContractScreen.java').read_text(encoding='utf-8'), 'contract UI should use the ornate pixel frame'
assert 'five equally spaced satellites' not in client
assert 'private static String feedback =' in client, 'feedback state referenced by the HUD must be declared'
assert client.count('private static String compact(') == 1, 'compact helper must have a single declaration to avoid Java duplicate-method errors'
assert 'transient and never\n        // expands the HUD' in client, 'HUD feedback must not permanently consume a third line'
assert 'registryForLearnedAdditions(learned)' in client and 'learnedAdditionalSealIds' in client, 'client matching must only accept learned additional seals'
assert 'drawOccultPanel' in client and 'PANEL_INNER' in client, 'HUD must use the arcane rail styling'
assert 'SpellGrowthService.isAdditionalSealLearned(player, additionId)' in network, 'server must validate that every additional seal is learned'
print('PASS Stage 2.9/Stage 5.2.2 source audit: compact top-positioned occult seal HUD; feedback/compact compile-regression guards; mastered-addition-only input matching; first-person pose data; server-authoritative cast validation; native spell invocation; and key-isolation Mixin declarations verified.')
