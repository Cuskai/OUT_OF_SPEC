from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
model = ROOT / "src/main/java/cn/blockforge/outofspec/spellcraft/model/SealInputSession.java"
text = model.read_text(encoding="utf-8")

for phase in ["IDLE", "BASE_INPUT", "ADDITIONAL_INPUT", "VALIDATING", "CASTING"]:
    assert phase in text, f"missing state: {phase}"
assert "this(registry, 800L)" in text, "default 800ms input timeout missing"
assert "physicallyHeldSeals.add(seal)" in text and "REPEAT_KEYDOWN_IGNORED" in text
assert "registry.matchBase(sequence)" in text and "registry.matchAdditional(selectedRecipeId, sequence)" in text
assert "EXACT_AND_PREFIX" in (ROOT / "src/main/java/cn/blockforge/outofspec/spellcraft/model/SequenceMatch.java").read_text(encoding="utf-8")
assert "public Result confirmBase" in text and "public Result confirmAdditional" in text
assert "public Result submitCast" in text and "new CastPlanRequest(pendingRequestId, selectedRecipeId, selectedAdditionalSealIds)" in text
assert "new Result(Code.CAST_REQUEST_READY" in text
assert "requestId.equals(requestId)" not in text  # explicitly avoid self-comparison as a response gate
assert "!pendingRequestId.equals(requestId)" in text, "async server result must match the pending request"
assert "REQUIRED_ADDITION_MISSING" in text and "ADDITION_CONFLICT" in text
assert "TIMED_OUT" in text and "unconfirmed seal sequence expired; no cast was triggered" in text
assert "currentSequenceTimes.remove" in text and "currentSequenceTimes.get(currentSequenceTimes.size() - 1)" in text, "backspace must restore the timestamp of the remaining final seal"
assert "TOO_LATE_TO_CANCEL" in text and "VALIDATION_REJECTED_RECOVERABLE" in text
assert "onCastEnded" in text and "STALE_CAST_END_IGNORED" in text
assert "import net.minecraft" not in text and "net.minecraftforge" not in text
print("PASS Stage 2.7 source audit: phase separation, physical key-edge de-duplication, explicit recipe confirmation, timeout/backspace behavior, addition requirement/conflict checks, selection-only request submission, matching server-response gate, and safe cancellation boundaries.")
print("PASS Stage 2.7 pure-Java state machine remains platform independent; the Stage 2.8 client adapter adds rebindable seal keys and a diagnostic HUD with Stage 2.9 real-spell submission now layered on top.")
print("LIMIT Stage 2.7/2.8 runtime: Forge Mixin transformation, live keyboard behavior, and Minecraft gameplay still require an actual Forge build and in-game test.")
