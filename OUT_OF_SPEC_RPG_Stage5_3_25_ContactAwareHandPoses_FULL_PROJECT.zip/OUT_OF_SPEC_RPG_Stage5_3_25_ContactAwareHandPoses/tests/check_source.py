from pathlib import Path
root = Path(__file__).resolve().parents[1]
def read(path):
    return (root / path).read_text(encoding="utf-8")

judge = read('src/main/java/cn/blockforge/outofspec/binding/BindingContractJudge.java')
screen = read('src/main/java/cn/blockforge/outofspec/binding/client/BindingContractScreen.java')
menu = read('src/main/java/cn/blockforge/outofspec/binding/mixin/client/SAOSkillBindingMenuMixin.java')
network = read('src/main/java/cn/blockforge/outofspec/binding/network/BindingCastingNetwork.java')
state = read('src/main/java/cn/blockforge/outofspec/binding/BindingCastingState.java')
events = read('src/main/java/cn/blockforge/outofspec/binding/BindingCastingServerEvents.java')
resolver = read('src/main/java/cn/blockforge/outofspec/binding/SpellNameResolver.java')
advisor = read('src/main/java/cn/blockforge/outofspec/binding/client/BindingAIAdvisor.java')
experience = read('src/main/java/cn/blockforge/outofspec/binding/client/ContractExperienceStore.java')
assert 'import cn.blockforge.outofspec.binding.BindingContractJudge;' in experience
assert 'import cn.blockforge.outofspec.binding.SpellNameResolver;' in experience
powerMixin = read('src/main/java/cn/blockforge/outofspec/binding/mixin/AbstractSpellBindingMixin.java')
visibilityMixin = read('src/main/java/cn/blockforge/outofspec/binding/mixin/LivingEntityVisibilityMixin.java')
harness = read('tests/java/BindingJudgeHarness.java')

assert 'MIN_FAIR_RATIO = 1.15' in judge
assert 'ONE_USE_LIMIT' in judge and 'beforeRewardClause' in judge
assert 'SpellNameResolver.findSpellIds' in judge and 'parseDamageScope' in judge
assert 'Math.min(50' not in judge and 'Math.min(25' not in judge
assert 'irons_spellbooks:fireball' in resolver and 'irons_spellbooks:lightning_lance' in resolver and 'irons_spellbooks:firebolt' in resolver
assert '全部法术' in screen and 'ALL_SPELLS' in read('src/main/java/cn/blockforge/outofspec/binding/BindingContract.java')
assert 'com.sao.saomenulite.client.SAOMenuScreen' in menu and 'activeItems' in menu and 'runAction' in menu
assert 'BindingContractJudge.evaluate(packet.text())' in network
assert 'UNSUPPORTED_SCOPE' in judge and 'UNSUPPORTED_CONDITION' in judge and 'UNSUPPORTED_STAT' in judge
assert 'sacrificeSummary()' in screen and 'benefitSummary()' in screen
assert 'data.put(NBT_KEY, writeContractTag(contract))' in state
assert '分析交易' in screen and '缔结契约' in screen and '解除契约' in screen and 'AI 协商' in screen
assert 'SpellOnCastEvent' in events and 'SpellCooldownAddedEvent.Pre' in events
assert 'SpellDamageEvent' in events and 'consumeDamageMultiplierFor' in events
assert 'permanent_slowness' in state and 'permanent_insomnia' in state and 'single_use_spell_limits' in state
assert 'PlayerSleepInBedEvent' in events and 'Player.BedSleepingProblem.OTHER_PROBLEM' in events
assert 'PlayerEvent.Clone' in events and 'BindingCastingState.copyFrom' in events
assert 'PlayerLoggedInEvent' in events and 'BindingCastingState.enforcePermanentCosts' in events
assert 'hasSpellUseCommitment' in network and 'hasPermanentSlowness(player)' in network
assert 'permanent_contract_effects' in state and 'permanent_cast_move_speed_costs' in state
assert 'permanentCastMoveSpeedModifier' in events and 'permanentCastMoveSpeedCostPct' in state
assert 'healthConditionMet(player.getHealth(), player.getMaxHealth())' in powerMixin
assert 'healthConditionMet(player.getHealth(), player.getMaxHealth())' in visibilityMixin
assert 'healthConditionMet(event.getEntity().getHealth(), event.getEntity().getMaxHealth())' in events
assert 'DELAYED_SEAL_COST' in judge and 'SEAL_STACK_BONUS' in judge and 'HEALTH_THRESHOLD' in judge
assert 'PERMANENT_INSOMNIA_COST' in judge and 'PERMANENT_CAST_SPEED_COST' in judge
assert 'MODE_PERMANENT' in read('src/main/java/cn/blockforge/outofspec/binding/BindingContract.java')
assert 'CONTINUOUS_LIFETIME' in judge and 'declaredRewardLifetimes > 1' in judge
assert 'BindingAIAdvisor.request(intent)' in screen
# Stage 3.4 base: persistent experience retrieval and warm Ollama path.
assert 'out_of_spec_binding_experience.json' in experience
assert 'SERVER_ACCEPTED' in experience and 'exactAccepted' in experience and 'relevant' in experience
assert 'MAX_CASES = 80' in experience and 'MAX_RELEVANT_CASES = 3' in experience
assert 'ContractExperienceStore.exactAccepted(safeIntent)' in advisor
assert 'loadConfig().experienceEnabled()' in advisor
assert 'trackPendingServerOutcome' in screen and 'recordLocalRejection' in screen
assert 'recordPendingServerOutcome(actionSucceeded, hasContract, message)' in read('src/main/java/cn/blockforge/outofspec/binding/client/BindingCastingClient.java')
assert 'ContractExperienceStore.recordServerOutcome' in advisor
assert 'BindingAIAdvisor.experienceMemoryEnabled()' in screen
assert 'experienceMemoryEnabled()' in advisor and 'experience_memory_enabled' in advisor
assert 'BindingAIAdvisor.prewarmIfLocal()' in screen
assert 'keep_alive' in advisor and '/api/generate' in advisor and '/api/chat' in advisor
assert 'PREWARM_IO' in advisor and 'out-of-spec-binding-ai-prewarm' in advisor
assert 'keepAliveMinutes() + "m"' in advisor
assert 'timeout_seconds", "180"' in advisor and 'parseInt(properties.getProperty("timeout_seconds"), 180, 10, 300)' in advisor
assert 'SERVER_ACCEPTED' in advisor or 'SERVER_ACCEPTED' in experience
assert '仍会重新进行本地与服务端裁定' in advisor
assert 'BindingContractJudge.evaluate(input.getValue())' in screen and 'BindingCastingClient.submit(lastSubmittedText, result.contract())' in screen
assert 'BindingContractJudge.evaluate(packet.text())' in network
assert '死亡、重生和重新登录后仍保留' in read('src/main/java/cn/blockforge/outofspec/binding/BindingContract.java')
assert 'castSpeedPercentTarget' in harness and 'permanentInsomniaCost' in harness
print('PASS base source audit: Stage 3.3 gameplay features and Stage 3.4 persistent local experience, exact verified-case fast path, similar-case retrieval, isolated asynchronous Ollama prewarm/keep-alive, server-only verified learning and 180-300 second timeout support.')

# Stage 3.5 regression fixes.
assert '失去睡觉能力' in judge
assert 'equivalentAcceptedTrade' in judge
assert 'equivalentAcceptedTrade' in experience and 'isSafeExactReplay' in experience
context_start = advisor.index('private static String buildExperienceContext(')
context_end = advisor.index('private static JsonObject message(', context_start)
context = advisor[context_start:context_end]
assert '.append(entry.intent())' not in context and '.append(entry.contractText())' not in context
assert '抽象机制索引' in context and 'message("system", buildExperienceContext(examples))' in advisor
assert 'CURRENT_REQUEST' in advisor and '不要把历史契约拼进来' in advisor
assert 'aiRequestSequence' in screen and 'requestToken != aiRequestSequence' in screen
assert 'applyingAiCandidate' in screen and 'changedExplicitSpellScope' in screen
assert 'changesExplicitSpellScope(intent, proposed)' in screen
assert 'findPositiveSpellIds' in resolver and 'findNegatedSpellIds' in resolver and 'NEGATED_TARGET_PREFIX' in resolver
assert '候选改动了本次请求明确指定或排除的法术范围' in screen
assert '原始交易已通过本地预审' in screen and '已自动清空输入框' in screen
assert 'AI 没有返回单独的规范化候选' in screen and '本地规则也未通过' in screen
assert 'if (wasWaitingForServer && succeeded && hasContract)' in screen
assert 'return requested.accepted()' in experience and '!requested.accepted() ||' not in experience
print('PASS Stage 3.5 compile regression: ContractExperienceStore imports BindingContractJudge and SpellNameResolver from parent package.')
print('PASS Stage 3.5 audit: insomnia alias, fail-closed cache replay, anonymized mechanism-only experience context, strict current-request isolation, stale callback cancellation, original-text fallback when AI omits proposal, and success-state input clearing.')

# Stage 3.7 regressions plus Stage 3.8 canonical transport / preparation executor.
assert '仅限(?:于)?(?!下一次|下次|这次|本次|下一发|这一发|一发|一次)' in judge
assert '正常|基础|原本|当前|普通' in judge and '速度(?:的)?' in judge
assert 'openOrResume(Screen parent)' in screen and 'receiveBackgroundServerStatus' in screen and '返回菜单 · 推演继续' in screen, 'closing the contract UI must preserve asynchronous AI/server work'
assert '当前生效的契约' in screen and '返回 SAO Menu' in screen, 'binding UI must always expose active state and an exit path'
assert 'mod_version=0.6.34' in read('gradle.properties')
assert 'OUT_OF_SPEC_RPG_IronSpell_SAO_Stage5_3_25_ContactAwareHandPoses.jar' in read('build.gradle')
assert '缓慢\\\\s*(?:I{1,3}|[1-3]|[一二三])?' in judge
assert 'timedSpellScopedCastLock' in judge and 'movementPenaltyPct * (1.0 + 3.0 * severity * severity)' in judge
assert '代价估值' in judge and '收益估值' in judge
assert 'private record SubmitProposalPacket(String text, BindingContract expectedContract)' in network
assert 'result.contract().equals(packet.expectedContract())' in network
assert 'writeContract(buffer, expectedContract)' in network and 'readContract(buffer)' in network
assert 'private static void writeContract(FriendlyByteBuf b, BindingContract c)' in network
assert 'private static BindingContract readContract(FriendlyByteBuf b)' in network
assert 'PREPARATION_SNEAK_STATIONARY' in read('src/main/java/cn/blockforge/outofspec/binding/BindingContract.java')
assert 'SNEAK_STATIONARY_REQUIREMENT' in judge and 'hasConflictingDurationDeclarations' in judge
assert 'UNSUPPORTED_ADVANCED_MECHANIC' in judge
assert 'hasNamedSpellInStatClause' in judge and 'unsupportedNamedStatScope' in judge
assert '永久缩短|永久降低|永久减少' in judge
assert 'requiredPreparationTicks(player, spellId)' in powerMixin
assert 'castingPreparationProgressTicks(player)' in powerMixin
assert 'updateCastingPreparationProgress(player)' in state
assert 'preparation_mode' in state and 'preparation_spell_id' in state and 'preparation_ticks' in state
assert '双方玩家同意/交换执行器' in advisor and '真正的结印输入/手势识别' in advisor
assert 'current-request' not in advisor.lower() or 'CURRENT_REQUEST' in advisor
assert 'OUT_OF_SPEC_BindingContracts_Stage5_3_25_ContactAwareHandPoses' in read('settings.gradle')
assert 'BindingCastingState.consumeCastingPreparationProgress(player)' in powerMixin
assert 'if (player == null || level.isClientSide || !Boolean.TRUE.equals(cir.getReturnValue())) return;' in powerMixin
assert 'consumeCastingPreparationProgress' in state and 'remove(CAST_PREPARATION_PROGRESS_KEY)' in state
assert '主动提出' in advisor and '当前交易' in advisor

# The network codec must account for every canonical record component in a stable positional order.
import re
record_head = re.search(r'public record BindingContract\((.*?)\)\s*\{', read('src/main/java/cn/blockforge/outofspec/binding/BindingContract.java'), re.S)
assert record_head, 'BindingContract record signature not found'
record_fields = re.findall(r'(?:String|double|boolean|int)\s+(\w+)\s*(?:,|$)', record_head.group(1).replace('\n', ' ') + ',')
assert len(record_fields) == 26, f'expected 26 canonical fields, found {len(record_fields)}: {record_fields}'
write_body = network[network.index('private static void writeContract('):network.index('private static BindingContract readContract(')]
for field in record_fields:
    assert f'c.{field}()' in write_body, f'canonical field missing from network encode: {field}'
read_body = network[network.index('private static BindingContract readContract('):network.index('private record ContractStatusPacket')]
read_ops = re.findall(r'\.read(?:Utf|Double|Boolean|Int)\(', read_body)
assert len(read_ops) == 26, f'canonical decoder must consume 26 fields in positional record order, got {len(read_ops)}'
assert 'result.contract().equals(packet.expectedContract())' in network
print('PASS Stage 3.8 audit: all 26 canonical fields are serialized; server comparison gates activation; preparation is spell-scoped, separately timed, and consumed only after successful cast initiation; unsupported single-spell scopes for global-only attributes fail closed; AI creative suggestions may introduce targets only for open-ended requests, while explicit included/excluded spell scopes are protected; unsupported advanced mechanics fail closed.')
print('PASS carried-forward Stage 3.7 audit: Slowness I/II/III, severity-aware timed cast-root valuation, transparent score output, request isolation, and version identity.')
