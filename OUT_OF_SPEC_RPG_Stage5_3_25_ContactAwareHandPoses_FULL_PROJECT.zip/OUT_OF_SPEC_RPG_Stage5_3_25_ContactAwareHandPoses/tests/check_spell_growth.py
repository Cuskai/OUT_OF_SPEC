from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
def read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")

catalog = read("src/main/java/cn/blockforge/outofspec/spellcraft/growth/SpellGrowthCatalog.java")
service = read("src/main/java/cn/blockforge/outofspec/spellcraft/growth/SpellGrowthService.java")
events = read("src/main/java/cn/blockforge/outofspec/spellcraft/growth/SpellGrowthEvents.java")
network = read("src/main/java/cn/blockforge/outofspec/spellcraft/network/SpellGrowthNetwork.java")
screen = read("src/main/java/cn/blockforge/outofspec/spellcraft/client/SpellGrowthScreen.java")
sao_mixin = read("src/main/java/cn/blockforge/outofspec/binding/mixin/client/SAOSkillBindingMenuMixin.java")
scroll = read("src/main/java/cn/blockforge/outofspec/spellcraft/item/SpellScrollItem.java")
resolver = read("src/main/java/cn/blockforge/outofspec/spellcraft/item/SpellScrollResolver.java")
items = read("src/main/java/cn/blockforge/outofspec/spellcraft/item/SpellGrowthItems.java")
grimoire = read("src/main/java/cn/blockforge/outofspec/spellcraft/item/ArcaneGrimoireItem.java")
seal_network = read("src/main/java/cn/blockforge/outofspec/binding/network/SealCastingNetwork.java")
spell_mixin = read("src/main/java/cn/blockforge/outofspec/binding/mixin/AbstractSpellBindingMixin.java")
mod = read("src/main/java/cn/blockforge/outofspec/binding/BindingCastingMod.java")

for spell_id in ("irons_spellbooks:firebolt", "irons_spellbooks:magic_arrow", "irons_spellbooks:fireball", "irons_spellbooks:lightning_lance"):
    assert spell_id in catalog, f"growth catalog must only rely on real supported spell ID: {spell_id}"
for token in ("SpellTier.LOWER", "SpellTier.MIDDLE", "SpellTier.UPPER", "maxLevel", "requiredProficiency", "isBreakthroughLevel"):
    assert token in catalog, f"tier/level model missing: {token}"
assert "SpellRegistry.REGISTRY.get().getValues()" in catalog, "all registered native and add-on spells must be enumerated dynamically"
assert "SpellSealSequenceGenerator.generate(dynamicIds, CURATED_SEQUENCES.values())" in catalog, "all non-curated spells need generated non-colliding seal sequences"
assert "refreshFromRegistry()" in catalog and "generation++" in catalog, "catalog refresh must publish a new shared generation"
assert "SpellGrowthCatalog.refreshFromRegistry()" in events and "RealSealCastingRecipes.refresh()" in events, "registry reconciliation must rebuild growth and casting catalogues together"
assert "registeredDynamicSpellCount" in catalog and "getSpellResource()" in catalog, "runtime diagnostic must count the actual spell registry"

for token in ("public static ActionResult research", "consumeScroll(player, spellId, 1)", "discover(player, spellId)", "player.getRandom().nextDouble() < chance", "卷轴已消耗", "可重新寻找卷轴后再试", "public static ActionResult levelUp", "public static ActionResult breakthrough", "state.putInt(\"level\", currentLevel + 1)", "state.putString(\"branch\", branch.name())", "copyOnClone"):
    assert token in service, f"server-side growth rule missing: {token}"
assert "currentLevel == 3" in catalog, "the first key breakthrough must be Lv.3 to Lv.4"
assert "return Math.max(0.05, Math.min(0.95" in service, "research chance must be bounded and may never guarantee success"
assert "can_level" in service and "can_breakthrough" in service, "UI must reflect server-calculated eligibility"
assert 'current >= profile.maxLevel()\n                    ? 0 : SpellGrowthCatalog.requiredProficiency(profile, current)' in service, "max-level spells must not display a fake next-level requirement"

assert "inventoryTick" in scroll and "SpellGrowthService.discover(player, spellId)" in scroll, "custom scroll inventory ticking should remain as a fallback"
assert "onSpellScrollPickup(PlayerEvent.ItemPickupEvent event)" in events and "discoverFromStack(player, event.getStack())" in events, "pickup event must route both supported scroll families through the resolver"
assert "onPlayerTick(TickEvent.PlayerTickEvent event)" in events and "discoverInventoryScrolls(event.player)" in events, "server inventory reconciliation must run independently of scroll subclass ticks"
assert "onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event)" in events, "login must reconcile scrolls already in inventory"
assert "onRegisterGrowthCommands(RegisterCommandsEvent event)" in events and 'Commands.literal("oosgrowth")' in events, "a live diagnostic command must be available"
assert '.requires(source -> source.hasPermission(2))' not in events, "player-only inventory diagnostics must not be hidden behind OP permission"
for command in ('Commands.literal("version")', 'Commands.literal("scan")', 'Commands.literal("diagnose")'):
    assert command in events, f"missing accessible runtime diagnostic subcommand: {command}"
assert 'BUILD_MARKER = "OUT_OF_SPEC_STAGE_5_3_25.0.6.34"' in events, "runtime version marker must distinguish this additional-seal build"
assert "discoverInventoryScrolls(Player player)" in service and "SpellScrollResolver.supportedSpellId(stack)" in service, "inventory reconciliation must inspect the actual stack data"
assert "SpellScrollResolver.matches(stack, spellId)" in service and "consumeScroll(player, spellId, 1)" in service, "research count and consumption must select the matching embedded spell ID, not only custom item registry objects"
assert "instanceof Scroll" in resolver and "ISpellContainer.isSpellContainer(stack)" in resolver and "container.getSpellAtIndex(0)" in resolver, "native Iron's Spells scrolls must resolve their embedded spell data"
assert 'CONTAINER_KEYS = {"irons_spellbooks:spell_container", "ISB_Spells"}' in resolver and 'spellIdFromRawTag(stack)' in resolver, "legacy/native scroll NBT fallback must remain available"
assert 'MinecraftForge.EVENT_BUS.register(SpellGrowthEvents.class)' in mod, "Forge-side growth events and commands must be explicitly registered"
assert "MinecraftForge.EVENT_BUS.register(SpellGrowthEvents.class)" in mod and "@Mod.EventBusSubscriber" not in events, "event handlers must have one explicit registration path, avoiding missing/double pickup handlers"
assert "SpellGrowthService.discoverInventoryScrolls(player)" in network, "every server snapshot should reconcile scroll inventory before building UI rows"
assert "public void tick()" in screen and "snapshotRefreshTicks >= 20" in screen, "research UI must refresh periodically when a scroll is picked up while it is open"
assert "原版卷轴" in screen and "空白卷轴" in screen, "research UI must state that spell-bearing native scrolls are supported and blank scrolls are not"
assert "roll >= 0.12f" in events and "tierRoll < 0.72f" in events and "tierRoll < 0.90f" in events and "tierRoll < 0.99f" in events, "mob finds must be rare and weighted toward lower-tier scrolls"
assert "VillagerProfession.LIBRARIAN" in events and "getVillagerData().getLevel() < 5" in events and "LIGHTNING_LANCE_SCROLL" in events, "upper-tier inheritance source must be explicit"

for token in ("RESEARCH, GROWTH, CODEX, GRIMOIRE, ADDITIONS", "selectedBranch", "optionButton", "row.getInt(\"scroll_count\") > 0", "row.getBoolean(\"can_breakthrough\")"):
    assert token in screen, f"growth interface feature missing: {token}"
assert "row.getBoolean(\"discovered\") || row.getBoolean(\"learned\") || row.getInt(\"scroll_count\") > 0" in screen, "research UI must not reveal unknown spell names before discovery"
assert 'row.getInt("breakthrough_shard_cost")' in screen and 'row.getInt("challenge_required")' in screen, "breakthrough screen should show the concrete material and combat requirements"
assert '"连续叠施"' in screen, "grimoire UI should accurately label the current queued sequential implementation"
for token in (
    "out_of_spec_binding.spell_research", "out_of_spec_binding.spell_growth",
    "out_of_spec_binding.seal_codex", "out_of_spec_binding.arcane_grimoire", "out_of_spec_binding.additional_seals",
    "SpellGrowthClient.openResearch(parent)", "SpellGrowthClient.openGrowth(parent)",
    "SpellGrowthClient.openCodex(parent)", "SpellGrowthClient.openAdditionalSeals(parent)", "SpellGrowthClient.openGrimoire(parent)",
):
    assert token in sao_mixin, f"SAO Menu entry integration missing: {token}"
zh_lang = json.loads((ROOT / "src/main/resources/assets/out_of_spec_binding/lang/zh_cn.json").read_text(encoding="utf-8"))
en_lang = json.loads((ROOT / "src/main/resources/assets/out_of_spec_binding/lang/en_us.json").read_text(encoding="utf-8"))
for key in ("out_of_spec_binding.skill_contract", "out_of_spec_binding.spell_research",
            "out_of_spec_binding.spell_growth", "out_of_spec_binding.seal_codex",
            "out_of_spec_binding.arcane_grimoire", "out_of_spec_binding.additional_seals"):
    assert key in zh_lang and key in en_lang, f"SAO Menu label must be localized in both locales: {key}"
assert "private final Screen parent" in screen and "minecraft.setScreen(parent)" in screen, "closing an SAO-launched growth screen must return to SAO Menu"
assert not (ROOT / "src/main/java/cn/blockforge/outofspec/spellcraft/client/SpellGrowthKeyMappings.java").exists(), "growth screens should not consume separate I/L/U keybinds"
assert not (ROOT / "src/main/java/cn/blockforge/outofspec/spellcraft/client/SpellGrowthClientEvents.java").exists(), "growth screens should be accessed from SAO Menu instead of standalone keybind events"
assert "packet.firstSpellId" in network and "packet.secondSpellId" in network, "grimoire request fields must be accessed with their actual fields"
assert "packet.firstSpellId()" not in network and "packet.secondSpellId()" not in network, "GrimoireCastRequest is not a record and has no generated accessors"
assert "SpellGrowthItems.ITEMS.register(modBus)" in mod and "SpellGrowthNetwork.register()" in mod

assert "spell.isLearned(player)" not in seal_network and "SpellGrowthService.isLearned(player, plan.spellId())" in seal_network
assert "CastSource.SPELLBOOK" in seal_network and "不再要求装备法术书" in seal_network, "seals should cast known OOS spells without a physical spellbook"
assert "SpellGrowthService.level(player, plan.spellId())" in seal_network, "seal casting must use OOS growth level"
assert "SpellGrowthService.level(player, currentSpellId)" in spell_mixin and "growthBase / incomingBase" in spell_mixin, "OOS level must affect real Iron spell power"
assert "outOfSpec$requireResearchForGrowthSpells" in spell_mixin and "return SpellGrowthService.isLearned(player, spell.getSpellId())" in spell_mixin, "legacy Iron knowledge cannot bypass OOS study for growth-enabled spells"
assert "SpellGrowthRuntime.onSpellReleased(player, spellId)" in spell_mixin, "optional grimoire follow-up must be connected to real spell release"
assert "InteractionResultHolder<ItemStack> use" in grimoire and "SpellGrowthClient.openGrimoire()" in grimoire

for rel in ("src/main/resources/data/out_of_spec_binding/recipes/arcane_core.json", "src/main/resources/data/out_of_spec_binding/recipes/arcane_grimoire.json"):
    json.loads((ROOT / rel).read_text(encoding="utf-8"))
assert 'row.getBoolean("available")' in screen, "growth UI must distinguish registered but disabled spells from currently castable spells"
assert "LIST_VISIBLE_ROWS" in screen and "mouseScrolled" in screen and "GLFW_KEY_PAGE_DOWN" in screen, "dynamic spell list must remain navigable beyond the first page"
assert "challenge_uses" in service and "recordSuccessfulRelease" in service, "non-damaging spells need a breakthrough progress path"
assert "SpellGrowthRuntime.onSpellReleased(player, spellId)" in spell_mixin, "successful native spell release must train the dynamic profile"
runtime = read("src/main/java/cn/blockforge/outofspec/spellcraft/growth/SpellGrowthRuntime.java")
assert "SpellGrowthService.recordRealCast(player, completedSpellId)" in runtime and "SpellGrowthService.recordSuccessfulRelease(player, completedSpellId)" in runtime, "proficiency and utility spell challenges must progress only after the actual spell executor returns"
assert "SpellGrowthService.recordRealCast(player, spellId)" not in events, "pre-executor SpellOnCastEvent must not award successful-cast proficiency prematurely"
assert "isSpellAvailable(spellId, SpellRegistry.getSpell(spellId))" in service, "disabled spells must be rejected by server-side level and breakthrough actions"
print("PASS Stage 4.5 source audit: custom + native scroll ID resolution, embedded SpellContainer API + legacy NBT fallback, explicit Forge event registration, accessible version/scan/diagnose commands, login version marker, pickup/login/tick/snapshot discovery, exact-scroll consumption, tier/level separation, weighted acquisition, live UI refresh, failure cost, manual upgrades, breakthrough branches, SAO Menu integration, bookless seals, grimoire queue, recipes, and undiscovered-name privacy.")
