#!/usr/bin/env python3
"""Verify against the bundled Stage 1.1 artifact that live Stage 2.9 spells consume getSpellPower."""
from __future__ import annotations
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JAR = ROOT / "baseline" / "OUT_OF_SPEC_RPG_IronSpell_SAO_Mobility_Stage1_1.jar"
SPELLS = {
    "Magic Arrow": "io.redspace.ironsspellbooks.spells.ender.MagicArrowSpell",
    "Firebolt": "io.redspace.ironsspellbooks.spells.fire.FireboltSpell",
    "Lightning Lance": "io.redspace.ironsspellbooks.spells.lightning.LightningLanceSpell",
    "Fireball": "io.redspace.ironsspellbooks.spells.fire.FireballSpell",
}

def fail(message: str) -> None:
    print(f"FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)

def main() -> int:
    if not JAR.is_file():
        fail(f"Bundled verified baseline JAR missing: {JAR}")
    javap = shutil.which("javap")
    if javap is None:
        fail("javap was not found. Run this test with a full JDK 17, not only a JRE.")
    try:
        # The project's general validation script performs the full CRC pass. This focused
        # bytecode audit only needs the central directory and does not re-read every JAR entry.
        with zipfile.ZipFile(JAR) as archive:
            names = set(archive.namelist())
            for label, class_name in SPELLS.items():
                entry = class_name.replace(".", "/") + ".class"
                if entry not in names:
                    fail(f"Baseline JAR does not contain {label} class: {entry}")
    except zipfile.BadZipFile as exc:
        fail(f"Baseline JAR is not a valid ZIP archive: {exc}")

    # Extract only the bytecode targets once. Pointing javap at the entire 19 MB mod JAR for every
    # class forces repeated ZIP scans on slower CI/container filesystems and previously timed out;
    # extracting these few entries makes the same assertions deterministic without changing scope.
    with tempfile.TemporaryDirectory(prefix="out-of-spec-bytecode-") as tmp:
        extracted = Path(tmp)
        needed_classes = {name for name in SPELLS.values()}
        needed_classes.update((
            "io.redspace.ironsspellbooks.api.spells.AbstractSpell",
            "io.redspace.ironsspellbooks.spells.fire.FireballSpell",
        ))
        needed_classes.update(
            class_name for class_name, _projectile in (
                ("io.redspace.ironsspellbooks.spells.ender.MagicArrowSpell", "MagicArrowProjectile"),
                ("io.redspace.ironsspellbooks.spells.fire.FireboltSpell", "FireboltProjectile"),
                ("io.redspace.ironsspellbooks.spells.lightning.LightningLanceSpell", "LightningLanceProjectile"),
                ("io.redspace.ironsspellbooks.spells.fire.FireballSpell", "MagicFireball"),
            )
        )
        with zipfile.ZipFile(JAR) as archive:
            for class_name in needed_classes:
                entry = class_name.replace(".", "/") + ".class"
                destination = extracted / entry
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(archive.read(entry))

        for label, class_name in SPELLS.items():
            result = subprocess.run(
                [javap, "-classpath", str(extracted), "-c", "-p", class_name],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                timeout=20, check=False,
            )
            if result.returncode != 0:
                fail(f"javap failed for {label}: {result.stderr.strip()}")
            if "getSpellPower:" not in result.stdout:
                fail(f"{label} has no bytecode call to AbstractSpell#getSpellPower; do not treat the focus seal as validated for this spell")
            print(f"PASS baseline bytecode: {label} calls AbstractSpell#getSpellPower")

        result = subprocess.run(
            [javap, "-classpath", str(extracted), "-p", "io.redspace.ironsspellbooks.api.spells.AbstractSpell"],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            timeout=20, check=False,
        )
        if result.returncode != 0:
            fail(f"javap failed for AbstractSpell API shape: {result.stderr.strip()}")
        required = (
            "getSpellPower(int, net.minecraft.world.entity.Entity)",
            "getEffectiveCastTime(int, net.minecraft.world.entity.LivingEntity)",
            "attemptInitiateCast(net.minecraft.world.item.ItemStack, int, net.minecraft.world.level.Level, net.minecraft.world.entity.player.Player, io.redspace.ironsspellbooks.api.spells.CastSource, boolean, java.lang.String)",
            "castSpell(net.minecraft.world.level.Level, int, net.minecraft.server.level.ServerPlayer, io.redspace.ironsspellbooks.api.spells.CastSource, boolean)",
            "getLevelFor(int, net.minecraft.world.entity.LivingEntity)",
        )
        missing = [signature for signature in required if signature not in result.stdout]
        if missing:
            fail("AbstractSpell API signature mismatch: " + "; ".join(missing))
        print("PASS baseline API shape: spell power, cast-time, level resolution, initiate and execution entrypoints exist")

        projectile_types = {
            "Magic Arrow": ("io.redspace.ironsspellbooks.spells.ender.MagicArrowSpell", "MagicArrowProjectile"),
            "Firebolt": ("io.redspace.ironsspellbooks.spells.fire.FireboltSpell", "FireboltProjectile"),
            "Lightning Lance": ("io.redspace.ironsspellbooks.spells.lightning.LightningLanceSpell", "LightningLanceProjectile"),
            "Fireball": ("io.redspace.ironsspellbooks.spells.fire.FireballSpell", "MagicFireball"),
        }
        for label, (class_name, projectile_class) in projectile_types.items():
            result = subprocess.run(
                [javap, "-classpath", str(extracted), "-p", "-c", class_name],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                timeout=20, check=False,
            )
            if result.returncode != 0:
                fail(f"javap failed while checking {label} projectile executor: {result.stderr.strip()}")
            if "public void onCast(" not in result.stdout or projectile_class not in result.stdout or "m_7967_" not in result.stdout or "shoot:" not in result.stdout:
                fail(f"{label} does not expose the expected native projectile spawn path; do not enable multirelease")
            print(f"PASS baseline bytecode: {label} onCast creates {projectile_class} through the real entity-spawn path")

        result = subprocess.run(
            [javap, "-classpath", str(extracted), "-p", "io.redspace.ironsspellbooks.spells.fire.FireballSpell"],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            timeout=20, check=False,
        )
        if result.returncode != 0 or "getRadius(int, net.minecraft.world.entity.LivingEntity)" not in result.stdout:
            fail("FireballSpell#getRadius signature mismatch; do not enable Fireball Expansion")
        print("PASS baseline API shape: FireballSpell#getRadius is the expected concrete radius hook")
    print("PASS: Stage 2.9 spell-power / Stage 4.8 projectile-executor baseline bytecode audit.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
