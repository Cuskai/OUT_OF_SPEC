from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
def read(path): return (ROOT / path).read_text(encoding="utf-8")
def require(value, message): assert value, message

hook = read("src/main/java/cn/blockforge/outofspec/binding/mixin/client/StandaloneFirstPersonHandsMixin.java")
renderer = read("src/main/java/cn/blockforge/outofspec/binding/client/SealHandPoseRenderer.java")
config = json.loads(read("src/main/resources/out_of_spec_binding.client.mixins.json"))
build = read("build.gradle")

require('@Mixin(ItemInHandRenderer.class)' in hook, "mixin must target the vanilla first-person item renderer")
require('method = "renderHandsWithItems"' in hook and '@At("HEAD")' in hook,
        "bilateral frame state must be initialized before vanilla begins its hand pass")
require('method = "renderHandsWithItems"' in hook and '@At("RETURN")' in hook,
        "the custom bilateral pair must be drawn at the end of the real vanilla hand pass")
require('outOfSpec$drawBilateralPairAtReturn' in hook and 'finishFirstPersonHandFrame(' in hook,
        "the end-of-frame pair renderer hook is missing")
require('method = "renderPlayerArm"' in hook and 'cancellable = true' in hook,
        "native individual arm geometry must be suppressed to avoid drawing a duplicate single hand")
require("prepareFirstPersonArm(player, HumanoidArm.LEFT" in renderer
        and "prepareFirstPersonArm(player, HumanoidArm.RIGHT" in renderer
        and "renderPreparedFirstPersonArm(poseStack, buffers, packedLight, player,\n                    HumanoidArm.LEFT" in renderer
        and "renderPreparedFirstPersonArm(poseStack, buffers, packedLight, player,\n                    HumanoidArm.RIGHT" in renderer,
        "both sides must be prepared and rendered unconditionally, then contact-solved together")
require("buffers.endBatch();" in renderer,
        "custom arm vertices emitted after vanilla's endBatch must be flushed explicitly")
require("Standalone bilateral first-person hands rendered (left + right)" in renderer,
        "runtime log marker missing; client logs must prove the pair render path executed")
require("leftArmDrawnThisFrame" not in renderer and "rightArmDrawnThisFrame" not in renderer,
        "legacy per-side flags must not decide whether one hand is omitted")
require("StandaloneFirstPersonHandsMixin" in config["client"], "standalone mixin is not registered")
require("Punchy" not in build and "punchy" not in build.lower(), "Gradle must not compile or embed Punchy")
for java_file in (ROOT / "src/main/java").rglob("*.java"):
    src = java_file.read_text(encoding="utf-8")
    require("punchy.client" not in src.lower() and "PunchyArmRenderer" not in src,
            f"active Java source still targets Punchy: {java_file.relative_to(ROOT)}")
print("PASS bilateral standalone audit: renderPlayerArm is suppressed, both hands are unconditionally emitted at renderHandsWithItems RETURN, and custom vertices are explicitly flushed.")
