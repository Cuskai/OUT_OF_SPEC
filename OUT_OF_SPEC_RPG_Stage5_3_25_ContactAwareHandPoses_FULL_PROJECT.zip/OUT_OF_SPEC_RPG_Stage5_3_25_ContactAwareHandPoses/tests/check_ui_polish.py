from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
def read(p): return (ROOT / p).read_text(encoding="utf-8")

hud = read("src/main/java/cn/blockforge/outofspec/binding/client/SealInputDebugClient.java")
contract = read("src/main/java/cn/blockforge/outofspec/binding/client/BindingContractScreen.java")
client = read("src/main/java/cn/blockforge/outofspec/binding/client/BindingCastingClient.java")
service = read("src/main/java/cn/blockforge/outofspec/spellcraft/growth/SpellGrowthService.java")
network = read("src/main/java/cn/blockforge/outofspec/spellcraft/network/SpellGrowthNetwork.java")
sealNetwork = read("src/main/java/cn/blockforge/outofspec/binding/network/SealCastingNetwork.java")
session = read("src/main/java/cn/blockforge/outofspec/spellcraft/model/SealInputSession.java")
recipes = read("src/main/java/cn/blockforge/outofspec/spellcraft/model/RealSealCastingRecipes.java")
screen = read("src/main/java/cn/blockforge/outofspec/spellcraft/client/SpellGrowthScreen.java")
screenClient = read("src/main/java/cn/blockforge/outofspec/spellcraft/client/SpellGrowthClient.java")
menu = read("src/main/java/cn/blockforge/outofspec/binding/mixin/client/SAOSkillBindingMenuMixin.java")
events = read("src/main/java/cn/blockforge/outofspec/spellcraft/growth/SpellGrowthEvents.java")
props = read("gradle.properties")

assert "int width = Math.min(314, screenW - 20)" in hud and "int height = 40" in hud
assert "int y = Math.min(28, Math.max(8, screenH - height - 8))" in hud
assert "int toastY = y + height + 5" in hud
assert "drawPixelArcaneFrame" in contract and "drawPixelArcaneFrame" not in screen
assert "int y = Math.min(28, Math.max(8, screenH - 28))" in hud
assert "transient and never" in hud and "if (now - feedbackAtMillis <= 1150L" in hud, "HUD feedback should be transient, not another permanent line"
assert "registryForLearnedAdditions(learned)" in hud and "learnedAdditionalSealIds" in session
assert "Set.copyOf(registry.additionalSeals().keySet())" in session and "casting registry must be frozen" in session
assert "additionalSealStates(Player player)" in service and 'data.put("additional_seals"' in service
assert "learnAdditionalSeal(Player player, String additionId)" in service
assert "紫水晶碎片" in service and "奥术核心" in service
assert "highestLevel >= 3" in service and "highestLevel >= 2" in service
assert "RealSealCastingRecipes.isKnownAdditionalSeal(additionId)" in service
assert "case RealSealCastingRecipes.MULTI_RELEASE" in service
assert "case RealSealCastingRecipes.TRIUNE_RELEASE" in service
assert "case RealSealCastingRecipes.FIREBALL_EXPANSION" in service
assert "createAdditionalSealSnapshot(player)" in service and 'snapshot.put("additional_seals",' in service
assert "LearnAdditionalSealRequest" in network and "SpellGrowthService.learnAdditionalSeal" in network
assert "SpellGrowthService.isAdditionalSealLearned(player, additionId)" in sealNetwork, "unlearned additions must be rejected server side"
assert "Mode { RESEARCH, GROWTH, CODEX, GRIMOIRE, ADDITIONS }" in screen
assert "openAdditionalSeals(Screen parent)" in screenClient and "out_of_spec_binding.additional_seals" in menu
assert "snapshotRefreshTicks >= 20" in screen and "Mode.ADDITIONS" in screen, "study UI needs fresh server state while open"
assert 'fitLabel(row.getString("requirements"), width)), left, y + 224' in screen
assert "graphics.drawString(this.font, Component.literal(fitLabel(state, width)), left, y + 207" in screen
assert "renderAdditionalSealDetails" in screen and "y + 245" in screen, "addition detail text must stay above the action row"
assert "drawHeaderSigil" in screen and "drawAstralFrame" in screen and "drawRitualCorners" in contract
assert "setBordered(false)" in contract and "renderEngravedButton" in contract and "drawOathSigil" in contract
assert "private static BindingContractScreen retainedInstance" in contract and "openOrResume(Screen parent)" in contract
assert "BindingAIAdvisor.request(intent).whenComplete" in contract
assert "mouseScrolled(double mouseX, double mouseY, double delta)" in contract, "AI transcript must be scrollable without occupying the gameplay view"
assert "drawScrollableAiResponse" in contract and "enableScissor" in contract and "disableScissor" in contract, "long AI reasoning/alternatives must be clipped and scrollable instead of truncated"
assert "aiStartedAtMillis" in contract and "formatElapsed(System.currentTimeMillis() - aiStartedAtMillis)" in contract, "in-flight AI wait time must remain visible"
assert "推演耗时 " in contract and "wrappedAiResponse" in contract, "completed duration and full wrapped response should remain inspectable"
request_block = contract[contract.index("private void requestAiAdvice()"):contract.index("private void evaluate()") ]
assert "minecraft.screen != this" not in request_block, "closing the screen must not discard an AI reply"
assert "if (input != null) draftText = input.getValue()" in contract and "返回菜单 · 推演继续" in contract
assert "receiveBackgroundServerStatus" in contract and "BindingContractScreen.receiveBackgroundServerStatus" in client
assert 'BUILD_MARKER = "OUT_OF_SPEC_STAGE_5_3_25.0.6.34"' in events and "mod_version=0.6.34" in props
print("PASS Stage 5.2.2 UI carry-forward audit: top-positioned compact occult HUD, symmetric sigil asset and pixel-forged bezel, learnable seals with server validation, engraved contract controls, background AI/session retention, full scrollable AI transcript, first-person arm-pivot hand-sign rig with player-skin UVs and per-seal finger poses, and visible elapsed wait time.")
