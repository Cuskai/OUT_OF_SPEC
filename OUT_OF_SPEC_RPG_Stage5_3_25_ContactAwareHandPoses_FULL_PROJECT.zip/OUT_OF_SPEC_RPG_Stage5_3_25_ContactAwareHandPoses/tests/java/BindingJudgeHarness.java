import cn.blockforge.outofspec.binding.BindingContract;
import cn.blockforge.outofspec.binding.BindingContractJudge;
import cn.blockforge.outofspec.binding.SpellNameResolver;

public final class BindingJudgeHarness {
    private static int passed;
    private static void check(String text, boolean expected, String label) {
        BindingContractJudge.Result result = BindingContractJudge.evaluate(text);
        if (result.accepted() != expected) {
            throw new AssertionError(label + " expected=" + expected + " got=" + result.status()
                    + " ratio=" + result.ratio() + " reason=" + result.reason() + " suggestion=" + result.suggestion());
        }
        passed++;
        System.out.println("PASS " + label + " => " + result.status() + " ratio=" + BindingContract.format(result.ratio()));
    }
    private static void checkNamedScopeRejected(String text, String label) {
        BindingContractJudge.Result result = BindingContractJudge.evaluate(text);
        if (result.status() != BindingContractJudge.Status.UNSUPPORTED
                || !result.reason().contains("单个法术")) {
            throw new AssertionError(label + " expected fail-closed single-spell scope rejection, got "
                    + result.status() + " / " + result.reason());
        }
        passed++;
        System.out.println("PASS " + label + " => explicit unsupported-scope refusal");
    }
    public static void main(String[] args) {
        check("法术强度系数降至99%，换取施法时移动速度提高12%，持续性", false, "1% loss for 12% casting movement remains unbalanced");
        check("法术强度系数降至80%，换取施法时移动速度提高12%，持续性", true, "20% spell-power loss for 12% movement accepted");
        check("法术强度降低20%，换取施法时移动速度提高12%，适用范围：全部法术，持续性", true, "all-spell scope supported");
        check("施法时间延长35%，换取施法时移动速度提高12%，持续性", true, "cast time is a valid cost");
        check("法术强度降低10%，换取施法时移动速度提高12%，持续性", false, "small cost still rejected by valuation");
        check("法力消耗增加40%，换取冷却时间缩短15%，持续性", true, "mana can pay for cooldown benefit");
        check("法力消耗增加20%，换取冷却时间缩短20%，持续性", false, "unfair resource trade remains rejected");
        check("冷却时间延长50%，换取法力消耗降低20%，持续性", true, "long cooldown can pay for mana saving");
        check("法力消耗增加40%，换取冷却时间缩短15%，持续性", true, "local AI candidate: mana-for-cooldown trade is executable");
        check("冷却时间延长50%，换取法力消耗降低20%，持续性", true, "local AI candidate: cooldown-for-mana trade is executable");
        check("法术强度降低20%，换取施法时间缩短10%，持续性", true, "local AI candidate: cast-time trade is executable");
        check("法术强度降低20%，换取施法时移动速度提高12%，持续性", true, "local AI candidate: casting mobility trade is executable");
        check("永久承受缓慢效果，换取可见度降低30%，持续性", true, "local AI candidate: visibility trade is executable");
        check("法术强度降低20%，换取施法时雷鸣长枪移动速度提高12%，持续性", true, "named spell casting mobility trade remains supported");
        check("法力消耗增加60%，换取施法时间缩短15%，持续性", true, "a stronger resource cost can buy a moderate global cast-time benefit");
        check("冷却时间延长40%，换取施法时移动速度提高12%，持续性", true, "40% cooldown cost can fund a moderate casting-mobility reward");
        check("永久失去睡眠能力，换取所有法术施法时间永久缩短20%", true, "irreversible insomnia can fund a persistent cast-time reward");
        check("永久承受缓慢效果，换取生物可见度降低20%，持续性", true, "a persistent visibility effect can be bought with an irreversible burden");
        check("永久降低雷鸣长枪施法期间移动速度30%为代价，换取下一次雷鸣长枪伤害提高到500%", true, "a spell-scoped permanent movement burden can fund a targeted one-shot reward");
        check("法力消耗增加50%，换取生物可见度降低20%，持续性", true, "mana cost can fund a persistent visibility reward");
        check("法术强度降低30%，换取冷却时间缩短15%，持续性", true, "power sacrifice can fund a moderate cooldown benefit");
        check("冷却时间延长200%，换取法力消耗降低50%，持续性", true, "large cooldown cost supports a stronger mana-saving trade without arbitrary caps");

        check("法力消耗降低30%", false, "a single reward is not a trade");
        check("法力消耗增加200%，换取冷却时间缩短10%，持续性", true, "200% mana cost no longer hits arbitrary cap");
        check("法术强度降低20%，换取施法时间缩短10%，持续性", true, "20% power loss for 10% cast-time improvement accepted");
        check("法术强度降低20%，换取持续性法术强度提高5%", false, "duplicate stat requires clarification");
        check("法术强度降低20%，换取施法时移动速度提高12%，仅对雷鸣长枪生效，持续性", false, "named scope is not applied to a non-damage attribute");
        check("法术强度降低20%，换取施法时移动速度提高12%，命中敌人后生效，持续性", false, "unsupported delayed trigger is not ignored");
        check("当血量低于50%时，法术强度降低20%，换取施法时移动速度提高12%，持续性", true, "supported health-threshold condition is accepted");
        check("瞬间移动作为代价，换取伤害提高到1000%", false, "teleport remains explicitly unsupported");
        check("永久承受缓慢效果，换取下一次雷鸣长枪的伤害提高到1000%", true, "permanent slow buys one-shot Lightning Lance damage");
        check("永久承受缓慢效果，换取下一次火球术的伤害提高到1000%", true, "offline AI fallback candidate: Fireball one-shot trade is locally executable");
        check("永久失去睡眠能力，换取下一次雷鸣长枪的伤害提高到1000%", true, "offline AI fallback candidate: permanent insomnia is locally executable");
        check("永久承受缓慢效果，换取下一次所有法术伤害提高到1000%", true, "offline AI fallback candidate: all-spell one-shot trade is locally executable");
        check("只能使用一次火球术作为代价，换取下一次火球术的伤害增加到10000%", true, "offline AI fallback candidate: one-use spell trade is locally executable");
        BindingContractJudge.Result permanent = BindingContractJudge.evaluate("永久承受缓慢效果，换取下一次雷鸣长枪的伤害提高到1000%");
        if (!permanent.contract().permanentSlownessCost()
                || !permanent.contract().damageMode().equals(BindingContract.MODE_NEXT_CAST)
                || !permanent.contract().spellScopeId().equals(BindingContract.LIGHTNING_LANCE)
                || Math.abs(permanent.contract().spellDamageMultiplier() - 10.0) > 0.0001) {
            throw new AssertionError("permanent/one-shot contract did not parse as expected");
        }
        passed++;
        System.out.println("PASS permanent+one-shot structured fields are parsed");
        check("只能使用一次雷鸣长枪作为代价，换取这次的雷鸣长枪的伤害提高到1000%", true, "one cast restriction buys 10x damage on that cast");
        BindingContractJudge.Result oneUse = BindingContractJudge.evaluate("只能使用一次雷鸣长枪作为代价，换取这次的雷鸣长枪的伤害提高到1000%");
        if (!oneUse.contract().singleUseSpellCost()
                || !oneUse.contract().singleUseSpellId().equals(BindingContract.LIGHTNING_LANCE)
                || oneUse.contract().damageRewardSpent()
                || !oneUse.contract().damageMode().equals(BindingContract.MODE_NEXT_CAST)) {
            throw new AssertionError("one-use spell cost fields were not parsed");
        }
        passed++;
        System.out.println("PASS one-use spell lock is independent from reward scope");
        check("法术强度降低80%，换取施法时移动速度提高50%，持续性", true, "movement reward above the former 25% cap is allowed");
        check("冷却时间延长300%，换取法术强度提高100%，持续性", true, "spell power reward above the former 50% cap is allowed");
        check("法术强度降低20%，换取施法时移动速度提高12%，持续30秒", true, "timed contracts supported");
        BindingContractJudge.Result timed = BindingContractJudge.evaluate("法术强度降低20%，换取施法时移动速度提高12%，持续30秒");
        if (timed.contract().durationTicks() != 600) throw new AssertionError("30 seconds should become 600 game ticks");
        passed++;
        System.out.println("PASS timed duration is encoded in Minecraft ticks");
        check("法术强度降低20%，换取永久性伤害提高到1000%", false, "extreme persistent damage reward still requires a stronger cost");
        check("法术强度降低20%，换取持续性伤害提高10%", true, "implemented damage effect can be evaluated as an actual trade");
        check("法术强度降低20%，换取持续性冷却时间减少10秒", false, "unimplemented flat-unit cooldown phrasing remains rejected");

        String sealLightning = "只能释放一次雷鸣长枪，换取下一次雷鸣长枪的伤害增加到10000%";
        check(sealLightning, true, "the exact one-use spell-seal wording from the screenshot is recognized and balanced");
        BindingContractJudge.Result sealed = BindingContractJudge.evaluate(sealLightning);
        if (!sealed.contract().singleUseSpellCost()
                || !sealed.contract().singleUseSpellId().equals("irons_spellbooks:lightning_lance")
                || !sealed.contract().spellScopeId().equals("irons_spellbooks:lightning_lance")
                || Math.abs(sealed.contract().spellDamageMultiplier() - 100.0) > 0.0001
                || !sealed.contract().damageMode().equals(BindingContract.MODE_NEXT_CAST)) {
            throw new AssertionError("one-use seal must bind the single allowed Lightning Lance cast to a 100x damage reward");
        }
        passed++;
        System.out.println("PASS exact screenshot phrase stores the correct cost ID, reward scope, 100x multiplier and next-cast lifetime");

        check("只能释放一次火球术，换取下一次火球术的伤害增加到10000%", true,
                "generic named spell seal works for Fireball, not just Lightning Lance");
        BindingContractJudge.Result fireball = BindingContractJudge.evaluate(
                "只能释放一次火球术，换取下一次火球术的伤害增加到10000%");
        if (!fireball.contract().singleUseSpellId().equals("irons_spellbooks:fireball")
                || !fireball.contract().spellScopeId().equals("irons_spellbooks:fireball"))
            throw new AssertionError("Chinese Fireball name was not resolved independently for cost and reward");
        if (!fireball.contract().matchesSpell("irons_spellbooks:fireball")
                || fireball.contract().matchesSpell("irons_spellbooks:lightning_lance"))
            throw new AssertionError("named Fireball reward must affect Fireball only");
        passed++;
        System.out.println("PASS named Chinese spell scope matches Fireball and excludes Lightning Lance");
        passed++;
        System.out.println("PASS generic Chinese spell-name resolver selects Fireball as both cost and reward target");
        check("只能释放一次 Fireball，换取下一次 Fireball 的伤害增加到10000%", true,
                "English spell name resolves for both cost and reward scopes");
        BindingContractJudge.Result englishFireball = BindingContractJudge.evaluate(
                "只能释放一次 Fireball，换取下一次 Fireball 的伤害增加到10000%");
        if (!englishFireball.contract().singleUseSpellId().equals("irons_spellbooks:fireball")
                || !englishFireball.contract().spellScopeId().equals("irons_spellbooks:fireball"))
            throw new AssertionError("English Fireball name was not resolved");
        passed++;
        System.out.println("PASS English names resolve to the same canonical ID as localized Chinese names");

        if (!SpellNameResolver.findUniqueSpellId("强效治疗").orElse("").equals("irons_spellbooks:greater_heal"))
            throw new AssertionError("longer localized spell name should not also match the contained shorter spell name");
        passed++;
        System.out.println("PASS longer spell names suppress misleading contained-name matches");

        check("永久承受缓慢效果，换取下一次火球术的伤害提高到1000%", true,
                "permanent cost can target any supported spell name");
        BindingContractJudge.Result allSpellsDefault = BindingContractJudge.evaluate(
                "永久承受缓慢效果，换取下一次法术伤害提高到1000%");
        if (!allSpellsDefault.accepted() || !allSpellsDefault.contract().spellScopeId().equals(BindingContract.ALL_SPELLS))
            throw new AssertionError("unnamed damage reward should default to all spells");
        passed++;
        System.out.println("PASS unnamed next-cast damage reward defaults to all spells");

        BindingContractJudge.Result explicitlyAll = BindingContractJudge.evaluate(
                "永久承受缓慢效果，换取下一次所有法术伤害提高到1000%");
        if (!explicitlyAll.accepted() || !explicitlyAll.contract().spellScopeId().equals(BindingContract.ALL_SPELLS))
            throw new AssertionError("explicit all-spell scope was not preserved");
        if (!explicitlyAll.contract().matchesSpell("irons_spellbooks:fireball")
                || !explicitlyAll.contract().matchesSpell("irons_spellbooks:lightning_lance"))
            throw new AssertionError("all-spell reward must match every supported spell id");
        passed++;
        System.out.println("PASS explicit all-spell scope matches both Fireball and Lightning Lance");
        passed++;
        System.out.println("PASS explicit all-spell reward remains global, not confused with the cost spell");

        BindingContractJudge.Result unrelatedSpellSeal = BindingContractJudge.evaluate(
                "只能释放一次雷鸣长枪，换取下一次火球术的伤害增加到10000%");
        if (unrelatedSpellSeal.accepted()
                || !unrelatedSpellSeal.contract().singleUseSpellId().equals("irons_spellbooks:lightning_lance")
                || !unrelatedSpellSeal.contract().spellScopeId().equals("irons_spellbooks:fireball"))
            throw new AssertionError("unrelated permanent spell seal must not silently subsidize a huge different-spell reward");
        passed++;
        System.out.println("PASS cost spell and reward spell remain independent, and unrelated seal does not subsidize 100x reward");

        BindingContractJudge.Result ambiguousReward = BindingContractJudge.evaluate(
                "永久承受缓慢效果，换取下一次火球术与雷鸣长枪的伤害提高到1000%");
        if (ambiguousReward.status() != BindingContractJudge.Status.UNSUPPORTED)
            throw new AssertionError("ambiguous multiple spell names must fail closed until multi-scope is implemented");
        passed++;
        System.out.println("PASS ambiguous multi-spell scope is rejected instead of silently choosing one");

        if (!BindingContract.normalizeSpellId("火球术").equals("irons_spellbooks:fireball")
                || !BindingContract.normalizeSpellId("Fireball").equals("irons_spellbooks:fireball")
                || !BindingContract.normalizeSpellId("irons_spellbooks:fireball").equals("irons_spellbooks:fireball"))
            throw new AssertionError("spell canonicalizer must support Chinese, English and namespaced IDs");
        passed++;
        System.out.println("PASS spell canonicalizer accepts Chinese names, English names and registry IDs");

        BindingContractJudge.Result insomnia = BindingContractJudge.evaluate(
                "一直睡不了觉为代价，换取下一次雷鸣长枪的伤害提高到1000%");
        if (!insomnia.accepted() || !insomnia.contract().permanentInsomniaCost()
                || !insomnia.contract().damageMode().equals(BindingContract.MODE_NEXT_CAST))
            throw new AssertionError("permanent insomnia must be recognized as an irreversible cost for a one-shot spell reward");
        passed++;
        System.out.println("PASS permanent insomnia cost parses as an irreversible burden and survives clear/death by NBT design");

        BindingContractJudge.Result permanentLifetime = BindingContractJudge.evaluate(
                "永久承受缓慢效果，换取全部法术伤害永久性提高到200%");
        if (!permanentLifetime.accepted() || !permanentLifetime.contract().damageMode().equals(BindingContract.MODE_PERMANENT))
            throw new AssertionError("explicit permanent reward must have its own non-revocable mode");
        passed++;
        System.out.println("PASS explicit permanent reward has a distinct permanent lifetime mode");

        BindingContractJudge.Result continuousLifetime = BindingContractJudge.evaluate(
                "永久承受缓慢效果并一直睡不了觉为代价，换取全部法术伤害持续性提高到200%");
        if (!continuousLifetime.accepted() || !continuousLifetime.contract().damageMode().equals(BindingContract.MODE_PERSISTENT))
            throw new AssertionError("continuous reward must remain a separate revocable mode");
        passed++;
        System.out.println("PASS continuous/revocable lifetime is distinguished from irreversible permanent lifetime");

        BindingContractJudge.Result castSpeedCost = BindingContractJudge.evaluate(
                "永久降低雷鸣长枪施法期间移动速度20%为代价，换取下一次雷鸣长枪伤害提高到200%");
        if (!castSpeedCost.accepted() || castSpeedCost.contract().moveSpeedDeltaPct() >= 0
                || !castSpeedCost.contract().permanentCastMoveSpeedCost()
                || !castSpeedCost.contract().moveSpeedScopeId().equals("irons_spellbooks:lightning_lance"))
            throw new AssertionError("spell-scoped permanent cast-movement penalty must be parsed and scoped correctly");
        passed++;
        System.out.println("PASS permanent cast-time movement cost is a real scoped cost and remains independent of one-shot reward");

        BindingContractJudge.Result castSpeedPercentTarget = BindingContractJudge.evaluate(
                "永久承受施法期间移动速度降低为20%为代价，换取火焰箭伤害提高200%，持续性");
        if (!castSpeedPercentTarget.accepted() || Math.abs(castSpeedPercentTarget.contract().moveSpeedDeltaPct() - (-80.0)) > 0.001
                || !castSpeedPercentTarget.contract().permanentCastMoveSpeedCost()
                || !castSpeedPercentTarget.contract().spellScopeId().equals("irons_spellbooks:firebolt"))
            throw new AssertionError("cast-time movement speed reduced TO 20% must parse as -80%, and firebolt reward target must be identified");
        passed++;
        System.out.println("PASS cast-time move speed reduced to 20% is parsed correctly while Firebolt damage scope remains named");

        BindingContractJudge.Result castSpeedMissingLifetime = BindingContractJudge.evaluate(
                "永久承受施法期间移动速度降低为20%为代价，换取火焰箭伤害提高200%");
        if (castSpeedMissingLifetime.status() != BindingContractJudge.Status.UNSUPPORTED)
            throw new AssertionError("cast-speed cost may be permanent but its repeatable reward still needs an explicit lifetime");
        passed++;
        System.out.println("PASS permanent cast-speed cost does not silently make an ambiguous damage reward permanent");

        BindingContractJudge.Result healthTrigger = BindingContractJudge.evaluate(
                "永久承受缓慢效果，换取当生命值低于50%时全部法术伤害永久性提高到200%");
        if (!healthTrigger.accepted() || Math.abs(healthTrigger.contract().healthThresholdPct() - 50.0) > 0.001)
            throw new AssertionError("supported low-health trigger should be parsed into a real condition");
        passed++;
        System.out.println("PASS low-health activation condition is parsed into the contract");

        BindingContractJudge.Result sealStack = BindingContractJudge.evaluate(
                "只能释放一次雷鸣长枪，换取每永久封存一个法术，全部法术伤害额外提高20%，永久性");
        if (!sealStack.accepted() || sealStack.contract().damagePerSealedSpellPct() <= 0.0
                || !sealStack.contract().damageMode().equals(BindingContract.MODE_PERMANENT))
            throw new AssertionError("permanent seal-stack reward must be parsed into irreversible mode");
        passed++;
        System.out.println("PASS seal-count stacking reward is permanent and separately recorded");

        BindingContractJudge.Result delayedSeal = BindingContractJudge.evaluate(
                "永久承受缓慢效果，换取全部法术伤害提高到200%，限时30秒，期限结束后永久封存火球术");
        if (!delayedSeal.accepted() || !delayedSeal.contract().delayedSealSpellId().equals("irons_spellbooks:fireball")
                || delayedSeal.contract().durationTicks() != 600)
            throw new AssertionError("timed reward with delayed permanent seal must parse its expiry and target");
        passed++;
        System.out.println("PASS timed contract with delayed spell seal parses its duration and target");

        BindingContractJudge.Result immediateSealExchange = BindingContractJudge.evaluate(
                "立即永久封存火球术，换取下一次雷鸣长枪伤害达到200%，一次性");
        if (!immediateSealExchange.accepted() || !immediateSealExchange.contract().immediateSealCost()
                || !immediateSealExchange.contract().singleUseSpellId().equals("irons_spellbooks:fireball")
                || !immediateSealExchange.contract().spellScopeId().equals("irons_spellbooks:lightning_lance"))
            throw new AssertionError("immediate seal of spell A must be distinct from the reward target spell B");
        passed++;
        System.out.println("PASS immediate permanent seal of spell A can fund a one-shot reward on spell B");

        BindingContractJudge.Result ambiguousLifetime = BindingContractJudge.evaluate(
                "永久承受缓慢效果，换取全部法术伤害提高到200%");
        if (ambiguousLifetime.status() != BindingContractJudge.Status.UNSUPPORTED)
            throw new AssertionError("ambiguous reward lifetime should require an explicit next/timed/continuous/permanent term");
        passed++;
        System.out.println("PASS ambiguous reward lifetime is rejected instead of silently treated as persistent");

        BindingContractJudge.Result conflictingTimedPermanent = BindingContractJudge.evaluate(
                "永久承受缓慢效果，换取全部法术伤害永久性提高到200%，限时30秒");
        if (conflictingTimedPermanent.status() != BindingContractJudge.Status.UNSUPPORTED)
            throw new AssertionError("timed and permanent reward modes must not silently override each other");
        passed++;
        System.out.println("PASS timed/permanent benefit conflict is rejected");

        BindingContractJudge.Result conflictingContinuousTimed = BindingContractJudge.evaluate(
                "永久承受缓慢效果，换取全部法术伤害持续性提高到200%，限时30秒");
        if (conflictingContinuousTimed.status() != BindingContractJudge.Status.UNSUPPORTED)
            throw new AssertionError("continuous and timed reward modes must not silently override each other");
        passed++;
        System.out.println("PASS continuous/timed benefit conflict is rejected");

        BindingContractJudge.Result unknownCostSpell = BindingContractJudge.evaluate(
                "只能释放一次未知咒语，换取下一次伤害提高到1000%");
        if (unknownCostSpell.status() != BindingContractJudge.Status.UNSUPPORTED)
            throw new AssertionError("unknown spell seal should fail closed rather than becoming a fake cost");
        passed++;
        System.out.println("PASS unknown spell name cannot be treated as a valid irreversible cost");

        String screenshotInsomnia = "永久失去睡觉能力，换取雷鸣长枪基础伤害提高200%。永久生效。";
        BindingContractJudge.Result screenshotParsed = BindingContractJudge.evaluate(screenshotInsomnia);
        if (!screenshotParsed.accepted() || !screenshotParsed.contract().permanentInsomniaCost()
                || !screenshotParsed.contract().damageMode().equals(BindingContract.MODE_PERMANENT)
                || !screenshotParsed.contract().spellScopeId().equals("irons_spellbooks:lightning_lance")
                || Math.abs(screenshotParsed.contract().spellDamageMultiplier() - 3.0) > 0.0001) {
            throw new AssertionError("Exact screenshot wording should parse as permanent insomnia for a 300%-of-base reward: "
                    + screenshotParsed.status() + " / " + screenshotParsed.reason());
        }
        passed++;
        System.out.println("PASS exact screenshot wording: permanent lose-sleep-ability cost + Thunder Lance base damage increased by 200% => 300% base, permanent");

        check("永久失去睡觉能力，换取雷鸣长枪基础伤害提高200%。永久生效。", true,
                "lose ability to sleep alias is recognized and supports named permanent damage benefit");
        check("永久不能睡觉，换取火焰箭基础伤害提高200%。永久生效。", true,
                "alternate no-sleep wording is recognized");

        String sameTradeA = "永久失去睡觉能力，换取雷鸣长枪基础伤害提高200%。永久生效。";
        String sameTradeB = "永久失去睡眠能力，换取雷鸣长枪伤害达到基础伤害的300%。永久生效。";
        if (!BindingContractJudge.equivalentAcceptedTrade(sameTradeA, sameTradeB))
            throw new AssertionError("Equivalent natural-language descriptions should compare as the same trade");
        passed++;
        System.out.println("PASS paraphrase guard accepts equivalent amount/scope/lifetime wording");
        if (BindingContractJudge.equivalentAcceptedTrade(sameTradeA,
                "永久失去睡眠能力，换取火焰箭最终伤害达到基础伤害的300%。永久生效。"))
            throw new AssertionError("Trade-equivalence guard must reject changing the named target spell");
        passed++;
        System.out.println("PASS paraphrase guard rejects old/foreign target spell contamination");

        // Stage 3.6 compatibility regressions matching the reported Minecraft screenshots.
        String hitLimitedSleep = "永久失去睡觉能力，换取雷鸣长枪最终伤害达到基础伤害的300%。永久代价，收益仅限下一次成功命中。";
        BindingContractJudge.Result hitLimited = BindingContractJudge.evaluate(hitLimitedSleep);
        if (!hitLimited.accepted() || !hitLimited.contract().permanentInsomniaCost()
                || !hitLimited.contract().damageMode().equals(BindingContract.MODE_NEXT_CAST)
                || !hitLimited.contract().spellScopeId().equals(BindingContract.LIGHTNING_LANCE))
            throw new AssertionError("Stage 3.6: '收益仅限下一次成功命中' must not be classified as unsupported scope; got "
                    + hitLimited.status() + " / " + hitLimited.reason());
        passed++;
        System.out.println("PASS Stage 3.6: one-successful-hit wording accepted as supported next-cast lifetime");

        String timedSpeedCost = "未来30秒内，火焰箭施法期间移动速度降低至正常速度的20%，换取火焰箭最终伤害达到基础伤害的300%。代价与收益均限时30秒。";
        BindingContractJudge.Result timedSpeed = BindingContractJudge.evaluate(timedSpeedCost);
        if (Math.abs(timedSpeed.contract().moveSpeedDeltaPct() - (-80.0)) > 0.001
                || !timedSpeed.contract().moveSpeedScopeId().equals("irons_spellbooks:firebolt")
                || !timedSpeed.contract().spellScopeId().equals("irons_spellbooks:firebolt")
                || timedSpeed.contract().durationTicks() != 600
                || !timedSpeed.contract().damageMode().equals(BindingContract.MODE_TIMED)
                || timedSpeed.status() == BindingContractJudge.Status.UNRECOGNIZED
                || timedSpeed.status() == BindingContractJudge.Status.UNSUPPORTED)
            throw new AssertionError("Stage 3.6: timed casting speed cost must parse as -80%, scoped Firebolt, 600 ticks; got "
                    + timedSpeed.status() + " / " + timedSpeed.reason() + " / speed=" + timedSpeed.contract().moveSpeedDeltaPct());
        passed++;
        System.out.println("PASS Stage 3.6: casting movement speed lowered to 20% of normal parses as -80% for Firebolt");

        String sleepForeverDamage = "一直睡不了觉为代价，换取雷鸣长枪伤害永久提高300%。";
        BindingContractJudge.Result sleepForever = BindingContractJudge.evaluate(sleepForeverDamage);
        if (!sleepForever.accepted() || !sleepForever.contract().permanentInsomniaCost()
                || !sleepForever.contract().damageMode().equals(BindingContract.MODE_PERMANENT)
                || Math.abs(sleepForever.contract().spellDamageMultiplier() - 4.0) > 0.001)
            throw new AssertionError("Stage 3.6: insomnia + permanent named-damage wording must parse; got "
                    + sleepForever.status() + " / " + sleepForever.reason());
        passed++;
        System.out.println("PASS Stage 3.6: permanent insomnia + damage permanently increased by 300% yields 4x damage");

        String sealOneBuffAnother = "以永久封存魔法箭为代价，换取雷鸣长枪伤害永久提高300%。";
        BindingContractJudge.Result sealTrade = BindingContractJudge.evaluate(sealOneBuffAnother);
        if (!sealTrade.accepted() || !sealTrade.contract().immediateSealCost()
                || !sealTrade.contract().singleUseSpellId().equals("irons_spellbooks:magic_arrow")
                || !sealTrade.contract().spellScopeId().equals(BindingContract.LIGHTNING_LANCE)
                || Math.abs(sealTrade.contract().spellDamageMultiplier() - 4.0) > 0.001)
            throw new AssertionError("Stage 3.6: permanent Magic Arrow seal should fund permanent Lightning Lance buff; got "
                    + sealTrade.status() + " / " + sealTrade.reason() + " / ratio=" + sealTrade.ratio());
        passed++;
        System.out.println("PASS Stage 3.6: permanent Magic Arrow seal funds separate permanent Lightning Lance 4x damage");

        // Stage 3.7: plain vanilla effect label "缓慢 I" must be parsed as a permanent cost.
        String slowOneShot = "永久承受缓慢I，换取下一次火焰箭最终伤害达到基础伤害的300%。代价永久，收益仅限下一次成功命中。";
        BindingContractJudge.Result slowOneShotResult = BindingContractJudge.evaluate(slowOneShot);
        if (!slowOneShotResult.accepted() || !slowOneShotResult.contract().permanentSlownessCost()
                || !slowOneShotResult.contract().damageMode().equals(BindingContract.MODE_NEXT_CAST)
                || !slowOneShotResult.contract().spellScopeId().equals("irons_spellbooks:firebolt"))
            throw new AssertionError("Stage 3.7: '永久承受缓慢 I' should be a recognized irreversible cost; got "
                    + slowOneShotResult.status() + " / " + slowOneShotResult.reason());
        passed++;
        System.out.println("PASS Stage 3.7: permanent Slowness I + one-shot Firebolt 300%-of-base reward parses");

        // The user's exact timed case: complete rooting while casting Firebolt for ten seconds
        // should be priced as a severe, spell-scoped cost rather than a linear 100-point penalty.
        String fullCastLock = "未来10秒内，火焰箭施法期间移动速度降低至正常速度的0%，换取火焰箭最终伤害达到基础伤害的300%。代价与收益均限时10秒。";
        BindingContractJudge.Result fullCastLockResult = BindingContractJudge.evaluate(fullCastLock);
        if (!fullCastLockResult.accepted()
                || Math.abs(fullCastLockResult.contract().moveSpeedDeltaPct() - (-100.0)) > 0.001
                || !fullCastLockResult.contract().moveSpeedScopeId().equals("irons_spellbooks:firebolt")
                || !fullCastLockResult.contract().spellScopeId().equals("irons_spellbooks:firebolt")
                || fullCastLockResult.contract().durationTicks() != 200
                || !fullCastLockResult.contract().damageMode().equals(BindingContract.MODE_TIMED))
            throw new AssertionError("Stage 3.7: timed 100% cast-root for 10s vs 3x Firebolt should pass with parsed 200 ticks; got "
                    + fullCastLockResult.status() + " ratio=" + fullCastLockResult.ratio() + " / " + fullCastLockResult.reason());
        passed++;
        System.out.println("PASS Stage 3.7: exact 10-second full cast-root vs 3x Firebolt is accepted with transparent scores");

        // More modest reduction to 20% of normal speed is an 80% penalty, not a total root;
        // under the same 10-second 3x reward it should remain below the fair-trade threshold.
        String partialCastSlow = "未来10秒内，火焰箭施法期间移动速度降低至正常速度的20%，换取火焰箭最终伤害达到基础伤害的300%。代价与收益均限时10秒。";
        BindingContractJudge.Result partialCastSlowResult = BindingContractJudge.evaluate(partialCastSlow);
        if (partialCastSlowResult.status() != BindingContractJudge.Status.UNBALANCED)
            throw new AssertionError("Stage 3.7: 80% movement penalty should not be treated as the same severity as a full cast-root; got "
                    + partialCastSlowResult.status() + " ratio=" + partialCastSlowResult.ratio());
        passed++;
        System.out.println("PASS Stage 3.7: 80% cast movement penalty remains distinct from a complete root");

        // Stage 3.8: the ritual preparation is a real structured field, not a fake duration.
        String preparedTrade = "永久承受缓慢I，换取火焰箭施法前必须潜行静止2秒，且火焰箭伤害永久提高300%。";
        BindingContractJudge.Result preparedResult = BindingContractJudge.evaluate(preparedTrade);
        if (!preparedResult.accepted()
                || !preparedResult.contract().preparationMode().equals(BindingContract.PREPARATION_SNEAK_STATIONARY)
                || !preparedResult.contract().preparationSpellId().equals("irons_spellbooks:firebolt")
                || preparedResult.contract().preparationTicks() != 40
                || preparedResult.contract().durationTicks() != 0
                || !preparedResult.contract().permanentSlownessCost()
                || !preparedResult.contract().damageMode().equals(BindingContract.MODE_PERMANENT))
            throw new AssertionError("Stage 3.8: sneak-and-still preparation must be spell-scoped and must not be parsed as contract expiry; got "
                    + preparedResult.status() + " / " + preparedResult.reason() + " / " + preparedResult.contract());
        passed++;
        System.out.println("PASS Stage 3.8: server-enforced spell-scoped sneak/still preparation is structured separately from contract duration");

        // The canonical object is stable for the same input and includes each executable term.
        BindingContract canonicalAgain = BindingContractJudge.evaluate(preparedTrade).contract();
        if (!preparedResult.contract().equals(canonicalAgain))
            throw new AssertionError("Stage 3.8: parsing the same text did not reproduce the same canonical BindingContract");
        passed++;
        System.out.println("PASS Stage 3.8: the same request reproduces the same canonical contract");
        BindingContract alteredPreparation = new BindingContract(canonicalAgain.source(),
                canonicalAgain.spellPowerDeltaPct(), canonicalAgain.moveSpeedDeltaPct(), canonicalAgain.castTimeDeltaPct(),
                canonicalAgain.visibilityReductionPct(), canonicalAgain.manaCostDeltaPct(), canonicalAgain.cooldownDeltaPct(),
                canonicalAgain.spellScopeId(), canonicalAgain.singleUseSpellId(), canonicalAgain.spellDamageMultiplier(),
                canonicalAgain.damageMode(), canonicalAgain.permanentSlownessCost(), canonicalAgain.singleUseSpellCost(),
                canonicalAgain.durationTicks(), canonicalAgain.damageRewardSpent(), canonicalAgain.spellPowerScopeId(),
                canonicalAgain.moveSpeedScopeId(), canonicalAgain.permanentInsomniaCost(), canonicalAgain.healthThresholdPct(),
                canonicalAgain.damagePerSealedSpellPct(), canonicalAgain.delayedSealSpellId(), canonicalAgain.immediateSealCost(),
                canonicalAgain.permanentCastMoveSpeedCost(), canonicalAgain.preparationMode(), canonicalAgain.preparationSpellId(),
                canonicalAgain.preparationTicks() + 1);
        if (preparedResult.contract().equals(alteredPreparation))
            throw new AssertionError("Stage 3.8: canonical contract equality ignored a changed executable preparation field");
        passed++;
        System.out.println("PASS Stage 3.8: canonical contract equality detects changed executable fields");

        check("双方玩家签订契约，永久承受缓慢I，换取下一次火焰箭最终伤害达到基础伤害的300%。", false,
                "unsupported bilateral player contract fails closed");
        check("永久承受缓慢I，换取下一次火焰箭最终伤害达到基础伤害的300%，施法前必须结印并咏唱。", false,
                "unsupported hand seals and chant are not silently treated as ordinary casts");
        check("永久承受缓慢I，换取下一次火焰箭最终伤害达到基础伤害的300%，违约后永久封存全部法术。", false,
                "unsupported breach consequence fails closed");
        check("未来10秒内，火焰箭施法期间移动速度降低至正常速度的0%，换取火焰箭最终伤害达到基础伤害的300%，代价限时10秒、收益限时30秒。", false,
                "conflicting term deadlines fail closed rather than sharing one timer");
        check("永久承受缓慢I，换取下一次火焰箭最终伤害达到基础伤害的300%，并要求施法前潜行静止100000秒。", false,
                "preparation duration outside safe representable bounds fails closed");
        checkNamedScopeRejected("永久承受缓慢I，换取雷鸣长枪冷却时间永久缩短20%。",
                "single-spell cooldown scope is refused while cooldown remains global-only");
        checkNamedScopeRejected("永久承受缓慢I，换取雷鸣长枪施法时间永久缩短20%。",
                "single-spell cast-time scope is refused while cast time remains global-only");
        checkNamedScopeRejected("永久承受缓慢I，换取雷鸣长枪法力消耗永久降低20%。",
                "single-spell mana-cost scope is refused while mana cost remains global-only");
        checkNamedScopeRejected("永久承受缓慢I，换取雷鸣长枪可见度永久降低20%。",
                "single-spell visibility scope is refused while visibility remains global-only");
        check("永久承受缓慢I，换取全部法术冷却时间永久缩短20%。", true,
                "global cooldown scope remains supported even when another cost names a sealed spell");

        // AI scope guard: creative, open-ended requests may receive new supported spell targets.
        if (SpellNameResolver.changesExplicitSpellScope("给我一个新颖的束缚创意",
                "永久封存魔法箭，换取雷鸣长枪伤害永久提高100%。"))
            throw new AssertionError("Stage 3.8: open-ended creative AI suggestion was incorrectly rejected for introducing spell targets");
        passed++;
        System.out.println("PASS Stage 3.8: open-ended AI proposal can introduce a new spell combination");

        String explicitScope = "永久封存魔法箭，换取雷鸣长枪伤害永久提高100%。";
        if (SpellNameResolver.changesExplicitSpellScope(explicitScope, explicitScope))
            throw new AssertionError("Stage 3.8: equivalent explicit spell scope was marked as changed");
        passed++;
        System.out.println("PASS Stage 3.8: exact explicit spell scope is preserved");

        if (!SpellNameResolver.changesExplicitSpellScope(explicitScope,
                "永久封存魔法箭，换取火焰箭伤害永久提高100%。"))
            throw new AssertionError("Stage 3.8: candidate target substitution escaped the explicit scope guard");
        passed++;
        System.out.println("PASS Stage 3.8: AI candidate cannot silently substitute an explicitly named reward spell");

        if (!SpellNameResolver.changesExplicitSpellScope(explicitScope, "永久封存魔法箭。"))
            throw new AssertionError("Stage 3.8: candidate omission of one explicit spell target escaped the scope guard");
        passed++;
        System.out.println("PASS Stage 3.8: AI candidate cannot silently drop part of an explicit spell scope");

        String excludedSpellIntent = "不要火焰箭，给我一个不同法术的束缚创意";
        if (SpellNameResolver.changesExplicitSpellScope(excludedSpellIntent,
                "永久封存魔法箭，换取雷鸣长枪伤害永久提高100%。"))
            throw new AssertionError("Stage 3.8: AI proposal satisfying an explicit spell exclusion was rejected");
        passed++;
        System.out.println("PASS Stage 3.8: open-ended proposal can choose a different spell than an explicitly excluded target");

        if (!SpellNameResolver.changesExplicitSpellScope(excludedSpellIntent,
                "永久封存火焰箭，换取雷鸣长枪伤害永久提高100%。"))
            throw new AssertionError("Stage 3.8: AI reintroduced an explicitly excluded spell");
        passed++;
        System.out.println("PASS Stage 3.8: AI cannot reintroduce a spell explicitly excluded by the current request");

        if (!SpellNameResolver.changesExplicitSpellScope("不要火焰箭，但也写了火焰箭伤害强化，换取一个收益",
                "永久封存火焰箭，换取雷鸣长枪伤害永久提高100%。"))
            throw new AssertionError("Stage 3.8: a negative mention must remain an exclusion even if the same ID also appears positively");
        passed++;
        System.out.println("PASS Stage 3.8: explicit exclusions take precedence over contradictory positive mentions");

        System.out.println("PASS all " + passed + " contract assertions");
    }
}
