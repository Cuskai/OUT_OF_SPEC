import cn.blockforge.outofspec.spellcraft.model.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class ComposableCastingModelHarness {
    private static int checks;

    public static void main(String[] args) {
        testTwelveSealsAndStableKeys();
        testImmutableSequencesAndPrefixes();
        testRegistryPrefixResolutionAndFreeze();
        testAmbiguousRecipesFailClosed();
        testAdditionalSequenceContextAndAmbiguity();
        testTypedEffectValidation();
        testSuccessfulServerPlanResolution();
        testPlanRejections();
        testServerBindingEffectScopeAndProvenance();
        testStableFingerprint();
        int stage26Assertions = checks;
        testInputSessionLifecycle();
        int stage27Assertions = checks - stage26Assertions;
        System.out.println("PASS all " + stage26Assertions + " Stage 2.6 model assertions");
        System.out.println("PASS all " + stage27Assertions + " Stage 2.7 input-session assertions");
        System.out.println("PASS all " + checks + " combined model/input assertions");
    }

    private static void testTwelveSealsAndStableKeys() {
        equal(12, BasicSeal.values().length, "exactly twelve base seals");
        Set<Character> keys = new HashSet<>();
        for (BasicSeal seal : BasicSeal.values()) {
            ok(keys.add(seal.suggestedDefaultKey()), "default key suggestions are unique: " + seal);
            equal(seal, BasicSeal.byId(seal.id()).orElseThrow(), "stable seal ID round-trip " + seal);
        }
        equal(BasicSeal.ZI, BasicSeal.byId(" ZI ").orElseThrow(), "seal IDs normalize case and surrounding spaces");
    }

    private static void testImmutableSequencesAndPrefixes() {
        List<BasicSeal> mutable = new ArrayList<>(List.of(BasicSeal.ZI, BasicSeal.CHOU));
        SealSequence shortSeq = new SealSequence(mutable);
        mutable.add(BasicSeal.YIN);
        equal(2, shortSeq.seals().size(), "sequence takes an immutable defensive copy");
        SealSequence longSeq = SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU, BasicSeal.YIN);
        ok(shortSeq.isStrictPrefixOf(longSeq), "short sequence is a strict prefix");
        ok(!longSeq.isPrefixOf(shortSeq), "long sequence cannot prefix a short sequence");
        equal("zi.chou.yin", longSeq.canonicalKey(), "canonical sequence excludes keybindings/localization");
        expect(IllegalArgumentException.class, () -> new SealSequence(List.of()), "empty sequence rejected");
        expect(IllegalArgumentException.class, () -> new SealSequence(java.util.Collections.nCopies(33, BasicSeal.ZI)), "oversize sequence rejected");
    }

    private static void testRegistryPrefixResolutionAndFreeze() {
        CastingRecipeRegistry registry = new CastingRecipeRegistry();
        registry.registerSpellRecipe(recipe("out_of_spec:recipe/fireball_short", "irons_spellbooks:fireball", SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU)));
        registry.registerSpellRecipe(recipe("out_of_spec:recipe/fireball_long", "irons_spellbooks:firebolt", SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU, BasicSeal.YIN)));
        registry.freeze(Set.of());
        SequenceMatch match = registry.matchBase(SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU));
        equal(SequenceMatch.Status.EXACT_AND_PREFIX, match.status(), "exact recipe plus longer-prefix ambiguity is represented explicitly");
        equal(List.of("out_of_spec:recipe/fireball_short"), match.exactIds(), "exact match IDs");
        equal(List.of("out_of_spec:recipe/fireball_long"), match.longerPrefixIds(), "longer prefix IDs");
        equal(SequenceMatch.Status.PREFIX_ONLY, registry.matchBase(SealSequence.of(BasicSeal.ZI)).status(), "prefix-only state");
        equal(SequenceMatch.Status.NONE, registry.matchBase(SealSequence.of(BasicSeal.HAI)).status(), "non-matching sequence");
        expect(IllegalStateException.class, () -> registry.registerSpellRecipe(recipe("out_of_spec:recipe/late", "irons_spellbooks:ice_spike", SealSequence.of(BasicSeal.HAI))), "frozen registry rejects later mutation");
    }

    private static void testAmbiguousRecipesFailClosed() {
        CastingRecipeRegistry registry = new CastingRecipeRegistry();
        registry.registerSpellRecipe(recipe("out_of_spec:recipe/a", "irons_spellbooks:fireball", SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU)));
        expect(IllegalArgumentException.class,
                () -> registry.registerSpellRecipe(recipe("out_of_spec:recipe/b", "irons_spellbooks:lightning_lance", SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU))),
                "same exact base sequence cannot randomly choose a spell");
        expect(IllegalArgumentException.class,
                () -> registry.registerSpellRecipe(recipe("out_of_spec:recipe/a", "irons_spellbooks:ice_spike", SealSequence.of(BasicSeal.HAI))),
                "original recipe remains registered after ambiguous add was rejected");
        registry.registerSpellRecipe(recipe("out_of_spec:recipe/other", "irons_spellbooks:ice_spike", SealSequence.of(BasicSeal.HAI)));
    }

    private static void testAdditionalSequenceContextAndAmbiguity() {
        String r1 = "out_of_spec:recipe/fireball";
        String r2 = "out_of_spec:recipe/lightning";
        CastingRecipeRegistry registry = new CastingRecipeRegistry();
        registry.registerSpellRecipe(recipe(r1, "irons_spellbooks:fireball", SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU)));
        registry.registerSpellRecipe(recipe(r2, "irons_spellbooks:lightning_lance", SealSequence.of(BasicSeal.WU, BasicSeal.WEI)));
        registry.registerAdditionalSeal(addition("out_of_spec:additional/area", SealSequence.of(BasicSeal.MAO), Set.of(r1), Set.of(), Set.of(), 1, List.of()));
        registry.registerAdditionalSeal(addition("out_of_spec:additional/track", SealSequence.of(BasicSeal.MAO), Set.of(r2), Set.of(), Set.of(), 1, List.of()));
        registry.freeze(Set.of());
        equal(List.of("out_of_spec:additional/area"), registry.matchAdditional(r1, SealSequence.of(BasicSeal.MAO)).exactIds(), "same sequence can mean different additions in different recipe contexts");
        equal(List.of("out_of_spec:additional/track"), registry.matchAdditional(r2, SealSequence.of(BasicSeal.MAO)).exactIds(), "context resolves additional sequence");

        CastingRecipeRegistry ambiguous = new CastingRecipeRegistry();
        ambiguous.registerSpellRecipe(recipe(r1, "irons_spellbooks:fireball", SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU)));
        ambiguous.registerAdditionalSeal(addition("out_of_spec:additional/a", SealSequence.of(BasicSeal.MAO), Set.of(r1), Set.of(), Set.of(), 1, List.of()));
        ambiguous.registerAdditionalSeal(addition("out_of_spec:additional/b", SealSequence.of(BasicSeal.MAO), Set.of(r1), Set.of(), Set.of(), 1, List.of()));
        expect(IllegalArgumentException.class, () -> ambiguous.freeze(Set.of()), "ambiguous additional sequence for same recipe rejected");

        CastingRecipeRegistry special = new CastingRecipeRegistry();
        special.registerSpellRecipe(recipe(r1, "irons_spellbooks:fireball", SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU)));
        special.registerAdditionalSeal(new AdditionalSealDefinition("out_of_spec:additional/special", SealSequence.of(BasicSeal.SI), 800,
                Set.of(r1), Set.of(), Set.of(), 1, AdditionalSealTier.SPECIAL, CompositionMode.SPECIAL_EXECUTOR,
                "out_of_spec:executor/ring_burst", List.of()));
        expect(IllegalArgumentException.class, () -> special.freeze(Set.of()), "special effect cannot freeze without a registered executor");
        special.freeze(Set.of("out_of_spec:executor/ring_burst"));
        ok(special.isFrozen(), "registry accepts special definition only when adapter declares its executor registered");

        CastingRecipeRegistry contradictory = new CastingRecipeRegistry();
        contradictory.registerSpellRecipe(recipe(r1, "irons_spellbooks:fireball", SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU)));
        contradictory.registerAdditionalSeal(addition("out_of_spec:additional/requires_b", SealSequence.of(BasicSeal.SI), Set.of(r1), Set.of("out_of_spec:additional/b_conflicts_a"), Set.of(), 1, List.of()));
        contradictory.registerAdditionalSeal(addition("out_of_spec:additional/b_conflicts_a", SealSequence.of(BasicSeal.WU), Set.of(r1), Set.of(), Set.of("out_of_spec:additional/requires_b"), 1, List.of()));
        expect(IllegalArgumentException.class, () -> contradictory.freeze(Set.of()), "registry rejects contradictory required-versus-conflicting composition rules");
    }

    private static void testTypedEffectValidation() {
        expect(IllegalArgumentException.class, () -> effect("out_of_spec:effect/bad", EffectSource.ADDITIONAL_SEAL,
                "out_of_spec:additional/area", "*", EffectParameter.DAMAGE, EffectOperation.ADD, EffectUnit.TICKS, 20),
                "invalid unit/operation/parameter tuple rejected");
        expect(IllegalArgumentException.class, () -> effect("out_of_spec:effect/nan", EffectSource.ADDITIONAL_SEAL,
                "out_of_spec:additional/area", "*", EffectParameter.DAMAGE, EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, Double.NaN),
                "NaN rejected");
        equal(0.0, effect("out_of_spec:effect/zero", EffectSource.BINDING_COST,
                "out_of_spec:contract/test", "*", EffectParameter.MANA_COST, EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 0).value(),
                "zero multiplier is representable for full suppression or zero cost");
        equal(0.0, effect("out_of_spec:effect/cast_root", EffectSource.BINDING_COST,
                "out_of_spec:contract/test", "*", EffectParameter.CAST_MOVE_SPEED, EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 0).value(),
                "cast-movement multiplier permits a real full-root cost");
        expect(IllegalArgumentException.class, () -> effect("out_of_spec:effect/negative", EffectSource.ADDITIONAL_SEAL,
                "out_of_spec:additional/area", "*", EffectParameter.DAMAGE, EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, -1),
                "negative multiplier rejected");
        expect(IllegalArgumentException.class, () -> new EffectContribution("not-namespaced", EffectSource.BINDING_REWARD,
                "out_of_spec:contract/test", "*", EffectParameter.DAMAGE, EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 2),
                "unstable contribution ID rejected");
    }

    private static void testSuccessfulServerPlanResolution() {
        String recipeId = "out_of_spec:recipe/fireball";
        String areaId = "out_of_spec:additional/area";
        String splitId = "out_of_spec:additional/split";
        String contractId = "out_of_spec:contract/test";
        CastingRecipeRegistry registry = new CastingRecipeRegistry();
        registry.registerSpellRecipe(recipe(recipeId, "irons_spellbooks:fireball", SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU)));
        registry.registerSpellRecipe(recipe("out_of_spec:recipe/lightning", "irons_spellbooks:lightning_lance", SealSequence.of(BasicSeal.WU, BasicSeal.WEI)));
        registry.registerAdditionalSeal(addition("out_of_spec:additional/lightning_only", SealSequence.of(BasicSeal.HAI), Set.of("out_of_spec:recipe/lightning"), Set.of(), Set.of(), 1, List.of()));
        registry.registerAdditionalSeal(addition(areaId, SealSequence.of(BasicSeal.MAO), Set.of(recipeId), Set.of(), Set.of(), 1,
                List.of(effect("out_of_spec:effect/area_radius", EffectSource.ADDITIONAL_SEAL, areaId, "*", EffectParameter.AREA_RADIUS, EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 1.5))));
        registry.registerAdditionalSeal(addition(splitId, SealSequence.of(BasicSeal.CHEN), Set.of(recipeId), Set.of(areaId), Set.of(), 1,
                List.of(effect("out_of_spec:effect/projectiles", EffectSource.ADDITIONAL_SEAL, splitId, "*", EffectParameter.PROJECTILE_COUNT, EffectOperation.ADD, EffectUnit.COUNT, 2))));
        registry.freeze(Set.of());

        UUID requestId = UUID.fromString("11111111-1111-1111-1111-111111111111");
        UUID casterId = UUID.fromString("22222222-2222-2222-2222-222222222222");
        CastPlanRequest request = new CastPlanRequest(requestId, recipeId, List.of(areaId, splitId));
        List<EffectContribution> bindingEffects = List.of(
                effect("out_of_spec:contract/test/reward_damage", EffectSource.BINDING_REWARD, contractId, "irons_spellbooks:fireball", EffectParameter.DAMAGE, EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 2.0),
                effect("out_of_spec:contract/test/cost_mana", EffectSource.BINDING_COST, contractId, "*", EffectParameter.MANA_COST, EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 1.25),
                effect("out_of_spec:contract/test/other_spell", EffectSource.BINDING_REWARD, contractId, "irons_spellbooks:lightning_lance", EffectParameter.DAMAGE, EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 50.0));
        PlanResolution result = new CastPlanResolver().resolve(request, registry, new ServerCastContext(casterId, new ServerBindingSnapshot(List.of(contractId), bindingEffects), 900));
        ok(result.accepted(), "valid plan accepted: " + result.message());
        ResolvedCastPlan plan = result.plan();
        equal("irons_spellbooks:fireball", plan.spellId(), "plan resolves real spell identity");
        equal(casterId, plan.casterId(), "caster identity is derived from trusted server context");
        equal(List.of(areaId, splitId), plan.selectedAdditionalSealIds(), "plan preserves selected additional-seal order for audit");
        equal(4, plan.effects().size(), "two additional effects plus applicable binding effects only");
        equal(0, plan.effects().get(0).occurrenceIndex(), "first selected addition occurrence index");
        equal(0, plan.effects().get(1).occurrenceIndex(), "first occurrence of a distinct additional seal");
        ok(plan.effects().stream().noneMatch(e -> "out_of_spec:contract/test/other_spell".equals(e.contribution().contributionId())), "unrelated spell-scoped binding effect not applied");
        equal(64, plan.fingerprint().length(), "plan fingerprint is SHA-256");
        equal(900L, plan.resolvedAtServerTick(), "server tick recorded for diagnostics");
    }

    private static void testPlanRejections() {
        String recipeId = "out_of_spec:recipe/fireball";
        String areaId = "out_of_spec:additional/area";
        String splitId = "out_of_spec:additional/split";
        String rootId = "out_of_spec:additional/root";
        String conflictId = "out_of_spec:additional/forbidden";
        CastingRecipeRegistry registry = new CastingRecipeRegistry();
        registry.registerSpellRecipe(recipe(recipeId, "irons_spellbooks:fireball", SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU)));
        registry.registerSpellRecipe(recipe("out_of_spec:recipe/lightning", "irons_spellbooks:lightning_lance", SealSequence.of(BasicSeal.WU, BasicSeal.WEI)));
        registry.registerAdditionalSeal(addition("out_of_spec:additional/lightning_only", SealSequence.of(BasicSeal.HAI), Set.of("out_of_spec:recipe/lightning"), Set.of(), Set.of(), 1, List.of()));
        registry.registerAdditionalSeal(addition(areaId, SealSequence.of(BasicSeal.MAO), Set.of(recipeId), Set.of(), Set.of(conflictId), 1, List.of()));
        registry.registerAdditionalSeal(addition(splitId, SealSequence.of(BasicSeal.CHEN), Set.of(recipeId), Set.of(areaId), Set.of(), 1, List.of()));
        registry.registerAdditionalSeal(addition(rootId, SealSequence.of(BasicSeal.SI), Set.of(recipeId), Set.of(), Set.of(), 1, List.of()));
        registry.registerAdditionalSeal(addition(conflictId, SealSequence.of(BasicSeal.WU), Set.of(recipeId), Set.of(), Set.of(), 1, List.of()));
        registry.freeze(Set.of());
        CastPlanResolver resolver = new CastPlanResolver();
        UUID req = UUID.randomUUID();
        UUID caster = UUID.randomUUID();
        equal(PlanResolution.RejectionCode.UNKNOWN_RECIPE,
                resolver.resolve(new CastPlanRequest(req, "out_of_spec:recipe/missing", List.of()), registry, new ServerCastContext(caster, new ServerBindingSnapshot(List.of(), List.of()), 0)).code(),
                "unknown recipe rejected");
        equal(PlanResolution.RejectionCode.UNKNOWN_ADDITIONAL_SEAL,
                resolver.resolve(new CastPlanRequest(req, recipeId, List.of("out_of_spec:additional/other")), registry, new ServerCastContext(caster, new ServerBindingSnapshot(List.of(), List.of()), 0)).code(),
                "unknown add-on ID is explicitly rejected");
        equal(PlanResolution.RejectionCode.INCOMPATIBLE_ADDITIONAL_SEAL,
                resolver.resolve(new CastPlanRequest(req, recipeId, List.of("out_of_spec:additional/lightning_only")), registry, new ServerCastContext(caster, new ServerBindingSnapshot(List.of(), List.of()), 0)).code(),
                "known add-on registered for another spell is rejected");
        equal(PlanResolution.RejectionCode.OCCURRENCE_LIMIT_EXCEEDED,
                resolver.resolve(new CastPlanRequest(req, recipeId, List.of(rootId, rootId)), registry, new ServerCastContext(caster, new ServerBindingSnapshot(List.of(), List.of()), 0)).code(),
                "duplicate addition cannot stack by default");
        equal(PlanResolution.RejectionCode.REQUIRED_ADDITIONAL_SEAL_MISSING,
                resolver.resolve(new CastPlanRequest(req, recipeId, List.of(splitId)), registry, new ServerCastContext(caster, new ServerBindingSnapshot(List.of(), List.of()), 0)).code(),
                "missing required addition rejected");
        equal(PlanResolution.RejectionCode.CONFLICTING_ADDITIONAL_SEALS,
                resolver.resolve(new CastPlanRequest(req, recipeId, List.of(areaId, conflictId)), registry, new ServerCastContext(caster, new ServerBindingSnapshot(List.of(), List.of()), 0)).code(),
                "incompatible additions rejected");
        expect(IllegalArgumentException.class,
                () -> new ServerCastContext(caster, new ServerBindingSnapshot(List.of(), List.of()), -1),
                "invalid server tick rejected by trusted context construction");
        ok(java.util.Arrays.stream(CastPlanRequest.class.getRecordComponents()).noneMatch(c -> {
            String field = c.getName().toLowerCase();
            return field.contains("binding") || field.contains("effect") || field.contains("caster");
        }), "untrusted cast request has no caster identity, active-contract or effect-value fields");
        expect(IllegalArgumentException.class, () -> new ServerBindingSnapshot(List.of("out_of_spec:contract/a", "out_of_spec:contract/a"), List.of()),
                "duplicate active contract IDs rejected in server-derived snapshot");

        CastingRecipeRegistry repeatable = new CastingRecipeRegistry();
        repeatable.registerSpellRecipe(recipe(recipeId, "irons_spellbooks:fireball", SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU)));
        String repeatId = "out_of_spec:additional/repeatable_projectile";
        repeatable.registerAdditionalSeal(addition(repeatId, SealSequence.of(BasicSeal.MAO), Set.of(recipeId), Set.of(), Set.of(), 2,
                List.of(effect("out_of_spec:effect/add_projectile", EffectSource.ADDITIONAL_SEAL, repeatId, "*", EffectParameter.PROJECTILE_COUNT, EffectOperation.ADD, EffectUnit.COUNT, 1))));
        repeatable.freeze(Set.of());
        PlanResolution repeated = resolver.resolve(new CastPlanRequest(req, recipeId, List.of(repeatId, repeatId)), repeatable,
                new ServerCastContext(caster, new ServerBindingSnapshot(List.of(), List.of()), 15));
        ok(repeated.accepted(), "explicitly repeatable additional seal can be selected up to its declared count");
        equal(2, repeated.plan().effects().size(), "each authorized occurrence has a separate effect application");
        equal(0, repeated.plan().effects().get(0).occurrenceIndex(), "first repeat occurrence index");
        equal(1, repeated.plan().effects().get(1).occurrenceIndex(), "second repeat occurrence index");
        ok(!repeated.plan().effects().get(0).applicationId().equals(repeated.plan().effects().get(1).applicationId()), "repeat applications get distinct idempotency keys");
    }

    private static void testServerBindingEffectScopeAndProvenance() {
        String recipeId = "out_of_spec:recipe/fireball";
        String contractId = "out_of_spec:contract/test";
        CastingRecipeRegistry registry = new CastingRecipeRegistry();
        registry.registerSpellRecipe(recipe(recipeId, "irons_spellbooks:fireball", SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU)));
        registry.freeze(Set.of());
        UUID requestId = UUID.randomUUID();
        UUID casterId = UUID.randomUUID();
        CastPlanRequest request = new CastPlanRequest(requestId, recipeId, List.of());
        CastPlanResolver resolver = new CastPlanResolver();
        EffectContribution inactiveOwnerEffect = effect("out_of_spec:effect/reward", EffectSource.BINDING_REWARD,
                "out_of_spec:contract/not_active", "*", EffectParameter.DAMAGE, EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 2);
        equal(PlanResolution.RejectionCode.INVALID_BINDING_EFFECT,
                resolver.resolve(request, registry, new ServerCastContext(casterId, new ServerBindingSnapshot(List.of(contractId), List.of(inactiveOwnerEffect)), 4)).code(),
                "effect from inactive contract rejected");
        EffectContribution forgedAdditionalSource = effect("out_of_spec:effect/forged", EffectSource.ADDITIONAL_SEAL,
                contractId, "*", EffectParameter.DAMAGE, EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 2);
        equal(PlanResolution.RejectionCode.INVALID_BINDING_EFFECT,
                resolver.resolve(request, registry, new ServerCastContext(casterId, new ServerBindingSnapshot(List.of(contractId), List.of(forgedAdditionalSource)), 4)).code(),
                "binding channel cannot carry an additional-seal source");
        EffectContribution binding = effect("out_of_spec:contract/test/reward", EffectSource.BINDING_REWARD,
                contractId, "*", EffectParameter.DAMAGE, EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 2);
        equal(PlanResolution.RejectionCode.DUPLICATE_BINDING_CONTRIBUTION,
                resolver.resolve(request, registry, new ServerCastContext(casterId, new ServerBindingSnapshot(List.of(contractId), List.of(binding, binding)), 4)).code(),
                "duplicate server-side binding contribution rejected");
        EffectContribution sameIdDifferentSource = effect("out_of_spec:contract/test/reward", EffectSource.BINDING_COST,
                contractId, "*", EffectParameter.MANA_COST, EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 1.2);
        equal(PlanResolution.RejectionCode.DUPLICATE_BINDING_CONTRIBUTION,
                resolver.resolve(request, registry, new ServerCastContext(casterId, new ServerBindingSnapshot(List.of(contractId), List.of(binding, sameIdDifferentSource)), 4)).code(),
                "same contract cannot reuse one contribution ID across cost and reward");
        equal(PlanResolution.RejectionCode.REGISTRY_NOT_FROZEN,
                resolver.resolve(request, new CastingRecipeRegistry(), new ServerCastContext(casterId, new ServerBindingSnapshot(List.of(), List.of()), 4)).code(),
                "unfrozen registry cannot resolve plans");
    }

    private static void testInputSessionLifecycle() {
        CastingRecipeRegistry registry = inputSessionRegistry();
        expect(IllegalArgumentException.class, () -> new SealInputSession(new CastingRecipeRegistry()),
                "input session requires a frozen registry");
        SealInputSession session = new SealInputSession(registry);
        equal(SealInputSession.Phase.IDLE, session.snapshot().phase(), "input session starts idle");
        equal(SealInputSession.Code.IGNORED_WRONG_PHASE, session.press(BasicSeal.ZI, 0).code(),
                "basic seal outside a session does not start a recipe");
        equal(SealInputSession.Code.REPEAT_KEYDOWN_IGNORED, session.press(BasicSeal.ZI, 1).code(),
                "repeated key-down while physically held is ignored");
        equal(SealInputSession.Code.KEY_RELEASED, session.release(BasicSeal.ZI, 2).code(),
                "physical release clears held-key state");
        equal(SealInputSession.Code.STARTED, session.start(3).code(), "explicit start enters base input");
        equal(SealInputSession.Code.INPUT_ACCEPTED, session.press(BasicSeal.ZI, 4).code(), "first base seal accepted");
        equal(SealInputSession.Code.REPEAT_KEYDOWN_IGNORED, session.press(BasicSeal.ZI, 5).code(),
                "holding a seal cannot record it twice");
        equal(1, session.snapshot().currentSequence().size(), "held-key repeat leaves one input token");
        session.release(BasicSeal.ZI, 6);
        session.press(BasicSeal.CHOU, 7);
        session.release(BasicSeal.CHOU, 8);
        equal(SequenceMatch.Status.EXACT_AND_PREFIX, session.snapshot().currentMatch().status(),
                "input session exposes exact-and-longer recipe ambiguity");
        equal(SealInputSession.Code.BASE_CONFIRMED, session.confirmBase(9).code(),
                "explicit confirmation chooses the exact shorter recipe");
        equal("out_of_spec:recipe/fireball", session.snapshot().selectedRecipeId(), "confirmed base recipe ID is stable");
        equal(SealInputSession.Phase.ADDITIONAL_INPUT, session.snapshot().phase(),
                "base confirmation enters optional additional-seal phase");

        session.press(BasicSeal.MAO, 10);
        session.release(BasicSeal.MAO, 11);
        equal(SequenceMatch.Status.EXACT_AND_PREFIX, session.snapshot().currentMatch().status(),
                "additional input also exposes exact-and-longer ambiguity");
        equal(SealInputSession.Code.ADDITION_CONFIRMED, session.confirmAdditional(12).code(),
                "explicit confirmation selects the exact additional seal");
        equal(List.of("out_of_spec:additional/area"), session.snapshot().selectedAdditionalSealIds(),
                "confirmed addition is retained in the draft plan");

        session.press(BasicSeal.SI, 13);
        session.release(BasicSeal.SI, 14);
        equal(SealInputSession.Code.ADDITION_CONFLICT, session.confirmAdditional(15).code(),
                "registered conflict prevents adding a second incompatible seal");
        equal(List.of("out_of_spec:additional/area"), session.snapshot().selectedAdditionalSealIds(),
                "conflict rejection preserves prior confirmed selection");
        session.press(BasicSeal.CHEN, 16);
        session.release(BasicSeal.CHEN, 17);
        equal(SealInputSession.Code.ADDITION_CONFIRMED, session.confirmAdditional(18).code(),
                "required addition can be selected after its prerequisite");
        SealInputSession.Result submission = session.submitCast(19);
        equal(SealInputSession.Code.CAST_REQUEST_READY, submission.code(), "confirmed draft creates selection-only request");
        equal(List.of("out_of_spec:additional/area", "out_of_spec:additional/split"),
                submission.castRequest().selectedAdditionalSealIds(), "request preserves addition order without client effects");
        equal(SealInputSession.Phase.VALIDATING, session.snapshot().phase(), "submit enters validation-pending state");
        equal(SealInputSession.Code.STALE_VALIDATION_IGNORED,
                session.onValidationResult(UUID.randomUUID(), true, false, 20).code(),
                "response for another request cannot approve this draft");
        equal(SealInputSession.Phase.VALIDATING, session.snapshot().phase(), "stale response does not change phase");
        equal(SealInputSession.Code.VALIDATION_ACCEPTED,
                session.onValidationResult(submission.castRequest().requestId(), true, false, 21).code(),
                "only matching server response can approve the request");
        equal(SealInputSession.Code.TOO_LATE_TO_CANCEL, session.cancel(22).code(),
                "local cancel cannot undo a submitted server request or active cast");
        equal(SealInputSession.Code.STALE_CAST_END_IGNORED,
                session.onCastEnded(UUID.randomUUID(), 23).code(), "cast end for another request is ignored");
        equal(SealInputSession.Code.CAST_FINISHED,
                session.onCastEnded(submission.castRequest().requestId(), 24).code(), "matching cast completion clears transient state");
        equal(SealInputSession.Phase.IDLE, session.snapshot().phase(), "completed cast returns session to idle");

        SealInputSession backspace = new SealInputSession(registry);
        backspace.start(100);
        equal(SealInputSession.Code.NO_TIMEOUT, backspace.tick(100).code(), "idle input timer returns a non-error no-timeout result");
        backspace.press(BasicSeal.ZI, 101); backspace.release(BasicSeal.ZI, 102);
        backspace.press(BasicSeal.CHOU, 103); backspace.release(BasicSeal.CHOU, 104);
        equal(SealInputSession.Code.BACKSPACE_APPLIED, backspace.backspace(105).code(), "backspace removes last unconfirmed seal");
        equal(List.of(BasicSeal.ZI), backspace.snapshot().currentSequence(), "backspace preserves remaining prefix");
        equal(SealInputSession.Code.TIMED_OUT, backspace.tick(902).code(), "default 800ms timeout clears unconfirmed sequence");
        equal(List.of(), backspace.snapshot().currentSequence(), "timeout clears input buffer only");
        equal(SealInputSession.Phase.BASE_INPUT, backspace.snapshot().phase(), "timeout does not auto-cast or end session");

        SealInputSession stalePrefix = new SealInputSession(registry);
        stalePrefix.start(1000);
        stalePrefix.press(BasicSeal.ZI, 1001); stalePrefix.release(BasicSeal.ZI, 1002);
        equal(SealInputSession.Code.TIMED_OUT, stalePrefix.tick(1802).code(), "prefix expires strictly after the configured interval");
        equal(SealInputSession.Code.UNKNOWN_SEQUENCE, stalePrefix.press(BasicSeal.CHOU, 1803).code(),
                "post-timeout seal cannot combine with the expired prefix");

        SealInputSession required = new SealInputSession(registry);
        required.start(2000);
        required.press(BasicSeal.ZI, 2001); required.release(BasicSeal.ZI, 2002);
        required.press(BasicSeal.CHOU, 2003); required.release(BasicSeal.CHOU, 2004);
        required.confirmBase(2005);
        required.press(BasicSeal.CHEN, 2006); required.release(BasicSeal.CHEN, 2007);
        required.confirmAdditional(2008);
        equal(SealInputSession.Code.REQUIRED_ADDITION_MISSING, required.submitCast(2009).code(),
                "draft cannot submit while an addition prerequisite is absent");
        equal(SealInputSession.Phase.ADDITIONAL_INPUT, required.snapshot().phase(),
                "missing prerequisite keeps the draft editable");
        required.press(BasicSeal.MAO, 2010); required.release(BasicSeal.MAO, 2011);
        required.confirmAdditional(2012);
        SealInputSession.Result retry = required.submitCast(2013);
        equal(SealInputSession.Code.CAST_REQUEST_READY, retry.code(), "draft submits after required addition is supplied");
        equal(SealInputSession.Code.VALIDATION_REJECTED_RECOVERABLE,
                required.onValidationResult(retry.castRequest().requestId(), false, true, 2014).code(),
                "recoverable server rejection returns to edit phase");
        equal(List.of("out_of_spec:additional/split", "out_of_spec:additional/area"),
                required.snapshot().selectedAdditionalSealIds(), "recoverable rejection retains confirmed selections");
        equal(SealInputSession.Code.BACKSPACE_APPLIED, required.backspace(2015).code(),
                "backspace can remove the last confirmed addition when sequence buffer is empty");
        equal(SealInputSession.Code.BACKSPACE_APPLIED, required.backspace(2016).code(),
                "backspace can then remove the prior selected addition");
        equal(SealInputSession.Code.CANCELED, required.cancel(2017).code(), "unsubmitted corrected draft can be canceled");
        equal(SealInputSession.Phase.IDLE, required.snapshot().phase(), "cancel clears the unsubmitted draft");

        SealInputSession terminal = new SealInputSession(registry);
        terminal.start(3000);
        terminal.press(BasicSeal.ZI, 3001); terminal.release(BasicSeal.ZI, 3002);
        terminal.press(BasicSeal.CHOU, 3003); terminal.release(BasicSeal.CHOU, 3004);
        terminal.confirmBase(3005);
        SealInputSession.Result terminalRequest = terminal.submitCast(3006);
        equal(SealInputSession.Code.VALIDATION_REJECTED_TERMINAL,
                terminal.onValidationResult(terminalRequest.castRequest().requestId(), false, false, 3007).code(),
                "terminal server rejection clears the input session");
        equal(SealInputSession.Phase.IDLE, terminal.snapshot().phase(), "terminal rejection returns idle");

        SealInputSession cancel = new SealInputSession(registry);
        cancel.start(4000);
        cancel.press(BasicSeal.ZI, 4001);
        equal(SealInputSession.Code.CANCELED, cancel.cancel(4002).code(), "cancel clears pre-submission input");
        equal(0, cancel.snapshot().currentSequence().size(), "cancel leaves no partial input sequence");
        expect(IllegalArgumentException.class, () -> cancel.tick(3999), "monotonic clock regression is rejected");

        CastingRecipeRegistry maximum = new CastingRecipeRegistry();
        List<BasicSeal> maxSequence = java.util.Collections.nCopies(SealSequence.MAX_LENGTH, BasicSeal.ZI);
        maximum.registerSpellRecipe(recipe("out_of_spec:recipe/max_sequence", "irons_spellbooks:fireball", new SealSequence(maxSequence)));
        maximum.freeze(Set.of());
        SealInputSession overflow = new SealInputSession(maximum);
        overflow.start(5000);
        long at = 5001;
        for (int i = 0; i < SealSequence.MAX_LENGTH; i++) {
            overflow.press(BasicSeal.ZI, at++);
            overflow.release(BasicSeal.ZI, at++);
        }
        equal(SealSequence.MAX_LENGTH, overflow.snapshot().currentSequence().size(), "maximum registered input length is accepted");
        equal(SealInputSession.Code.SEQUENCE_TOO_LONG, overflow.press(BasicSeal.ZI, at).code(),
                "input beyond the sequence capacity is cleared safely");
        equal(0, overflow.snapshot().currentSequence().size(), "overflow does not retain a truncated candidate");
    }

    private static CastingRecipeRegistry inputSessionRegistry() {
        String fireball = "out_of_spec:recipe/fireball";
        String longFireball = "out_of_spec:recipe/fireball_long";
        String lightning = "out_of_spec:recipe/lightning";
        String area = "out_of_spec:additional/area";
        CastingRecipeRegistry registry = new CastingRecipeRegistry();
        registry.registerSpellRecipe(recipe(fireball, "irons_spellbooks:fireball", SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU)));
        registry.registerSpellRecipe(recipe(longFireball, "irons_spellbooks:firebolt", SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU, BasicSeal.YIN)));
        registry.registerSpellRecipe(recipe(lightning, "irons_spellbooks:lightning_lance", SealSequence.of(BasicSeal.WU, BasicSeal.WEI)));
        registry.registerAdditionalSeal(addition(area, SealSequence.of(BasicSeal.MAO), Set.of(fireball), Set.of(), Set.of("out_of_spec:additional/forbidden"), 1, List.of()));
        registry.registerAdditionalSeal(addition("out_of_spec:additional/area_combo", SealSequence.of(BasicSeal.MAO, BasicSeal.CHEN), Set.of(fireball), Set.of(), Set.of(), 1, List.of()));
        registry.registerAdditionalSeal(addition("out_of_spec:additional/split", SealSequence.of(BasicSeal.CHEN), Set.of(fireball), Set.of(area), Set.of(), 1, List.of()));
        registry.registerAdditionalSeal(addition("out_of_spec:additional/forbidden", SealSequence.of(BasicSeal.SI), Set.of(fireball), Set.of(), Set.of(area), 1, List.of()));
        registry.registerAdditionalSeal(addition("out_of_spec:additional/lightning_track", SealSequence.of(BasicSeal.HAI), Set.of(lightning), Set.of(), Set.of(), 1, List.of()));
        registry.freeze(Set.of());
        return registry;
    }

    private static void testStableFingerprint() {
        String recipeId = "out_of_spec:recipe/fireball";
        CastingRecipeRegistry registry = new CastingRecipeRegistry();
        registry.registerSpellRecipe(recipe(recipeId, "irons_spellbooks:fireball", SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU)));
        registry.registerAdditionalSeal(addition("out_of_spec:additional/area", SealSequence.of(BasicSeal.MAO), Set.of(recipeId), Set.of(), Set.of(), 1,
                List.of(effect("out_of_spec:effect/area", EffectSource.ADDITIONAL_SEAL, "out_of_spec:additional/area", "*", EffectParameter.AREA_RADIUS, EffectOperation.MULTIPLY, EffectUnit.MULTIPLIER, 1.2))));
        registry.freeze(Set.of());
        UUID requestId = UUID.fromString("33333333-3333-3333-3333-333333333333");
        UUID casterId = UUID.fromString("44444444-4444-4444-4444-444444444444");
        CastPlanRequest request = new CastPlanRequest(requestId, recipeId, List.of("out_of_spec:additional/area"));
        CastPlanResolver resolver = new CastPlanResolver();
        ResolvedCastPlan a = resolver.resolve(request, registry, new ServerCastContext(casterId, new ServerBindingSnapshot(List.of(), List.of()), 100)).plan();
        ResolvedCastPlan b = resolver.resolve(request, registry, new ServerCastContext(casterId, new ServerBindingSnapshot(List.of(), List.of()), 101)).plan();
        equal(a.fingerprint(), b.fingerprint(), "fingerprint excludes server tick but includes normalized plan identity");
        ResolvedCastPlan tampered = new ResolvedCastPlan(a.modelVersion(), a.requestId(), a.casterId(), a.recipeId(), a.spellId(),
                a.selectedAdditionalSealIds(), a.activeBindingContractIds(), a.effects(), a.resolvedAtServerTick(), a.fingerprint());
        equal(a.fingerprint(), tampered.fingerprint(), "canonical plan reconstruction verifies fingerprint");
        expect(IllegalArgumentException.class, () -> new ResolvedCastPlan(a.modelVersion(), a.requestId(), a.casterId(), a.recipeId(), a.spellId(),
                a.selectedAdditionalSealIds(), a.activeBindingContractIds(), List.of(), a.resolvedAtServerTick(), a.fingerprint()),
                "fingerprint mismatch detects changed plan contents");
    }

    private static SpellRecipe recipe(String id, String spellId, SealSequence sequence) {
        return new SpellRecipe(id, spellId, sequence, 800, CastMobilityPolicy.FREE);
    }

    private static AdditionalSealDefinition addition(String id, SealSequence sequence, Set<String> compatible,
                                                       Set<String> required, Set<String> incompatible, int max,
                                                       List<EffectContribution> effects) {
        return new AdditionalSealDefinition(id, sequence, 800, compatible, required, incompatible, max,
                AdditionalSealTier.BASIC, CompositionMode.INDEPENDENT_EFFECTS, "", effects);
    }

    private static EffectContribution effect(String contributionId, EffectSource source, String owner,
                                               String target, EffectParameter parameter, EffectOperation operation,
                                               EffectUnit unit, double value) {
        return new EffectContribution(contributionId, source, owner, target, parameter, operation, unit, value);
    }

    private static void ok(boolean condition, String label) {
        checks++;
        if (!condition) throw new AssertionError("FAIL " + label);
        System.out.println("PASS " + label);
    }
    private static void equal(Object expected, Object actual, String label) {
        ok(java.util.Objects.equals(expected, actual), label + " (expected=" + expected + ", actual=" + actual + ")");
    }
    private static void expect(Class<? extends Throwable> type, Runnable action, String label) {
        checks++;
        try { action.run(); }
        catch (Throwable t) {
            if (type.isInstance(t)) { System.out.println("PASS " + label); return; }
            throw new AssertionError("FAIL " + label + " got " + t, t);
        }
        throw new AssertionError("FAIL " + label + " did not throw " + type.getSimpleName());
    }
}
