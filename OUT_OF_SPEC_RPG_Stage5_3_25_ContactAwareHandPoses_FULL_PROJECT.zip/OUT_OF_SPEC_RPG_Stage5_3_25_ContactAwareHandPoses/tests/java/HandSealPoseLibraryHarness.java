import cn.blockforge.outofspec.binding.client.handpose.HandSealPoseLibrary;
import cn.blockforge.outofspec.binding.client.handpose.HandSealPoseLibrary.ContactConstraint;
import cn.blockforge.outofspec.binding.client.handpose.HandSealPoseLibrary.DetailStatus;
import cn.blockforge.outofspec.binding.client.handpose.HandSealPoseLibrary.DigitPose;
import cn.blockforge.outofspec.binding.client.handpose.HandSealPoseLibrary.Element;
import cn.blockforge.outofspec.binding.client.handpose.HandSealPoseLibrary.PoseProfile;
import cn.blockforge.outofspec.binding.client.handpose.HandSealPoseLibrary.Relation;
import cn.blockforge.outofspec.binding.client.handpose.HandSealPoseLibrary.Side;
import cn.blockforge.outofspec.spellcraft.model.BasicSeal;

import java.util.HashSet;
import java.util.Set;

/** Dependency-free regression checks for the twelve hand-pose profiles. */
public final class HandSealPoseLibraryHarness {
    private static int checks;

    public static void main(String[] args) {
        var profiles = HandSealPoseLibrary.all();
        check(profiles.size() == 12, "exactly twelve hand-seal profiles registered");
        check(profiles.keySet().containsAll(Set.of(BasicSeal.values())), "all BasicSeal enum values covered");
        check(new HashSet<>(profiles.values()).size() == 12, "all twelve profiles are distinct");

        for (BasicSeal seal : BasicSeal.values()) {
            PoseProfile profile = HandSealPoseLibrary.get(seal);
            check(profile.seal() == seal, "profile key matches enum " + seal);
            check(profile.left() != null && profile.right() != null, "bilateral pose exists for " + seal);
            check(!profile.calibrationNote().isBlank(), "calibration note exists for " + seal);
            for (Side side : Side.values()) {
                for (Element digit : new Element[]{Element.THUMB, Element.INDEX, Element.MIDDLE, Element.RING, Element.PINKY}) {
                    DigitPose pose = profile.hand(side).digit(digit);
                    check(pose != null, "digit pose exists " + seal + "/" + side + "/" + digit);
                    check(angleSafe(pose.baseFlexionDeg()) && angleSafe(pose.middleFlexionDeg())
                                    && angleSafe(pose.tipFlexionDeg()) && angleSafe(pose.spreadDeg())
                                    && angleSafe(pose.yawDeg()),
                            "finite and bounded digit angles " + seal + "/" + side + "/" + digit);
                    check(Math.abs(pose.offsetX()) <= 1.0f && Math.abs(pose.offsetY()) <= 1.0f
                                    && Math.abs(pose.offsetZ()) <= 1.0f,
                            "digit offset remains local " + seal + "/" + side + "/" + digit);
                }
            }
            check(Math.abs(profile.left().offsetX()) <= 0.75f && Math.abs(profile.right().offsetX()) <= 0.75f,
                    "hand offsets stay within wrist-scale envelope " + seal);
            for (ContactConstraint c : profile.contacts()) {
                check(c.firstSide() != null && c.secondSide() != null && c.firstElement() != null
                                && c.secondElement() != null && c.firstPoint() != null && c.secondPoint() != null,
                        "contact constraint is complete " + seal);
                if (c.relation() == Relation.CROSSES) {
                    check(c.status() == DetailStatus.NEEDS_REFERENCE || c.foregroundSide() != null,
                            "no unspecified crossing order is fabricated " + seal);
                }
            }
        }

        PoseProfile rat = HandSealPoseLibrary.get(BasicSeal.ZI);
        check(rat.left().index().baseFlexionDeg() < 5 && rat.left().middle().baseFlexionDeg() < 5,
                "子 keeps left index/middle upright");
        check(rat.left().ring().baseFlexionDeg() > 45 && rat.left().pinky().baseFlexionDeg() > 45,
                "子 folds left ring/pinky");

        PoseProfile hare = HandSealPoseLibrary.get(BasicSeal.MAO);
        check(hare.right().pinky().baseFlexionDeg() < 10 && Math.abs(hare.right().pinky().offsetX()) > 0.3f,
                "卯 has a separately extended/positioned right pinky");
        PoseProfile monkey = HandSealPoseLibrary.get(BasicSeal.SHEN);
        check(monkey.right().pinky().baseFlexionDeg() < 10 && Math.abs(monkey.right().pinky().offsetX()) > 0.3f,
                "申 has a separately extended/positioned right pinky");
        check(Math.abs(hare.left().wristYawDeg() - monkey.left().wristYawDeg()) > 5,
                "卯 and 申 do not share one wrist pose");

        PoseProfile horse = HandSealPoseLibrary.get(BasicSeal.WU);
        check(horse.left().index().tipFlexionDeg() == 0 && horse.right().index().tipFlexionDeg() == 0,
                "午 uses straight index fingertips");
        check(horse.contacts().stream().anyMatch(c -> c.relation() == Relation.TOUCH
                        && c.firstElement() == Element.INDEX && c.secondElement() == Element.INDEX),
                "午 encodes index-tip contact as explicit data");

        PoseProfile dog = HandSealPoseLibrary.get(BasicSeal.XU);
        PoseProfile boar = HandSealPoseLibrary.get(BasicSeal.HAI);
        check(dog.right().index().baseFlexionDeg() > 60, "戌 right hand uses a fist-like index curl");
        check(boar.right().index().baseFlexionDeg() < dog.right().index().baseFlexionDeg(),
                "亥 half-fist differs from 戌 full fist");

        check(HandSealPoseLibrary.get(BasicSeal.YOU).contacts().stream().anyMatch(c ->
                        c.firstElement() == Element.THUMB && c.secondElement() == Element.THUMB
                                && c.firstPoint().name().equals("TIP") && c.secondPoint().name().equals("TIP")),
                "酉 uses thumb-tip anchor relation");
        System.out.println("PASS all " + checks + " hand-pose library assertions");
    }

    private static boolean angleSafe(float value) {
        return Float.isFinite(value) && Math.abs(value) <= 180.0f;
    }

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError("FAIL " + description);
    }
}
