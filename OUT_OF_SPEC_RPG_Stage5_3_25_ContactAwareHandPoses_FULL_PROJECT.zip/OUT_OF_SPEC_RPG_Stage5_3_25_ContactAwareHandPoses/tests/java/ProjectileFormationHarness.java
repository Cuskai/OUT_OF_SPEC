import cn.blockforge.outofspec.spellcraft.model.ProjectileFormation;
import java.util.List;

public final class ProjectileFormationHarness {
    private static int checks;
    public static void main(String[] args) {
        List<ProjectileFormation.Slot> two = ProjectileFormation.distribute(2);
        eq(2, two.size(), "two-shot multi release contains two slots");
        close(-0.36, two.get(0).lateralOffsetBlocks(), "two-shot left offset");
        close(0.36, two.get(1).lateralOffsetBlocks(), "two-shot right offset");
        close(0.0, two.get(0).lateralOffsetBlocks() + two.get(1).lateralOffsetBlocks(), "two-shot offsets are symmetric");
        if (Math.abs(two.get(1).lateralOffsetBlocks() - two.get(0).lateralOffsetBlocks()) < 0.70)
            throw new AssertionError("two-shot gap should be visually distinct from a single projectile");
        checks++;
        System.out.println("PASS bilateral launch positions have visible separation");
        close(-5.0, two.get(0).yawOffsetDegrees(), "left shot diverges left visibly");
        close(5.0, two.get(1).yawOffsetDegrees(), "right shot diverges right visibly");

        List<ProjectileFormation.Slot> three = ProjectileFormation.distribute(3);
        eq(3, three.size(), "triune release contains three slots");
        close(-0.72, three.get(0).lateralOffsetBlocks(), "three-shot left offset");
        close(0.0, three.get(1).lateralOffsetBlocks(), "three-shot center offset");
        close(0.72, three.get(2).lateralOffsetBlocks(), "three-shot right offset");
        close(0.0, three.get(0).lateralOffsetBlocks() + three.get(2).lateralOffsetBlocks(), "three-shot offsets are symmetric");
        close(-10.0, three.get(0).yawOffsetDegrees(), "three-shot left divergence visibly");
        close(0.0, three.get(1).yawOffsetDegrees(), "three-shot center remains straight");
        close(10.0, three.get(2).yawOffsetDegrees(), "three-shot right divergence visibly");
        close(0.0, ProjectileFormation.distribute(1).get(0).lateralOffsetBlocks(), "one native projectile is not offset");
        eq(0, ProjectileFormation.distribute(0).size(), "zero projectiles yield no formation slots");
        try {
            ProjectileFormation.distribute(ProjectileFormation.MAX_SUPPORTED_PROJECTILES + 1);
            throw new AssertionError("oversized projectile spread should be rejected");
        } catch (IllegalArgumentException expected) { checks++; System.out.println("PASS oversized formation fails closed"); }
        System.out.println("PASS all " + checks + " pure-Java projectile formation assertions");
    }
    private static void eq(int expected, int actual, String label) {
        checks++;
        if (expected != actual) throw new AssertionError(label + " expected=" + expected + " actual=" + actual);
        System.out.println("PASS " + label + " (expected=" + expected + ", actual=" + actual + ")");
    }
    private static void close(double expected, double actual, String label) {
        checks++;
        if (Math.abs(expected - actual) > 1.0E-7) throw new AssertionError(label + " expected=" + expected + " actual=" + actual);
        System.out.println("PASS " + label + " (expected=" + expected + ", actual=" + actual + ")");
    }
}
