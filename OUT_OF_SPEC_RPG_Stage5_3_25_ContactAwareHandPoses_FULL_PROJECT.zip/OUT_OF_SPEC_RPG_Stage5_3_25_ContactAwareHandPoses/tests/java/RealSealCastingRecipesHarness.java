import cn.blockforge.outofspec.spellcraft.model.AdditionalSealDefinition;
import cn.blockforge.outofspec.spellcraft.model.BasicSeal;
import cn.blockforge.outofspec.spellcraft.model.CastPlanRequest;
import cn.blockforge.outofspec.spellcraft.model.CastPlanResolver;
import cn.blockforge.outofspec.spellcraft.model.CastingRecipeRegistry;
import cn.blockforge.outofspec.spellcraft.model.EffectContribution;
import cn.blockforge.outofspec.spellcraft.model.EffectParameter;
import cn.blockforge.outofspec.spellcraft.model.EffectSource;
import cn.blockforge.outofspec.spellcraft.model.PlanResolution;
import cn.blockforge.outofspec.spellcraft.model.RealSealCastingRecipes;
import cn.blockforge.outofspec.spellcraft.model.SealSequence;
import cn.blockforge.outofspec.spellcraft.model.ServerBindingSnapshot;
import cn.blockforge.outofspec.spellcraft.model.ServerCastContext;
import cn.blockforge.outofspec.spellcraft.model.SequenceMatch;
import cn.blockforge.outofspec.spellcraft.model.ResolvedCastPlan;

import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class RealSealCastingRecipesHarness {
    private static int assertions;

    public static void main(String[] args) {
        int registeredSpells = TestSpellRegistryFixtures.populate(120);
        cn.blockforge.outofspec.spellcraft.growth.SpellGrowthCatalog.refreshFromRegistry();
        RealSealCastingRecipes.refresh();
        CastingRecipeRegistry registry = RealSealCastingRecipes.registry();
        check(registry.isFrozen(), "real-casting registry is frozen");
        eq(registeredSpells, registry.spellRecipes().size(), "every native and add-on registry spell has a real casting recipe");
        for (var profile : cn.blockforge.outofspec.spellcraft.growth.SpellGrowthCatalog.profiles()) {
            var recipe = registry.recipe(RealSealCastingRecipes.recipeIdForSpell(profile.spellId()));
            if (recipe == null) throw new AssertionError("recipe missing for registered spell " + profile.spellId());
            if (!profile.spellId().equals(recipe.spellId())) throw new AssertionError("wrong spell ID for recipe " + profile.spellId());
            int sequenceLength = recipe.sequence().seals().size();
            if (sequenceLength < 2 || sequenceLength > 4) throw new AssertionError("invalid sequence length for " + profile.spellId());
            if (!registry.matchBase(recipe.sequence()).exactIds().contains(recipe.recipeId()))
                throw new AssertionError("input sequence cannot resolve to recipe for " + profile.spellId());
            assertions += 4;
        }
        eq(6, registry.additionalSeals().size(), "six additional seals are registered with concrete execution paths");
        eq("irons_spellbooks:magic_arrow", RealSealCastingRecipes.spellId(RealSealCastingRecipes.MAGIC_ARROW), "Magic Arrow registry ID");
        eq("irons_spellbooks:firebolt", RealSealCastingRecipes.spellId(RealSealCastingRecipes.FIREBOLT), "Firebolt registry ID");
        eq("irons_spellbooks:lightning_lance", RealSealCastingRecipes.spellId(RealSealCastingRecipes.LIGHTNING_LANCE), "Lightning Lance registry ID");
        eq("irons_spellbooks:fireball", RealSealCastingRecipes.spellId(RealSealCastingRecipes.FIREBALL), "Fireball registry ID");

        SequenceMatch zx = registry.matchBase(SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU));
        eq(List.of(RealSealCastingRecipes.MAGIC_ARROW), zx.exactIds(), "ZX exact-match is Magic Arrow");
        eq(List.of(RealSealCastingRecipes.FIREBOLT), zx.longerPrefixIds(), "ZX offers Firebolt as longer recipe");
        eq(List.of(RealSealCastingRecipes.FIREBOLT), registry.matchBase(SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU, BasicSeal.YIN)).exactIds(), "ZXC exact-match is Firebolt");
        eq(List.of(RealSealCastingRecipes.LIGHTNING_LANCE), registry.matchBase(SealSequence.of(BasicSeal.YIN, BasicSeal.MAO, BasicSeal.CHEN)).exactIds(), "CVB exact-match is Lightning Lance");
        eq(List.of(RealSealCastingRecipes.FIREBALL), registry.matchBase(SealSequence.of(BasicSeal.CHOU, BasicSeal.SI, BasicSeal.HAI)).exactIds(), "XNY exact-match is Fireball");

        SequenceMatch f = registry.matchAdditional(RealSealCastingRecipes.MAGIC_ARROW, SealSequence.of(BasicSeal.WU));
        eq(List.of(RealSealCastingRecipes.POWER_FOCUS), f.exactIds(), "F exact-match is normal power focus");
        eq(List.of(RealSealCastingRecipes.POWER_FOCUS_STRONG), f.longerPrefixIds(), "F offers FG as advanced power focus");
        eq(List.of(RealSealCastingRecipes.POWER_FOCUS_STRONG), registry.matchAdditional(RealSealCastingRecipes.FIREBALL,
                SealSequence.of(BasicSeal.WU, BasicSeal.WEI)).exactIds(), "FG exact-match is advanced power focus");

        AdditionalSealDefinition normal = registry.additionalSeal(RealSealCastingRecipes.POWER_FOCUS);
        AdditionalSealDefinition strong = registry.additionalSeal(RealSealCastingRecipes.POWER_FOCUS_STRONG);
        check(normal.incompatibleAdditionalSealIds().contains(strong.id()), "normal and advanced focus conflict");
        check(strong.incompatibleAdditionalSealIds().contains(normal.id()), "advanced and normal focus conflict symmetrically");
        eq(1, normal.maxOccurrencesPerCast(), "normal focus cannot repeat");
        eq(1, strong.maxOccurrencesPerCast(), "advanced focus cannot repeat");
        eq(EffectSource.ADDITIONAL_SEAL, normal.effects().get(0).source(), "normal focus effect source is additional seal");
        eq(EffectParameter.SPELL_POWER, normal.effects().get(0).parameter(), "normal focus only modifies spell-power value");
        eq(1.20, normal.effects().get(0).value(), "normal focus multiplier");
        eq(1.35, strong.effects().get(0).value(), "advanced focus multiplier");
        eq("irons_spellbooks:magic_arrow", registry.recipe(RealSealCastingRecipes.MAGIC_ARROW).spellId(), "recipe points to actual registered spell, not a debug ID");

        CastPlanResolver resolver = new CastPlanResolver();
        UUID caster = UUID.fromString("12345678-1234-1234-1234-123456789abc");
        ServerCastContext context = new ServerCastContext(caster, new ServerBindingSnapshot(List.of(), List.of()), 1000L);
        PlanResolution accepted = resolver.resolve(new CastPlanRequest(UUID.randomUUID(), RealSealCastingRecipes.MAGIC_ARROW,
                List.of(RealSealCastingRecipes.POWER_FOCUS)), registry, context);
        check(accepted.accepted(), "server resolver accepts registered real recipe and executable focus");
        ResolvedCastPlan plan = accepted.plan();
        eq("irons_spellbooks:magic_arrow", plan.spellId(), "resolved plan keeps real spell ID");
        eq(1, plan.effects().size(), "resolved plan has one selected focus contribution");
        eq(EffectSource.ADDITIONAL_SEAL, plan.effects().get(0).contribution().source(), "resolved effect source retained");
        eq(1.20, plan.effects().get(0).contribution().value(), "resolved multiplier cannot be supplied by client");

        PlanResolution strongAccepted = resolver.resolve(new CastPlanRequest(UUID.randomUUID(), RealSealCastingRecipes.FIREBALL,
                List.of(RealSealCastingRecipes.POWER_FOCUS_STRONG)), registry, context);
        check(strongAccepted.accepted(), "advanced focus can be used with registered Fireball recipe");
        PlanResolution conflict = resolver.resolve(new CastPlanRequest(UUID.randomUUID(), RealSealCastingRecipes.FIREBALL,
                List.of(RealSealCastingRecipes.POWER_FOCUS, RealSealCastingRecipes.POWER_FOCUS_STRONG)), registry, context);
        check(!conflict.accepted(), "normal and advanced focus cannot stack");
        PlanResolution unknown = resolver.resolve(new CastPlanRequest(UUID.randomUUID(), "out_of_spec_binding:recipe_not_real",
                List.of()), registry, context);
        check(!unknown.accepted(), "unknown recipes cannot be cast");
        PlanResolution unsupported = resolver.resolve(new CastPlanRequest(UUID.randomUUID(), RealSealCastingRecipes.MAGIC_ARROW,
                List.of("out_of_spec_binding:range_expansion_not_registered")), registry, context);
        check(!unsupported.accepted(), "unregistered additions cannot enter a real cast plan");
        check(!RealSealCastingRecipes.additionPreview(RealSealCastingRecipes.POWER_FOCUS).contains("damage ×"),
                "preview describes spell-power calculation instead of claiming direct damage multiplier");

        AdditionalSealDefinition quick = registry.additionalSeal(RealSealCastingRecipes.QUICK_RELEASE);
        AdditionalSealDefinition multi = registry.additionalSeal(RealSealCastingRecipes.MULTI_RELEASE);
        AdditionalSealDefinition triune = registry.additionalSeal(RealSealCastingRecipes.TRIUNE_RELEASE);
        AdditionalSealDefinition expansion = registry.additionalSeal(RealSealCastingRecipes.FIREBALL_EXPANSION);
        check(quick.effects().stream().anyMatch(e -> e.parameter() == EffectParameter.CAST_TIME_TICKS && e.value() == 0.50),
                "quick release carries a real 50% effective cast-time reduction");
        check(multi.effects().stream().anyMatch(e -> e.parameter() == EffectParameter.PROJECTILE_COUNT && e.value() == 1),
                "multi-release carries one extra projectile");
        check(multi.effects().stream().anyMatch(e -> e.parameter() == EffectParameter.MANA_COST && e.value() == 1.40),
                "multi-release includes a mana-cost balancing modifier");
        check(triune.effects().stream().anyMatch(e -> e.parameter() == EffectParameter.PROJECTILE_COUNT && e.value() == 2),
                "triune release carries two extra projectiles");
        check(triune.incompatibleAdditionalSealIds().contains(RealSealCastingRecipes.MULTI_RELEASE)
                        && multi.incompatibleAdditionalSealIds().contains(RealSealCastingRecipes.TRIUNE_RELEASE),
                "multi-release and triune release conflict symmetrically");
        check(expansion.compatibleRecipeIds().equals(Set.of(RealSealCastingRecipes.FIREBALL)),
                "fireball expansion is limited to the concrete Fireball spell");
        eq(List.of(RealSealCastingRecipes.QUICK_RELEASE), registry.matchAdditional(RealSealCastingRecipes.MAGIC_ARROW,
                SealSequence.of(BasicSeal.ZI, BasicSeal.HAI)).exactIds(), "quick-release sequence is registered");
        eq(List.of(RealSealCastingRecipes.MULTI_RELEASE), registry.matchAdditional(RealSealCastingRecipes.MAGIC_ARROW,
                SealSequence.of(BasicSeal.SHEN, BasicSeal.XU)).exactIds(), "multi-release sequence is registered");
        eq(List.of(RealSealCastingRecipes.TRIUNE_RELEASE), registry.matchAdditional(RealSealCastingRecipes.MAGIC_ARROW,
                SealSequence.of(BasicSeal.SHEN, BasicSeal.YOU, BasicSeal.XU)).exactIds(), "triune-release sequence is registered");
        eq(List.of(RealSealCastingRecipes.FIREBALL_EXPANSION), registry.matchAdditional(RealSealCastingRecipes.FIREBALL,
                SealSequence.of(BasicSeal.MAO, BasicSeal.YOU)).exactIds(), "fireball expansion sequence is registered");
        check(registry.matchAdditional(RealSealCastingRecipes.MAGIC_ARROW,
                SealSequence.of(BasicSeal.MAO, BasicSeal.YOU)).exactIds().isEmpty(),
                "fireball expansion does not match for Magic Arrow");

        PlanResolution multiAccepted = resolver.resolve(new CastPlanRequest(UUID.randomUUID(), RealSealCastingRecipes.MAGIC_ARROW,
                List.of(RealSealCastingRecipes.MULTI_RELEASE)), registry, context);
        check(multiAccepted.accepted(), "server resolver accepts multi-release for a supported projectile spell");
        PlanResolution triuneAccepted = resolver.resolve(new CastPlanRequest(UUID.randomUUID(), RealSealCastingRecipes.FIREBALL,
                List.of(RealSealCastingRecipes.TRIUNE_RELEASE, RealSealCastingRecipes.FIREBALL_EXPANSION)), registry, context);
        check(triuneAccepted.accepted(), "triune release and fireball expansion can compose when both are applicable");
        PlanResolution multiConflict = resolver.resolve(new CastPlanRequest(UUID.randomUUID(), RealSealCastingRecipes.FIREBALL,
                List.of(RealSealCastingRecipes.MULTI_RELEASE, RealSealCastingRecipes.TRIUNE_RELEASE)), registry, context);
        check(!multiConflict.accepted(), "multi-release variants cannot stack into an unintended projectile count");
        String dynamicRecipeId = registry.spellRecipes().values().stream()
                .map(r -> r.recipeId()).filter(id -> !Set.of(RealSealCastingRecipes.MAGIC_ARROW,
                        RealSealCastingRecipes.FIREBOLT, RealSealCastingRecipes.LIGHTNING_LANCE,
                        RealSealCastingRecipes.FIREBALL).contains(id)).findFirst().orElseThrow();
        PlanResolution unsupportedProjectile = resolver.resolve(new CastPlanRequest(UUID.randomUUID(), dynamicRecipeId,
                List.of(RealSealCastingRecipes.MULTI_RELEASE)), registry, context);
        check(!unsupportedProjectile.accepted(), "multi-release is rejected for spells without verified projectile executors");
        PlanResolution wrongExpansion = resolver.resolve(new CastPlanRequest(UUID.randomUUID(), RealSealCastingRecipes.MAGIC_ARROW,
                List.of(RealSealCastingRecipes.FIREBALL_EXPANSION)), registry, context);
        check(!wrongExpansion.accepted(), "fireball-only radius expansion cannot be applied to Magic Arrow");

        // The full registry must retain references while the session still filters user input by mastery.
        var fullRegistry = RealSealCastingRecipes.registryForLearnedAdditions(Set.of(RealSealCastingRecipes.MULTI_RELEASE));
        check(fullRegistry.additionalSeal(RealSealCastingRecipes.TRIUNE_RELEASE) != null,
                "input registry retains conflict targets so freeze-time references remain valid");
        var learnedOnlySession = new cn.blockforge.outofspec.spellcraft.model.SealInputSession(
                fullRegistry, 800L, Set.of(RealSealCastingRecipes.MULTI_RELEASE));
        learnedOnlySession.start(0L);
        learnedOnlySession.press(BasicSeal.ZI, 1L);
        learnedOnlySession.press(BasicSeal.CHOU, 2L);
        learnedOnlySession.confirmBase(3L);
        learnedOnlySession.press(BasicSeal.SHEN, 4L);
        learnedOnlySession.press(BasicSeal.XU, 5L);
        check(learnedOnlySession.snapshot().currentMatch().exactIds().contains(RealSealCastingRecipes.MULTI_RELEASE),
                "a mastered additional seal remains matchable when other definitions are retained");
        learnedOnlySession.confirmAdditional(6L);
        learnedOnlySession.release(BasicSeal.SHEN, 7L);
        learnedOnlySession.release(BasicSeal.XU, 8L);
        learnedOnlySession.press(BasicSeal.SHEN, 9L);
        learnedOnlySession.release(BasicSeal.SHEN, 10L);
        var unlearnedSequenceResult = learnedOnlySession.press(BasicSeal.YOU, 11L);
        check(unlearnedSequenceResult.code() == cn.blockforge.outofspec.spellcraft.model.SealInputSession.Code.UNKNOWN_SEQUENCE,
                "the same session will not match a different, unlearned addition sequence");

        System.out.println("PASS: " + assertions + " Stage 2.9/4.8 real-seal casting recipe assertions.");
    }

    private static void check(boolean condition, String label) {
        assertions++;
        if (!condition) throw new AssertionError(label);
        System.out.println("PASS " + label);
    }

    private static void eq(Object expected, Object actual, String label) {
        assertions++;
        if (expected == null ? actual != null : !expected.equals(actual)) {
            throw new AssertionError(label + " (expected=" + expected + ", actual=" + actual + ")");
        }
        System.out.println("PASS " + label + " (expected=" + expected + ", actual=" + actual + ")");
    }
}
