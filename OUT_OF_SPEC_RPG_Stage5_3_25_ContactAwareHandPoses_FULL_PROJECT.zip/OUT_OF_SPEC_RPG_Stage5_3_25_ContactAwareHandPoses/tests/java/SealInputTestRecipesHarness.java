import cn.blockforge.outofspec.spellcraft.model.AdditionalSealDefinition;
import cn.blockforge.outofspec.spellcraft.model.BasicSeal;
import cn.blockforge.outofspec.spellcraft.model.CastingRecipeRegistry;
import cn.blockforge.outofspec.spellcraft.model.SealInputSession;
import cn.blockforge.outofspec.spellcraft.model.SealInputTestRecipes;
import cn.blockforge.outofspec.spellcraft.model.SealSequence;
import cn.blockforge.outofspec.spellcraft.model.SequenceMatch;

import java.util.List;
import java.util.UUID;

public final class SealInputTestRecipesHarness {
    private static int assertions;

    public static void main(String[] args) {
        CastingRecipeRegistry registry = SealInputTestRecipes.registry();
        check(registry.isFrozen(), "diagnostic test registry is frozen");
        eq(4, registry.spellRecipes().size(), "four visible diagnostic recipes are registered");
        eq(5, registry.additionalSeals().size(), "five diagnostic additional seals are registered");
        eq("诊断术式·青焰弹", SealInputTestRecipes.spellName(SealInputTestRecipes.BLUE_BOLT), "blue bolt test name is localized and explicitly diagnostic");

        SequenceMatch basePrefix = registry.matchBase(SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU));
        eq(SequenceMatch.Status.EXACT_AND_PREFIX, basePrefix.status(), "ZX is an exact recipe and prefix of ZXC");
        eq(List.of(SealInputTestRecipes.BLUE_BOLT), basePrefix.exactIds(), "ZX resolves the short recipe only as exact candidate");
        eq(List.of(SealInputTestRecipes.BLUE_BURST), basePrefix.longerPrefixIds(), "ZXC remains offered as the longer candidate");

        SequenceMatch additionPrefix = registry.matchAdditional(SealInputTestRecipes.BLUE_BOLT, SealSequence.of(BasicSeal.WU));
        eq(SequenceMatch.Status.EXACT_AND_PREFIX, additionPrefix.status(), "F is exact and prefix of FG in additional-seal context");
        eq(List.of(SealInputTestRecipes.RANGE_SMALL), additionPrefix.exactIds(), "F maps to the smaller range preview");
        eq(List.of(SealInputTestRecipes.RANGE_LARGE), additionPrefix.longerPrefixIds(), "FG maps to the larger range preview");

        SealInputSession session = new SealInputSession(registry, 800L);
        eq(SealInputSession.Code.STARTED, session.start(1000).code(), "diagnostic session starts");
        pressRelease(session, BasicSeal.ZI, 1010);
        pressRelease(session, BasicSeal.CHOU, 1100);
        eq(SealInputSession.Code.BASE_CONFIRMED, session.confirmBase(1110).code(), "ZX can be explicitly confirmed as the short recipe");
        eq(SealInputTestRecipes.BLUE_BOLT, session.snapshot().selectedRecipeId(), "short base recipe is selected");
        pressRelease(session, BasicSeal.WU, 1200);
        eq(SealInputSession.Code.ADDITION_CONFIRMED, session.confirmAdditional(1210).code(), "F selects small range when explicitly confirmed");
        eq(List.of(SealInputTestRecipes.RANGE_SMALL), session.snapshot().selectedAdditionalSealIds(), "small range addition is recorded");

        pressRelease(session, BasicSeal.SHEN, 1300);
        pressRelease(session, BasicSeal.YOU, 1380);
        eq(SealInputSession.Code.ADDITION_CONFIRMED, session.confirmAdditional(1390).code(), "HR selects projectile split for a compatible bolt recipe");
        eq(2, session.snapshot().selectedAdditionalSealIds().size(), "two compatible additions can coexist");

        var submitted = session.submitCast(1400);
        eq(SealInputSession.Code.CAST_REQUEST_READY, submitted.code(), "diagnostic combination creates a selection-only request");
        check(submitted.castRequest() != null, "request exists after validation stage");
        check(submitted.castRequest().selectedAdditionalSealIds().contains(SealInputTestRecipes.SPLIT), "request carries split selection");
        check(submitted.castRequest().selectedAdditionalSealIds().contains(SealInputTestRecipes.RANGE_SMALL), "request carries range selection");
        eq(SealInputSession.Code.VALIDATION_ACCEPTED, session.onValidationResult(submitted.castRequest().requestId(), true, false, 1400).code(), "test lifecycle accepts matching local response");
        eq(SealInputSession.Code.CAST_FINISHED, session.onCastEnded(submitted.castRequest().requestId(), 1400).code(), "test lifecycle returns to idle");
        eq(SealInputSession.Phase.IDLE, session.snapshot().phase(), "completed diagnostic lifecycle does not leave the session stuck");

        // A world unload clears validating/casting client state and makes late packets stale.
        SealInputSession disconnected = new SealInputSession(registry, 800L);
        disconnected.start(2000);
        pressRelease(disconnected, BasicSeal.ZI, 2010);
        pressRelease(disconnected, BasicSeal.CHOU, 2100);
        disconnected.confirmBase(2110);
        var disconnectSubmit = disconnected.submitCast(2120);
        UUID pendingRequest = disconnectSubmit.castRequest().requestId();
        disconnected.resetAfterDisconnect(2130);
        eq(SealInputSession.Phase.IDLE, disconnected.snapshot().phase(), "disconnect resets every local input/cast phase");
        check(disconnected.snapshot().physicallyHeldSeals().isEmpty(), "disconnect clears held-key edges");
        eq(SealInputSession.Code.STALE_VALIDATION_IGNORED,
                disconnected.onValidationResult(pendingRequest, true, false, 2140).code(), "late validation from unloaded world is ignored");
        eq(SealInputSession.Phase.IDLE, disconnected.snapshot().phase(), "late validation cannot revive disconnected session");

        // Test recipes are deliberately not registered with an Iron's Spells executor.
        check(registry.recipe(SealInputTestRecipes.BLUE_BOLT).spellId().contains(":debug_"), "test spell IDs are clearly separated from real spell IDs");
        check(registry.additionalSeal(SealInputTestRecipes.SPLIT).effects().get(0).targetSpellId().equals("*"), "test-only effects are preview contributions, not real spell bindings");

        System.out.println("PASS: " + assertions + " diagnostic recipe assertions.");
    }

    private static void pressRelease(SealInputSession session, BasicSeal seal, long time) {
        check(session.press(seal, time).code() == SealInputSession.Code.INPUT_ACCEPTED, "press records " + seal.id());
        check(session.release(seal, time + 1).code() == SealInputSession.Code.KEY_RELEASED, "release clears held state for " + seal.id());
    }

    private static void check(boolean condition, String message) {
        assertions++;
        if (!condition) throw new AssertionError("FAIL: " + message);
    }

    private static void eq(Object expected, Object actual, String message) {
        assertions++;
        if (!expected.equals(actual)) throw new AssertionError("FAIL: " + message + " expected=" + expected + " actual=" + actual);
    }
}
