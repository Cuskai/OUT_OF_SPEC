import cn.blockforge.outofspec.spellcraft.growth.SpellGrowthBranch;
import cn.blockforge.outofspec.spellcraft.growth.SpellGrowthCatalog;
import cn.blockforge.outofspec.spellcraft.growth.SpellGrowthProfile;
import cn.blockforge.outofspec.spellcraft.growth.SpellTier;

public final class SpellGrowthCatalogHarness {
    private static int assertions;

    public static void main(String[] args) {
        int registryCount = TestSpellRegistryFixtures.populate(120);
        int profileCount = SpellGrowthCatalog.refreshFromRegistry();
        equal(registryCount, profileCount, "every registered spell receives a growth profile, including add-on and disabled entries");
        equal(registryCount, SpellGrowthCatalog.registeredDynamicSpellCount(), "runtime registry count matches fake spell registry");
        tier("irons_spellbooks:firebolt", SpellTier.LOWER, "Firebolt is lower tier");
        tier("irons_spellbooks:magic_arrow", SpellTier.MIDDLE, "Magic Arrow is middle tier");
        tier("irons_spellbooks:fireball", SpellTier.MIDDLE, "Fireball is middle tier by design in this version");
        tier("irons_spellbooks:lightning_lance", SpellTier.UPPER, "Lightning Lance is upper tier");
        truth(SpellGrowthCatalog.bySpellId("irons_spellbooks:portal") != null, "registered spatial portal receives a profile");
        equal(SpellTier.SUPER, SpellGrowthCatalog.bySpellId("irons_spellbooks:portal").tier(), "spatial portal is graded by scope, not damage");
        truth(SpellGrowthCatalog.bySpellId("irons_spellbooks:healing_circle") != null, "registered healing spell receives a profile");
        truth(SpellGrowthCatalog.bySpellId("addon_magic:generated_spell_001") != null, "third-party spell namespace is included");
        truth(!SpellGrowthCatalog.bySpellId("addon_a:b").key().equals(SpellGrowthCatalog.bySpellId("addon:a_b").key()), "flattening-collision spell keys stay distinct");
        equal(null, SpellGrowthCatalog.bySpellId("irons_spellbooks:unknown_spell"), "unregistered spells do not get fabricated profiles");
        java.util.Set<String> seenSequences = new java.util.HashSet<>();
        java.util.Set<String> profileIds = new java.util.HashSet<>();
        for (SpellGrowthProfile profile : SpellGrowthCatalog.profiles()) {
            truth(profileIds.add(profile.spellId()), "profile spell ID is unique: " + profile.spellId());
            var sequence = SpellGrowthCatalog.sealSequence(profile.spellId());
            truth(sequence != null, "every profile has a seal sequence: " + profile.spellId());
            if (!SpellGrowthCatalog.sealSequence(profile.spellId()).seals().equals(java.util.List.of(
                    cn.blockforge.outofspec.spellcraft.model.BasicSeal.ZI, cn.blockforge.outofspec.spellcraft.model.BasicSeal.CHOU))
                    && !SpellGrowthCatalog.sealSequence(profile.spellId()).seals().equals(java.util.List.of(
                    cn.blockforge.outofspec.spellcraft.model.BasicSeal.ZI, cn.blockforge.outofspec.spellcraft.model.BasicSeal.CHOU,
                    cn.blockforge.outofspec.spellcraft.model.BasicSeal.YIN))
                    && !SpellGrowthCatalog.sealSequence(profile.spellId()).seals().equals(java.util.List.of(
                    cn.blockforge.outofspec.spellcraft.model.BasicSeal.YIN, cn.blockforge.outofspec.spellcraft.model.BasicSeal.MAO,
                    cn.blockforge.outofspec.spellcraft.model.BasicSeal.CHEN))
                    && !SpellGrowthCatalog.sealSequence(profile.spellId()).seals().equals(java.util.List.of(
                    cn.blockforge.outofspec.spellcraft.model.BasicSeal.CHOU, cn.blockforge.outofspec.spellcraft.model.BasicSeal.SI,
                    cn.blockforge.outofspec.spellcraft.model.BasicSeal.HAI))) {
                truth(seenSequences.add(sequence.canonicalKey()), "generated sequences are collision-free: " + profile.spellId());
            }
        }

        SpellGrowthProfile lower = SpellGrowthCatalog.bySpellId("irons_spellbooks:firebolt");
        SpellGrowthProfile middle = SpellGrowthCatalog.bySpellId("irons_spellbooks:magic_arrow");
        SpellGrowthProfile upper = SpellGrowthCatalog.bySpellId("irons_spellbooks:lightning_lance");
        equal(5, lower.maxLevel(), "growth level ceiling is explicit");
        equal(80, SpellGrowthCatalog.requiredProficiency(lower, 1), "lower tier level 1 threshold");
        equal(140, SpellGrowthCatalog.requiredProficiency(lower, 2), "proficiency threshold rises at each level");
        equal(200, SpellGrowthCatalog.requiredProficiency(lower, 3), "breakthrough carries a higher proficiency requirement");
        equal(100, SpellGrowthCatalog.requiredProficiency(middle, 1), "middle tier needs more proficiency than lower tier");
        equal(140, SpellGrowthCatalog.requiredProficiency(upper, 1), "upper tier needs more proficiency than middle tier");
        equal(4, SpellGrowthCatalog.breakthroughCombatHitsRequired(lower), "lower-tier breakthrough combat challenge");
        equal(5, SpellGrowthCatalog.breakthroughCombatHitsRequired(middle), "middle-tier breakthrough combat challenge");
        equal(7, SpellGrowthCatalog.breakthroughCombatHitsRequired(upper), "upper-tier breakthrough combat challenge");
        truth(SpellGrowthCatalog.isBreakthroughLevel(3), "Lv.3 to Lv.4 is the key branch breakthrough");
        truth(!SpellGrowthCatalog.isBreakthroughLevel(2), "ordinary upgrades before breakthrough do not require branch selection");
        equal(1, SpellGrowthCatalog.materialCostForLevel(lower, 1), "lower tier has lower growth material cost");
        equal(2, SpellGrowthCatalog.materialCostForLevel(middle, 1), "middle tier has moderate growth material cost");
        equal(3, SpellGrowthCatalog.materialCostForLevel(upper, 1), "upper tier has higher growth material cost");
        equal(2, SpellGrowthCatalog.materialCostForLevel(lower, 4), "later level material cost scales modestly");
        equal(SpellGrowthBranch.REFINEMENT, SpellGrowthBranch.byId("refinement"), "branch IDs parse case-insensitively");
        equal(SpellGrowthBranch.BURST, SpellGrowthBranch.byId("BURST"), "burst branch is registered");
        equal(SpellGrowthBranch.CONTROL, SpellGrowthBranch.byId("CONTROL"), "control branch is registered");
        equal(SpellGrowthBranch.NONE, SpellGrowthBranch.byId("not-a-branch"), "invalid branch IDs fail closed");

        System.out.println("PASS all " + assertions + " spell-growth catalog assertions across " + SpellGrowthCatalog.profiles().size() + " profiles.");
    }

    private static void tier(String id, SpellTier expected, String message) {
        SpellGrowthProfile profile = SpellGrowthCatalog.bySpellId(id);
        truth(profile != null, message + " (profile exists)");
        equal(expected, profile.tier(), message);
    }

    private static void equal(Object expected, Object actual, String message) {
        assertions++;
        if (expected == null ? actual != null : !expected.equals(actual)) {
            throw new AssertionError(message + " (expected=" + expected + ", actual=" + actual + ")");
        }
        if (assertions <= 25) System.out.println("PASS " + message + " (expected=" + expected + ", actual=" + actual + ")");
    }

    private static void truth(boolean value, String message) {
        assertions++;
        if (!value) throw new AssertionError(message);
        if (assertions <= 25) System.out.println("PASS " + message);
    }
}
