import cn.blockforge.outofspec.spellcraft.model.BasicSeal;
import cn.blockforge.outofspec.spellcraft.model.SealSequence;
import cn.blockforge.outofspec.spellcraft.model.SpellSealSequenceGenerator;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class SpellSealSequenceGeneratorHarness {
    private static int assertions;
    public static void main(String[] args) {
        List<String> ids = new ArrayList<>();
        for (int i = 0; i < 500; i++) ids.add("addon:stress_spell_" + i);
        List<SealSequence> reserved = List.of(
                SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU),
                SealSequence.of(BasicSeal.ZI, BasicSeal.CHOU, BasicSeal.YIN),
                SealSequence.of(BasicSeal.YIN, BasicSeal.MAO, BasicSeal.CHEN),
                SealSequence.of(BasicSeal.CHOU, BasicSeal.SI, BasicSeal.HAI));
        var first = SpellSealSequenceGenerator.generate(ids, reserved);
        var reversed = new ArrayList<>(ids);
        java.util.Collections.reverse(reversed);
        var second = SpellSealSequenceGenerator.generate(reversed, reserved);
        check(first.equals(second), "assignments are deterministic regardless of registry order");
        eq(ids.size(), first.size(), "all 500 stress spells receive a sequence");
        Set<String> seen = new HashSet<>();
        for (var entry : first.entrySet()) {
            var seq = entry.getValue();
            eq(4, seq.seals().size(), "generated sequence is exactly four seals");
            check(seen.add(seq.canonicalKey()), "generated sequence is unique: " + entry.getKey());
            for (int i = 1; i < seq.seals().size(); i++) check(seq.seals().get(i) != seq.seals().get(i-1), "no adjacent repeated seals");
            for (var fixed : reserved) check(!seq.isPrefixOf(fixed) && !fixed.isPrefixOf(seq), "does not collide with curated sequence prefixes");
        }
        System.out.println("PASS all " + assertions + " generated sequence stress assertions.");
    }
    private static void check(boolean value, String message) { assertions++; if (!value) throw new AssertionError(message); }
    private static void eq(Object expected, Object actual, String message) { assertions++; if (!expected.equals(actual)) throw new AssertionError(message + " expected=" + expected + " actual=" + actual); }
}
