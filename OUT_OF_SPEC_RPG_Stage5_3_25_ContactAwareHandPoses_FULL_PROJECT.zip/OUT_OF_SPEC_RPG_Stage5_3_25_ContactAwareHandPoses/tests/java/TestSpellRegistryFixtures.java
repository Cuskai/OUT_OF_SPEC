import io.redspace.ironsspellbooks.api.registry.SpellRegistry;
import io.redspace.ironsspellbooks.api.spells.AbstractSpell;
import java.util.ArrayList;
import java.util.List;

/** Deterministic fake registry used to stress-test dynamic spell enumeration without a Forge runtime. */
public final class TestSpellRegistryFixtures {
    private TestSpellRegistryFixtures() {}

    public static int populate(int generatedSpellCount) {
        List<AbstractSpell> spells = new ArrayList<>();
        spells.add(new AbstractSpell("irons_spellbooks:firebolt", 12, 10, true, "Fire"));
        spells.add(new AbstractSpell("irons_spellbooks:magic_arrow", 18, 20, true, "Arcane"));
        spells.add(new AbstractSpell("irons_spellbooks:fireball", 42, 45, true, "Fire"));
        spells.add(new AbstractSpell("irons_spellbooks:lightning_lance", 72, 85, true, "Lightning"));
        spells.add(new AbstractSpell("irons_spellbooks:portal", 80, 90, true, "Eldritch"));
        spells.add(new AbstractSpell("irons_spellbooks:healing_circle", 35, 30, true, "Holy"));
        spells.add(new AbstractSpell("irons_spellbooks:shield", 22, 24, true, "Holy"));
        spells.add(new AbstractSpell("irons_spellbooks:disabled_test_spell", 10, 10, false, "Arcane"));
        // These pairs collide under naive namespace/path flattening and must remain distinct.
        spells.add(new AbstractSpell("addon_a:b", 20, 20, true, "Arcane"));
        spells.add(new AbstractSpell("addon:a_b", 20, 20, true, "Arcane"));
        for (int i = 0; i < generatedSpellCount; i++) {
            String namespace = i % 3 == 0 ? "irons_spellbooks" : (i % 3 == 1 ? "addon_magic" : "test_namespace");
            String id = namespace + ":generated_spell_" + String.format(java.util.Locale.ROOT, "%03d", i);
            spells.add(new AbstractSpell(id, 10 + (i % 90), 5 + (i % 100), true, "School" + (i % 6)));
        }
        SpellRegistry.REGISTRY_VALUE.setValues(spells);
        return spells.size();
    }
}
