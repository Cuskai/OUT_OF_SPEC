package io.redspace.ironsspellbooks.api.registry;

import io.redspace.ironsspellbooks.api.spells.AbstractSpell;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Supplier;

public final class SpellRegistry {
    public static final FakeRegistry REGISTRY_VALUE = new FakeRegistry();
    public static final Supplier<FakeRegistry> REGISTRY = () -> REGISTRY_VALUE;

    private SpellRegistry() {}

    public static AbstractSpell getSpell(String id) {
        if (id == null) return null;
        for (AbstractSpell spell : REGISTRY_VALUE.getValues()) {
            if (id.equals(spell.getSpellId())) return spell;
        }
        return null;
    }

    public static final class FakeRegistry {
        private List<AbstractSpell> values = new ArrayList<>();
        public Collection<AbstractSpell> getValues() { return List.copyOf(values); }
        public void setValues(Collection<AbstractSpell> values) { this.values = new ArrayList<>(values); }
    }
}
