package io.redspace.ironsspellbooks.api.spells;

import net.minecraft.resources.ResourceLocation;

public class AbstractSpell {
    private final String spellId;
    private final ResourceLocation resource;
    private final int manaCost;
    private final int castTime;
    private final boolean enabled;
    private final SchoolType school;

    public AbstractSpell(String spellId, int manaCost, int castTime, boolean enabled, String schoolName) {
        this.spellId = spellId;
        this.resource = ResourceLocation.tryParse(spellId);
        this.manaCost = manaCost;
        this.castTime = castTime;
        this.enabled = enabled;
        this.school = new SchoolType(schoolName == null ? "Arcane" : schoolName);
    }

    public String getSpellId() { return spellId; }
    public ResourceLocation getSpellResource() { return resource; }
    public SchoolType getSchoolType() { return school; }
    public int getManaCost(int level) { return manaCost; }
    public int getCastTime(int level) { return castTime; }
    public boolean isEnabled() { return enabled; }
    public String getComponentId() { return "spell." + spellId.replace(':', '.'); }
}
