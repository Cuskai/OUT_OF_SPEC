package io.redspace.ironsspellbooks.api.spells;

import net.minecraft.network.chat.Component;

public final class SchoolType {
    private final String name;
    public SchoolType(String name) { this.name = name; }
    public Component getDisplayName() { return Component.literal(name); }
}
