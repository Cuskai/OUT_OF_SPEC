package net.minecraft.network.chat;

public final class Component {
    private final String value;
    private Component(String value) { this.value = value; }
    public static Component literal(String value) { return new Component(value); }
    public static Component translatable(String key) { return new Component(key); }
    public String getString() { return value; }
}
