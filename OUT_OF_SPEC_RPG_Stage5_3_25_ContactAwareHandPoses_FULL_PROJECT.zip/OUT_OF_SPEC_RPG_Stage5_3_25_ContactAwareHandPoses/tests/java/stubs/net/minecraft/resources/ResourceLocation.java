package net.minecraft.resources;

import java.util.Locale;

public final class ResourceLocation {
    private final String namespace;
    private final String path;

    public ResourceLocation(String namespace, String path) {
        this.namespace = namespace;
        this.path = path;
    }

    public static ResourceLocation tryParse(String value) {
        if (value == null || value.isBlank()) return null;
        String normalized = value.toLowerCase(Locale.ROOT);
        String[] parts = normalized.split(":", 2);
        if (parts.length == 1) return new ResourceLocation("minecraft", parts[0]);
        if (parts[0].isBlank() || parts[1].isBlank()) return null;
        return new ResourceLocation(parts[0], parts[1]);
    }

    public String getNamespace() { return namespace; }
    public String getPath() { return path; }
    @Override public String toString() { return namespace + ":" + path; }
    @Override public boolean equals(Object other) {
        return other instanceof ResourceLocation r && namespace.equals(r.namespace) && path.equals(r.path);
    }
    @Override public int hashCode() { return 31 * namespace.hashCode() + path.hashCode(); }
}
