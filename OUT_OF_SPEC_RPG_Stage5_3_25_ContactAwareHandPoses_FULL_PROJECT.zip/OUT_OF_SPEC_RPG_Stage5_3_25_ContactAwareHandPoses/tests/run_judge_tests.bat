@echo off
setlocal
cd /d "%~dp0.."
where java >nul 2>nul || (echo ERROR: Java was not found.& exit /b 2)
where javac >nul 2>nul || (echo ERROR: Full JDK with javac was not found.& exit /b 2)
where python >nul 2>nul || (echo ERROR: Python 3 is required for source/configuration audits.& exit /b 2)
set "TEST_CLASSES=%TEMP%\out_of_spec_stage5_tests"
set "SOURCE_LIST=%TEMP%\out_of_spec_stage5_sources.txt"
if exist "%TEST_CLASSES%" rmdir /s /q "%TEST_CLASSES%"
if exist "%SOURCE_LIST%" del /q "%SOURCE_LIST%"
mkdir "%TEST_CLASSES%" || exit /b 2
for /r "tests\java\stubs" %%F in (*.java) do >>"%SOURCE_LIST%" echo "%%F"
>>"%SOURCE_LIST%" echo "src\main\java\cn\blockforge\outofspec\binding\SpellNameResolver.java"
>>"%SOURCE_LIST%" echo "src\main\java\cn\blockforge\outofspec\binding\BindingContract.java"
>>"%SOURCE_LIST%" echo "src\main\java\cn\blockforge\outofspec\binding\BindingContractJudge.java"
for /r "src\main\java\cn\blockforge\outofspec\spellcraft\model" %%F in (*.java) do >>"%SOURCE_LIST%" echo "%%F"
>>"%SOURCE_LIST%" echo "src\main\java\cn\blockforge\outofspec\binding\client\handpose\HandSealPoseLibrary.java"
>>"%SOURCE_LIST%" echo "src\main\java\cn\blockforge\outofspec\spellcraft\growth\SpellTier.java"
>>"%SOURCE_LIST%" echo "src\main\java\cn\blockforge\outofspec\spellcraft\growth\SpellGrowthBranch.java"
>>"%SOURCE_LIST%" echo "src\main\java\cn\blockforge\outofspec\spellcraft\growth\SpellGrowthProfile.java"
>>"%SOURCE_LIST%" echo "src\main\java\cn\blockforge\outofspec\spellcraft\growth\SpellGrowthCatalog.java"
>>"%SOURCE_LIST%" echo "tests\java\SpellGrowthCatalogHarness.java"
>>"%SOURCE_LIST%" echo "tests\java\SpellSealSequenceGeneratorHarness.java"
>>"%SOURCE_LIST%" echo "tests\java\TestSpellRegistryFixtures.java"
>>"%SOURCE_LIST%" echo "tests\java\BindingJudgeHarness.java"
>>"%SOURCE_LIST%" echo "tests\java\ComposableCastingModelHarness.java"
>>"%SOURCE_LIST%" echo "tests\java\SealInputTestRecipesHarness.java"
>>"%SOURCE_LIST%" echo "tests\java\RealSealCastingRecipesHarness.java"
>>"%SOURCE_LIST%" echo "tests\java\ProjectileFormationHarness.java"
>>"%SOURCE_LIST%" echo "tests\java\HandSealPoseLibraryHarness.java"
javac --release 17 -encoding UTF-8 -d "%TEST_CLASSES%" @"%SOURCE_LIST%"
if errorlevel 1 (echo ERROR: Pure-Java compilation failed.& exit /b 3)
java -Dfile.encoding=UTF-8 -cp "%TEST_CLASSES%" SpellGrowthCatalogHarness
if errorlevel 1 exit /b 4
java -Dfile.encoding=UTF-8 -cp "%TEST_CLASSES%" SpellSealSequenceGeneratorHarness
if errorlevel 1 exit /b 4
java -Dfile.encoding=UTF-8 -cp "%TEST_CLASSES%" BindingJudgeHarness
if errorlevel 1 exit /b 4
java -Dfile.encoding=UTF-8 -cp "%TEST_CLASSES%" ComposableCastingModelHarness
if errorlevel 1 exit /b 4
java -Dfile.encoding=UTF-8 -cp "%TEST_CLASSES%" SealInputTestRecipesHarness
if errorlevel 1 exit /b 4
java -Dfile.encoding=UTF-8 -cp "%TEST_CLASSES%" RealSealCastingRecipesHarness
if errorlevel 1 exit /b 4
java -Dfile.encoding=UTF-8 -cp "%TEST_CLASSES%" ProjectileFormationHarness
if errorlevel 1 exit /b 4
java -Dfile.encoding=UTF-8 -cp "%TEST_CLASSES%" HandSealPoseLibraryHarness
if errorlevel 1 exit /b 4
python tests\check_source.py
if errorlevel 1 exit /b 5
python tests\check_composable_model.py
if errorlevel 1 exit /b 5
python tests\check_seal_input_session.py
if errorlevel 1 exit /b 5
python tests\check_seal_debug_hud.py
if errorlevel 1 exit /b 5
python tests\check_additional_seals.py
if errorlevel 1 exit /b 5
python tests\check_first_person_hand_rig.py
if errorlevel 1 exit /b 5
python tests\check_hand_scale_contact_and_occupancy.py
if errorlevel 1 exit /b 5
python tests\check_standalone_hand_rendering.py
if errorlevel 1 exit /b 5
python tests\check_spell_growth.py
if errorlevel 1 exit /b 5
python tests\check_ui_polish.py
if errorlevel 1 exit /b 5
python tests\check_spell_power_baseline.py
if errorlevel 1 exit /b 5
python tests\validate_project.py
if errorlevel 1 exit /b 6
echo.
echo PASS: Stage 3.8 binding contracts, Stage 2.6/2.7 seal model, Stage 2.8 HUD, Stage 2.9 casting, Stage 4.5 spell registry, Stage 4.7/4.8 UI and additional seals, Stage 5.3.25 contact-aware hand pose and two-hand interaction lock, 500-sequence stress tests and source/configuration audits.
echo NOTE: These tests do not replace a real Gradle/Forge build or Minecraft in-game test.
exit /b 0
