#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
classes_dir="$(mktemp -d)"
trap 'rm -rf "$classes_dir"' EXIT
mapfile -d '' model_sources < <(find src/main/java/cn/blockforge/outofspec/spellcraft/model -name '*.java' -print0 | sort -z)
mapfile -d '' test_stubs < <(find tests/java/stubs -name '*.java' -print0 | sort -z)
javac --release 17 -encoding UTF-8 -d "$classes_dir" \
  "${test_stubs[@]}" \
  src/main/java/cn/blockforge/outofspec/binding/SpellNameResolver.java \
  src/main/java/cn/blockforge/outofspec/binding/BindingContract.java \
  src/main/java/cn/blockforge/outofspec/binding/BindingContractJudge.java \
  src/main/java/cn/blockforge/outofspec/binding/client/handpose/HandSealPoseLibrary.java \
  "${model_sources[@]}" \
  src/main/java/cn/blockforge/outofspec/spellcraft/growth/SpellTier.java \
  src/main/java/cn/blockforge/outofspec/spellcraft/growth/SpellGrowthBranch.java \
  src/main/java/cn/blockforge/outofspec/spellcraft/growth/SpellGrowthProfile.java \
  src/main/java/cn/blockforge/outofspec/spellcraft/growth/SpellGrowthCatalog.java \
  tests/java/SpellGrowthCatalogHarness.java \
  tests/java/SpellSealSequenceGeneratorHarness.java \
  tests/java/TestSpellRegistryFixtures.java \
  tests/java/BindingJudgeHarness.java \
  tests/java/ComposableCastingModelHarness.java \
  tests/java/SealInputTestRecipesHarness.java \
  tests/java/RealSealCastingRecipesHarness.java \
  tests/java/ProjectileFormationHarness.java \
  tests/java/HandSealPoseLibraryHarness.java
java -Dfile.encoding=UTF-8 -cp "$classes_dir" SpellGrowthCatalogHarness
java -Dfile.encoding=UTF-8 -cp "$classes_dir" SpellSealSequenceGeneratorHarness
java -Dfile.encoding=UTF-8 -cp "$classes_dir" BindingJudgeHarness
java -Dfile.encoding=UTF-8 -cp "$classes_dir" ComposableCastingModelHarness
java -Dfile.encoding=UTF-8 -cp "$classes_dir" SealInputTestRecipesHarness
java -Dfile.encoding=UTF-8 -cp "$classes_dir" RealSealCastingRecipesHarness
java -Dfile.encoding=UTF-8 -cp "$classes_dir" ProjectileFormationHarness
java -Dfile.encoding=UTF-8 -cp "$classes_dir" HandSealPoseLibraryHarness
python3 tests/check_source.py
python3 tests/check_composable_model.py
python3 tests/check_seal_input_session.py
python3 tests/check_seal_debug_hud.py
python3 tests/check_additional_seals.py
python3 tests/check_first_person_hand_rig.py
python3 tests/check_hand_scale_contact_and_occupancy.py
python3 tests/check_standalone_hand_rendering.py
python3 tests/check_spell_growth.py
python3 tests/check_ui_polish.py
python3 tests/check_spell_power_baseline.py
python3 tests/validate_project.py
