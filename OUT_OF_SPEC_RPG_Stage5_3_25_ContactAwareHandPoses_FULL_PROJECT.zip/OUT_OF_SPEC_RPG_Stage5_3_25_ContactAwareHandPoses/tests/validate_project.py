from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import zipfile
import struct
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_BASELINE_SHA256 = "ebb72ec47f22b64fbac3ab58ff96f9d0df5fe276638bb3cb57bf3b1832fd1fda"
CURRENT_VERSION = "0.6.34"
PROJECT_NAME = "OUT_OF_SPEC_BindingContracts_Stage5_3_25_ContactAwareHandPoses"
OUTPUT_JAR = "OUT_OF_SPEC_RPG_IronSpell_SAO_Stage5_3_25_ContactAwareHandPoses.jar"

# All JSON assets/configurations must remain parseable.
json_files = sorted((ROOT / "src/main/resources").rglob("*.json"))
for path in json_files:
    json.loads(path.read_text(encoding="utf-8"))
print(f"PASS package config: parsed {len(json_files)} resource JSON files")

# Keep editable vector artwork and the alpha PNG resource.
sigil_svg = ROOT / "design/ritual_seal.svg"
sigil_png = ROOT / "src/main/resources/assets/out_of_spec_binding/textures/gui/ritual_seal.png"
svg_root = ET.parse(sigil_svg).getroot()
assert svg_root.tag.endswith("svg"), "ritual sigil SVG is malformed"
png_bytes = sigil_png.read_bytes()
assert png_bytes[:8] == b"\x89PNG\r\n\x1a\n", "ritual sigil texture is not a PNG"
png_w, png_h = struct.unpack(">II", png_bytes[16:24])
assert (png_w, png_h) == (256, 256), f"unexpected ritual texture dimensions: {png_w}x{png_h}"
assert png_bytes[25] in (4, 6), "ritual texture should preserve transparency"
print("PASS visual assets: editable SVG parsed; 256x256 alpha PNG packaged")

# Expand Gradle placeholders and parse the current single-mod add-on metadata.
try:
    import tomllib
except ImportError:
    tomllib = None
mods_toml = (ROOT / "src/main/resources/META-INF/mods.toml").read_text(encoding="utf-8")
if tomllib is not None:
    expanded = mods_toml
    replacements = {
        "${mod_id}": "out_of_spec_binding",
        "${mod_version}": CURRENT_VERSION,
        "${mod_name}": "OUT OF SPEC RPG Spell Growth",
        "${forge_version_range}": "[47.4.0,48)",
        "${irons_spellbooks_version}": "[1.20.1-3.16.3,]",
    }
    for before, after in replacements.items():
        expanded = expanded.replace(before, after)
    parsed = tomllib.loads(expanded)
    mod_ids = [entry["modId"] for entry in parsed["mods"]]
    assert mod_ids == ["out_of_spec_binding"], f"unexpected add-on mod IDs: {mod_ids}"
    print("PASS package config: expanded mods.toml parses and declares only OUT OF SPEC")
else:
    assert 'modId="${mod_id}"' in mods_toml
    print("WARN package config: tomllib unavailable; metadata structurally checked")
assert 'modId="punchy"' not in mods_toml.lower() and 'version="2.8f"' not in mods_toml.lower()

# Standalone rendering has no third-party arm renderer in the active mixin chain.
client_mixins_json = json.loads((ROOT / "src/main/resources/out_of_spec_binding.client.mixins.json").read_text(encoding="utf-8"))
assert "StandaloneFirstPersonHandsMixin" in client_mixins_json["client"]
assert "StandaloneFirstPersonPlayerRendererMixin" not in client_mixins_json["client"]
assert all("punchy" not in entry.lower() for entry in client_mixins_json["client"])
hand_hook = (ROOT / "src/main/java/cn/blockforge/outofspec/binding/mixin/client/StandaloneFirstPersonHandsMixin.java").read_text(encoding="utf-8")
assert 'method = "renderPlayerArm"' in hand_hook and "cancellable = true" in hand_hook
assert 'method = "renderHandsWithItems"' in hand_hook and '@At("RETURN")' in hand_hook
assert 'outOfSpec$drawBilateralPairAtReturn' in hand_hook and 'finishFirstPersonHandFrame(' in hand_hook
assert 'method = "renderHandsWithItems"' in hand_hook and 'finishFirstPersonHandFrame(' in hand_hook
assert 'beginFirstPersonHandFrame(player)' in hand_hook
assert 'isHandFrameActive()' in hand_hook and 'buffers.endBatch();' in (ROOT / 'src/main/java/cn/blockforge/outofspec/binding/client/SealHandPoseRenderer.java').read_text(encoding='utf-8')
assert 'finishFirstPersonHandFrame' in (ROOT / 'src/main/java/cn/blockforge/outofspec/binding/client/SealHandPoseRenderer.java').read_text(encoding='utf-8')
assert "PunchyArmRenderer" not in hand_hook and "punchy.client" not in hand_hook.lower()
print("PASS bilateral standalone hand integration: end-of-frame draws both sides unconditionally and flushes custom vertices")

# Source tree, packaging and metadata must contain no live Punchy dependency.
build = (ROOT / "build.gradle").read_text(encoding="utf-8")
settings = (ROOT / "settings.gradle").read_text(encoding="utf-8")
properties = (ROOT / "gradle.properties").read_text(encoding="utf-8")
bat = (ROOT / "Build-Stage4-Full.bat").read_text(encoding="utf-8")
assert re.search(rf"(?m)^mod_version={re.escape(CURRENT_VERSION)}$", properties)
assert PROJECT_NAME in settings and PROJECT_NAME in build
assert OUTPUT_JAR in build and OUTPUT_JAR in bat
assert "JavaLanguageVersion.of(17)" in build and "options.release = 17" in build
assert "Punchy" not in build and "punchy" not in build.lower()
assert "PunchyJarEmbedder" not in build and "compileOnly files('libs/punchy-2.8f-forge-1.20.1.jar')" not in build
assert not (ROOT / "libs/punchy-2.8f-forge-1.20.1.jar").exists()
assert not (ROOT / "tools/PunchyJarEmbedder.java").exists()
for path in (ROOT / "src/main/java").rglob("*.java"):
    source = path.read_text(encoding="utf-8")
    assert "PunchyArmRenderer" not in source and "punchy.client" not in source.lower(), f"live Punchy reference in {path.relative_to(ROOT)}"
events = (ROOT / "src/main/java/cn/blockforge/outofspec/spellcraft/growth/SpellGrowthEvents.java").read_text(encoding="utf-8")
assert 'BUILD_MARKER = "OUT_OF_SPEC_STAGE_5_3_25.0.6.34"' in events
print("PASS build identity: Stage 5.3.25 contact-aware hand pose and two-hand interaction lock, Java 17, output path and no Punchy runtime/build dependency")

# Bundled baseline must remain byte-identical and readable.
base = ROOT / "baseline/OUT_OF_SPEC_RPG_IronSpell_SAO_Mobility_Stage1_1.jar"
assert base.is_file(), "bundled Stage 1.1 rollback baseline is missing"
base_hash = hashlib.sha256(base.read_bytes()).hexdigest()
assert base_hash == EXPECTED_BASELINE_SHA256, f"unexpected Stage 1.1 baseline hash: {base_hash}"
with zipfile.ZipFile(base) as archive:
    assert archive.testzip() is None, "baseline ZIP CRC failed"
    base_entries = set(archive.namelist())
    assert "META-INF/MANIFEST.MF" in base_entries and "META-INF/mods.toml" in base_entries
print(f"PASS package baseline: Stage 1.1 payload intact (SHA-256 {base_hash})")

# Optionally compile/run the JDK-only merger against a synthetic standalone add-on and the real baseline.
if os.environ.get("OUT_OF_SPEC_DEEP_PACKAGE_TEST") == "1":
    javac, java = shutil.which("javac"), shutil.which("java")
    assert javac and java, "JDK tools are required for archive integration fixture tests"
    with tempfile.TemporaryDirectory(prefix="out-of-spec-stage5-standalone-merge-") as td:
        temp = Path(td)
        classes = temp / "classes"
        classes.mkdir()
        merger_source = ROOT / "tools/Stage11JarMerger.java"
        subprocess.run([javac, "--release", "17", "-encoding", "UTF-8", "-d", str(classes), str(merger_source)],
                       check=True, capture_output=True, text=True)
        addon = temp / "synthetic-standalone-addon.jar"
        addon_toml = "\n".join([
            'modLoader="javafml"', 'loaderVersion="[47,)"', 'license="All Rights Reserved"', '',
            '[[mods]]', 'modId="out_of_spec_binding"', f'version="{CURRENT_VERSION}"', 'displayName="Synthetic OUT OF SPEC"', '',
            '[[dependencies.out_of_spec_binding]]', 'modId="forge"', 'mandatory=true', 'versionRange="[47.4.0,48)"', 'ordering="NONE"', 'side="BOTH"', '',
        ])
        with zipfile.ZipFile(addon, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("META-INF/MANIFEST.MF", "Manifest-Version: 1.0\r\nMixinConfigs: out_of_spec_binding.mixins.json,out_of_spec_binding.client.mixins.json\r\n\r\n")
            archive.writestr("META-INF/mods.toml", addon_toml)
            archive.writestr("out_of_spec_binding.mixins.json", '{"required":true,"package":"fixture","mixins":[]}')
            archive.writestr("out_of_spec_binding.client.mixins.json", '{"required":false,"package":"fixture","refmap":"out_of_spec_binding.refmap.json","client":["StandaloneFirstPersonHandsMixin"]}')
            archive.writestr("out_of_spec_binding.refmap.json", '{"mappings":{},"data":{}}')
            archive.writestr("fixture/stage5-merger-check.txt", "standalone; test fixture only\n")
        merged = temp / "merged-stage5-fixture.jar"
        subprocess.run([java, "-cp", str(classes), "Stage11JarMerger", str(base), str(addon), str(merged)],
                       check=True, capture_output=True, text=True, timeout=180)
        with zipfile.ZipFile(merged) as output_zip, zipfile.ZipFile(base) as baseline_zip:
            output_infos = {info.filename: info for info in output_zip.infolist()}
            names = set(output_infos)
            for entry in ("fixture/stage5-merger-check.txt", "out_of_spec_binding.mixins.json",
                          "out_of_spec_binding.client.mixins.json", "out_of_spec_binding.refmap.json"):
                assert entry in names, f"merged archive missing {entry}"
            merged_config = json.loads(output_zip.read("out_of_spec_binding.client.mixins.json").decode("utf-8"))
            assert "StandaloneFirstPersonHandsMixin" in merged_config["client"]
            manifest = output_zip.read("META-INF/MANIFEST.MF").decode("utf-8", errors="replace").replace("\r\n ", "").replace("\n ", "")
            assert "out_of_spec_binding.mixins.json" in manifest and "out_of_spec_binding.client.mixins.json" in manifest
            merged_toml = output_zip.read("META-INF/mods.toml").decode("utf-8", errors="replace")
            assert 'modId="out_of_spec_binding"' in merged_toml
            assert 'modId="punchy"' not in merged_toml.lower()
            signature_re = re.compile(r"META-INF/[^/]+\.(?:SF|RSA|DSA|EC)$", re.I)
            for info in baseline_zip.infolist():
                name = info.filename
                if name.endswith("/") or signature_re.fullmatch(name) or name in {"META-INF/MANIFEST.MF", "META-INF/mods.toml"}:
                    continue
                assert name in names, f"merger dropped baseline entry: {name}"
                out_info = output_infos[name]
                assert out_info.file_size == info.file_size and out_info.CRC == info.CRC, f"baseline entry changed: {name}"
            for name in (
                "io/redspace/ironsspellbooks/spells/ender/MagicArrowSpell.class",
                "io/redspace/ironsspellbooks/spells/fire/FireboltSpell.class",
                "io/redspace/ironsspellbooks/spells/lightning/LightningLanceSpell.class",
            ):
                if name in output_infos:
                    assert output_zip.read(name) == baseline_zip.read(name), f"critical baseline class changed: {name}"
        assert hashlib.sha256(base.read_bytes()).hexdigest() == EXPECTED_BASELINE_SHA256
    print("PASS deep standalone merge fixture: JDK merger compiled; standalone mod and mixins merged; baseline CRC/size and critical classes preserved; no Punchy metadata")
else:
    print("SKIP deep standalone merge fixture; set OUT_OF_SPEC_DEEP_PACKAGE_TEST=1 to run JDK merge integration test")
