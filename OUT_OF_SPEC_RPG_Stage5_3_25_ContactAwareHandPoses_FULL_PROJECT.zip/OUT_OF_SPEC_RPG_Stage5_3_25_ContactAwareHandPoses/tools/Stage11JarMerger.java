import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.jar.Attributes;
import java.util.jar.Manifest;
import java.util.regex.Pattern;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/** JDK-only merger: creates a new Stage 1.1 + Binding Contracts JAR without modifying the baseline. */
public final class Stage11JarMerger {
    private static final String MOD_ID = "out_of_spec_binding";
    private static final String MANIFEST = "META-INF/MANIFEST.MF";
    private static final String MODS_TOML = "META-INF/mods.toml";
    private static final Pattern SIGNATURE = Pattern.compile("META-INF/[^/]+\\.(SF|RSA|DSA|EC)", Pattern.CASE_INSENSITIVE);

    private Stage11JarMerger() {}

    public static void main(String[] args) throws Exception {
        if (args.length != 3) {
            throw new IllegalArgumentException("Usage: Stage11JarMerger <base-jar> <addon-jar> <output-jar>");
        }
        Path base = Path.of(args[0]).toAbsolutePath().normalize();
        Path addon = Path.of(args[1]).toAbsolutePath().normalize();
        Path output = Path.of(args[2]).toAbsolutePath().normalize();
        if (!Files.isRegularFile(base) || !Files.isRegularFile(addon)) {
            throw new IOException("Base JAR and compiled add-on JAR must both exist. base=" + base + "; addon=" + addon);
        }
        if (base.equals(output)) throw new IOException("Refusing to overwrite the Stage 1.1 baseline JAR.");
        Files.createDirectories(output.getParent());

        try (ZipFile bz = new ZipFile(base.toFile()); ZipFile az = new ZipFile(addon.toFile())) {
            byte[] baseTomlBytes = readRequired(bz, MODS_TOML);
            byte[] addonTomlBytes = readRequired(az, MODS_TOML);
            byte[] baseManifestBytes = readRequired(bz, MANIFEST);
            byte[] addonManifestBytes = readRequired(az, MANIFEST);

            String baseToml = new String(baseTomlBytes, StandardCharsets.UTF_8);
            String addonToml = new String(addonTomlBytes, StandardCharsets.UTF_8);
            if (baseToml.contains("modId = \"" + MOD_ID + "\"") || baseToml.contains("modId=\"" + MOD_ID + "\"")) {
                throw new IOException("Base JAR already declares " + MOD_ID + "; refusing to add it twice.");
            }
            String addonSections = extractAddonSections(addonToml);
            byte[] mergedToml = (baseToml.stripTrailing() + "\n\n# Added by OUT OF SPEC RPG Stage 4 Spell Growth merger.\n" + addonSections + "\n")
                    .getBytes(StandardCharsets.UTF_8);
            byte[] mergedManifest = mergeManifest(baseManifestBytes, addonManifestBytes);

            Set<String> baseNames = fileNames(bz);
            Set<String> addonNames = fileNames(az);
            for (String name : addonNames) {
                if (isSignature(name) || name.equals(MANIFEST) || name.equals(MODS_TOML)) continue;
                if (baseNames.contains(name) && !java.util.Arrays.equals(readEntry(bz, bz.getEntry(name)), readEntry(az, az.getEntry(name)))) {
                    throw new IOException("Add-on entry collides with a different Stage 1.1 entry: " + name);
                }
            }

            Set<String> written = new LinkedHashSet<>();
            List<String> added = new ArrayList<>();
            try (ZipOutputStream out = new ZipOutputStream(Files.newOutputStream(output))) {
                out.setLevel(Deflater.BEST_SPEED);
                Enumeration<? extends ZipEntry> entries = bz.entries();
                while (entries.hasMoreElements()) {
                    ZipEntry entry = entries.nextElement();
                    String name = entry.getName();
                    // Any source-JAR signatures are invalid after a merge, so don't carry them forward.
                    if (isSignature(name)) continue;
                    if (!written.add(name)) continue;
                    byte[] payload;
                    if (name.equals(MODS_TOML)) payload = mergedToml;
                    else if (name.equals(MANIFEST)) payload = mergedManifest;
                    else if (entry.isDirectory()) payload = new byte[0];
                    else payload = readEntry(bz, entry);
                    writeEntry(out, entry, payload);
                }
                entries = az.entries();
                while (entries.hasMoreElements()) {
                    ZipEntry entry = entries.nextElement();
                    String name = entry.getName();
                    if (entry.isDirectory() || isSignature(name) || name.equals(MANIFEST) || name.equals(MODS_TOML)) continue;
                    if (!written.add(name)) continue; // Previously verified to be byte-identical.
                    writeEntry(out, entry, readEntry(az, entry));
                    added.add(name);
                }
            }

            // Read-back validation checks every retained baseline entry through the ZIP directory's
            // uncompressed size and CRC, which ZipOutputStream computes from the bytes actually written.
            // The input entries were already fully read once to copy them. Re-decompressing both the
            // 19 MB base and output archive a second time adds minutes on slower machines without
            // increasing meaningful coverage; selected runtime entries are byte-compared in tests.
            try (ZipFile out = new ZipFile(output.toFile())) {
                Set<String> outNames = fileNames(out);
                for (String name : baseNames) {
                    if (isSignature(name)) continue;
                    if (!outNames.contains(name)) throw new IOException("Output is missing baseline entry: " + name);
                    if (!name.equals(MANIFEST) && !name.equals(MODS_TOML)) {
                        ZipEntry sourceEntry = bz.getEntry(name);
                        ZipEntry outputEntry = out.getEntry(name);
                        if (sourceEntry == null || outputEntry == null
                                || sourceEntry.getSize() != outputEntry.getSize()
                                || sourceEntry.getCrc() != outputEntry.getCrc()) {
                            throw new IOException("Unexpected modification to baseline payload (size/CRC mismatch): " + name);
                        }
                    }
                }
                for (String name : added) if (!outNames.contains(name)) throw new IOException("Output is missing add-on entry: " + name);
                String outToml = new String(readRequired(out, MODS_TOML), StandardCharsets.UTF_8);
                if (!outToml.contains("modId=\"" + MOD_ID + "\"") && !outToml.contains("modId = \"" + MOD_ID + "\"")) {
                    throw new IOException("Merged mods.toml does not declare " + MOD_ID);
                }
                String mixinConfigs = new Manifest(new java.io.ByteArrayInputStream(readRequired(out, MANIFEST)))
                        .getMainAttributes().getValue("MixinConfigs");
                System.out.println("Patched JAR: " + output);
                System.out.println("Baseline bytes: " + Files.size(base) + "; patched bytes: " + Files.size(output));
                System.out.println("Baseline entries retained (excluding invalid signatures): " + (baseNames.size() - countSignatures(baseNames)));
                System.out.println("New add-on entries: " + added.size());
                System.out.println("MixinConfigs: " + (mixinConfigs == null ? "(none)" : mixinConfigs));
                System.out.println("Verified: original baseline payloads retained; baseline JAR was not modified.");
            }
        }
    }

    private static byte[] mergeManifest(byte[] baseRaw, byte[] addonRaw) throws IOException {
        Manifest base = new Manifest(new java.io.ByteArrayInputStream(baseRaw));
        Manifest addon = new Manifest(new java.io.ByteArrayInputStream(addonRaw));
        Attributes target = base.getMainAttributes();
        String baseMixins = target.getValue("MixinConfigs");
        String addonMixins = addon.getMainAttributes().getValue("MixinConfigs");
        LinkedHashSet<String> mixins = new LinkedHashSet<>();
        addMixins(mixins, baseMixins);
        addMixins(mixins, addonMixins);
        if (!mixins.isEmpty()) target.putValue("MixinConfigs", String.join(",", mixins));
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        base.write(out);
        return out.toByteArray();
    }

    private static void addMixins(Set<String> set, String raw) {
        if (raw == null) return;
        for (String item : raw.split(",")) if (!item.isBlank()) set.add(item.trim());
    }

    private static String extractAddonSections(String toml) throws IOException {
        if (!toml.contains("modId=\"" + MOD_ID + "\"") && !toml.contains("modId = \"" + MOD_ID + "\"")) {
            throw new IOException("Add-on mods.toml does not declare mod ID " + MOD_ID);
        }
        int start = toml.indexOf("[[mods]]");
        if (start < 0) throw new IOException("Add-on mods.toml has no [[mods]] section");
        return toml.substring(start).strip();
    }

    private static Set<String> fileNames(ZipFile zip) {
        Set<String> result = new LinkedHashSet<>();
        Enumeration<? extends ZipEntry> entries = zip.entries();
        while (entries.hasMoreElements()) {
            ZipEntry entry = entries.nextElement();
            if (!entry.isDirectory()) result.add(entry.getName());
        }
        return result;
    }

    private static byte[] readRequired(ZipFile zip, String name) throws IOException {
        ZipEntry entry = zip.getEntry(name);
        if (entry == null) throw new IOException("Required archive entry missing: " + name);
        return readEntry(zip, entry);
    }

    private static byte[] readEntry(ZipFile zip, ZipEntry entry) throws IOException {
        try (var in = zip.getInputStream(entry)) { return in.readAllBytes(); }
    }

    private static boolean isSignature(String name) { return SIGNATURE.matcher(name).matches(); }
    private static int countSignatures(Set<String> names) { int n = 0; for (String name : names) if (isSignature(name)) n++; return n; }

    private static void writeEntry(ZipOutputStream out, ZipEntry source, byte[] payload) throws IOException {
        ZipEntry target = new ZipEntry(source.getName());
        if (source.getTime() >= 0) target.setTime(source.getTime());
        if (source.getComment() != null) target.setComment(source.getComment());
        if (source.isDirectory() && !target.getName().endsWith("/")) target = new ZipEntry(target.getName() + "/");
        out.putNextEntry(target);
        if (!source.isDirectory()) out.write(payload);
        out.closeEntry();
    }
}
