# Stage 5.3.5 Validation Evidence

- `source_audits.log`: each of the ten source/config checks was run individually in one batch; final marker is `SOURCE_AUDIT_BATCH_EXIT_CODE=0`.
- `model_harnesses.log`: platform-independent Java model harnesses run independently; includes growth catalog, seal-sequence stress, binding judge, real-seal recipes, and projectile formation assertions. Recorded command exits are included per harness.
- `deep_package_validation.log`: `OUT_OF_SPEC_DEEP_PACKAGE_TEST=1 python -u tests/validate_project.py`, exit code 0. This compiles the two JDK-only archive tools and verifies the real Punchy jar is embedded in a synthetic addon then merged with the Stage 1.1 baseline, checking both mod IDs, Mixin configs, Punchy classes/assets/license/icon, and byte-for-byte baseline payload retention.

Important: the one-command `tests/run_judge_tests.sh` exceeded the authoring environment time limit; no reliable final exit code was recorded. This package has NOT been compiled with ForgeGradle here and has NOT been launched in Minecraft. These checks do not prove runtime visual correctness.
